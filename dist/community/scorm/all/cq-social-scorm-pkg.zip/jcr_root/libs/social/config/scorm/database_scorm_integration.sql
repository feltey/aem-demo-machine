-- --------------------------------------------------------------------
-- Scorm Engine v.2013.1
-- Copyright 2003-2013 Rustici Software, LLC.  All Rights Reserved.
--
-- MySQL Server DDL - Communities Integration
-- --------------------------------------------------------------------

-- start_template[client.external.package.id.addkeystotable]
USE `ScormEngineDB` ; 
ALTER TABLE ScormPackage ADD course_id INT NOT NULL;
ALTER TABLE ScormPackage ADD tenant_id VARCHAR(50) NOT NULL;
ALTER TABLE ScormPackage ADD site_id VARCHAR(50) NOT NULL;

ALTER TABLE ScormPackage ADD UNIQUE (course_id, tenant_id, site_id, version_id);
-- end_template


-- start_template[client.external.registration.id.addkeystotable]
ALTER TABLE ScormRegistration ADD course_id INT NOT NULL;
ALTER TABLE ScormRegistration ADD user_name VARCHAR(50) NOT NULL;
ALTER TABLE ScormRegistration ADD tenant_id VARCHAR(50) NOT NULL;
ALTER TABLE ScormRegistration ADD site_id VARCHAR(50) NOT NULL;

ALTER TABLE ScormRegistration ADD UNIQUE (course_id, user_name, tenant_id, site_id, instance_id);
-- end_template

INSERT INTO ScormEngineDbUpdates (update_id) values ('2012.1.VANILLA');
