﻿
$(document).ready(function() {
    LoadSupportPackageDiv();

    $('input[name="regid"]').val(input_regId);
    $('input[name="debug"]').val(input_debugUrl);

    $('#dlPackage').click(DownloadPkg_BtnClick);
    $('#savePackage').click(function() {
        SavePkg_BtnClick($(this), "save");
    });
    $('#sendPackage').click(function() {
        SavePkg_BtnClick($(this), "send");
    });


});

function LoadSupportPackageDiv() {
    var divContent = "<h2>Support Packager</h2>\
        <p>This tool is to help the support people at Rustici Software disagnose problems you may have.  Enter the external registration ID or the launch URL of the course/registration \
        you are having issues with and click one of the buttons to make the package.  Then send the created package to support@scorm.com and we will get to figuring out the problem.\
        Note that optionally selecting to send the entire package (if it is not too huge) will also prove helpful. </p>\
        <input type='radio' name='inputType' checked='checked' id='inputType' onclick='toggleInputType(true);'>Enter the launch URL: <input type='text' id='launchString' name='launchString' style='width:400px;' />\
        <br> <input type='radio' name='inputType'  id='inputType' onclick='toggleInputType(false);'>Enter external registration ID and (optionally) external configuration directly:\
        <div disabled='disabled' id='explicitInputsDiv' style='margin-left: 100px'>registration ID: <input type='text' id='registration' disabled='disabled' name='registration' style='width:200px;' />\
        <br />configuration: (optional) <input type='text' id='configuration' disabled='disabled' name='configuration' style='width:200px;' />\
        </div><br />\
        Enter url of the debug log (if you have one): <input type='text' style='width:300px;' name='debug' />\
        <br /><br />\
        <input type='checkbox' name='sendpackage' /> Include the course package in the support package.\
        <br />\
        <br />\
        Please provide a contact information for getting back to you: <br />\
        Name: <input type='text' name='name' />\
        Company Name: <input type='text' name='company' />\
        Email:<input type='text' name='email' />\
        <br /><br />";
    if (allowPkgSend === true)
        divContent += "If you have a Help Desk (Zendesk) ticket number to associate with this support package, please enter it here:<input type='text' name='zentick' />\
        <br/><input type='checkbox' name='newtick' /> Create a new Zendesk support ticket.\
        <br /><br />";
    divContent += "Problem description (specifics of problem and steps to reproduce are helpful):<br/>\
        <textarea name='desc' style='width:600px;height:100px;'></textarea>\
        <br /><br />\
        <button id='dlPackage'>Download Package</button>\
        <iframe width='1' height='1' id='dlIframe' style='border:none;' src=''></iframe>\
        &nbsp;&nbsp;<button id='savePackage' >Create Local Package</button>";
    if (allowPkgSend === true)
        divContent += "&nbsp;&nbsp;<button id='sendPackage' >Send Package to Rustici Support</button>";
    divContent += "<div id='pkgLinkDiv' style='display:none;'>Your package is here: <a id='pkgLink' href=''></a></div>";
    if (allowPkgSend === false)
        divContent += "<br /><br />\
        <p>Note that adding the argument 'config=[SupportPackagerSendKey]' to the page URL will enable the Send functionality.</p>\
        ";
    $('#supportPackagerWrapper').html(divContent);

}

function DownloadPkg_BtnClick(btnObj) {
    var ajaxdata = $('input[type="text"]').map(function() {
        return $(this).attr('name') + "=" + escape($(this).val());
    }).get().join('&');
    if ($('input[name="sendpackage"]:checked').length > 0)
        ajaxdata += "&sendpackage=true";
    ajaxdata += "&method=dl";
    ajaxdata += "&desc=" + $('textarea[name="desc"]').val();
    ajaxdata += "&time=" + new Date;

    $.ajax({
        type: "POST",
        url: ajaxUrl,
        data: ajaxdata,
        success: function(msg) {
                //alert(msg);
                $('#dlIframe').attr('src', msg);
            } //close success
    });

}

function toggleInputType(launchStringWasEnabled) {

    if (launchStringWasEnabled) {
        $("#launchString").removeAttr('disabled');
        $("#registration").attr('disabled', 'disabled');
        $("#configuration").attr('disabled', 'disabled');
        $("#explicitInputsDiv").attr('disabled', 'disabled');
    } else {
        $("#launchString").attr('disabled', 'disabled');
        $("#registration").removeAttr('disabled');
        $("#configuration").removeAttr('disabled');
        $("#explicitInputsDiv").removeAttr('disabled');
    }
}

function SavePkg_BtnClick(btnObj, method) {
    var ajaxdata = $('input[type="text"]').map(function() {
        return $(this).attr('name') + "=" + escape($(this).val());
    }).get().join('&');
    if ($('input[name="sendpackage"]:checked').length > 0)
        ajaxdata += "&sendpackage=true";
    if ($('input[name="newtick"]:checked').length > 0)
        ajaxdata += "&newtick=true";
    ajaxdata += "&method=" + method;
    ajaxdata += "&desc=" + $('textarea[name="desc"]').val();
    ajaxdata += "&time=" + new Date;

    $.ajax({
        type: "POST",
        url: ajaxUrl,
        data: ajaxdata,
        success: function(msg) {
                $('#pkgLink').attr('href', msg).text(msg);
                $('#pkgLinkDiv').show();
            } //close success
    });

}
