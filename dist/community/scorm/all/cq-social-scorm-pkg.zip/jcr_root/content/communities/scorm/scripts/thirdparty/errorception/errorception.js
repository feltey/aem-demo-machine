var RusticiSoftware_c = onerror;
onerror = function() {
    var a = arguments;
    var b = Array.prototype.slice.call(arguments);
    // firefox often sets 2nd and 3rd args
    // to invalid.
    // errorception won't accept this, so
    // artificially modify 
    if ("" == b[1] || "undefined" == b[1]) {
        b = [b[0], "example.com", "0"];
    }
    // concatenate SCORM Environment Parameters
    if (typeof RusticiSoftware_extRegId != "undefined") {
        b[0] = b[0] + " ExternalRegistrationID: " + RusticiSoftware_extRegId + ".";
    }
    if (typeof RusticiSoftware_extConfigId != "undefined") {
        b[0] = b[0] + " ExternalConfigurationID: " + RusticiSoftware_extConfigId + ".";
    }
    _errs.push(b);
    RusticiSoftware_c && RusticiSoftware_c.apply(this, a);
};
