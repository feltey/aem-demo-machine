function RunTimeApi(_1, _2) {
    this.RunTimeData = null;
    this.LearningObject = null;
    this.Activity = null;
}
RunTimeApi.prototype.GetNavigationRequest = RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.InitializeForDelivery = RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.NeedToCloseOutSession = RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.ResetState = RunTimeApi_DoNothing;
RunTimeApi.prototype.SetDirtyData = RunTimeApi_DoNothing;
RunTimeApi.prototype.WriteHistoryLog = RunTimeApi_DoNothing;
RunTimeApi.prototype.WriteHistoryReturnValue = RunTimeApi_DoNothing;
RunTimeApi.prototype.WriteAuditLog = RunTimeApi_DoNothing;
RunTimeApi.prototype.WriteAuditReturnValue = RunTimeApi_DoNothing;
RunTimeApi.prototype.WriteDetailedLog = RunTimeApi_DoNothing;
RunTimeApi.prototype.CloseOutSession = RunTimeApi_DoNothing;
RunTimeApi.prototype.AccumulateTotalTimeTracked = RunTimeApi_DoNothing;
RunTimeApi.prototype.InitTrackedTimeStart = RunTimeApi_DoNothing;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded = RunTimeApi_DoNothing;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded = RunTimeApi_DoNothing;

function RunTimeApi_GetNavigationRequest() {
    return null;
}

function RunTimeApi_InitializeForDelivery(_3) {
    this.RunTimeData = _3.RunTime;
    this.LearningObject = _3.LearningObject;
    this.Activity = _3;
}

function RunTimeApi_NeedToCloseOutSession() {
    return false;
}

function RunTimeApi_DoNothing() {}

function Sequencer(_4, _5) {
    this.LookAhead = _4;
    this.Activities = _5;
    this.NavigationRequest = null;
    this.SuspendedActivity = null;
    this.CurrentActivity = null;
    this.ExceptionText = "";
}
Sequencer.prototype.OverallSequencingProcess = Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity = Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity = Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start = Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection = Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity = Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText = Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction = Sequencer_GetExitAction;
Sequencer.prototype.EvaluatePossibleNavigationRequests = Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes = Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess = Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;

function Sequencer_OverallSequencingProcess() {
    if (this.NavigationRequest === null) {
        var _6 = this.GetExitAction(this.GetCurrentActivity());
        switch (_6) {
            case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
                this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL, null, "");
                break;
            case (EXIT_ACTION_EXIT_CONFIRMATION):
                Debug.AssertError("EXIT_ACTION_EXIT_CONFIRMATION not supported for AICC");
                break;
            case (EXIT_ACTION_GO_TO_NEXT_SCO):
                Debug.AssertError("EXIT_ACTION_GO_TO_NEXT_SCO not supported for AICC");
                break;
            case (EXIT_ACTION_DISPLAY_MESSAGE):
                Debug.AssertError("EXIT_ACTION_DISPLAY_MESSAGE not supported for AICC");
                break;
            case (EXIT_ACTION_DO_NOTHING):
                Debug.AssertError("EXIT_ACTION_DO_NOTHING not supported for AICC");
                break;
            case (EXIT_ACTION_REFRESH_PAGE):
                Control.RefreshPage();
                break;
        }
    }
    if (this.NavigationRequest === null) {
        this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
    } else {
        if (this.NavigationRequest.Type == NAVIGATION_REQUEST_CHOICE) {
            var _7 = this.Activities.GetActivityFromIdentifier(this.NavigationRequest.TargetActivity);
            if (_7 === null || _7.IsDeliverable() === false) {
                Debug.AssertError("Selected an activity that does not exist or is not deliverable. Activity=" + _7);
            }
            this.CurrentActivity = _7;
            var _8 = this.Activities.SortedActivityList;
            var i;
            for (i = 0; i < _8.length; i++) {
                _8[i].SetActive(false);
            }
            var _a = this.Activities.GetActivityPath(_7, true);
            for (i = 0; i < _a.length; i++) {
                _a[i].SetActive(true);
            }
            if (Control.Package.Properties.ScoLaunchType !== LAUNCH_TYPE_POPUP_AFTER_CLICK && Control.Package.Properties.ScoLaunchType !== LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR) {
                this.ContentDeliveryEnvironmentActivityDataSubProcess();
            }
            Control.DeliverActivity(_7);
        } else {
            if (this.NavigationRequest.Type == NAVIGATION_REQUEST_EXIT) {} else {
                if (this.NavigationRequest.Type == NAVIGATION_REQUEST_SUSPEND_ALL || this.NavigationRequest.Type == NAVIGATION_REQUEST_EXIT_ALL || this.NavigationRequest.Type == NAVIGATION_REQUEST_EXIT_PLAYER) {
                    Control.ExitScormPlayer();
                } else {
                    Debug.AssertError("Only choice navigation requests are supported for AICC., Received type-" + this.NavigationRequest.Type);
                    this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
                }
            }
        }
    }
}

function Sequencer_SetSuspendedActivity(_b) {
    this.SuspendedActivity = _b;
}

function Sequencer_GetSuspendedActivity() {
    return this.SuspendedActivity;
}

function Sequencer_Start() {
    if (this.Activities.GetNumDeliverableActivities() == 1) {
        for (var i = 0; i < this.Activities.SortedActivityList.length; i++) {
            if (this.Activities.SortedActivityList[i].IsDeliverable()) {
                this.SuspendedActivity = null;
                this.CurrentActivity = this.Activities.SortedActivityList[i];
                Control.DeliverActivity(this.Activities.SortedActivityList[i]);
                return;
            }
        }
    } else {
        this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
    }
}

function Sequencer_InitialRandomizationAndSelection() {}

function Sequencer_GetCurrentActivity() {
    return this.CurrentActivity;
}

function Sequencer_GetExceptionText() {
    return this.ExceptionText;
}

function Sequencer_GetExitAction(_d) {
    if (this.Activities.GetNumDeliverableActivities() == 1) {
        return EXIT_ACTION_EXIT_NO_CONFIRMATION;
    } else {
        return EXIT_ACTION_REFRESH_PAGE;
    }
}

function Sequencer_EvaluatePossibleNavigationRequests(_e, _f, _10) {
    var _11 = Control.Package.Properties;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_START].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_RESUME_ALL].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = false;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed = false;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT_ALL].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_SUSPEND_ALL].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON].WillSucceed = true;
    _e[POSSIBLE_NAVIGATION_REQUEST_INDEX_ABANDON_ALL].WillSucceed = true;
    var _12;
    for (var i = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; i < _e.length; i++) {
        _12 = this.Activities.GetActivityFromIdentifier(_e[i].TargetActivityItemIdentifier);
        _e[i].WillSucceed = (_12.IsDeliverable() && _11.EnableChoiceNav === true);
    }
    return _e;
}

function Sequencer_InitializePossibleNavigationRequestAbsolutes(_14) {}

function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess() {
    this.SuspendedActivity = null;
}
