var uploader;
var controlPrefix;

SWFUpload.onload = function() {
    var lblId = document.getElementById("lblUploadImportControlInstanceName");
    controlPrefix = lblId.innerHTML + "_";

    //var txtFileName = document.getElementById(controlPrefix + "txtFileName");
    //txtFileName.value = "";

    uploader = new SWFUpload({
        //minimum_flash_version: "9.0.28",
        minimum_flash_version: "100",
        upload_url: resourceUrl + "UploadPage.aspx",
        flash_url: resourceUrl + "flash/swfupload.swf",
        file_types: "*.zip",
        file_types_description: "SCORM Content Zip Files",
        file_queue_limit: 1,
        file_size_limit: 1000000,
        swfupload_pre_load_handler: swfupload_preload,
        swfupload_load_failed_handler: swfupload_load_failed,
        swfupload_loaded_handler: swfupload_loaded,
        file_queued_handler: file_queued,
        file_queue_error_handler: file_queue_error,
        file_dialog_complete_handler: fileDialogComplete,
        upload_start_handler: upload_start,
        upload_progress_handler: upload_progress,
        upload_error_handler: upload_error,
        upload_success_handler: upload_success,
        upload_complete_handler: upload_complete,
        //button settings
        button_image_url: resourceUrl + "images/browsebutton.jpg",
        button_placeholder_id: controlPrefix + "divButtonPlaceholder",
        button_width: 80,
        button_height: 18,
        //button_text : "Browse...",
        //button_text_style : ".redText { color: #FF0000; }",
        button_text_left_padding: 0,
        button_text_top_padding: 0,
        //button_action : SWFUpload.BUTTON_ACTION.SELECT_FILE,
        //button_disabled : false,
        //button_cursor : SWFUpload.CURSOR.HAND
        //button_window_mode : SWFUpload.WINDOW_MODE.TRANSPARENT
        custom_settings: {
            upload_target: controlPrefix + "pnlUploadStatus"
        },
        debug: false
    });
    AjaxPro.timeoutPeriod = 300000; //5 minutes
}

/**************************************
 * Event Handlers for SWFUpload
 *************************************/

/**
 * Called once the SWFUpload object's initialization is complete.
 */

function swfupload_preload() {
    var lblNotLoaded = document.getElementById(controlPrefix + "lblNotLoaded");
    lblNotLoaded.innerHTML = "Loading...";
    //var swfPanel = document.getElementById(controlPrefix + "swfu_container");
    //swfPanel.style.display = "none";
}

function swfupload_loaded() {
    var pnlInit = document.getElementById(controlPrefix + "pnlInit");
    pnlInit.style.display = "none";
    var swfPanel = document.getElementById(controlPrefix + "swfu_container");
    swfPanel.style.display = "block";
}

function swfupload_load_failed() {
    var pnlInit = document.getElementById(controlPrefix + "pnlInit");
    pnlInit.style.display = "none";
    var htmlPanel = document.getElementById(controlPrefix + "pnlHtmlUpload");
    htmlPanel.style.display = "block";
    var swfPanel = document.getElementById(controlPrefix + "swfu_container");
    swfPanel.style.display = "none";
}

/**
 * Called whenever a file is queued for upload.
 * 
 * file - a file object representing the file that was queued
 */
function file_queued(file) {
    var txtFileName = document.getElementById(controlPrefix + "txtFileName");
    txtFileName.value = file.name;
    var btnUpload = document.getElementById(controlPrefix + "btnUpload");
    btnUpload.disabled = false;
}

/**
 * Called whenever there's a problem attempting to queue a file for upload.
 *
 * file - a file object representing the file that errored out
 * err_code - error code (defined in SWFUpload.QUEUE_ERROR)
 * err_msg - detailed error description
 */
function file_queue_error(file, err_code, err_msg) {
    alert("Error queueing " + file.name +
        ".  Code: " + err_code +
        ", Message: " + err_msg);
}

/**
 * Called when the upload begins for a particular file.
 *
 * file - file object representing the file being uploaded
 */
function upload_start(file) {
    var pnlUploadStatus = document.getElementById(controlPrefix + "pnlUploadStatus");
    pnlUploadStatus.style.display = "block";
    myJsProgressBarHandler.setPercentage('uploadProgress', '0')
}

/**
 * Called periodically during a file upload to indicate the upload progress.
 *
 * file - file object representing the file being uploaded
 * bytes_complete - number of bytes that have been uploaded
 * total_bytes - total size of the file being uploaded
 */
function upload_progress(file, bytes_complete, total_bytes) {
    var percent = Math.floor((bytes_complete / total_bytes) * 100);
    myJsProgressBarHandler.setPercentage('uploadProgress', percent)
    if (percent >= 100) {
        var pnlUploadStatus = document.getElementById(controlPrefix + "pnlUploadStatus");
        pnlUploadStatus.style.display = "none";
        var pnlImportStatus = document.getElementById(controlPrefix + "pnlImportStatus");
        pnlImportStatus.style.display = "block";
        var lblImporting = document.getElementById(controlPrefix + "lblImporting");
        lblImporting.innerHTML = "Upload complete.  Saving file to server (this may take a few minutes for very large files)...";
    }
}

/**
 * Called if an error occurs during or after a file is uploaded.
 * 
 * file - file object representing the file being uploaded
 * err_code - error code (defined in SWFUpload.UPLOAD_ERROR)
 * err_msg - message describing the error...  usually an HTTP error code
 */
function upload_error(file, err_code, err_msg) {
    if (err_msg != "File Cancelled") {
        alert("Error uploading " + file.name + ".  Code: " + err_code + ", Message: " + err_msg);
    }
}
/**
 * Called when an upload is successful.
 *
 * file - file object representing the uploaded file
 * server_data - raw copy of any data returned in the server response to the upload
 */
function upload_success(file, server_data) {
    var lblImporting = document.getElementById(controlPrefix + "lblImporting");
    lblImporting.innerHTML = "File saved.  Importing course (this may take a few minutes for very large files)...";
}
/**
 * Called when an upload completes successfully.
 *
 * file - file object representing the uploaded file
 * server_data - raw copy of any data returned in the server response to the upload
 *
 * This calls the processFile method via AjaxPro
 * processFile(string fileName, bool bShowManifestPathColumn, bool bShowTitleColumn, bool bShowMessageColumn, bool bShowParserWarningsColumn)
 * 
 */
function upload_complete(file, server_data) {
    var lblImporting = document.getElementById(controlPrefix + "lblImporting");
    lblImporting.innerHTML = "Upload complete.  Importing course (this may take a few minutes for very large files)...";

    //This is the call to complete the import and return the HTML to show the ImportResults grid.
    //You can set grid options for the results grid here. See the method comment above for options.

    RusticiSoftware.ScormContentPlayer.WebControls.UploadImportControl2.processFile(file.name, true, true, true, true, process_file_callback);
}

/**
 * This function is called at various points throughout the upload process if
 * debugging is enabled.
 *
 * msg - the debug message
 */
function show_debug(msg) {
    alert("Debug: " + msg);
}



/**************************************
 * Helper Functions
 *************************************/

/**
 * Handles launching the file selection dialog.  Calling selectFile() rather
 * than selectFiles() ensures that only one file may be selected.
 */
function launchFileChooser() {
    //make sure the text box is emyty and the upload button is disabled
    var txtFileName = document.getElementById(controlPrefix + "txtFileName");
    txtFileName.value = "";
    var btnUpload = document.getElementById(controlPrefix + "btnUpload");
    btnUpload.disabled = true;

    //hide the results panel for any previous uploads
    var pnlMessages = document.getElementById(controlPrefix + "pnlMessages");
    pnlMessages.style.display = "none";

    //make sure there's not a file already in the queue
    //note that this will stop any uploads that are in progress
    uploader.cancelUpload()
        //myJsProgressBarHandler.setPercentage('uploadProgress', '0')

    //tell SWFUpload to launch its file chooser
    uploader.selectFile();
}

function fileDialogComplete(numFilesSelected, numFilesQueued) {
    try {
        if (numFilesQueued > 0) {

        }
    } catch (ex) {
        this.debug(ex);
    }
}

/**
 * Begins the file upload.
 */
function startUpload() {
    var btnUpload = document.getElementById(controlPrefix + "btnUpload");
    btnUpload.disabled = true;
    uploader.startUpload();
}

/**
 * Gets called asynchronously after the uploaded file has been imported.
 * Updates the results panel with messages generated by the file import.
 */
function process_file_callback(res) {
    //hide the upload progress bar now that we have the results
    var pnlImportStatus = document.getElementById(controlPrefix + "pnlImportStatus");
    pnlImportStatus.style.display = "none";

    var pnlMessages = document.getElementById(controlPrefix + "pnlMessages");
    pnlMessages.innerHTML = res.value;
    pnlMessages.style.display = "block";
}



/**************************************
 * Helper Functions
 *************************************/

/**
 * Shows/hides the help text.
 */
function toggleUploadImportControlHelp() {
    //var help = document.getElementById('uploadImportControlHelp');
    var help = document.getElementById(controlPrefix + 'pnlHelp');
    var helpLink = document.getElementById(controlPrefix + 'lnkHelp');
    var lblAltHelp = document.getElementById(controlPrefix + 'lblAltHelp');

    if (help.style.display == 'none') {
        help.style.display = 'block';
    } else {
        help.style.display = 'none';
    }

    var temp = helpLink.innerHTML;
    helpLink.innerHTML = lblAltHelp.innerHTML;
    lblAltHelp.innerHTML = temp;
}
