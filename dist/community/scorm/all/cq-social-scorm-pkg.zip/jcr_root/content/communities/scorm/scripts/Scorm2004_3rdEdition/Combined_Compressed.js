var SCORM_TRUE = "true";
var SCORM_FALSE = "false";
var SCORM_UNKNOWN = "unknown";
var SCORM2004_NO_ERROR = "0";
var SCORM2004_GENERAL_EXCEPTION_ERROR = "101";
var SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR = "102";
var SCORM2004_ALREADY_INTIAILIZED_ERROR = "103";
var SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR = "104";
var SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR = "111";
var SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR = "112";
var SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR = "113";
var SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR = "122";
var SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR = "123";
var SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR = "132";
var SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR = "133";
var SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR = "142";
var SCORM2004_COMMIT_AFTER_TERMINATION_ERROR = "143";
var SCORM2004_GENERAL_ARGUMENT_ERROR = "201";
var SCORM2004_GENERAL_GET_FAILURE_ERROR = "301";
var SCORM2004_GENERAL_SET_FAILURE_ERROR = "351";
var SCORM2004_GENERAL_COMMIT_FAILURE_ERROR = "391";
var SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR = "401";
var SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR = "402";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR = "403";
var SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR = "404";
var SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR = "405";
var SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR = "406";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR = "407";
var SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR = "408";
var SCORM2004_ErrorStrings = new Array();
SCORM2004_ErrorStrings[SCORM2004_NO_ERROR] = "No Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_EXCEPTION_ERROR] = "General Exception";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR] = "General Initialization Failure";
SCORM2004_ErrorStrings[SCORM2004_ALREADY_INTIAILIZED_ERROR] = "Already Initialized";
SCORM2004_ErrorStrings[SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR] = "Content Instance Terminated";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR] = "General Termination Failure";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR] = "Termination Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR] = "Termination AFter Termination";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR] = "Retrieve Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR] = "Retrieve Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR] = "Store Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR] = "Store Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR] = "Commit Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_AFTER_TERMINATION_ERROR] = "Commit After Termination";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_ARGUMENT_ERROR] = "General Argument Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_GET_FAILURE_ERROR] = "General Get Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_SET_FAILURE_ERROR] = "General Set Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_COMMIT_FAILURE_ERROR] = "General Commit Failure";
SCORM2004_ErrorStrings[SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR] = "Undefined Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR] = "Unimplemented Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR] = "Data Model Element Value Not Initialized";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR] = "Data Model Element Is Read Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR] = "Data Model Element Is Write Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR] = "Data Model Element Type Mismatch";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR] = "Data Model Element Value Out Of Range";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR] = "Data Model Dependency Not Established";
var SCORM2004_VERSION = "1.0";
var SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN = "comment,location,timestamp";
var SCORM2004_COMMENTS_FROM_LMS_CHILDREN = "comment,location,timestamp";
var SCORM2004_INTERACTIONS_CHILDREN = "id,type,objectives,timestamp,correct_responses,weighting,learner_response,result,latency,description";
var SCORM2004_LEARNER_PREFERENCE_CHILDREN = "audio_level,language,delivery_speed,audio_captioning";
var SCORM2004_OBJECTIVES_CHILDREN = "progress_measure,description,score,id,success_status,completion_status";
var SCORM2004_OBJECTIVES_SCORE_CHILDREN = "scaled,raw,min,max";
var SCORM2004_SCORE_CHILDREN = "scaled,min,max,raw";

function RunTimeApi(_1, _2) {
    this.LearnerId = _1;
    this.LearnerName = _2;
    this.ErrorNumber = SCORM2004_NO_ERROR;
    this.ErrorString = "";
    this.ErrorDiagnostic = "";
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
    this.TrackedSessionTimePrevCall = 0;
    this.SessionTotalTimeReportedPrevCall = 0;
    this.Initialized = false;
    this.Terminated = false;
    this.ScoCalledFinish = false;
    this.CloseOutSessionCalled = false;
    this.RunTimeData = null;
    this.LearningObject = null;
    this.Activity = null;
    this.IsLookAheadSequencerDataDirty = false;
    this.IsLookAheadSequencerRunning = false;
    this.LearnerPrefsArray = new Object();
    if (SSP_ENABLED) {
        this.SSPApi = new SSPApi(MAX_SSP_STORAGE, this);
    }
}
RunTimeApi.prototype.GetNavigationRequest = RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.ResetState = RunTimeApi_ResetState;
RunTimeApi.prototype.InitializeForDelivery = RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.SetDirtyData = RunTimeApi_SetDirtyData;
RunTimeApi.prototype.WriteHistoryLog = RunTimeApi_WriteHistoryLog;
RunTimeApi.prototype.WriteHistoryReturnValue = RunTimeApi_WriteHistoryReturnValue;
RunTimeApi.prototype.WriteAuditLog = RunTimeApi_WriteAuditLog;
RunTimeApi.prototype.WriteAuditReturnValue = RunTimeApi_WriteAuditReturnValue;
RunTimeApi.prototype.WriteDetailedLog = RunTimeApi_WriteDetailedLog;
RunTimeApi.prototype.CloseOutSession = RunTimeApi_CloseOutSession;
RunTimeApi.prototype.NeedToCloseOutSession = RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.AccumulateTotalTimeTracked = RunTimeApi_AccumulateTotalTimeTracked;
RunTimeApi.prototype.InitTrackedTimeStart = RunTimeApi_InitTrackedTimeStart;

function RunTimeApi_GetNavigationRequest() {
    return null;
}

function RunTimeApi_ResetState(_3) {
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
}

function RunTimeApi_InitializeForDelivery(_4) {
    this.RunTimeData = _4.RunTime;
    this.LearningObject = _4.LearningObject;
    this.Activity = _4;
    this.CloseOutSessionCalled = false;
    if (Control.Package.Properties.ResetRunTimeDataTiming == RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND) {
        if (this.RunTimeData.Exit != SCORM_EXIT_SUSPEND && this.RunTimeData.Exit != SCORM_EXIT_LOGOUT) {
            var _5 = {
                ev: "ResetRuntime",
                ai: _4.ItemIdentifier,
                at: _4.LearningObject.Title
            };
            this.WriteHistoryLog("", _5);
            this.RunTimeData.ResetState();
        }
    }
    this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_NONE;
    this.Initialized = false;
    this.Terminated = false;
    this.ScoCalledFinish = false;
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
    this.ErrorNumber = SCORM2004_NO_ERROR;
    this.ErrorString = "";
    this.ErrorDiagnostic = "";
    var _6;
    var _7;
    var _8;
    for (var _9 in this.Activity.ActivityObjectives) {
        _8 = this.Activity.ActivityObjectives[_9];
        _6 = _8.GetIdentifier();
        if (_6 !== null && _6 !== undefined && _6.length > 0) {
            _7 = this.RunTimeData.FindObjectiveWithId(_6);
            if (_7 === null) {
                this.RunTimeData.AddObjective();
                _7 = this.RunTimeData.Objectives[this.RunTimeData.Objectives.length - 1];
                _7.Identifier = _6;
            }
            if (_8.GetProgressStatus(this.Activity, false) === true) {
                if (_8.GetSatisfiedStatus(this.Activity, false) === true) {
                    _7.SuccessStatus = SCORM_STATUS_PASSED;
                } else {
                    _7.SuccessStatus = SCORM_STATUS_FAILED;
                }
            }
            if (_8.GetMeasureStatus(this.Activity, false) === true) {
                _7.ScoreScaled = _8.GetNormalizedMeasure(this.Activity, false);
            }
            _7.SuccessStatusChangedDuringRuntime = false;
            _7.MeasureChangedDuringRuntime = false;
        }
    }
}

function RunTimeApi_SetDirtyData() {
    this.Activity.DataState = DATA_STATE_DIRTY;
}

function RunTimeApi_WriteHistoryLog(_a, _b) {
    HistoryLog.WriteEventDetailed(_a, _b);
}

function RunTimeApi_WriteHistoryReturnValue(_c, _d) {
    HistoryLog.WriteEventDetailedReturnValue(_c, _d);
}

function RunTimeApi_WriteAuditLog(_e) {
    Debug.WriteRteAudit(_e);
}

function RunTimeApi_WriteAuditReturnValue(_f) {
    Debug.WriteRteAuditReturnValue(_f);
}

function RunTimeApi_WriteDetailedLog(str) {
    Debug.WriteRteDetailed(str);
}

function RunTimeApi_NeedToCloseOutSession() {
    return !this.CloseOutSessionCalled;
}
RunTimeApi.prototype.version = SCORM2004_VERSION;
RunTimeApi.prototype.Initialize = RunTimeApi_Initialize;
RunTimeApi.prototype.Terminate = RunTimeApi_Terminate;
RunTimeApi.prototype.GetValue = RunTimeApi_GetValue;
RunTimeApi.prototype.SetValue = RunTimeApi_SetValue;
RunTimeApi.prototype.Commit = RunTimeApi_Commit;
RunTimeApi.prototype.GetLastError = RunTimeApi_GetLastError;
RunTimeApi.prototype.GetErrorString = RunTimeApi_GetErrorString;
RunTimeApi.prototype.GetDiagnostic = RunTimeApi_GetDiagnostic;
RunTimeApi.prototype.RetrieveGetValueData = RunTimeApi_RetrieveGetValueData;
RunTimeApi.prototype.StoreValue = RunTimeApi_StoreValue;
RunTimeApi.prototype.SetErrorState = RunTimeApi_SetErrorState;
RunTimeApi.prototype.ClearErrorState = RunTimeApi_ClearErrorState;
RunTimeApi.prototype.CheckMaxLength = RunTimeApi_CheckMaxLength;
RunTimeApi.prototype.CheckLengthAndWarn = RunTimeApi_CheckLengthAndWarn;
RunTimeApi.prototype.CheckForInitializeError = RunTimeApi_CheckForInitializeError;
RunTimeApi.prototype.CheckForTerminateError = RunTimeApi_CheckForTerminateError;
RunTimeApi.prototype.CheckForGetValueError = RunTimeApi_CheckForGetValueError;
RunTimeApi.prototype.CheckForSetValueError = RunTimeApi_CheckForSetValueError;
RunTimeApi.prototype.CheckForCommitError = RunTimeApi_CheckForCommitError;
RunTimeApi.prototype.CheckCommentsCollectionLength = RunTimeApi_CheckCommentsCollectionLength;
RunTimeApi.prototype.CheckInteractionsCollectionLength = RunTimeApi_CheckInteractionsCollectionLength;
RunTimeApi.prototype.CheckInteractionObjectivesCollectionLength = RunTimeApi_CheckInteractionObjectivesCollectionLength;
RunTimeApi.prototype.CheckInteractionsCorrectResponsesCollectionLength = RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength;
RunTimeApi.prototype.CheckObjectivesCollectionLength = RunTimeApi_CheckObjectivesCollectionLength;
RunTimeApi.prototype.LookAheadSessionClose = RunTimeApi_LookAheadSessionClose;
RunTimeApi.prototype.ValidOtheresponse = RunTimeApi_ValidOtheresponse;
RunTimeApi.prototype.ValidNumericResponse = RunTimeApi_ValidNumericResponse;
RunTimeApi.prototype.ValidSequencingResponse = RunTimeApi_ValidSequencingResponse;
RunTimeApi.prototype.ValidPerformanceResponse = RunTimeApi_ValidPerformanceResponse;
RunTimeApi.prototype.ValidMatchingResponse = RunTimeApi_ValidMatchingResponse;
RunTimeApi.prototype.ValidLikeRTResponse = RunTimeApi_ValidLikeRTResponse;
RunTimeApi.prototype.ValidLongFillInResponse = RunTimeApi_ValidLongFillInResponse;
RunTimeApi.prototype.ValidFillInResponse = RunTimeApi_ValidFillInResponse;
RunTimeApi.prototype.IsValidArrayOfLocalizedStrings = RunTimeApi_IsValidArrayOfLocalizedStrings;
RunTimeApi.prototype.IsValidArrayOfShortIdentifiers = RunTimeApi_IsValidArrayOfShortIdentifiers;
RunTimeApi.prototype.IsValidCommaDelimitedArrayOfShortIdentifiers = RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers;
RunTimeApi.prototype.ValidMultipleChoiceResponse = RunTimeApi_ValidMultipleChoiceResponse;
RunTimeApi.prototype.ValidTrueFalseResponse = RunTimeApi_ValidTrueFalseResponse;
RunTimeApi.prototype.ValidTimeInterval = RunTimeApi_ValidTimeInterval;
RunTimeApi.prototype.ValidTime = RunTimeApi_ValidTime;
RunTimeApi.prototype.ValidReal = RunTimeApi_ValidReal;
RunTimeApi.prototype.IsValidUrn = RunTimeApi_IsValidUrn;
RunTimeApi.prototype.ValidIdentifier = RunTimeApi_ValidIdentifier;
RunTimeApi.prototype.ValidShortIdentifier = RunTimeApi_ValidShortIdentifier;
RunTimeApi.prototype.ValidLongIdentifier = RunTimeApi_ValidLongIdentifier;
RunTimeApi.prototype.ValidLanguage = RunTimeApi_ValidLanguage;
RunTimeApi.prototype.ExtractLanguageDelimiterFromLocalizedString = RunTimeApi_ExtractLanguageDelimiterFromLocalizedString;
RunTimeApi.prototype.ValidLocalizedString = RunTimeApi_ValidLocalizedString;
RunTimeApi.prototype.ValidCharString = RunTimeApi_ValidCharString;
RunTimeApi.prototype.TranslateBooleanIntoCMI = RunTimeApi_TranslateBooleanIntoCMI;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded = RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded = RunTimeApi_RunLookAheadSequencerIfNeeded;
RunTimeApi.prototype.GetCompletionStatus = RunTimeApi_GetCompletionStatus;
RunTimeApi.prototype.GetSuccessStatus = RunTimeApi_GetSuccessStatus;

function RunTimeApi_Initialize(arg) {
    this.WriteAuditLog("`1736`" + arg + "')");
    var _12 = {
        ev: "ApiInitialize"
    };
    if (this.Activity) {
        _12.ai = this.Activity.ItemIdentifier;
    }
    this.WriteHistoryLog("", _12);
    var _13;
    var _14;
    this.ClearErrorState();
    _13 = this.CheckForInitializeError(arg);
    if (!_13) {
        _14 = SCORM_FALSE;
    } else {
        if (this.TrackedStartDate == null) {
            this.TrackedStartDate = new Date();
        }
        if (this.StartSessionTotalTime == null && this.Activity) {
            this.StartSessionTotalTime = this.Activity.RunTime.TotalTime;
        }
        this.TrackedSessionTimePrevCall = 0;
        this.SessionTotalTimeReportedPrevCall = 0;
        this.RunTimeData.Exit = SCORM_EXIT_UNKNOWN;
        this.Initialized = true;
        _14 = SCORM_TRUE;
    }
    Control.ScoLoader.ScoLoaded = true;
    this.WriteAuditReturnValue(_14);
    return _14;
}

function RunTimeApi_Terminate(arg) {
    this.WriteAuditLog("`1746`" + arg + "')");
    var _16;
    var _17;
    var _18;
    this.ClearErrorState();
    _16 = this.CheckForTerminateError(arg);
    var _19 = (_16 && (this.ScoCalledFinish === false));
    if (!_16) {
        _18 = SCORM_FALSE;
    } else {
        var _1a = {
            ev: "ApiTerminate"
        };
        if (this.Activity) {
            _1a.ai = this.Activity.ItemIdentifier;
        }
        this.WriteHistoryLog("", _1a);
        this.CloseOutSession("Terminate");
        this.RunLookAheadSequencerIfNeeded();
        this.Terminated = true;
        this.ScoCalledFinish = true;
        this.SetDirtyData();
        _18 = SCORM_TRUE;
    }
    if (_19 === true && this.RunTimeData.NavRequest != SCORM_RUNTIME_NAV_REQUEST_NONE && Control.IsThereAPendingNavigationRequest() === false) {
        this.WriteDetailedLog("`442`" + Control.IsThereAPendingNavigationRequest());
        window.setTimeout("Control.ScoHasTerminatedSoUnload();", 150);
    }
    Control.SignalTerminated();
    this.WriteAuditReturnValue(_18);
    return _18;
}

function RunTimeApi_GetValue(_1b) {
    this.WriteAuditLog("`1749`" + _1b + "')");
    var _1c;
    var _1d;
    this.ClearErrorState();
    _1b = CleanExternalString(_1b);
    var _1e = RemoveIndiciesFromCmiElement(_1b);
    var _1f = ExtractIndex(_1b);
    var _20 = ExtractSecondaryIndex(_1b);
    _1d = this.CheckForGetValueError(_1b, _1e, _1f, _20);
    if (!_1d) {
        _1c = "";
    } else {
        _1c = this.RetrieveGetValueData(_1b, _1e, _1f, _20);
        if (_1c === null) {
            _1c = "";
        }
    }
    this.WriteAuditReturnValue(_1c);
    return _1c;
}

function RunTimeApi_SetValue(_21, _22) {
    this.WriteAuditLog("`1750`" + _21 + "`1761`" + _22 + "')");
    var _23;
    var _24;
    this.ClearErrorState();
    _21 = CleanExternalString(_21);
    _22 = CleanExternalString(_22);
    var _25 = RemoveIndiciesFromCmiElement(_21);
    var _26 = ExtractIndex(_21);
    var _27 = ExtractSecondaryIndex(_21);
    this.CheckMaxLength(_25, _22);
    _23 = this.CheckForSetValueError(_21, _22, _25, _26, _27);
    if (!_23) {
        _24 = SCORM_FALSE;
    } else {
        this.StoreValue(_21, _22, _25, _26, _27);
        this.SetDirtyData();
        _24 = SCORM_TRUE;
    }
    this.WriteAuditReturnValue(_24);
    return _24;
}

function RunTimeApi_Commit(arg) {
    this.WriteAuditLog("`1753`" + arg + "')");
    var _29;
    var _2a;
    this.ClearErrorState();
    _29 = this.CheckForCommitError(arg);
    if (!_29) {
        _2a = SCORM_FALSE;
    } else {
        _2a = SCORM_TRUE;
    }
    this.RunLookAheadSequencerIfNeeded(true);
    this.WriteAuditReturnValue(_2a);
    return _2a;
}

function RunTimeApi_GetLastError() {
    this.WriteAuditLog("`1727`");
    var _2b = this.ErrorNumber;
    this.WriteAuditReturnValue(_2b);
    return _2b;
}

function RunTimeApi_GetErrorString(arg) {
    this.WriteAuditLog("`1699`" + arg + "')");
    var _2d = "";
    if (arg === "") {
        _2d = "";
    } else {
        if (SCORM2004_ErrorStrings[arg] !== null && SCORM2004_ErrorStrings[arg] !== undefined) {
            _2d = SCORM2004_ErrorStrings[arg];
        }
    }
    this.WriteAuditReturnValue(_2d);
    return _2d;
}

function RunTimeApi_GetDiagnostic(arg) {
    this.WriteAuditLog("`1710`" + arg + "')");
    var _2f;
    if (this.ErrorDiagnostic === "") {
        _2f = "No diagnostic information available";
    } else {
        _2f = this.ErrorDiagnostic;
    }
    this.WriteAuditReturnValue(_2f);
    return _2f;
}

function RunTimeApi_CloseOutSession(_30) {
    this.WriteDetailedLog("`1668`");
    this.WriteDetailedLog("`1755`" + this.RunTimeData.Mode);
    this.WriteDetailedLog("`1752`" + this.RunTimeData.Credit);
    this.WriteDetailedLog("`1453`" + this.RunTimeData.CompletionStatus);
    this.WriteDetailedLog("`1517`" + this.RunTimeData.SuccessStatus);
    this.WriteDetailedLog("`1588`" + this.LearningObject.GetScaledPassingScore());
    this.WriteDetailedLog("`1754`" + this.RunTimeData.ScoreScaled);
    this.WriteDetailedLog("`1549`" + this.LearningObject.CompletionThreshold);
    this.WriteDetailedLog("`1620`" + this.RunTimeData.ProgressMeasure);
    var _31 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime);
    var _32 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime);
    var _33 = _31 + _32;
    var _34 = ConvertHundredthsToIso8601TimeSpan(_33);
    this.WriteDetailedLog("`1728`" + this.RunTimeData.SessionTime + " (" + _31 + "`1733`");
    this.WriteDetailedLog("`1713`" + this.RunTimeData.TotalTime + " (" + _32 + "`1733`");
    this.WriteDetailedLog("`1700`" + _34 + " (" + _33 + "`1733`");
    this.RunTimeData.TotalTime = _34;
    this.RunTimeData.SessionTime = "";
    this.AccumulateTotalTimeTracked();
    this.WriteDetailedLog("`1538`" + this.RunTimeData.TotalTimeTracked);
    if (Control.IsThereAPendingNavigationRequest()) {
        if (Control.PendingNavigationRequest.Type == NAVIGATION_REQUEST_SUSPEND_ALL) {
            this.WriteDetailedLog("`913`");
            this.RunTimeData.Exit = SCORM_EXIT_SUSPEND;
        }
    } else {
        if (this.RunTimeData.NavRequest == SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL) {
            this.WriteDetailedLog("`931`");
            this.RunTimeData.Exit = SCORM_EXIT_SUSPEND;
        }
    }
    if (this.RunTimeData.Exit == SCORM_EXIT_SUSPEND || this.RunTimeData.Exit == SCORM_EXIT_LOGOUT) {
        this.WriteDetailedLog("`1606`");
        this.RunTimeData.Entry = SCORM_ENTRY_RESUME;
    }
    var _35 = this.GetCompletionStatus();
    if (_35 != this.RunTimeData.CompletionStatus) {
        this.RunTimeData.CompletionStatus = _35;
        this.RunTimeData.CompletionStatusChangedDuringRuntime = true;
    }
    var _36 = this.GetSuccessStatus();
    if (_36 != this.RunTimeData.SuccessStatus) {
        this.RunTimeData.SuccessStatus = this.GetSuccessStatus();
        this.RunTimeData.SuccessStatusChangedDuringRuntime = true;
    }
    if (this.RunTimeData.Exit == SCORM_EXIT_TIME_OUT) {
        this.WriteDetailedLog("`1481`");
        this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_EXITALL;
    } else {
        if (this.RunTimeData.Exit == SCORM_EXIT_LOGOUT) {
            if (Control.Package.Properties.LogoutCausesPlayerExit === true) {
                this.WriteDetailedLog("`1341`");
                this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL;
            } else {
                this.WriteDetailedLog("`341`");
                this.Activity.SetSuspended(true);
            }
        } else {
            if (this.RunTimeData.Exit == SCORM_EXIT_SUSPEND) {
                this.WriteDetailedLog("`1621`");
                this.Activity.SetSuspended(true);
            }
        }
    }
    this.CloseOutSessionCalled = true;
    return true;
}

function RunTimeApi_LookAheadSessionClose() {
    if (this.RunTimeData != null) {
        this.RunTimeData.LookAheadCompletionStatus = this.GetCompletionStatus();
        this.RunTimeData.LookAheadSuccessStatus = this.GetSuccessStatus();
    }
}

function RunTimeApi_RetrieveGetValueData(_37, _38, _39, _3a) {
    this.WriteDetailedLog("`1576`" + _37 + ", " + _38 + ", " + _39 + ", " + _3a + ") ");
    var _3b;
    var _3c = "";
    var _3d;
    if (_37.indexOf("adl.nav.request_valid.choice") === 0) {
        this.WriteDetailedLog("`1285`");
        _3b = ((_37.indexOf("{") >= 0) ? _37.substring(_37.indexOf("{")) : "");
        if (!Control.IsTargetValid(_3b)) {
            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The target of the choice request (" + _3b + ") is invalid.");
            return SCORM_FALSE;
        }
        _3c = Control.IsChoiceRequestValid(_3b);
        if (_3c == false) {
            var _3e = Control.ParseTargetStringIntoActivity(_3b);
            var _3f = Control.FindPossibleChoiceRequestForActivity(_3e);
            this.WriteDetailedLog(_3f.GetExceptionReason());
        }
        _3c = this.TranslateBooleanIntoCMI(_3c);
        return _3c;
    }
    switch (_38) {
        case "cmi._version":
            this.WriteDetailedLog("`1510`");
            _3c = SCORM2004_VERSION;
            break;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1161`");
            _3c = SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN;
            break;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            _3c = this.RunTimeData.Comments.length;
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1212`");
            _3c = this.RunTimeData.Comments[_39].GetCommentValue();
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1186`");
            _3c = this.RunTimeData.Comments[_39].Location;
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1163`");
            _3c = this.RunTimeData.Comments[_39].Timestamp;
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            _3c = SCORM2004_COMMENTS_FROM_LMS_CHILDREN;
            break;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            _3c = this.RunTimeData.CommentsFromLMS.length;
            break;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1289`");
            _3c = this.RunTimeData.CommentsFromLMS[_39].GetCommentValue();
            break;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1268`");
            _3c = this.RunTimeData.CommentsFromLMS[_39].Location;
            break;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1249`");
            _3c = this.RunTimeData.CommentsFromLMS[_39].Timestamp;
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            _3c = this.GetCompletionStatus();
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1370`");
            _3c = this.LearningObject.CompletionThreshold;
            break;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            _3c = this.RunTimeData.Credit;
            break;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            _3c = this.RunTimeData.Entry;
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            Debug.AssertError("Exit element is write only");
            _3c = "";
            break;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            _3c = SCORM2004_INTERACTIONS_CHILDREN;
            break;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            _3c = this.RunTimeData.Interactions.length;
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1474`");
            _3c = this.RunTimeData.Interactions[_39].Id;
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1430`");
            _3c = this.RunTimeData.Interactions[_39].Type;
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1189`");
            _3c = this.RunTimeData.Interactions[_39].Objectives.length;
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1270`");
            _3c = this.RunTimeData.Interactions[_39].Objectives[_3a];
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1334`");
            _3c = this.RunTimeData.Interactions[_39].Timestamp;
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`1059`");
            _3c = this.RunTimeData.Interactions[_39].CorrectResponses.length;
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`1024`");
            _3c = this.RunTimeData.Interactions[_39].CorrectResponses[_3a];
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1335`");
            _3c = this.RunTimeData.Interactions[_39].Weighting;
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1214`");
            _3c = this.RunTimeData.Interactions[_39].LearnerResponse;
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1392`");
            _3c = this.RunTimeData.Interactions[_39].Result;
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1372`");
            _3c = this.RunTimeData.Interactions[_39].Latency;
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1301`");
            _3c = this.RunTimeData.Interactions[_39].Description;
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            _3c = this.LearningObject.DataFromLms;
            break;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1569`");
            _3c = LearnerId;
            break;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1528`");
            _3c = LearnerName;
            break;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            _3c = SCORM2004_LEARNER_PREFERENCE_CHILDREN;
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1553`");
            _3c = this.RunTimeData.AudioLevel;
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1601`");
            _3c = this.RunTimeData.LanguagePreference;
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1492`");
            _3c = this.RunTimeData.DeliverySpeed;
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1445`");
            _3c = this.RunTimeData.AudioCaptioning;
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            _3c = this.RunTimeData.Location;
            var _40 = {
                ev: "Get",
                k: "location",
                v: (_3c == null ? "<null>" : _3c)
            };
            if (this.Activity) {
                _40.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _40);
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1446`");
            _3c = "";
            if (this.LearningObject.SequencingData !== null && this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl === true) {
                _3c = this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationLimit;
            }
            break;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            _3c = this.RunTimeData.Mode;
            break;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            _3c = SCORM2004_OBJECTIVES_CHILDREN;
            break;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            _3c = this.RunTimeData.Objectives.length;
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1515`");
            _3c = this.RunTimeData.Objectives[_39].Identifier;
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1271`");
            _3c = SCORM2004_OBJECTIVES_SCORE_CHILDREN;
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1317`");
            _3c = this.RunTimeData.Objectives[_39].ScoreScaled;
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1376`");
            _3c = this.RunTimeData.Objectives[_39].ScoreRaw;
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1375`");
            _3c = this.RunTimeData.Objectives[_39].ScoreMin;
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1374`");
            _3c = this.RunTimeData.Objectives[_39].ScoreMax;
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1291`");
            _3c = this.RunTimeData.Objectives[_39].SuccessStatus;
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1235`");
            _3c = this.RunTimeData.Objectives[_39].CompletionStatus;
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1252`");
            _3c = this.RunTimeData.Objectives[_39].ProgressMeasure;
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1336`");
            _3c = this.RunTimeData.Objectives[_39].Description;
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1448`");
            _3c = this.RunTimeData.ProgressMeasure;
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1377`");
            _3c = this.LearningObject.GetScaledPassingScore();
            if (_3c === null) {
                _3c = "";
            }
            break;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            _3c = SCORM2004_SCORE_CHILDREN;
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            _3c = this.RunTimeData.ScoreScaled;
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            _3c = this.RunTimeData.ScoreRaw;
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            _3c = this.RunTimeData.ScoreMax;
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            _3c = this.RunTimeData.ScoreMin;
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1531`");
            _3c = "";
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1494`");
            _3c = this.GetSuccessStatus();
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1535`");
            _3c = this.RunTimeData.SuspendData;
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1433`");
            _3c = this.LearningObject.TimeLimitAction;
            break;
        case "cmi.total_time":
            this.WriteDetailedLog("`1574`");
            _3c = this.RunTimeData.TotalTime;
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1471`");
            _3c = this.RunTimeData.NavRequest;
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1180`");
            _3c = Control.IsContinueRequestValid();
            if (_3c == false) {
                _3d = Control.GetPossibleContinueRequest();
                this.WriteDetailedLog(_3d.GetExceptionReason());
            }
            _3c = this.TranslateBooleanIntoCMI(_3c);
            break;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1181`");
            _3c = Control.IsPreviousRequestValid();
            if (_3c == false) {
                _3d = Control.GetPossiblePreviousRequest();
                this.WriteDetailedLog(_3d.GetExceptionReason());
            }
            _3c = this.TranslateBooleanIntoCMI(_3c);
            break;
        case "adl.nav.request_valid.choice":
            this.WriteDetailedLog("`1331`");
            Debug.AssertError("Entered invalid case in RunTimeApi_RetrieveGetValueData");
            break;
        default:
            if (_38.indexOf("ssp") === 0 && SSP_ENABLED) {
                _3c = this.SSPApi.RetrieveGetValueData(_37, _38, _39, _3a);
            } else {
                Debug.AssertError("Entered default case in RunTimeApi_RetrieveGetValueData");
                _3c = "";
            }
            break;
    }
    return _3c;
}

function RunTimeApi_StoreValue(_41, _42, _43, _44, _45) {
    this.WriteDetailedLog("`1738`" + _41 + ", " + _42 + ", " + _43 + ", " + _44 + ", " + _45 + ") ");
    var _46 = true;
    var _47;
    switch (_43) {
        case "cmi._version":
            this.WriteDetailedLog("`1599`");
            break;
        case "cmi.comments_from_learner._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._children");
            _46 = false;
            break;
        case "cmi.comments_from_learner._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._count");
            _46 = false;
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1231`");
            this.CheckCommentsCollectionLength(_44);
            this.RunTimeData.Comments[_44].SetCommentValue(_42);
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1184`");
            this.CheckCommentsCollectionLength(_44);
            this.RunTimeData.Comments[_44].Location = _42;
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1160`");
            this.CheckCommentsCollectionLength(_44);
            this.RunTimeData.Comments[_44].Timestamp = _42;
            break;
        case "cmi.comments_from_lms._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._children");
            _46 = false;
            break;
        case "cmi.comments_from_lms._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._count");
            _46 = false;
            break;
        case "cmi.comments_from_lms.n.comment":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.comment");
            _46 = false;
            break;
        case "cmi.comments_from_lms.n.location":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.location");
            _46 = false;
            break;
        case "cmi.comments_from_lms.n.timestamp":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.timestamp");
            _46 = false;
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            _47 = {
                ev: "Set",
                k: "completion",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.CompletionStatus, _42);
            this.RunTimeData.CompletionStatus = _42;
            this.RunTimeData.CompletionStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.completion_threshold":
            Debug.AssertError("ERROR - Element is Read Only, cmi.completion_threshold");
            _46 = false;
            break;
        case "cmi.credit":
            Debug.AssertError("ERROR - Element is Read Only, cmi.credit");
            _46 = false;
            break;
        case "cmi.entry":
            Debug.AssertError("ERROR - Element is Read Only, cmi.entry");
            _46 = false;
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            _47 = {
                ev: "Set",
                k: "cmi.exit",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.RunTimeData.Exit = _42;
            break;
        case "cmi.interactions._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._children");
            _46 = false;
            break;
        case "cmi.interactions._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._count");
            _46 = false;
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1474`");
            _47 = {
                ev: "Set",
                k: "interactions id",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Id = _42;
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1430`");
            _47 = {
                ev: "Set",
                k: "interactions type",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Type = _42;
            break;
        case "cmi.interactions.n.objectives._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.objectives._count");
            _46 = false;
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1270`");
            _47 = {
                ev: "Set",
                k: "interactions objectives id",
                i: _44,
                si: _45,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionObjectivesCollectionLength(_44, _45);
            this.RunTimeData.Interactions[_44].Objectives[_45] = _42;
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1334`");
            _47 = {
                ev: "Set",
                k: "interactions timestamp",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Timestamp = _42;
            break;
        case "cmi.interactions.n.correct_responses._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.correct_responses._count");
            _46 = false;
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`1024`");
            _47 = {
                ev: "Set",
                k: "interactions correct_responses pattern",
                i: _44,
                si: _45,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCorrectResponsesCollectionLength(_44, _45);
            this.RunTimeData.Interactions[_44].CorrectResponses[_45] = _42;
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1335`");
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Weighting = _42;
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1214`");
            _47 = {
                ev: "Set",
                k: "interactions learner_response",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].LearnerResponse = _42;
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1392`");
            _47 = {
                ev: "Set",
                k: "interactions result",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Result = _42;
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1372`");
            _47 = {
                ev: "Set",
                k: "interactions latency",
                i: _44,
                vh: ConvertIso8601TimeSpanToHundredths(_42)
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Latency = _42;
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1301`");
            _47 = {
                ev: "Set",
                k: "interactions description",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_44].Id) {
                _47.intid = this.RunTimeData.Interactions[_44].Id;
            }
            this.WriteHistoryLog("", _47);
            this.CheckInteractionsCollectionLength(_44);
            this.RunTimeData.Interactions[_44].Description = _42;
            break;
        case "cmi.launch_data":
            Debug.AssertError("ERROR - Element is Read Only, cmi.launch_data");
            _46 = false;
            break;
        case "cmi.learner_id":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_id");
            _46 = false;
            break;
        case "cmi.learner_name":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_name");
            _46 = false;
            break;
        case "cmi.learner_preference._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_preference._children");
            _46 = false;
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1527`");
            this.RunTimeData.AudioLevel = _42;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.AudioLevel = _42;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1601`");
            this.RunTimeData.LanguagePreference = _42;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.LanguagePreference = _42;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1511`");
            this.RunTimeData.DeliverySpeed = _42;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.DeliverySpeed = _42;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1445`");
            this.RunTimeData.AudioCaptioning = _42;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.AudioCaptioning = _42;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            this.RunTimeData.Location = _42;
            break;
        case "cmi.max_time_allowed":
            Debug.AssertError("ERROR - Element is Read Only, cmi.max_time_allowed");
            _46 = false;
            break;
        case "cmi.mode":
            Debug.AssertError("ERROR - Element is Read Only, cmi.mode");
            _46 = false;
            break;
        case "cmi.objectives._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._children");
            _46 = false;
            break;
        case "cmi.objectives._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._count");
            _46 = false;
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1515`");
            _47 = {
                ev: "Set",
                k: "objectives id",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckObjectivesCollectionLength(_44);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].Identifier, _42);
            this.RunTimeData.Objectives[_44].Identifier = _42;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.score._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives.n.score._children");
            _46 = false;
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1318`");
            this.CheckObjectivesCollectionLength(_44);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreScaled, _42);
            this.RunTimeData.Objectives[_44].ScoreScaled = _42;
            this.RunTimeData.Objectives[_44].MeasureChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1376`");
            this.CheckObjectivesCollectionLength(_44);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreRaw, _42);
            }
            this.RunTimeData.Objectives[_44].ScoreRaw = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1375`");
            this.CheckObjectivesCollectionLength(_44);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreMin, _42);
            }
            this.RunTimeData.Objectives[_44].ScoreMin = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1374`");
            this.CheckObjectivesCollectionLength(_44);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ScoreMax, _42);
            }
            this.RunTimeData.Objectives[_44].ScoreMax = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1291`");
            _47 = {
                ev: "Set",
                k: "objectives success",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Objectives[_44].Identifier) {
                _47.intid = this.RunTimeData.Objectives[_44].Identifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckObjectivesCollectionLength(_44);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].SuccessStatus, _42);
            this.RunTimeData.Objectives[_44].SuccessStatus = _42;
            this.RunTimeData.Objectives[_44].SuccessStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1235`");
            _47 = {
                ev: "Set",
                k: "objectives completion",
                i: _44,
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Objectives[_44].Identifier) {
                _47.intid = this.RunTimeData.Objectives[_44].Identifier;
            }
            this.WriteHistoryLog("", _47);
            this.CheckObjectivesCollectionLength(_44);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].CompletionStatus, _42);
            this.RunTimeData.Objectives[_44].CompletionStatus = _42;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1252`");
            this.CheckObjectivesCollectionLength(_44);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_44].ProgressMeasure, _42);
            this.RunTimeData.Objectives[_44].ProgressMeasure = _42;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1336`");
            this.CheckObjectivesCollectionLength(_44);
            this.RunTimeData.Objectives[_44].Description = _42;
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            this.RunTimeData.ProgressMeasure = _42;
            break;
        case "cmi.scaled_passing_score":
            Debug.AssertError("ERROR - Element is Read Only, cmi.scaled_passing_score");
            _46 = false;
            break;
        case "cmi.score._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.score._children");
            _46 = false;
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            _47 = {
                ev: "Set",
                k: "score.scaled",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreScaled, _42);
            this.RunTimeData.ScoreScaled = _42;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            _47 = {
                ev: "Set",
                k: "score.raw",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreRaw, _42);
            }
            this.RunTimeData.ScoreRaw = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            _47 = {
                ev: "Set",
                k: "score.max",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMax, _42);
            }
            this.RunTimeData.ScoreMax = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            _47 = {
                ev: "Set",
                k: "score.min",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMin, _42);
            }
            this.RunTimeData.ScoreMin = _42;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            _47 = {
                ev: "Set",
                k: "session time",
                vh: ConvertIso8601TimeSpanToHundredths(_42)
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.RunTimeData.SessionTime = _42;
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            _47 = {
                ev: "Set",
                k: "success",
                v: _42
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _47);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.SuccessStatus, _42);
            this.RunTimeData.SuccessStatus = _42;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            this.RunTimeData.SuspendData = _42;
            break;
        case "cmi.time_limit_action":
            Debug.AssertError("ERROR - Element is Read Only, cmi.time_limit_action");
            _46 = false;
            break;
        case "cmi.total_time":
            Debug.AssertError("ERROR - Element is Read Only, cmi.total_time");
            _46 = false;
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            _47 = {
                ev: "Set",
                k: "nav.request"
            };
            if (this.Activity) {
                _47.ai = this.Activity.ItemIdentifier;
            }
            var _48 = _42.match(/target\s*=\s*(\S+)\s*}\s*choice/);
            if (_48) {
                _47.tai = _48[1];
                _47.tat = Control.Activities.GetActivityFromIdentifier(_48[1]).LearningObject.Title;
                _47.v = "choice";
            } else {
                _47.v = _42;
            }
            this.WriteHistoryLog("", _47);
            this.RunTimeData.NavRequest = _42;
            break;
        case "adl.nav.request_valid.continue":
            Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.continue");
            break;
        case "adl.nav.request_valid.previous":
            Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.previous");
            break;
        case "adl.nav.request_valid.choice":
            Debug.AssertError("ERROR - Should never get here...handled above - Element is Read Only, adl.nav.request_valid.choice");
            break;
        default:
            if (_43.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.StoreValue(_41, _42, _43, _44, _45);
                }
            }
            Debug.AssertError("ERROR reached default case in RunTimeApi_StoreValue");
            returnData = "";
            break;
    }
    return _46;
}

function RunTimeApi_CheckCommentsCollectionLength(_49) {
    if (this.RunTimeData.Comments.length <= _49) {
        this.WriteDetailedLog("`1130`" + _49);
        this.RunTimeData.Comments[_49] = new ActivityRunTimeComment(null, null, null, null, null);
    }
}

function RunTimeApi_CheckInteractionsCollectionLength(_4a) {
    if (this.RunTimeData.Interactions.length <= _4a) {
        this.WriteDetailedLog("`1313`" + _4a);
        this.RunTimeData.Interactions[_4a] = new ActivityRunTimeInteraction(null, null, null, null, null, null, null, null, null, new Array(), new Array());
    }
}

function RunTimeApi_CheckInteractionObjectivesCollectionLength(_4b, _4c) {
    if (this.RunTimeData.Interactions[_4b].Objectives.length <= _4c) {
        this.WriteDetailedLog("`1113`" + _4c);
        this.RunTimeData.Interactions[_4b].Objectives[_4c] = null;
    }
}

function RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength(_4d, _4e) {
    if (this.RunTimeData.Interactions[_4d].CorrectResponses.length <= _4e) {
        this.WriteDetailedLog("`990`" + _4e);
        this.RunTimeData.Interactions[_4d].CorrectResponses[_4e] = null;
    }
}

function RunTimeApi_CheckObjectivesCollectionLength(_4f) {
    if (this.RunTimeData.Objectives.length <= _4f) {
        this.WriteDetailedLog("`1354`" + _4f);
        this.RunTimeData.Objectives[_4f] = new ActivityRunTimeObjective(null, "unknown", "unknown", null, null, null, null, null, null);
    }
}

function RunTimeApi_SetErrorState(_50, _51) {
    if (_50 != SCORM2004_NO_ERROR) {
        this.WriteDetailedLog("`1292`" + _50 + " - " + _51);
    }
    this.ErrorNumber = _50;
    this.ErrorString = SCORM2004_ErrorStrings[_50];
    this.ErrorDiagnostic = _51;
}

function RunTimeApi_ClearErrorState() {
    this.SetErrorState(SCORM2004_NO_ERROR, "");
}

function RunTimeApi_CheckForInitializeError(arg) {
    this.WriteDetailedLog("`1422`");
    if (this.Initialized) {
        this.SetErrorState(SCORM2004_ALREADY_INTIAILIZED_ERROR, "Initialize has already been called and may only be called once per session.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR, "Initialize cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Initialize must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForTerminateError(arg) {
    this.WriteDetailedLog("`1442`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR, "Terminate cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR, "Terminate cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Terminate must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForCommitError(arg) {
    this.WriteDetailedLog("`1506`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR, "Commit cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_COMMIT_AFTER_TERMINATION_ERROR, "Commit cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Commit must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckMaxLength(_55, _56) {
    switch (_55) {
        case "cmi.comments_from_learner.n.comment":
            this.CheckLengthAndWarn(_56, 4250);
            break;
        case "cmi.comments_from_learner.n.location":
            this.CheckLengthAndWarn(_56, 250);
            break;
        case "cmi.interactions.n.id":
            this.CheckLengthAndWarn(_56, 4000);
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.CheckLengthAndWarn(_56, 4000);
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.CheckLengthAndWarn(_56, 7800);
            break;
        case "cmi.interactions.n.learner_response":
            this.CheckLengthAndWarn(_56, 7800);
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.CheckLengthAndWarn(_56, 500);
            break;
        case "cmi.learner_preference.language":
            this.CheckLengthAndWarn(_56, 250);
            break;
        case "cmi.location":
            this.CheckLengthAndWarn(_56, 1000);
            break;
        case "cmi.objectives.n.id":
            this.CheckLengthAndWarn(_56, 4000);
            break;
        case "cmi.objectives.n.description":
            this.CheckLengthAndWarn(_56, 500);
            break;
        case "cmi.suspend_data":
            this.CheckLengthAndWarn(_56, Control.Package.Properties.SuspendDataMaxLength);
            break;
        default:
            break;
    }
    return;
}

function RunTimeApi_CheckLengthAndWarn(str, len) {
    if (str.length > len) {
        this.SetErrorState(SCORM2004_NO_ERROR, "The string was trimmed to fit withing the SPM of " + len + " characters.");
    }
    return;
}

function RunTimeApi_CheckForGetValueError(_59, _5a, _5b, _5c) {
    this.WriteDetailedLog("`1463`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR, "GetValue cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR, "GetValue cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (_59.length === 0) {
        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The data model element for GetValue was not specified.");
        return false;
    }
    if (_5b !== "") {
        if (_5a.indexOf("cmi.comments_from_learner") >= 0) {
            if (_5b >= this.RunTimeData.Comments.length) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Comments From Learner collection does not have an element at index " + _5b + ", the current element count is " + this.RunTimeData.Comments.length + ".");
                return false;
            }
        } else {
            if (_5a.indexOf("cmi.comments_from_lms") >= 0) {
                if (_5b >= this.RunTimeData.CommentsFromLMS.length) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Comments From LMS collection does not have an element at index " + _5b + ", the current element count is " + this.RunTimeData.CommentsFromLMS.length + ".");
                    return false;
                }
            } else {
                if (_5a.indexOf("cmi.objectives") >= 0) {
                    if (_5b >= this.RunTimeData.Objectives.length) {
                        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Objectives collection does not have an element at index " + _5b + ", the current element count is " + this.RunTimeData.Objectives.length + ".");
                        return false;
                    }
                } else {
                    if (_5a.indexOf("cmi.interactions") >= 0) {
                        if (_5b >= this.RunTimeData.Interactions.length) {
                            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Interactions collection does not have an element at index " + _5b + ", the current element count is " + this.RunTimeData.Interactions.length + ".");
                            return false;
                        }
                        if (_5a.indexOf("cmi.interactions.n.correct_responses") >= 0) {
                            if (_5c !== "") {
                                if (_5c >= this.RunTimeData.Interactions[_5b].CorrectResponses.length) {
                                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Correct Responses collection for Interaction #" + _5b + " does not have an element at index " + _5c + ", the current element count is " + this.RunTimeData.Interactions[_5b].CorrectResponses.length + ".");
                                    return false;
                                }
                            }
                        } else {
                            if (_5a.indexOf("cmi.interactions.n.objectives") >= 0) {
                                if (_5c !== "") {
                                    if (_5c >= this.RunTimeData.Interactions[_5b].Objectives.length) {
                                        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Objectives collection for Interaction #" + _5b + " does not have an element at index " + _5c + ", the current element count is " + this.RunTimeData.Interactions[_5b].Objectives.length + ".");
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    switch (_5a) {
        case "cmi._version":
            this.WriteDetailedLog("`1618`");
            break;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1187`");
            break;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1162`");
            if (this.RunTimeData.Comments[_5b].Comment === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Comment field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1134`");
            if (this.RunTimeData.Comments[_5b].Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1119`");
            if (this.RunTimeData.Comments[_5b].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The TimeStamp field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            break;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            break;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1248`");
            if (this.RunTimeData.CommentsFromLMS[_5b].Comment === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Comment field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1233`");
            if (this.RunTimeData.CommentsFromLMS[_5b].Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1213`");
            if (this.RunTimeData.CommentsFromLMS[_5b].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Timestamp field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1371`");
            if (this.LearningObject.CompletionThreshold === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The completion threshold for this SCO was not specificed.");
                return false;
            }
            break;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            break;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The Exit data model element is write-only.");
            return false;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            break;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1427`");
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1391`");
            if (this.RunTimeData.Interactions[_5b].Type === null || this.RunTimeData.Interactions[_5b].Type === "") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Type field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1135`");
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1188`");
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1302`");
            if (this.RunTimeData.Interactions[_5b].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Time Stamp field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`999`");
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`972`");
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1303`");
            if (this.RunTimeData.Interactions[_5b].Weighting === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Weighting field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1191`");
            if (this.RunTimeData.Interactions[_5b].LearnerResponse === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Learner Response field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1355`");
            if (this.RunTimeData.Interactions[_5b].Result === null || this.RunTimeData.Interactions[_5b].Result === "") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Result field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1333`");
            if (this.RunTimeData.Interactions[_5b].Latency === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Latency field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1269`");
            if (this.RunTimeData.Interactions[_5b].Description === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Description field has not been initialized for the element at index " + _5b);
                return false;
            }
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            if (this.LearningObject.DataFromLms === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Launch Data field was not specified for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1570`");
            break;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1529`");
            break;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1190`");
            if (this.RunTimeData.AudioLevel === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Audio Level field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1250`");
            if (this.RunTimeData.LanguagePreference === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Language Preference field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1120`");
            if (this.RunTimeData.DeliverySpeed === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Delivery Speed field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1079`");
            if (this.RunTimeData.AudioCaptioning === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Audio Captioning field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            if (this.RunTimeData.Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1447`");
            if (this.LearningObject.SequencingData === null || this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl === false) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Time Allowed field was not specified in the manifest for this SCO.");
                return false;
            }
            break;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            break;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            break;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1477`");
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1236`");
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1290`");
            if (this.RunTimeData.Objectives[_5b].ScoreScaled === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Score field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1339`");
            if (this.RunTimeData.Objectives[_5b].ScoreRaw === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Raw Score field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1338`");
            if (this.RunTimeData.Objectives[_5b].ScoreMin === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Min Score field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1337`");
            if (this.RunTimeData.Objectives[_5b].ScoreMax === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Score field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1251`");
            if (this.RunTimeData.Objectives[_5b].SuccessStatus === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The SuccessStatus field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1192`");
            if (this.RunTimeData.Objectives[_5b].CompletionStatus === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The CompletionStatus field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1216`");
            if (this.RunTimeData.Objectives[_5b].ProgressMeasure === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The ProgressMeasure field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1304`");
            if (this.RunTimeData.Objectives[_5b].Description === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Description field has not been initialized for the objective at index " + _5b);
                return false;
            }
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            if (this.RunTimeData.ProgressMeasure === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Progress Measure field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1378`");
            if (this.LearningObject.GetScaledPassingScore() === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Passing Score field was not specificed for this SCO.");
                return false;
            }
            break;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            if (this.RunTimeData.ScoreScaled === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            if (this.RunTimeData.ScoreRaw === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Raw Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            if (this.RunTimeData.ScoreMax === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            if (this.RunTimeData.ScoreMin === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Min Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The Exit data model element is write-only.");
            return false;
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            if (this.RunTimeData.SuspendData === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Suspend Data field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1434`");
            if (this.LearningObject.TimeLimitAction === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Time Limit Action field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.total_time":
            this.WriteDetailedLog("`1575`");
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1182`");
            break;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1183`");
            break;
        default:
            if (_5a.indexOf("adl.nav.request_valid.choice") === 0) {
                this.WriteDetailedLog("`1230`");
                return true;
            }
            if (_5a.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.CheckForGetValueError(_59, _5a, _5b, _5c);
                }
            }
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _59 + "' does not exist.");
            return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForSetValueError(_5d, _5e, _5f, _60, _61) {
    this.WriteDetailedLog("`1548`" + _5d + ", " + _5e + ", " + _5f + ", " + _60 + ", " + _61 + ") ");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR, "SetValue cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR, "SetValue cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (_5d.length === 0) {
        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The data model element for SetValue was not specified.");
        return false;
    }
    if (_5d.indexOf("adl.nav.request_valid.choice.{") === 0) {
        this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.choice element is read only");
        return false;
    }
    if (_60 !== "") {
        if (_5f.indexOf("cmi.comments_from_learner") >= 0) {
            if (_60 > this.RunTimeData.Comments.length) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Comments From Learner collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.Comments.length + ".");
                return false;
            }
        } else {
            if (_5f.indexOf("cmi.comments_from_lms") >= 0) {
                if (_60 > this.RunTimeData.CommentsFromLMS.length) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Comments From LMS collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.CommentsFromLMS.length + ".");
                    return false;
                }
            } else {
                if (_5f.indexOf("cmi.objectives") >= 0) {
                    if (_60 > this.RunTimeData.Objectives.length) {
                        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Objectives collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.Objectives.length + ".");
                        return false;
                    }
                } else {
                    if (_5f.indexOf("cmi.interactions") >= 0) {
                        if (_60 > this.RunTimeData.Interactions.length) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Interactions collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                            return false;
                        } else {
                            if (_5f.indexOf("cmi.interactions.n.correct_responses") >= 0) {
                                if (_60 >= this.RunTimeData.Interactions.length) {
                                    this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The Interactions collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                                    return false;
                                }
                                if (_61 !== "") {
                                    if (_61 > this.RunTimeData.Interactions[_60].CorrectResponses.length) {
                                        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Correct Responses collection elements for Interaction #" + _60 + " must be set sequentially the index " + _61 + " is greater than the next available index of " + this.RunTimeData.Interactions[_60].CorrectResponses.length + ".");
                                        return false;
                                    }
                                }
                            } else {
                                if (_5f.indexOf("cmi.interactions.n.objectives") >= 0) {
                                    if (_60 >= this.RunTimeData.Interactions.length) {
                                        this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The Interactions collection elements must be set sequentially, the index " + _60 + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                                        return false;
                                    }
                                    if (_61 !== "") {
                                        if (_61 > this.RunTimeData.Interactions[_60].Objectives.length) {
                                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Objectives collection elements for Interaction #" + _60 + " must be set sequentially the index " + _61 + " is greater than the next available index of " + this.RunTimeData.Interactions[_60].Objectives.length + ".");
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    var _62;
    var i;
    switch (_5f) {
        case "cmi._version":
            this.WriteDetailedLog("`1599`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi._version data model element is read-only");
            return false;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1161`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_learner._children data model element is read-only");
            return false;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_learner._count data model element is read-only");
            return false;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1162`");
            if (!this.ValidLocalizedString(_5e, 4000)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.comments_from_learner.n.comment data model element is not a valid localized string type (SPM 4000)");
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1134`");
            if (!this.ValidCharString(_5e, 250)) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The cmi.comments_from_learner.n.comment data model element is not a valid char string type (SPM 250)");
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1119`");
            if (!this.ValidTime(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.comments_from_learner.n.timestamp data model element is not a valid time");
                return false;
            }
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms._children data model element is read-only");
            return false;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms._count data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1248`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.comment data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1233`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.location data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1213`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.timestamp data model element is read-only");
            return false;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            if (_5e != SCORM_STATUS_COMPLETED && _5e != SCORM_STATUS_INCOMPLETE && _5e != SCORM_STATUS_NOT_ATTEMPTED && _5e != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The completion_status data model element must be a proper vocabulary element.");
                return false;
            }
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1371`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The completion_threshold data model element is read-only");
            return false;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The credit data model element is read-only");
            return false;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The entry data model element is read-only");
            return false;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            if (_5e != SCORM_EXIT_TIME_OUT && _5e != SCORM_EXIT_SUSPEND && _5e != SCORM_EXIT_LOGOUT && _5e != SCORM_EXIT_NORMAL && _5e != SCORM_EXIT_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The exit data model element must be a proper vocabulary element.");
                return false;
            }
            if (_5e == SCORM_EXIT_LOGOUT) {
                this.WriteDetailedLog("`349`");
            }
            break;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions._children element is read-only");
            return false;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions._count element is read-only");
            return false;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1427`");
            if (!this.ValidLongIdentifier(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".id value of '" + _5e + "' is not a valid long identifier.");
                return false;
            }
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1391`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (_5e != SCORM_TRUE_FALSE && _5e != SCORM_CHOICE && _5e != SCORM_FILL_IN && _5e != SCORM_LONG_FILL_IN && _5e != SCORM_LIKERT && _5e != SCORM_MATCHING && _5e != SCORM_PERFORMANCE && _5e != SCORM_SEQUENCING && _5e != SCORM_NUMERIC && _5e != SCORM_OTHER) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".type value of '" + _5e + "' is not a valid interaction type.");
                return false;
            }
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1135`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions.objectives._count element is read-only");
            return false;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1188`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLongIdentifier(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".objectives." + _61 + ".id value of '" + _5e + "' is not a valid long identifier type.");
                return false;
            }
            for (i = 0; i < this.RunTimeData.Interactions[_60].Objectives.length; i++) {
                if ((this.RunTimeData.Interactions[_60].Objectives[i] == _5e) && (i != _61)) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every interaction objective identifier must be unique. The value '" + _5e + "' has already been set in objective #" + i);
                    return false;
                }
            }
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1302`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidTime(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".timestamp value of '" + _5e + "' is not a valid time type.");
                return false;
            }
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`999`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions.correct_responses._count element is read-only");
            return false;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`972`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Type === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.type element must be set before a correct response can be set.");
                return false;
            }
            _62 = true;
            if (RegistrationToDeliver.Package.Properties.ValidateInteractionResponses) {
                switch (this.RunTimeData.Interactions[_60].Type) {
                    case SCORM_TRUE_FALSE:
                        if (this.RunTimeData.Interactions[_60].CorrectResponses.length > 0 && _61 > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A true-false interaction can only have one correct response.");
                            return false;
                        }
                        _62 = this.ValidTrueFalseResponse(_5e);
                        break;
                    case SCORM_CHOICE:
                        _62 = this.ValidMultipleChoiceResponse(_5e);
                        for (i = 0; i < this.RunTimeData.Interactions[_60].CorrectResponses.length; i++) {
                            if (this.RunTimeData.Interactions[_60].CorrectResponses[i] == _5e) {
                                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every correct response to a choice interaction must be unique. The value '" + _5e + "' has already been set in correct response #" + i);
                                return false;
                            }
                        }
                        break;
                    case SCORM_FILL_IN:
                        _62 = this.ValidFillInResponse(_5e, true);
                        break;
                    case SCORM_LONG_FILL_IN:
                        _62 = this.ValidLongFillInResponse(_5e, true);
                        break;
                    case SCORM_LIKERT:
                        if (this.RunTimeData.Interactions[_60].CorrectResponses.length > 0 && _61 > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A likert interaction can only have one correct response.");
                            return false;
                        }
                        _62 = this.ValidLikeRTResponse(_5e);
                        break;
                    case SCORM_MATCHING:
                        _62 = this.ValidMatchingResponse(_5e);
                        break;
                    case SCORM_PERFORMANCE:
                        _62 = this.ValidPerformanceResponse(_5e, true);
                        break;
                    case SCORM_SEQUENCING:
                        _62 = this.ValidSequencingResponse(_5e);
                        break;
                    case SCORM_NUMERIC:
                        if (this.RunTimeData.Interactions[_60].CorrectResponses.length > 0 && _61 > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A numeric interaction can only have one correct response.");
                            return false;
                        }
                        _62 = this.ValidNumericResponse(_5e, true);
                        break;
                    case SCORM_OTHER:
                        if (this.RunTimeData.Interactions[_60].CorrectResponses.length > 0 && _61 > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "An 'other' interaction can only have one correct response.");
                            return false;
                        }
                        _62 = this.ValidOtheresponse(_5e);
                        break;
                }
            }
            if (!_62) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".correct_responses." + _61 + ".pattern value of '" + _5e + "' is not a valid correct response to an interaction of type " + this.RunTimeData.Interactions[_60].Type + ".");
                return false;
            }
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1303`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".weighting value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1164`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (this.RunTimeData.Interactions[_60].Type === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.type element must be set before a learner response can be set.");
                return false;
            }
            _62 = true;
            if (RegistrationToDeliver.Package.Properties.ValidateInteractionResponses) {
                switch (this.RunTimeData.Interactions[_60].Type) {
                    case "true-false":
                        _62 = this.ValidTrueFalseResponse(_5e);
                        break;
                    case "choice":
                        _62 = this.ValidMultipleChoiceResponse(_5e);
                        break;
                    case "fill-in":
                        _62 = this.ValidFillInResponse(_5e, false);
                        break;
                    case "long-fill-in":
                        _62 = this.ValidLongFillInResponse(_5e, false);
                        break;
                    case "likert":
                        _62 = this.ValidLikeRTResponse(_5e);
                        break;
                    case "matching":
                        _62 = this.ValidMatchingResponse(_5e);
                        break;
                    case "performance":
                        _62 = this.ValidPerformanceResponse(_5e, false);
                        break;
                    case "sequencing":
                        _62 = this.ValidSequencingResponse(_5e);
                        break;
                    case "numeric":
                        _62 = this.ValidNumericResponse(_5e, false);
                        break;
                    case "other":
                        _62 = this.ValidOtheresponse(_5e);
                        break;
                }
            }
            if (!_62) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".learner_response value of '" + _5e + "' is not a valid response to an interaction of type " + this.RunTimeData.Interactions[_60].Type + ".");
                return false;
            }
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1355`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (_5e != SCORM_CORRECT && _5e != SCORM_INCORRECT && _5e != SCORM_UNANTICIPATED && _5e != SCORM_NEUTRAL) {
                if (!this.ValidReal(_5e)) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".result value of '" + _5e + "' is not a valid interaction result.");
                    return false;
                }
            }
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1333`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidTimeInterval(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".latency value of '" + _5e + "' is not a valid timespan.");
                return false;
            }
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1269`");
            if (this.RunTimeData.Interactions[_60] === undefined || this.RunTimeData.Interactions[_60].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLocalizedString(_5e, 250)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _60 + ".description value of '" + _5e + "' is not a valid localized string SPM 250.");
                return false;
            }
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.launch_data element is read-only");
            return false;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1570`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_id element is read-only");
            return false;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1529`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_name element is read-only");
            return false;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_preference._children element is read-only");
            return false;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1190`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.audio_level value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.learner_preference.audio_level value of '" + _5e + "' must be greater than zero.");
                return false;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1250`");
            if (!this.ValidLanguage(_5e, true)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.language value of '" + _5e + "' is not a valid language.");
                return false;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1120`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.delivery_speed value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.learner_preference.delivery_speed value of '" + _5e + "' must be greater than zero.");
                return false;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1079`");
            if (_5e != "-1" && _5e != "0" && _5e != "1") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.audio_captioning value of '" + _5e + "' must be -1, 0 or 1.");
                return false;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            if (!this.ValidCharString(_5e, 1000)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.location value of '" + _5e + "' is not a valid char string SPM 1000.");
                return false;
            }
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1447`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.max_time_allowed element is read only");
            return false;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.mode element is read only");
            return false;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives._children element is read only");
            return false;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives._count element is read only");
            return false;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1477`");
            if (!this.ValidLongIdentifier(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives.n.id value of '" + _5e + "' is not a valid long identifier.");
                return false;
            }
            if (this.RunTimeData.Objectives[_60] != undefined && this.RunTimeData.Objectives[_60].Identifier != null) {
                if (this.RunTimeData.Objectives[_60].Identifier !== null && this.RunTimeData.Objectives[_60].Identifier != _5e) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Objective identifiers may only be set once and may not be overwritten. The objective at index " + _60 + " already has the identifier " + this.RunTimeData.Objectives[_60].Identifier);
                    return false;
                }
            }
            for (i = 0; i < this.RunTimeData.Objectives.length; i++) {
                if ((this.RunTimeData.Objectives[i].Identifier == _5e) && (i != _60)) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every objective identifier must be unique. The value '" + _5e + "' has already been set in objective #" + i);
                    return false;
                }
            }
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1236`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives.n.score._children element is read only");
            return false;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1290`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".score.scaled value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < -1 || parseFloat(_5e) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.objectives." + _60 + ".score.scaled value of '" + _5e + "' must be between -1 and 1.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1339`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".score.raw value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1338`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".score.min value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1337`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".score.max value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1251`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (_5e != SCORM_STATUS_PASSED && _5e != SCORM_STATUS_FAILED && _5e != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".success_status value of '" + _5e + "' is not a valid success status.");
                return false;
            }
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1192`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (_5e != SCORM_STATUS_COMPLETED && _5e != SCORM_STATUS_INCOMPLETE && _5e != SCORM_STATUS_NOT_ATTEMPTED && _5e != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".completion_status value of '" + _5e + "' is not a valid completion status.");
                return false;
            }
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1216`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".progress_measure value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < 0 || parseFloat(_5e) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.objectives." + _60 + ".progress_measure value of '" + _5e + "' must be between 0 and 1.");
                return false;
            }
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1304`");
            if (this.RunTimeData.Objectives[_60] === undefined || this.RunTimeData.Objectives[_60].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLocalizedString(_5e, 250)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _60 + ".description value of '" + _5e + "' is not a valid localized string SPM 250.");
                return false;
            }
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.progress_measure value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < 0 || parseFloat(_5e) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.pogress_measure value of '" + _5e + "' must be between 0 and 1.");
                return false;
            }
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1378`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.scaled_passing_score element is read only");
            return false;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.score._children element is read only");
            return false;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.scaled value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_5e) < -1 || parseFloat(_5e) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi..score.scaled value of '" + _5e + "' must be between -1 and 1.");
                return false;
            }
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            if (!this.ValidReal(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _5e + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            if (!this.ValidTimeInterval(_5e)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.session_time value of '" + _5e + "' is not a valid time intervals.");
                return false;
            }
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            if (_5e != SCORM_STATUS_PASSED && _5e != SCORM_STATUS_FAILED && _5e != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.success_status value of '" + _5e + "' is not a valid success status.");
                return false;
            }
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            if (!this.ValidCharString(_5e, Control.Package.Properties.SuspendDataMaxLength)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.suspend_data value of '" + _5e + "' is not a valid char string SPM" + Control.Package.Properties.SuspendDataMaxLength + ".");
                return false;
            }
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1434`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.time_limit_action element is read only");
            return false;
        case "cmi.total_time":
            this.WriteDetailedLog("`1575`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.total_time element is read only");
            return false;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            if (_5e.substring(0, 1) == "{") {
                var _64 = _5e.substring(0, _5e.indexOf("}") + 1);
                if (Control.IsTargetValid(_64) === false) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value '" + _64 + "' is not a valid target of a choice request.");
                    return false;
                }
                if (_5e.indexOf("choice") != _64.length) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "A target may only be provided for a choice request.");
                    return false;
                }
            } else {
                if (_5e != SCORM_RUNTIME_NAV_REQUEST_CONTINUE && _5e != SCORM_RUNTIME_NAV_REQUEST_PREVIOUS && _5e != SCORM_RUNTIME_NAV_REQUEST_CHOICE && _5e != SCORM_RUNTIME_NAV_REQUEST_EXIT && _5e != SCORM_RUNTIME_NAV_REQUEST_EXITALL && _5e != SCORM_RUNTIME_NAV_REQUEST_ABANDON && _5e != SCORM_RUNTIME_NAV_REQUEST_ABANDONALL && _5e != SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL && _5e != SCORM_RUNTIME_NAV_REQUEST_NONE) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The adl.nav.request value of '" + _5e + "' is not a valid nav request.");
                    return false;
                }
            }
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1182`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.continue element is read only");
            return false;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1183`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.previous element is read only");
            return false;
        case "adl.nav.request_valid.choice":
            this.WriteDetailedLog("`1230`");
            break;
        default:
            if (_5f.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.CheckForSetValueError(_5d, _5e, _5f, _60, _61);
                }
            }
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _5d + "' is not defined in SCORM 2004");
            return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_ValidCharString(str, _66) {
    this.WriteDetailedLog("`1496`");
    return true;
}

function RunTimeApi_ValidLocalizedString(str, _68) {
    this.WriteDetailedLog("`1393`");
    var _69;
    var _6a = new String();
    var _6b;
    _69 = str;
    if (str.indexOf("{lang=") === 0) {
        _6b = str.indexOf("}");
        if (_6b > 0) {
            _6a = str.substr(0, _6b);
            _6a = _6a.replace(/\{lang=/, "");
            _6a = _6a.replace(/\}/, "");
            if (!this.ValidLanguage(_6a, false)) {
                return false;
            }
            if (str.length >= (_6b + 2)) {
                _69 = str.substring(_6b + 1);
            } else {
                _69 = "";
            }
        }
    }
    return true;
}

function RunTimeApi_ExtractLanguageDelimiterFromLocalizedString(str) {
    var _6d;
    var _6e = "";
    if (str.indexOf("{lang=") === 0) {
        _6d = str.indexOf("}");
        if (_6d > 0) {
            _6e = str.substr(0, _6d + 1);
        }
    }
    return _6e;
}

function RunTimeApi_ValidLanguage(str, _70) {
    this.WriteDetailedLog("`1540`");
    var _71;
    if (str.length === 0) {
        if (_70) {
            return true;
        } else {
            return false;
        }
    }
    _71 = str.split("-");
    for (var i = 0; i < _71.length; i++) {
        if (_71[i].length > 8) {
            return false;
        }
        if (_71[i].length < 2) {
            if (_71[i] != "i" && _71[i] != "x") {
                return false;
            }
        }
    }
    var _73 = new Iso639LangCodes_LangCodes();
    if (!_73.IsValid(_71[0].toLowerCase())) {
        return false;
    }
    if (str.length > 250) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidLongIdentifier(str) {
    this.WriteDetailedLog("`1412`");
    str = str.trim();
    if (!this.ValidIdentifier(str)) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidShortIdentifier(str) {
    this.WriteDetailedLog("`1395`");
    if (!this.ValidIdentifier(str)) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidIdentifier(str) {
    this.WriteDetailedLog("`1497`");
    str = str.trim();
    if (str.length === 0) {
        return false;
    }
    if (str.toLowerCase().indexOf("urn:") === 0) {
        return this.IsValidUrn(str);
    }
    if (str.search(/\w/) < 0) {
        return false;
    }
    if (str.search(/[^\w\-\(\)\+\.\:\=\@\;\$\_\!\*\'\%\/]/) >= 0) {
        return false;
    }
    return true;
}

function RunTimeApi_IsValidUrn(str) {
    this.WriteDetailedLog("`1587`");
    var _78 = str.split(":");
    var nid = new String("");
    var nss = "";
    if (_78.length > 1) {
        nid = _78[1];
    } else {
        return false;
    }
    if (_78.length > 2) {
        nss = _78[2];
    }
    if (nid.length === 0) {
        return false;
    }
    if (nid.indexOf(" ") > 0 || nss.indexOf(" ") > 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidReal(str) {
    this.WriteDetailedLog("`1607`");
    if (str.search(/[^.\d-]/) > -1) {
        return false;
    }
    if (str.search("-") > -1) {
        if (str.indexOf("-", 1) > -1) {
            return false;
        }
    }
    if (str.indexOf(".") != str.lastIndexOf(".")) {
        return false;
    }
    if (str.search(/\d/) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidTime(str) {
    this.WriteDetailedLog("`1608`");
    var _7d = "";
    var _7e = "";
    var day = "";
    var _80 = "";
    var _81 = "";
    var _82 = "";
    var _83 = "";
    var _84 = "";
    var _85 = "";
    var _86 = "";
    var _87;
    str = new String(str);
    var _88 = /^(\d\d\d\d)(-(\d\d)(-(\d\d)(T(\d\d)(:(\d\d)(:(\d\d))?)?)?)?)?/;
    if (str.search(_88) !== 0) {
        return false;
    }
    if (str.substr(str.length - 1, 1).search(/[\-T\:]/) >= 0) {
        return false;
    }
    var len = str.length;
    if (len != 4 && len != 7 && len != 10 && len != 13 && len != 16 && len < 19) {
        return false;
    }
    if (len >= 5) {
        if (str.substr(4, 1) != "-") {
            return false;
        }
    }
    if (len >= 8) {
        if (str.substr(7, 1) != "-") {
            return false;
        }
    }
    if (len >= 11) {
        if (str.substr(10, 1) != "T") {
            return false;
        }
    }
    if (len >= 14) {
        if (str.substr(13, 1) != ":") {
            return false;
        }
    }
    if (len >= 17) {
        if (str.substr(16, 1) != ":") {
            return false;
        }
    }
    var _8a = str.match(_88);
    _7d = _8a[1];
    _7e = _8a[3];
    day = _8a[5];
    _80 = _8a[7];
    _81 = _8a[9];
    _82 = _8a[11];
    if (str.length > 19) {
        if (str.length < 21) {
            return false;
        }
        if (str.substr(19, 1) != ".") {
            return false;
        }
        _87 = str.substr(20, 1);
        if (_87.search(/\d/) < 0) {
            return false;
        } else {
            _83 += _87;
        }
        for (var i = 21; i < str.length; i++) {
            _87 = str.substr(i, 1);
            if ((i == 21) && (_87.search(/\d/) === 0)) {
                _83 += _87;
            } else {
                _84 += _87;
            }
        }
    }
    if (_84.length === 0) {} else {
        if (_84.length == 1) {
            if (_84 != "Z") {
                return false;
            }
        } else {
            if (_84.length == 3) {
                if (_84.search(/[\+\-]\d\d/) !== 0) {
                    return false;
                } else {
                    _85 = _84.substr(1, 2);
                }
            } else {
                if (_84.length == 6) {
                    if (_84.search(/[\+\-]\d\d:\d\d/) !== 0) {
                        return false;
                    } else {
                        _85 = _84.substr(1, 2);
                        _86 = _84.substr(4, 2);
                    }
                } else {
                    return false;
                }
            }
        }
    }
    if (_7d < 1970 || _7d > 2038) {
        return false;
    }
    if (_7e !== undefined && _7e !== "") {
        _7e = parseInt(_7e, 10);
        if (_7e < 1 || _7e > 12) {
            return false;
        }
    }
    if (day !== undefined && day !== "") {
        var dtm = new Date(_7d, (_7e - 1), day);
        if (dtm.getDate() != day) {
            return false;
        }
    }
    if (_80 !== undefined && _80 !== "") {
        _80 = parseInt(_80, 10);
        if (_80 < 0 || _80 > 23) {
            return false;
        }
    }
    if (_81 !== undefined && _81 !== "") {
        _81 = parseInt(_81, 10);
        if (_81 < 0 || _81 > 59) {
            return false;
        }
    }
    if (_82 !== undefined && _82 !== "") {
        _82 = parseInt(_82, 10);
        if (_82 < 0 || _82 > 59) {
            return false;
        }
    }
    if (_85 !== undefined && _85 !== "") {
        _85 = parseInt(_85, 10);
        if (_85 < 0 || _85 > 23) {
            return false;
        }
    }
    if (_86 !== undefined && _86 !== "") {
        _86 = parseInt(_86, 10);
        if (_86 < 0 || _86 > 59) {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidTimeInterval(str) {
    this.WriteDetailedLog("`1455`");
    var _8e = /^P(\d+Y)?(\d+M)?(\d+D)?(T(\d+H)?(\d+M)?(\d+(.\d\d?)?S)?)?$/;
    if (str == "P") {
        return false;
    }
    if (str.lastIndexOf("T") == (str.length - 1)) {
        return false;
    }
    if (str.search(_8e) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidTrueFalseResponse(str) {
    this.WriteDetailedLog("`1362`");
    var _90 = /^(true|false)$/;
    if (str.search(_90) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidMultipleChoiceResponse(str) {
    this.WriteDetailedLog("`1275`");
    if (str.length === 0) {
        return true;
    }
    return (this.IsValidArrayOfShortIdentifiers(str, 36, true) || this.IsValidCommaDelimitedArrayOfShortIdentifiers(str, 36, true));
}

function RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers(str, _93, _94) {
    this.WriteDetailedLog("`1221`");
    var _95 = ",";
    var _96 = str.split(_95);
    for (var i = 0; i < _96.length; i++) {
        if (!this.ValidShortIdentifier(_96[i])) {
            return false;
        }
        if (_94) {
            for (var j = 0; j < _96.length; j++) {
                if (j != i) {
                    if (_96[j] == _96[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_IsValidArrayOfShortIdentifiers(str, _9a, _9b) {
    this.WriteDetailedLog("`1221`");
    var _9c = "[,]";
    var _9d = str.split(_9c);
    for (var i = 0; i < _9d.length; i++) {
        if (!this.ValidShortIdentifier(_9d[i])) {
            return false;
        }
        if (_9b) {
            for (var j = 0; j < _9d.length; j++) {
                if (j != i) {
                    if (_9d[j] == _9d[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_IsValidArrayOfLocalizedStrings(str, _a1, _a2) {
    this.WriteDetailedLog("`1220`");
    var _a3 = "[,]";
    var _a4 = str.split(_a3);
    for (var i = 0; i < _a4.length; i++) {
        if (!this.ValidLocalizedString(_a4[i], 0)) {
            return false;
        }
        if (_a2) {
            for (var j = 0; j < _a4.length; j++) {
                if (j != i) {
                    if (_a4[j] == _a4[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_ValidFillInResponse(str, _a8) {
    this.WriteDetailedLog("`1410`");
    if (str.length === 0) {
        return true;
    }
    var _a9 = /^\{case_matters=/;
    var _aa = /^\{order_matters=/;
    var _ab = /^\{lang=[\w\-]+\}\{/;
    var _ac = /^\{case_matters=(true|false)\}/;
    var _ad = /^\{order_matters=(true|false)\}/;
    var _ae = new String(str);
    if (_a8) {
        if (_ae.search(_a9) >= 0) {
            if (_ae.search(_ac) < 0) {
                return false;
            }
            _ae = _ae.replace(_ac, "");
        }
        if (_ae.search(_aa) >= 0) {
            if (_ae.search(_ad) < 0) {
                return false;
            }
            _ae = _ae.replace(_ad, "");
        }
        if (_ae.search(_a9) >= 0) {
            if (_ae.search(_ac) < 0) {
                return false;
            }
            _ae = _ae.replace(_ac, "");
        }
    }
    return this.IsValidArrayOfLocalizedStrings(_ae, 10, false);
}

function RunTimeApi_ValidLongFillInResponse(str, _b0) {
    this.WriteDetailedLog("`1344`");
    var _b1 = /^\{case_matters=/;
    var _b2 = /^\{case_matters=(true|false)\}/;
    var _b3 = new String(str);
    if (_b0) {
        if (_b3.search(_b1) >= 0) {
            if (_b3.search(_b2) < 0) {
                return false;
            }
            _b3 = _b3.replace(_b2, "");
        }
    }
    return this.ValidLocalizedString(_b3, 4000);
}

function RunTimeApi_ValidLikeRTResponse(str) {
    this.WriteDetailedLog("`1411`");
    return this.ValidShortIdentifier(str);
}

function RunTimeApi_ValidMatchingResponse(str) {
    this.WriteDetailedLog("`1383`");
    var _b6 = "[,]";
    var _b7 = "[.]";
    var _b8;
    var _b9;
    _b8 = str.split(_b6);
    for (var i = 0; i < _b8.length; i++) {
        _b9 = _b8[i].split(_b7);
        if (_b9.length != 2) {
            return false;
        }
        if (!this.ValidShortIdentifier(_b9[0])) {
            return false;
        }
        if (!this.ValidShortIdentifier(_b9[1])) {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidPerformanceResponse(str, _bc) {
    this.WriteDetailedLog("`1322`");
    var _bd = /^\{order_matters=/;
    var _be = /^\{order_matters=(true|false)\}/;
    var _bf;
    var _c0;
    var _c1;
    var _c2;
    var _c3;
    var _c4 = new String(str);
    if (str.length === 0) {
        return false;
    }
    if (_bc) {
        if (_c4.search(_bd) >= 0) {
            if (_c4.search(_be) < 0) {
                return false;
            }
            _c4 = _c4.replace(_be, "");
        }
    }
    _bf = _c4.split("[,]");
    if (_bf.length === 0) {
        return false;
    }
    for (var i = 0; i < _bf.length; i++) {
        _c0 = _bf[i];
        if (_c0.length === 0) {
            return false;
        }
        _c1 = _c0.split("[.]");
        if (_c1.length == 2) {
            _c2 = _c1[0];
            _c3 = _c1[1];
            if (_c2.length === 0 && _c3 === 0) {
                return false;
            }
            if (_c2.length > 0) {
                if (!this.ValidShortIdentifier(_c2)) {
                    return false;
                }
            }
        } else {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidSequencingResponse(str) {
    this.WriteDetailedLog("`1345`");
    return this.IsValidArrayOfShortIdentifiers(str, 36, false);
}

function RunTimeApi_ValidNumericResponse(str, _c8) {
    this.WriteDetailedLog("`1394`");
    var _c9 = "[:]";
    var _ca = str.split(_c9);
    if (_c8) {
        if (_ca.length > 2) {
            return false;
        }
    } else {
        if (_ca.length > 1) {
            return false;
        }
    }
    for (var i = 0; i < _ca.length; i++) {
        if (!this.ValidReal(_ca[i])) {
            return false;
        }
    }
    if (_ca.length >= 2) {
        if (_ca[0].length > 0 && _ca[1].length > 0) {
            if (parseFloat(_ca[0]) > parseFloat(_ca[1])) {
                return false;
            }
        }
    }
    return true;
}

function RunTimeApi_ValidOtheresponse(str) {
    this.WriteDetailedLog("`1454`");
    return true;
}

function RunTimeApi_TranslateBooleanIntoCMI(_cd) {
    if (_cd === true) {
        return SCORM_TRUE;
    } else {
        if (_cd === false) {
            return SCORM_FALSE;
        } else {
            return SCORM_UNKNOWN;
        }
    }
}

function RunTimeApi_GetCompletionStatus() {
    if (this.LearningObject.CompletionThreshold !== null) {
        if (this.RunTimeData.ProgressMeasure !== null) {
            if (parseFloat(this.RunTimeData.ProgressMeasure) >= parseFloat(this.LearningObject.CompletionThreshold)) {
                this.WriteDetailedLog("`616`");
                return SCORM_STATUS_COMPLETED;
            } else {
                this.WriteDetailedLog("`569`");
                return SCORM_STATUS_INCOMPLETE;
            }
        } else {
            this.WriteDetailedLog("`998`" + this.LearningObject.CompletionThreshold + "`670`");
            return SCORM_STATUS_UNKNOWN;
        }
    }
    this.WriteDetailedLog("`624`" + this.RunTimeData.CompletionStatus);
    return this.RunTimeData.CompletionStatus;
}

function RunTimeApi_GetSuccessStatus() {
    var _ce = this.LearningObject.GetScaledPassingScore();
    if (_ce !== null) {
        if (this.RunTimeData.ScoreScaled !== null) {
            if (parseFloat(this.RunTimeData.ScoreScaled) >= parseFloat(_ce)) {
                this.WriteDetailedLog("`697`");
                return SCORM_STATUS_PASSED;
            } else {
                this.WriteDetailedLog("`650`");
                return SCORM_STATUS_FAILED;
            }
        } else {
            this.WriteDetailedLog("`570`");
            return SCORM_STATUS_UNKNOWN;
        }
    }
    this.WriteDetailedLog("`641`" + this.RunTimeData.SuccessStatus);
    return this.RunTimeData.SuccessStatus;
}

function RunTimeApi_InitTrackedTimeStart(_cf) {
    this.TrackedStartDate = new Date();
    this.StartSessionTotalTime = _cf.RunTime.TotalTime;
}

function RunTimeApi_AccumulateTotalTimeTracked() {
    this.TrackedEndDate = new Date();
    var _d0 = Math.round((this.TrackedEndDate - this.TrackedStartDate) / 10);
    var _d1 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTimeTracked);
    var _d2 = 0;
    if ((_d0 + _d1) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`1299`");
        _d2 = _d0 + _d1;
    } else {
        _d2 = _d0 + _d1 - this.TrackedSessionTimePrevCall;
    }
    this.RunTimeData.TotalTimeTracked = ConvertHundredthsToIso8601TimeSpan(_d2);
    var _d3 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTimeTracked);
    var _d4 = 0;
    if ((_d0 + _d3) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`1266`");
        _d4 = _d0 + _d3;
    } else {
        _d4 = _d0 + _d3 - this.TrackedSessionTimePrevCall;
    }
    this.RunTimeData.SessionTimeTracked = ConvertHundredthsToIso8601TimeSpan(_d4);
    this.Activity.ActivityEndedDate = this.TrackedEndDate;
    var _d5 = GetDateFromUtcIso8601Time(this.Activity.GetActivityStartTimestampUtc());
    var _d6 = GetDateFromUtcIso8601Time(this.Activity.GetAttemptStartTimestampUtc());
    this.Activity.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate - _d5) / 10));
    this.Activity.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate - _d6) / 10));
    var _d7 = ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationTracked());
    var _d8 = null;
    if ((_d7 + _d0) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`970`");
        _d8 = ConvertHundredthsToIso8601TimeSpan(_d7 + _d0);
    } else {
        _d8 = ConvertHundredthsToIso8601TimeSpan(_d7 + _d0 - this.TrackedSessionTimePrevCall);
    }
    this.Activity.SetActivityExperiencedDurationTracked(_d8);
    var _d9 = ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationReported());
    var _da = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime) - ConvertIso8601TimeSpanToHundredths(this.StartSessionTotalTime);
    var _db = null;
    if ((_d9 + _da) < this.SessionTotalTimeReportedPrevCall) {
        this.WriteDetailedLog("`956`");
        _db = ConvertHundredthsToIso8601TimeSpan(_d9 + _da);
    } else {
        _db = ConvertHundredthsToIso8601TimeSpan(_d9 + _da - this.SessionTotalTimeReportedPrevCall);
    }
    this.Activity.SetActivityExperiencedDurationReported(_db);
    var _dc = ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationTracked());
    var _dd = null;
    if ((_dc + _d0) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`983`");
        _dd = ConvertHundredthsToIso8601TimeSpan(_dc + _d0);
    } else {
        _dd = ConvertHundredthsToIso8601TimeSpan(_dc + _d0 - this.TrackedSessionTimePrevCall);
    }
    this.Activity.SetAttemptExperiencedDurationTracked(_dd);
    var _de = ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationReported());
    var _df = null;
    if ((_de + _da) < this.SessionTotalTimeReportedPrevCall) {
        this.WriteDetailedLog("`971`");
        attemptReportedTimeSpan = ConvertHundredthsToIso8601TimeSpan(_de + _da);
    } else {
        attemptReportedTimeSpan = ConvertHundredthsToIso8601TimeSpan(_de + _da - this.SessionTotalTimeReportedPrevCall);
    }
    this.Activity.SetAttemptExperiencedDurationReported(attemptReportedTimeSpan);
    this.TrackedSessionTimePrevCall = _d0;
    this.SessionTotalTimeReportedPrevCall = _da;
}

function RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded(_e0, _e1) {
    if (this.IsLookAheadSequencerDataDirty == false && _e0 != _e1) {
        this.IsLookAheadSequencerDataDirty = true;
    }
}

function RunTimeApi_RunLookAheadSequencerIfNeeded(_e2) {
    if ((Control.Package.Properties.LookaheadSequencerMode != LOOKAHEAD_SEQUENCER_MODE_REALTIME && _e2 !== true) || Control.Package.Properties.LookaheadSequencerMode == LOOKAHEAD_SEQUENCER_MODE_DISABLE) {
        return;
    }
    if (this.RunTimeData != null) {
        this.LookAheadSessionClose();
    }
    if (this.IsLookAheadSequencerDataDirty === true && !this.IsLookAheadSequencerRunning) {
        this.IsLookAheadSequencerDataDirty = false;
        this.IsLookAheadSequencerRunning = true;
        window.setTimeout("Control.EvaluatePossibleNavigationRequests(true);", 150);
    }
}
var TERMINATION_REQUEST_EXIT = "EXIT";
var TERMINATION_REQUEST_EXIT_ALL = "EXIT ALL";
var TERMINATION_REQUEST_SUSPEND_ALL = "SUSPEND ALL";
var TERMINATION_REQUEST_ABANDON = "ABANDON";
var TERMINATION_REQUEST_ABANDON_ALL = "ABANDON ALL";
var TERMINATION_REQUEST_EXIT_PARENT = "EXIT PARENT";
var TERMINATION_REQUEST_NOT_VALID = "INVALID";
var SEQUENCING_REQUEST_START = "START";
var SEQUENCING_REQUEST_RESUME_ALL = "RESUME ALL";
var SEQUENCING_REQUEST_CONTINUE = "CONTINUE";
var SEQUENCING_REQUEST_PREVIOUS = "PREVIOUS";
var SEQUENCING_REQUEST_CHOICE = "CHOICE";
var SEQUENCING_REQUEST_RETRY = "RETRY";
var SEQUENCING_REQUEST_EXIT = "EXIT";
var SEQUENCING_REQUEST_NOT_VALID = "INVALID";
var RULE_SET_POST_CONDITION = "POST_CONDITION";
var RULE_SET_EXIT = "EXIT";
var RULE_SET_HIDE_FROM_CHOICE = "HIDE_FROM_CHOICE";
var RULE_SET_STOP_FORWARD_TRAVERSAL = "STOP_FORWARD_TRAVERSAL";
var RULE_SET_DISABLED = "DISABLED";
var RULE_SET_SKIPPED = "SKIPPED";
var RULE_SET_SATISFIED = "SATISFIED";
var RULE_SET_NOT_SATISFIED = "NOT_SATISFIED";
var RULE_SET_COMPLETED = "COMPLETED";
var RULE_SET_INCOMPLETE = "INCOMPLETE";
var SEQUENCING_RULE_ACTION_SKIP = "Skip";
var SEQUENCING_RULE_ACTION_DISABLED = "Disabled";
var SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE = "Hidden From Choice";
var SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL = "Stop Forward Traversal";
var SEQUENCING_RULE_ACTION_EXIT = "Exit";
var SEQUENCING_RULE_ACTION_EXIT_PARENT = "Exit Parent";
var SEQUENCING_RULE_ACTION_EXIT_ALL = "Exit All";
var SEQUENCING_RULE_ACTION_RETRY = "Retry";
var SEQUENCING_RULE_ACTION_RETRY_ALL = "Retry All";
var SEQUENCING_RULE_ACTION_CONTINUE = "Continue";
var SEQUENCING_RULE_ACTION_PREVIOUS = "Previous";
var FLOW_DIRECTION_FORWARD = "FORWARD";
var FLOW_DIRECTION_BACKWARD = "BACKWARD";
var RULE_CONDITION_OPERATOR_NOT = "Not";
var RULE_CONDITION_COMBINATION_ALL = "All";
var RULE_CONDITION_COMBINATION_ANY = "Any";
var RESULT_UNKNOWN = "unknown";
var SEQUENCING_RULE_CONDITION_SATISFIED = "Satisfied";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN = "Objective Status Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN = "Objective Measure Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN = "Objective Measure Greater Than";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN = "Objective Measure Less Than";
var SEQUENCING_RULE_CONDITION_COMPLETED = "Completed";
var SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN = "Activity Progress Known";
var SEQUENCING_RULE_CONDITION_ATTEMPTED = "Attempted";
var SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED = "Attempt Limit Exceeded";
var SEQUENCING_RULE_CONDITION_ALWAYS = "Always";
var ROLLUP_RULE_ACTION_SATISFIED = "Satisfied";
var ROLLUP_RULE_ACTION_NOT_SATISFIED = "Not Satisfied";
var ROLLUP_RULE_ACTION_COMPLETED = "Completed";
var ROLLUP_RULE_ACTION_INCOMPLETE = "Incomplete";
var CHILD_ACTIVITY_SET_ALL = "All";
var CHILD_ACTIVITY_SET_ANY = "Any";
var CHILD_ACTIVITY_SET_NONE = "None";
var CHILD_ACTIVITY_SET_AT_LEAST_COUNT = "At Least Count";
var CHILD_ACTIVITY_SET_AT_LEAST_PERCENT = "At Least Percent";
var ROLLUP_RULE_CONDITION_SATISFIED = "Satisfied";
var ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN = "Objective Status Known";
var ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN = "Objective Measure Known";
var ROLLUP_RULE_CONDITION_COMPLETED = "Completed";
var ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN = "Activity Progress Known";
var ROLLUP_RULE_CONDITION_ATTEMPTED = "Attempted";
var ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED = "Attempt Limit Exceeded";
var ROLLUP_RULE_CONDITION_NEVER = "Never";
var ROLLUP_CONSIDERATION_ALWAYS = "Always";
var ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED = "If Not Suspended";
var ROLLUP_CONSIDERATION_IF_ATTEMPTED = "If Attempted";
var ROLLUP_CONSIDERATION_IF_NOT_SKIPPED = "If Not Skipped";
var TIMING_NEVER = "Never";
var TIMING_ONCE = "Once";
var TIMING_ON_EACH_NEW_ATTEMPT = "On Each New Attempt";
var CONTROL_CHOICE_EXIT_ERROR_NAV = "NB.2.1-8";
var CONTROL_CHOICE_EXIT_ERROR_CHOICE = "SB.2.9-7";
var PREVENT_ACTIVATION_ERROR = "SB.2.9-6";
var CONSTRAINED_CHOICE_ERROR = "SB.2.9-8";

function Sequencer(_e3, _e4) {
    this.LookAhead = _e3;
    this.Activities = _e4;
    this.NavigationRequest = null;
    this.ChoiceTargetIdentifier = null;
    this.SuspendedActivity = null;
    this.CurrentActivity = null;
    this.Exception = null;
    this.ExceptionText = null;
    this.GlobalObjectives = new Array();
    this.ReturnToLmsInvoked = false;
}
Sequencer.prototype.OverallSequencingProcess = Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity = Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity = Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start = Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection = Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity = Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText = Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction = Sequencer_GetExitAction;
Sequencer.prototype.EvaluatePossibleNavigationRequests = Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes = Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.SetAllDescendentsToDisabled = Sequencer_SetAllDescendentsToDisabled;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess = Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;

function Sequencer_SetSuspendedActivity(_e5) {
    this.SuspendedActivity = _e5;
}

function Sequencer_GetSuspendedActivity(_e6) {
    var _e7 = this.SuspendedActivity;
    if (_e6 !== null && _e6 !== undefined) {
        this.LogSeq("`1578`" + _e7, _e6);
    }
    return _e7;
}

function Sequencer_Start() {
    if (this.SuspendedActivity === null) {
        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_START, null, "");
    } else {
        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_RESUME_ALL, null, "");
    }
    this.OverallSequencingProcess();
}

function Sequencer_InitialRandomizationAndSelection() {
    var _e8 = this.LogSeqAudit("`1321`");
    if (this.SuspendedActivity === null) {
        for (var _e9 in this.Activities.ActivityList) {
            this.SelectChildrenProcess(this.Activities.ActivityList[_e9], _e8);
            this.RandomizeChildrenProcess(this.Activities.ActivityList[_e9], false, _e8);
        }
    }
}

function Sequencer_GetCurrentActivity() {
    return this.CurrentActivity;
}

function Sequencer_GetExceptionText() {
    if (this.ExceptionText !== null && this.ExceptionText !== undefined) {
        return this.ExceptionText;
    } else {
        return "";
    }
}

function Sequencer_GetExitAction(_ea, _eb) {
    return EXIT_ACTION_DISPLAY_MESSAGE;
}
Sequencer.prototype.NavigationRequestProcess = Sequencer_NavigationRequestProcess;
Sequencer.prototype.SequencingExitActionRulesSubprocess = Sequencer_SequencingExitActionRulesSubprocess;
Sequencer.prototype.SequencingPostConditionRulesSubprocess = Sequencer_SequencingPostConditionRulesSubprocess;
Sequencer.prototype.TerminationRequestProcess = Sequencer_TerminationRequestProcess;
Sequencer.prototype.MeasureRollupProcess = Sequencer_MeasureRollupProcess;
Sequencer.prototype.ObjectiveRollupProcess = Sequencer_ObjectiveRollupProcess;
Sequencer.prototype.ObjectiveRollupUsingDefaultProcess = Sequencer_ObjectiveRollupUsingDefaultProcess;
Sequencer.prototype.ObjectiveRollupUsingMeasureProcess = Sequencer_ObjectiveRollupUsingMeasureProcess;
Sequencer.prototype.ObjectiveRollupUsingRulesProcess = Sequencer_ObjectiveRollupUsingRulesProcess;
Sequencer.prototype.ActivityProgressRollupProcess = Sequencer_ActivityProgressRollupProcess;
Sequencer.prototype.ActivityProgressRollupProcessUsingDefault = Sequencer_ActivityProgressRollupProcessUsingDefault;
Sequencer.prototype.RollupRuleCheckSubprocess = Sequencer_RollupRuleCheckSubprocess;
Sequencer.prototype.EvaluateRollupConditionsSubprocess = Sequencer_EvaluateRollupConditionsSubprocess;
Sequencer.prototype.CheckChildForRollupSubprocess = Sequencer_CheckChildForRollupSubprocess;
Sequencer.prototype.OverallRollupProcess = Sequencer_OverallRollupProcess;
Sequencer.prototype.SelectChildrenProcess = Sequencer_SelectChildrenProcess;
Sequencer.prototype.RandomizeChildrenProcess = Sequencer_RandomizeChildrenProcess;
Sequencer.prototype.FlowTreeTraversalSubprocess = Sequencer_FlowTreeTraversalSubprocess;
Sequencer.prototype.FlowActivityTraversalSubprocess = Sequencer_FlowActivityTraversalSubprocess;
Sequencer.prototype.FlowSubprocess = Sequencer_FlowSubprocess;
Sequencer.prototype.ChoiceActivityTraversalSubprocess = Sequencer_ChoiceActivityTraversalSubprocess;
Sequencer.prototype.StartSequencingRequestProcess = Sequencer_StartSequencingRequestProcess;
Sequencer.prototype.ResumeAllSequencingRequestProcess = Sequencer_ResumeAllSequencingRequestProcess;
Sequencer.prototype.ContinueSequencingRequestProcess = Sequencer_ContinueSequencingRequestProcess;
Sequencer.prototype.PreviousSequencingRequestProcess = Sequencer_PreviousSequencingRequestProcess;
Sequencer.prototype.ChoiceSequencingRequestProcess = Sequencer_ChoiceSequencingRequestProcess;
Sequencer.prototype.ChoiceFlowSubprocess = Sequencer_ChoiceFlowSubprocess;
Sequencer.prototype.ChoiceFlowTreeTraversalSubprocess = Sequencer_ChoiceFlowTreeTraversalSubprocess;
Sequencer.prototype.RetrySequencingRequestProcess = Sequencer_RetrySequencingRequestProcess;
Sequencer.prototype.ExitSequencingRequestProcess = Sequencer_ExitSequencingRequestProcess;
Sequencer.prototype.SequencingRequestProcess = Sequencer_SequencingRequestProcess;
Sequencer.prototype.DeliveryRequestProcess = Sequencer_DeliveryRequestProcess;
Sequencer.prototype.ContentDeliveryEnvironmentProcess = Sequencer_ContentDeliveryEnvironmentProcess;
Sequencer.prototype.ClearSuspendedActivitySubprocess = Sequencer_ClearSuspendedActivitySubprocess;
Sequencer.prototype.LimitConditionsCheckProcess = Sequencer_LimitConditionsCheckProcess;
Sequencer.prototype.SequencingRulesCheckProcess = Sequencer_SequencingRulesCheckProcess;
Sequencer.prototype.SequencingRulesCheckSubprocess = Sequencer_SequencingRulesCheckSubprocess;
Sequencer.prototype.TerminateDescendentAttemptsProcess = Sequencer_TerminateDescendentAttemptsProcess;
Sequencer.prototype.EndAttemptProcess = Sequencer_EndAttemptProcess;
Sequencer.prototype.CheckActivityProcess = Sequencer_CheckActivityProcess;
Sequencer.prototype.EvaluateSequencingRuleCondition = Sequencer_EvaluateSequencingRuleCondition;
Sequencer.prototype.ResetException = Sequencer_ResetException;
Sequencer.prototype.LogSeq = Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit = Sequencer_LogSeqAudit;
Sequencer.prototype.LogSeqReturn = Sequencer_LogSeqReturn;
Sequencer.prototype.WriteHistoryLog = Sequencer_WriteHistoryLog;
Sequencer.prototype.WriteHistoryReturnValue = Sequencer_WriteHistoryReturnValue;
Sequencer.prototype.SetCurrentActivity = Sequencer_SetCurrentActivity;
Sequencer.prototype.IsCurrentActivityDefined = Sequencer_IsCurrentActivityDefined;
Sequencer.prototype.IsSuspendedActivityDefined = Sequencer_IsSuspendedActivityDefined;
Sequencer.prototype.ClearSuspendedActivity = Sequencer_ClearSuspendedActivity;
Sequencer.prototype.GetRootActivity = Sequencer_GetRootActivity;
Sequencer.prototype.DoesActivityExist = Sequencer_DoesActivityExist;
Sequencer.prototype.GetActivityFromIdentifier = Sequencer_GetActivityFromIdentifier;
Sequencer.prototype.AreActivitiesSiblings = Sequencer_AreActivitiesSiblings;
Sequencer.prototype.FindCommonAncestor = Sequencer_FindCommonAncestor;
Sequencer.prototype.GetActivityPath = Sequencer_GetActivityPath;
Sequencer.prototype.GetPathToAncestorExclusive = Sequencer_GetPathToAncestorExclusive;
Sequencer.prototype.GetPathToAncestorInclusive = Sequencer_GetPathToAncestorInclusive;
Sequencer.prototype.ActivityHasSuspendedChildren = Sequencer_ActivityHasSuspendedChildren;
Sequencer.prototype.CourseIsSingleSco = Sequencer_CourseIsSingleSco;
Sequencer.prototype.TranslateSequencingRuleActionIntoSequencingRequest = Sequencer_TranslateSequencingRuleActionIntoSequencingRequest;
Sequencer.prototype.TranslateSequencingRuleActionIntoTerminationRequest = Sequencer_TranslateSequencingRuleActionIntoTerminationRequest;
Sequencer.prototype.IsActivity1BeforeActivity2 = Sequencer_IsActivity1BeforeActivity2;
Sequencer.prototype.GetOrderedListOfActivities = Sequencer_GetOrderedListOfActivities;
Sequencer.prototype.PreOrderTraversal = Sequencer_PreOrderTraversal;
Sequencer.prototype.IsActivityLastOverall = Sequencer_IsActivityLastOverall;
Sequencer.prototype.GetGlobalObjectiveByIdentifier = Sequencer_GetGlobalObjectiveByIdentifier;
Sequencer.prototype.AddGlobalObjective = Sequencer_AddGlobalObjective;
Sequencer.prototype.ResetGlobalObjectives = Sequencer_ResetGlobalObjectives;
Sequencer.prototype.FindActivitiesAffectedByWriteMaps = Sequencer_FindActivitiesAffectedByWriteMaps;
Sequencer.prototype.FindDistinctParentsOfActivitySet = Sequencer_FindDistinctParentsOfActivitySet;
Sequencer.prototype.FindDistinctAncestorsOfActivitySet = Sequencer_FindDistinctAncestorsOfActivitySet;
Sequencer.prototype.GetMinimalSubsetOfActivitiesToRollup = Sequencer_GetMinimalSubsetOfActivitiesToRollup;
Sequencer.prototype.CheckForRelevantSequencingRules = Sequencer_CheckForRelevantSequencingRules;
Sequencer.prototype.DoesThisActivityHaveSequencingRulesRelevantToChoice = Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice;

function Sequencer_ResetException() {
    this.Exception = null;
    this.ExceptionText = null;
}

function Sequencer_LogSeq(str, _ed) {
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteLookAheadDetailed(str, _ed);
    } else {
        return Debug.WriteSequencingDetailed(str, _ed);
    }
}

function Sequencer_LogSeqAudit(str, _ef) {
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteLookAheadAudit(str, _ef);
    } else {
        return Debug.WriteSequencingAudit(str, _ef);
    }
}

function Sequencer_LogSeqReturn(str, _f1) {
    if (_f1 === null || _f1 === undefined) {
        Debug.AssertError("`1564`");
    }
    str = str + "";
    if (this.LookAhead === true) {
        return _f1.setReturn(str);
    } else {
        return _f1.setReturn(str);
    }
}

function Sequencer_WriteHistoryLog(str, _f3) {
    HistoryLog.WriteEventDetailed(str, _f3);
}

function Sequencer_WriteHistoryReturnValue(str, _f5) {
    HistoryLog.WriteEventDetailedReturnValue(str, _f5);
}

function Sequencer_SetCurrentActivity(_f6, _f7) {
    Debug.AssertError("Parent log not passed.", (_f7 === undefined || _f7 === null));
    this.LogSeq("`1456`" + _f6, _f7);
    this.CurrentActivity = _f6;
}

function Sequencer_IsCurrentActivityDefined(_f8) {
    Debug.AssertError("Parent log not passed.", (_f8 === undefined || _f8 === null));
    var _f9 = this.GetCurrentActivity();
    var _fa = (_f9 !== null);
    if (_fa) {
        this.LogSeq("`1470`", _f8);
    } else {
        this.LogSeq("`1388`", _f8);
    }
    return _fa;
}

function Sequencer_IsSuspendedActivityDefined(_fb) {
    Debug.AssertError("Parent log not passed.", (_fb === undefined || _fb === null));
    var _fc = this.GetSuspendedActivity(_fb);
    var _fd = (_fc !== null);
    if (_fd) {
        this.LogSeq("`1436`", _fb);
    } else {
        this.LogSeq("`1363`", _fb);
    }
    return _fd;
}

function Sequencer_ClearSuspendedActivity(_fe) {
    Debug.AssertError("Parent log not passed.", (_fe === undefined || _fe === null));
    this.LogSeq("`1464`", _fe);
    this.SuspendedActivity = null;
}

function Sequencer_GetRootActivity(_ff) {
    Debug.AssertError("Parent log not passed.", (_ff === undefined || _ff === null));
    var _100 = this.Activities.GetRootActivity();
    this.LogSeq("`1673`" + _100, _ff);
    return _100;
}

function Sequencer_DoesActivityExist(_101, _102) {
    Debug.AssertError("Parent log not passed.", (_102 === undefined || _102 === null));
    var _103 = this.Activities.DoesActivityExist(_101, _102);
    if (_103) {
        this.LogSeq("`1702`" + _101 + "`1399`", _102);
    } else {
        this.LogSeq("`1702`" + _101 + "`1261`", _102);
    }
    return _103;
}

function Sequencer_GetActivityFromIdentifier(_104, _105) {
    Debug.AssertError("Parent log not passed.", (_105 === undefined || _105 === null));
    var _106 = this.Activities.GetActivityFromIdentifier(_104, _105);
    if (_106 !== null) {
        this.LogSeq("`1702`" + _104 + "`1485`" + _106, _105);
    } else {
        this.LogSeq("`1702`" + _104 + "`1229`", _105);
    }
    return _106;
}

function Sequencer_AreActivitiesSiblings(_107, _108, _109) {
    Debug.AssertError("Parent log not passed.", (_109 === undefined || _109 === null));
    if (_107 === null || _107 === undefined || _108 === null || _108 === undefined) {
        return false;
    }
    var _10a = _107.ParentActivity;
    var _10b = _108.ParentActivity;
    var _10c = (_10a == _10b);
    if (_10c) {
        this.LogSeq("`1714`" + _107 + "`1758`" + _108 + "`1724`", _109);
    } else {
        this.LogSeq("`1714`" + _107 + "`1758`" + _108 + "`1645`", _109);
    }
    return _10c;
}

function Sequencer_FindCommonAncestor(_10d, _10e, _10f) {
    Debug.AssertError("Parent log not passed.", (_10f === undefined || _10f === null));
    var _110 = new Array();
    var _111 = new Array();
    if (_10d !== null && _10d.IsTheRoot()) {
        this.LogSeq(_10d + "`942`" + _10d + "`1758`" + _10e + "`1760`" + _10d, _10f);
        return _10d;
    }
    if (_10e !== null && _10e.IsTheRoot()) {
        this.LogSeq(_10e + "`942`" + _10d + "`1758`" + _10e + "`1760`" + _10e, _10f);
        return _10e;
    }
    if (_10d !== null) {
        _110 = this.Activities.GetActivityPath(_10d, false);
    }
    if (_10e !== null) {
        _111 = this.Activities.GetActivityPath(_10e, false);
    }
    for (var i = 0; i < _110.length; i++) {
        for (var j = 0; j < _111.length; j++) {
            if (_110[i] == _111[j]) {
                this.LogSeq("`1346`" + _10d + "`1758`" + _10e + "`1760`" + _110[i], _10f);
                return _110[i];
            }
        }
    }
    this.LogSeq("`1739`" + _10d + "`1758`" + _10e + "`1398`", _10f);
    return null;
}

function Sequencer_GetActivityPath(_114, _115) {
    return this.Activities.GetActivityPath(_114, _115);
}

function Sequencer_GetPathToAncestorExclusive(_116, _117, _118) {
    var _119 = new Array();
    var _11a = 0;
    if (_116 !== null && _117 !== null && _116 !== _117) {
        if (_118 === true) {
            _119[_11a] = _116;
            _11a++;
        }
        while (_116.ParentActivity !== null && _116.ParentActivity !== _117) {
            _116 = _116.ParentActivity;
            _119[_11a] = _116;
            _11a++;
        }
    }
    return _119;
}

function Sequencer_GetPathToAncestorInclusive(_11b, _11c, _11d) {
    var _11e = new Array();
    var _11f = 0;
    if (_11d == null || _11d == undefined) {
        _11d === true;
    }
    _11e[_11f] = _11b;
    _11f++;
    while (_11b.ParentActivity !== null && _11b != _11c) {
        _11b = _11b.ParentActivity;
        _11e[_11f] = _11b;
        _11f++;
    }
    if (_11d === false) {
        _11e.splice(0, 1);
    }
    return _11e;
}

function Sequencer_ActivityHasSuspendedChildren(_120, _121) {
    Debug.AssertError("Parent log not passed.", (_121 === undefined || _121 === null));
    var _122 = _120.GetChildren();
    var _123 = false;
    for (var i = 0; i < _122.length; i++) {
        if (_122[i].IsSuspended()) {
            _123 = true;
        }
    }
    if (_123) {
        this.LogSeq("`1732`" + _120 + "`1521`", _121);
    } else {
        this.LogSeq("`1732`" + _120 + "`1327`", _121);
    }
    return _123;
}

function Sequencer_CourseIsSingleSco() {
    if (this.Activities.ActivityList.length <= 2) {
        return true;
    } else {
        return false;
    }
}

function Sequencer_TranslateSequencingRuleActionIntoSequencingRequest(_125) {
    switch (_125) {
        case SEQUENCING_RULE_ACTION_RETRY:
            return SEQUENCING_REQUEST_RETRY;
        case SEQUENCING_RULE_ACTION_CONTINUE:
            return SEQUENCING_REQUEST_CONTINUE;
        case SEQUENCING_RULE_ACTION_PREVIOUS:
            return SEQUENCING_REQUEST_PREVIOUS;
        default:
            Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoSequencingRequest - should never have an untranslatable sequencing request. ruleAction=" + _125);
            return null;
    }
}

function Sequencer_TranslateSequencingRuleActionIntoTerminationRequest(_126) {
    switch (_126) {
        case SEQUENCING_RULE_ACTION_EXIT_PARENT:
            return TERMINATION_REQUEST_EXIT_PARENT;
        case SEQUENCING_RULE_ACTION_EXIT_ALL:
            return TERMINATION_REQUEST_EXIT_ALL;
        default:
            Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoTerminationRequest - should never have an untranslatable sequencing request. ruleAction=" + _126);
            return null;
    }
}

function Sequencer_IsActivity1BeforeActivity2(_127, _128, _129) {
    Debug.AssertError("Parent log not passed.", (_129 === undefined || _129 === null));
    var _12a = this.GetOrderedListOfActivities(_129);
    for (var i = 0; i < _12a.length; i++) {
        if (_12a[i] == _127) {
            this.LogSeq("`1732`" + _127 + "`1522`" + _128, _129);
            return true;
        }
        if (_12a[i] == _128) {
            this.LogSeq("`1732`" + _127 + "`1545`" + _128, _129);
            return false;
        }
    }
    Debug.AssertError("ERROR IN Sequencer_IsActivity1BeforeActivity2");
    return null;
}

function Sequencer_GetOrderedListOfActivities(_12c) {
    Debug.AssertError("Parent log not passed.", (_12c === undefined || _12c === null));
    var list;
    var root = this.GetRootActivity(_12c);
    list = this.PreOrderTraversal(root);
    return list;
}

function Sequencer_PreOrderTraversal(_12f) {
    var list = new Array();
    list[0] = _12f;
    var _131 = _12f.GetAvailableChildren();
    var _132;
    for (var i = 0; i < _131.length; i++) {
        _132 = this.PreOrderTraversal(_131[i]);
        list = list.concat(_132);
    }
    return list;
}

function Sequencer_IsActivityLastOverall(_134, _135) {
    Debug.AssertError("Parent log not passed.", (_135 === undefined || _135 === null));
    var _136 = this.GetOrderedListOfActivities(_135);
    var _137 = null;
    for (var i = (_136.length - 1); i >= 0; i--) {
        if (_136[i].IsAvailable()) {
            _137 = _136[i];
            i = -1;
        }
    }
    if (_134 == _137) {
        this.LogSeq("`1732`" + _134 + "`1419`", _135);
        return true;
    }
    this.LogSeq("`1732`" + _134 + "`1353`", _135);
    return false;
}

function Sequencer_GetGlobalObjectiveByIdentifier(_139) {
    for (var obj in this.GlobalObjectives) {
        if (this.GlobalObjectives[obj].ID == _139) {
            return this.GlobalObjectives[obj];
        }
    }
    return null;
}

function Sequencer_AddGlobalObjective(ID, _13c, _13d, _13e, _13f) {
    var _140 = this.GlobalObjectives.length;
    var obj = new GlobalObjective(_140, ID, _13c, _13d, _13e, _13f);
    this.GlobalObjectives[_140] = obj;
    this.GlobalObjectives[_140].SetDirtyData();
}

function Sequencer_ResetGlobalObjectives() {
    var _142;
    for (var obj in this.GlobalObjectives) {
        _142 = this.GlobalObjectives[obj];
        _142.ResetState();
    }
}

function Sequencer_FindActivitiesAffectedByWriteMaps(_144) {
    var _145 = new Array();
    var _146;
    var _147 = _144.GetObjectives();
    var _148 = new Array();
    var i;
    var j;
    for (i = 0; i < _147.length; i++) {
        _146 = _147[i].GetMaps();
        for (j = 0; j < _146.length; j++) {
            if (_146[j].WriteSatisfiedStatus === true || _146[j].WriteNormalizedMeasure === true) {
                _145[_145.length] = _146[j].TargetObjectiveId;
            }
        }
    }
    if (_145.length === 0) {
        return _148;
    }
    var _14b;
    var _14c;
    var _14d;
    var _14e;
    for (var _14f in this.Activities.ActivityList) {
        _14b = this.Activities.ActivityList[_14f];
        if (_14b != _144) {
            _14c = _14b.GetObjectives();
            for (var _150 = 0; _150 < _14c.length; _150++) {
                _14d = _14c[_150].GetMaps();
                for (var map = 0; map < _14d.length; map++) {
                    if (_14d[map].ReadSatisfiedStatus === true || _14d[map].ReadNormalizedMeasure === true) {
                        _14e = _14d[map].TargetObjectiveId;
                        for (var _152 = 0; _152 < _145.length; _152++) {
                            if (_145[_152] == _14e) {
                                _148[_148.length] = _14b;
                            }
                        }
                    }
                }
            }
        }
    }
    return _148;
}

function Sequencer_FindDistinctAncestorsOfActivitySet(_153) {
    var _154 = new Array();
    for (var _155 = 0; _155 < _153.length; _155++) {
        var _156 = _153[_155];
        if (_156 !== null) {
            var _157 = this.GetActivityPath(_156, true);
            for (var i = 0; i < _157.length; i++) {
                var _159 = true;
                for (var j = 0; j < _154.length; j++) {
                    if (_157[i] == _154[j]) {
                        _159 = false;
                        break;
                    }
                }
                if (_159) {
                    _154[_154.length] = _157[i];
                }
            }
        }
    }
    return _154;
}

function Sequencer_FindDistinctParentsOfActivitySet(_15b) {
    var _15c = new Array();
    var _15d;
    var _15e;
    for (var _15f in _15b) {
        _15e = true;
        _15d = this.Activities.GetParentActivity(_15b[_15f]);
        if (_15d !== null) {
            for (var i = 0; i < _15c.length; i++) {
                if (_15c[i] == _15d) {
                    _15e = false;
                    break;
                }
            }
            if (_15e) {
                _15c[_15c.length] = _15d;
            }
        }
    }
    return _15c;
}

function Sequencer_GetMinimalSubsetOfActivitiesToRollup(_161, _162) {
    var _163 = new Array();
    var _164 = new Array();
    var _165;
    var _166;
    var _167;
    if (_162 !== null) {
        _163 = _163.concat(_162);
    }
    for (var _168 in _161) {
        _166 = _161[_168];
        _167 = false;
        for (var _169 in _163) {
            if (_163[_169] == _166) {
                _167 = true;
                break;
            }
        }
        if (_167 === false) {
            _164[_164.length] = _166;
            _165 = this.GetActivityPath(_166, true);
            _163 = _163.concat(_165);
        }
    }
    return _164;
}

function Sequencer_EvaluatePossibleNavigationRequests(_16a) {
    var _16b = this.LogSeqAudit("`991`");
    var _16c;
    var _16d = null;
    var _16e;
    var _16f;
    var id;
    for (id in _16a) {
        if (_16a[id].WillAlwaysSucceed === true) {
            _16a[id].WillSucceed = true;
        } else {
            if (_16a[id].WillNeverSucceed === true) {
                _16a[id].WillSucceed = false;
                _16a[id].Exception = "NB.2.1-10";
                _16a[id].ExceptionText = IntegrationImplementation.GetString("Your selection is not permitted. Please select 'Next' or 'Previous' to move through '{0}.'");
            } else {
                _16a[id].WillSucceed = null;
            }
        }
        _16a[id].Hidden = false;
        _16a[id].Disabled = false;
    }
    this.LogSeq("`789`", _16b);
    for (id in _16a) {
        if (_16a[id].WillSucceed === null) {
            _16c = this.NavigationRequestProcess(_16a[id].NavigationRequest, _16a[id].TargetActivityItemIdentifier, _16b);
            if (_16c.NavigationRequest == NAVIGATION_REQUEST_NOT_VALID) {
                this.LogSeq("`756`", _16b);
                _16a[id].WillSucceed = false;
                _16a[id].TargetActivity = this.GetActivityFromIdentifier(_16a[id].TargetActivityItemIdentifier, _16b);
                _16a[id].Exception = _16c.Exception;
                _16a[id].ExceptionText = _16c.ExceptionText;
            } else {
                this.LogSeq("`724`", _16b);
                _16a[id].WillSucceed = true;
                _16a[id].TargetActivity = _16c.TargetActivity;
                _16a[id].SequencingRequest = _16c.SequencingRequest;
                _16a[id].Exception = "";
                _16a[id].ExceptionText = "";
            }
        }
    }
    this.LogSeq("`215`", _16b);
    var _171 = this.GetCurrentActivity();
    if (_171 !== null && _171.IsActive() === true) {
        this.LogSeq("`958`", _16b);
        _16d = this.TerminationRequestProcess(TERMINATION_REQUEST_EXIT, _16b);
        this.LogSeq("`914`", _16b);
        if (_16d.TerminationRequest == TERMINATION_REQUEST_NOT_VALID) {
            this.LogSeq("`718`", _16b);
            if (_16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed) {
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = false;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = _16d.Exception;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = _16d.ExceptionText;
            }
            if (_16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed) {
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed = false;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].Exception = _16d.Exception;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].ExceptionText = _16d.ExceptionText;
            }
            if (_16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed) {
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed = false;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].Exception = _16d.Exception;
                _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].ExceptionText = _16d.ExceptionText;
            }
            for (id = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; id < _16a.length; id++) {
                if (_16a[id].WillSucceed) {
                    _16a[id].WillSucceed = false;
                    _16a[id].Exception = _16d.Exception;
                    _16a[id].ExceptionText = terminatonRequestResult.ExceptionText;
                } else {
                    _16a[id].TerminationSequencingRequest = _16d.SequencingRequest;
                }
            }
        }
        _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].TerminationSequencingRequest = _16d.SequencingRequest;
        _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].TerminationSequencingRequest = _16d.SequencingRequest;
        _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].TerminationSequencingRequest = _16d.SequencingRequest;
        for (id = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; id < _16a.length; id++) {
            _16a[id].TerminationSequencingRequest = _16d.SequencingRequest;
        }
    }
    this.LogSeq("`660`", _16b);
    for (id in _16a) {
        if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE && _16a[id].WillSucceed === true && _16a[id].WillAlwaysSucceed === false && _16a[id].WillNeverSucceed === false) {
            this.LogSeq("`867`", _16b);
            var _172 = this.CheckActivityProcess(_16a[id].TargetActivity, _16b);
            if (_172 === true) {
                this.LogSeq("`746`", _16b);
                _16a[id].WillSucceed = false;
                _16a[id].Disabled = true;
                this.SetAllDescendentsToDisabled(_16a, _16a[id].TargetActivity);
            }
        }
    }
    this.LogSeq("`678`", _16b);
    var _173 = null;
    for (id in _16a) {
        if (_16a[id].WillSucceed === true && _16a[id].WillAlwaysSucceed === false && _16a[id].WillNeverSucceed === false) {
            this.LogSeq("`625`", _16b);
            if (_16a[id].TerminationSequencingRequest !== null) {
                this.LogSeq("`418`", _16b);
                if (_173 === null) {
                    _16e = this.SequencingRequestProcess(_16a[id].TerminationSequencingRequest, null, _16b);
                } else {
                    _16e = _173;
                }
                if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE) {
                    this.LogSeq("`1042`", _16b);
                    var _174 = this.SequencingRulesCheckProcess(_16a[id].TargetActivity, RULE_SET_HIDE_FROM_CHOICE, _16b);
                    if (_174 !== null) {
                        _16a[id].Exception = "SB.2.9-3";
                        _16a[id].ExceptionText = "The activity " + _16a[id].TargetActivity.GetTitle() + " should be hidden and is not a valid selection";
                        _16a[id].Hidden = true;
                    }
                }
            } else {
                this.LogSeq("`1651`", _16b);
                this.LogSeq("`719`", _16b);
                _16e = this.SequencingRequestProcess(_16a[id].SequencingRequest, _16a[id].TargetActivity, _16b);
            }
            this.LogSeq("`838`", _16b);
            if (_16e.Exception !== null) {
                this.LogSeq("`1295`", _16b);
                _16a[id].WillSucceed = false;
                _16a[id].Exception = _16e.Exception;
                _16a[id].ExceptionText = _16e.ExceptionText;
                _16a[id].Hidden = _16e.Hidden;
            } else {
                if (_16e.DeliveryRequest !== null) {
                    this.LogSeq("`1123`", _16b);
                    _16f = this.DeliveryRequestProcess(_16e.DeliveryRequest, _16b);
                    this.LogSeq("`706`" + _16f.Valid + ")", _16b);
                    _16a[id].WillSucceed = _16f.Valid;
                }
            }
        }
    }
    this.LogSeq("`362`", _16b);
    var _175;
    for (id in _16a) {
        if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE) {
            if (_16a[id].WillSucceed === false) {
                _175 = _16a[id].Exception;
                if (_175 == CONTROL_CHOICE_EXIT_ERROR_NAV || _175 == CONTROL_CHOICE_EXIT_ERROR_CHOICE || _175 == PREVENT_ACTIVATION_ERROR || _175 == CONSTRAINED_CHOICE_ERROR) {
                    this.LogSeq("`1498`" + id + "`1735`" + _175, _16b);
                    _16a[id].Hidden = true;
                }
            }
        }
    }
    var _176 = this.Activities.GetParentActivity(_171);
    if (_176 != null) {
        if (_176.GetSequencingControlFlow() === true) {
            this.LogSeq("`430`", _16b);
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = true;
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = "";
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = "";
        } else {
            this.LogSeq("`405`", _16b);
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = false;
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = "SB.2.2-1";
            _16a[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = "Parent activity does not allow flow traversal";
        }
    }
    this.LogSeqReturn("", _16b);
    return _16a;
}

function Sequencer_SetAllDescendentsToDisabled(_177, _178) {
    for (var i = 0; i < _178.ChildActivities.length; i++) {
        var _17a = Control.FindPossibleChoiceRequestForActivity(_178.ChildActivities[i]);
        _17a.WillSucceed = false;
        _17a.Disabled = true;
        this.SetAllDescendentsToDisabled(_177, _178.ChildActivities[i]);
    }
}

function Sequencer_InitializePossibleNavigationRequestAbsolutes(_17b, _17c, _17d) {
    var _17e = this.LogSeqAudit("`1025`");
    this.CheckForRelevantSequencingRules(_17c, false);
    var _17f;
    var _180;
    var _181 = false;
    for (var _182 in _17d) {
        _17f = _17d[_182];
        var _183 = this.LogSeqAudit(_17f.StringIdentifier, _17e);
        if (_17f.GetSequencingControlChoice() === false) {
            this.LogSeqAudit("`1320`", _183);
            var _184 = this.LogSeqAudit("`835`" + _17f.ChildActivities.length + ")", _183);
            for (var i = 0; i < _17f.ChildActivities.length; i++) {
                _180 = Control.FindPossibleChoiceRequestForActivity(_17f.ChildActivities[i]);
                _180.WillNeverSucceed = true;
                this.LogSeqAudit(_17f.ChildActivities[i].StringIdentifier, _184);
            }
        }
        _181 = _181 || (_17f.GetSequencingControlChoiceExit() === true);
        this.LogSeqAudit("`1504`" + _181, _183);
        _180 = Control.FindPossibleChoiceRequestForActivity(_17f);
        if (_17f.IsDeliverable() === false && _17f.GetSequencingControlFlow() === false) {
            this.LogSeqAudit("`356`", _183);
            _180.WillNeverSucceed = true;
        }
        if (_17f.HasChildActivitiesDeliverableViaFlow === false) {
            this.LogSeqAudit("`505`", _183);
            _180.WillNeverSucceed = true;
        }
        if (_17f.HasSeqRulesRelevantToChoice === false && _180.WillNeverSucceed === false) {
            this.LogSeqAudit("`275`", _183);
            _180.WillAlwaysSucceed = true;
        } else {
            this.LogSeqAudit("`246`", _183);
            _180.WillAlwaysSucceed = false;
        }
        this.LogSeqAudit("`1609`" + _180.WillAlwaysSucceed, _183);
        this.LogSeqAudit("`1622`" + _180.WillNeverSucceed, _183);
    }
    if (_181 === true) {
        this.LogSeqAudit("`549`", _17e);
        for (var id in _17b) {
            _17b[id].WillAlwaysSucceed = false;
        }
    }
}

function Sequencer_CheckForRelevantSequencingRules(_187, _188) {
    if (_188 === true) {
        _187.HasSeqRulesRelevantToChoice = true;
    } else {
        if (this.DoesThisActivityHaveSequencingRulesRelevantToChoice(_187)) {
            _187.HasSeqRulesRelevantToChoice = true;
        } else {
            _187.HasSeqRulesRelevantToChoice = false;
        }
    }
    var _189 = false;
    for (var i = 0; i < _187.ChildActivities.length; i++) {
        this.CheckForRelevantSequencingRules(_187.ChildActivities[i], _187.HasSeqRulesRelevantToChoice);
        _189 = (_189 || _187.ChildActivities[i].HasChildActivitiesDeliverableViaFlow);
    }
    _187.HasChildActivitiesDeliverableViaFlow = (_187.IsDeliverable() || (_187.GetSequencingControlFlow() && _189));
}

function Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice(_18b) {
    if (_18b.GetSequencingControlForwardOnly() === true) {
        return true;
    }
    if (_18b.GetPreventActivation() === true) {
        return true;
    }
    if (_18b.GetConstrainedChoice() === true) {
        return true;
    }
    if (_18b.GetSequencingControlChoiceExit() === false) {
        return true;
    }
    var _18c = _18b.GetPreConditionRules();
    for (var i = 0; i < _18c.length; i++) {
        if (_18c[i].Action == SEQUENCING_RULE_ACTION_DISABLED || _18c[i].Action == SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE || _18c[i].Action == SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL) {
            return true;
        }
    }
    return false;
}

function Sequencer_ActivityProgressRollupProcess(_18e, _18f) {
    Debug.AssertError("Calling log not passed.", (_18f === undefined || _18f === null));
    var _190 = this.LogSeqAudit("`1176`" + _18e + ")", _18f);
    var _191;
    this.LogSeq("`336`", _190);
    _191 = this.RollupRuleCheckSubprocess(_18e, RULE_SET_INCOMPLETE, _190);
    this.LogSeq("`850`", _190);
    if (_191 === true) {
        this.LogSeq("`807`", _190);
        _18e.SetAttemptProgressStatus(true);
        this.LogSeq("`771`", _190);
        _18e.SetAttemptCompletionStatus(false);
    }
    this.LogSeq("`350`", _190);
    _191 = this.RollupRuleCheckSubprocess(_18e, RULE_SET_COMPLETED, _190);
    this.LogSeq("`852`", _190);
    if (_191 === true) {
        this.LogSeq("`808`", _190);
        _18e.SetAttemptProgressStatus(true);
        this.LogSeq("`781`", _190);
        _18e.SetAttemptCompletionStatus(true);
    }
    if (Sequencer_GetApplicableSetofRollupRules(_18e, RULE_SET_INCOMPLETE).length === 0 && Sequencer_GetApplicableSetofRollupRules(_18e, RULE_SET_COMPLETED).length === 0) {
        this.LogSeq("`1173`", _190);
        this.ActivityProgressRollupProcessUsingDefault(_18e, _190);
    }
    this.LogSeq("`1069`", _190);
    this.LogSeqReturn("", _190);
    return;
}

function Sequencer_ActivityProgressRollupProcessUsingDefault(_192, _193) {
    var _194 = this.LogSeqAudit("`909`" + _192 + ")", _193);
    var _195;
    var _196;
    var _197;
    this.LogSeq("`1280`", _194);
    if (_192.IsALeaf()) {
        this.LogSeq("`1297`", _194);
        this.LogSeqReturn("", _194);
        return;
    }
    this.LogSeq("`1093`", _194);
    var _198 = _192.GetChildren();
    this.LogSeq("`1106`", _194);
    var _199 = true;
    this.LogSeq("`1224`", _194);
    var _19a = true;
    this.LogSeq("`1281`", _194);
    var _19b = true;
    for (var i = 0; i < _198.length; i++) {
        this.LogSeq("`1365`" + _198[i] + "`1734`", _194);
        if (_198[i].IsTracked()) {
            this.LogSeq("`1052`", _194);
            _195 = _198[i].IsCompleted();
            this.LogSeq("`1053`", _194);
            _196 = _198[i].IsAttempted();
            this.LogSeq("`770`", _194);
            _197 = (_195 === false || _196 === true);
            this.LogSeq("`883`", _194);
            if (this.CheckChildForRollupSubprocess(_198[i], ROLLUP_RULE_ACTION_COMPLETED, _194)) {
                this.LogSeq("`884`", _194);
                _19a = (_19a && (_195 === true));
                _19b = false;
            }
            this.LogSeq("`875`", _194);
            if (this.CheckChildForRollupSubprocess(_198[i], ROLLUP_RULE_ACTION_INCOMPLETE, _194)) {
                this.LogSeq("`848`", _194);
                _199 = (_199 && _197);
                _19b = false;
            }
        }
    }
    if (_19b && Control.Package.Properties.RollupEmptySetToUnknown) {
        this.LogSeq("`542`" + Control.Package.Properties.RollupEmptySetToUnknown + ")", _194);
    } else {
        this.LogSeq("`1416`", _194);
        if (_199 === true) {
            this.LogSeq("`779`", _194);
            _192.SetAttemptProgressStatus(true);
            this.LogSeq("`747`", _194);
            _192.SetAttemptCompletionStatus(false);
        }
        this.LogSeq("`1437`", _194);
        if (_19a === true) {
            this.LogSeq("`780`", _194);
            _192.SetAttemptProgressStatus(true);
            this.LogSeq("`759`", _194);
            _192.SetAttemptCompletionStatus(true);
        }
    }
    this.LogSeqReturn("", _194);
}

function Sequencer_CheckActivityProcess(_19d, _19e) {
    Debug.AssertError("Calling log not passed.", (_19e === undefined || _19e === null));
    var _19f = this.LogSeqAudit("`1402`" + _19d + ")", _19e);
    this.LogSeq("`313`", _19f);
    var _1a0 = this.SequencingRulesCheckProcess(_19d, RULE_SET_DISABLED, _19f);
    this.LogSeq("`784`", _19f);
    if (_1a0 !== null) {
        this.LogSeq("`722`", _19f);
        this.LogSeqReturn("`1763`", _19f);
        return true;
    }
    this.LogSeq("`396`", _19f);
    var _1a1 = this.LimitConditionsCheckProcess(_19d, _19f);
    this.LogSeq("`865`", _19f);
    if (_1a1) {
        this.LogSeq("`615`", _19f);
        this.LogSeqReturn("`1763`", _19f);
        return true;
    }
    this.LogSeq("`753`", _19f);
    this.LogSeqReturn("`1759`", _19f);
    return false;
}

function Sequencer_CheckChildForRollupSubprocess(_1a2, _1a3, _1a4) {
    Debug.AssertError("Calling log not passed.", (_1a4 === undefined || _1a4 === null));
    var _1a5 = this.LogSeqAudit("`1114`" + _1a2 + ", " + _1a3 + ")", _1a4);
    var _1a6;
    this.LogSeq("`1350`", _1a5);
    var _1a7 = false;
    this.LogSeq("`815`", _1a5);
    if (_1a3 == ROLLUP_RULE_ACTION_SATISFIED || _1a3 == ROLLUP_RULE_ACTION_NOT_SATISFIED) {
        this.LogSeq("`406`", _1a5);
        if (_1a2.GetRollupObjectiveSatisfied() === true) {
            this.LogSeq("`591`", _1a5);
            _1a7 = true;
            var _1a8 = _1a2.GetRequiredForSatisfied();
            var _1a9 = _1a2.GetRequiredForNotSatisfied();
            this.LogSeq("`97`", _1a5);
            if ((_1a3 == ROLLUP_RULE_ACTION_SATISFIED && _1a8 == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED) || (_1a3 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _1a9 == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)) {
                this.LogSeq("`278`", _1a5);
                if (_1a2.GetAttemptCount() > 0 && _1a2.IsSuspended() === true) {
                    this.LogSeq("`1200`", _1a5);
                    _1a7 = false;
                }
            } else {
                this.LogSeq("`1595`", _1a5);
                this.LogSeq("`104`", _1a5);
                if ((_1a3 == ROLLUP_RULE_ACTION_SATISFIED && _1a8 == ROLLUP_CONSIDERATION_IF_ATTEMPTED) || (_1a3 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _1a9 == ROLLUP_CONSIDERATION_IF_ATTEMPTED)) {
                    this.LogSeq("`680`", _1a5);
                    if (_1a2.GetAttemptCount() === 0) {
                        this.LogSeq("`1143`", _1a5);
                        _1a7 = false;
                    }
                } else {
                    this.LogSeq("`1562`", _1a5);
                    this.LogSeq("`98`", _1a5);
                    if ((_1a3 == ROLLUP_RULE_ACTION_SATISFIED && _1a8 == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED) || (_1a3 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _1a9 == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)) {
                        this.LogSeq("`467`", _1a5);
                        _1a6 = this.SequencingRulesCheckProcess(_1a2, RULE_SET_SKIPPED, _1a5);
                        this.LogSeq("`634`", _1a5);
                        if (_1a6 !== null) {
                            this.LogSeq("`1108`", _1a5);
                            _1a7 = false;
                        }
                    }
                }
            }
        }
    }
    this.LogSeq("`853`", _1a5);
    if (_1a3 == ROLLUP_RULE_ACTION_COMPLETED || _1a3 == ROLLUP_RULE_ACTION_INCOMPLETE) {
        this.LogSeq("`419`", _1a5);
        if (_1a2.RollupProgressCompletion() === true) {
            this.LogSeq("`592`", _1a5);
            _1a7 = true;
            var _1aa = _1a2.GetRequiredForCompleted();
            var _1ab = _1a2.GetRequiredForIncomplete();
            this.LogSeq("`106`", _1a5);
            if ((_1a3 == ROLLUP_RULE_ACTION_COMPLETED && _1aa == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED) || (_1a3 == ROLLUP_RULE_ACTION_INCOMPLETE && _1ab == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)) {
                this.LogSeq("`279`", _1a5);
                if (_1a2.GetAttemptCount() > 0 && _1a2.IsSuspended() === true) {
                    this.LogSeq("`1384`", _1a5);
                    _1a7 = false;
                }
            } else {
                this.LogSeq("`1596`", _1a5);
                this.LogSeq("`117`", _1a5);
                if ((_1a3 == ROLLUP_RULE_ACTION_COMPLETED && _1aa == ROLLUP_CONSIDERATION_IF_ATTEMPTED) || (_1a3 == ROLLUP_RULE_ACTION_INCOMPLETE && _1ab == ROLLUP_CONSIDERATION_IF_ATTEMPTED)) {
                    this.LogSeq("`681`", _1a5);
                    if (_1a2.GetAttemptCount() === 0) {
                        this.LogSeq("`1144`", _1a5);
                        _1a7 = false;
                    }
                } else {
                    this.LogSeq("`1563`", _1a5);
                    this.LogSeq("`107`", _1a5);
                    if ((_1a3 == ROLLUP_RULE_ACTION_COMPLETED && _1aa == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED) || (_1a3 == ROLLUP_RULE_ACTION_INCOMPLETE && _1ab == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)) {
                        this.LogSeq("`468`", _1a5);
                        _1a6 = this.SequencingRulesCheckProcess(_1a2, RULE_SET_SKIPPED, _1a5);
                        this.LogSeq("`635`", _1a5);
                        if (_1a6 !== null) {
                            this.LogSeq("`1109`", _1a5);
                            _1a7 = false;
                        }
                    }
                }
            }
        }
    }
    this.LogSeq("`602`", _1a5);
    this.LogSeqReturn(_1a7, _1a5);
    return _1a7;
}

function Sequencer_ChoiceActivityTraversalSubprocess(_1ac, _1ad, _1ae) {
    Debug.AssertError("Calling log not passed.", (_1ae === undefined || _1ae === null));
    var _1af = this.LogSeqAudit("`1101`" + _1ac + ", " + _1ad + ")", _1ae);
    var _1b0 = null;
    var _1b1 = null;
    var _1b2;
    this.LogSeq("`987`", _1af);
    if (_1ad == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`445`", _1af);
        _1b0 = this.SequencingRulesCheckProcess(_1ac, RULE_SET_STOP_FORWARD_TRAVERSAL, _1af);
        this.LogSeq("`732`", _1af);
        if (_1b0 !== null) {
            this.LogSeq("`558`", _1af);
            _1b2 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-1", IntegrationImplementation.GetString("You are not allowed to move into {0} yet.", _1ac.GetTitle()));
            this.LogSeqReturn(_1b2, _1af);
            return _1b2;
        }
        this.LogSeq("`612`", _1af);
        _1b2 = new Sequencer_ChoiceActivityTraversalSubprocessResult(true, null);
        this.LogSeqReturn(_1b2, _1af);
        return _1b2;
    }
    this.LogSeq("`977`", _1af);
    if (_1ad == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`1111`", _1af);
        if (!_1ac.IsTheRoot()) {
            _1b1 = this.Activities.GetParentActivity(_1ac);
            this.LogSeq("`584`", _1af);
            if (_1b1.GetSequencingControlForwardOnly()) {
                this.LogSeq("`548`", _1af);
                _1b2 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-2", IntegrationImplementation.GetString("You must start {0} at the beginning.", _1b1.GetTitle()));
                this.LogSeqReturn(_1b2, _1af);
                return _1b2;
            }
        } else {
            this.LogSeq("`1638`", _1af);
            this.LogSeq("`237`", _1af);
            _1b2 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-3", IntegrationImplementation.GetString("You have reached the beginning of the course."));
            this.LogSeqReturn(_1b2, _1af);
            return _1b2;
        }
        this.LogSeq("`613`", _1af);
        _1b2 = new Sequencer_ChoiceActivityTraversalSubprocessResult(true, null);
        this.LogSeqReturn(_1b2, _1af);
        return _1b2;
    }
}

function Sequencer_ChoiceActivityTraversalSubprocessResult(_1b3, _1b4, _1b5) {
    this.Reachable = _1b3;
    this.Exception = _1b4;
    this.ExceptionText = _1b5;
}
Sequencer_ChoiceActivityTraversalSubprocessResult.prototype.toString = function() {
    return "Reachable=" + this.Reachable + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ChoiceFlowSubprocess(_1b6, _1b7, _1b8) {
    Debug.AssertError("Calling log not passed.", (_1b8 === undefined || _1b8 === null));
    var _1b9 = this.LogSeqAudit("`1328`" + _1b6 + ", " + _1b7 + ")", _1b8);
    this.LogSeq("`128`", _1b9);
    var _1ba = this.ChoiceFlowTreeTraversalSubprocess(_1b6, _1b7, _1b9);
    this.LogSeq("`733`", _1b9);
    if (_1ba === null) {
        this.LogSeq("`711`", _1b9);
        this.LogSeqReturn(_1b6, _1b9);
        return _1b6;
    } else {
        this.LogSeq("`1690`", _1b9);
        this.LogSeq("`338`", _1b9);
        this.LogSeqReturn(_1ba, _1b9);
        return _1ba;
    }
}

function Sequencer_ChoiceFlowTreeTraversalSubprocess(_1bb, _1bc, _1bd) {
    Debug.AssertError("Calling log not passed.", (_1bd === undefined || _1bd === null));
    var _1be = this.LogSeqAudit("`1037`" + _1bb + ", " + _1bc + ")", _1bd);
    var _1bf = this.Activities.GetParentActivity(_1bb);
    var _1c0 = null;
    var _1c1 = null;
    var _1c2 = null;
    this.LogSeq("`964`", _1be);
    if (_1bc == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`74`", _1be);
        if (this.IsActivityLastOverall(_1bb, _1be) || _1bb.IsTheRoot() === true) {
            this.LogSeq("`684`", _1be);
            this.LogSeqReturn("`1762`", _1be);
            return null;
        }
        this.LogSeq("`479`", _1be);
        if (_1bf.IsActivityTheLastAvailableChild(_1bb)) {
            this.LogSeq("`137`", _1be);
            _1c0 = this.ChoiceFlowTreeTraversalSubprocess(_1bf, FLOW_DIRECTION_FORWARD, _1be);
            this.LogSeq("`143`", _1be);
            this.LogSeqReturn(_1c0, _1be);
            return _1c0;
        } else {
            this.LogSeq("`1639`", _1be);
            this.LogSeq("`301`", _1be);
            _1c1 = _1bb.GetNextSibling();
            this.LogSeq("`446`", _1be);
            this.LogSeqReturn(_1c1, _1be);
            return _1c1;
        }
    }
    this.LogSeq("`954`", _1be);
    if (_1bc == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`456`", _1be);
        if (_1bb.IsTheRoot()) {
            this.LogSeq("`685`", _1be);
            this.LogSeqReturn("`1762`", _1be);
            return null;
        }
        this.LogSeq("`472`", _1be);
        if (_1bf.IsActivityTheFirstAvailableChild(_1bb)) {
            this.LogSeq("`135`", _1be);
            _1c0 = this.ChoiceFlowTreeTraversalSubprocess(_1bf, FLOW_DIRECTION_BACKWARD, _1be);
            this.LogSeq("`138`", _1be);
            this.LogSeqReturn(_1c0, _1be);
            return _1c0;
        } else {
            this.LogSeq("`1640`", _1be);
            this.LogSeq("`268`", _1be);
            _1c2 = _1bb.GetPreviousSibling();
            this.LogSeq("`447`", _1be);
            this.LogSeqReturn(_1c2, _1be);
            return _1c2;
        }
    }
}

function Sequencer_ChoiceSequencingRequestProcess(_1c3, _1c4) {
    Debug.AssertError("Calling log not passed.", (_1c4 === undefined || _1c4 === null));
    var _1c5 = this.LogSeqAudit("`1159`" + _1c3 + ")", _1c4);
    var _1c6 = null;
    var _1c7;
    var _1c8 = null;
    var _1c9 = null;
    var _1ca = null;
    var _1cb = null;
    var _1cc;
    var i;
    var _1ce;
    this.LogSeq("`502`" + _1c3.LearningObject.ItemIdentifier, _1c5);
    if (_1c3 === null) {
        this.LogSeq("`448`", _1c5);
        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-1", IntegrationImplementation.GetString("Your selection is not permitted.  Please select an available menu item to continue."), false);
        this.LogSeqReturn(_1ce, _1c5);
        return _1ce;
    }
    this.LogSeq("`333`", _1c5);
    _1c7 = this.GetActivityPath(_1c3, true);
    this.LogSeq("`1035`", _1c5);
    for (i = (_1c7.length - 1); i >= 0; i--) {
        this.LogSeq("`795`", _1c5);
        if (_1c7[i].IsTheRoot() == false) {
            this.LogSeq("`262`", _1c5);
            if (_1c7[i].IsAvailable === false) {
                this.LogSeq("`395`", _1c5);
                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-2", "The activity " + _1c3.GetTitle() + " should not be available and is not a valid selection", true);
                this.LogSeqReturn(_1ce, _1c5);
                return _1ce;
            }
        }
        this.LogSeq("`247`", _1c5);
        _1c8 = this.SequencingRulesCheckProcess(_1c7[i], RULE_SET_HIDE_FROM_CHOICE, _1c5);
        this.LogSeq("`737`", _1c5);
        if (_1c8 !== null) {
            this.LogSeq("`220`", _1c5);
            _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-3", "The activity " + _1c3.GetTitle() + " should be hidden and is not a valid selection", true);
            this.LogSeqReturn(_1ce, _1c5);
            return _1ce;
        }
    }
    this.LogSeq("`750`", _1c5);
    if (!_1c3.IsTheRoot()) {
        this.LogSeq("`221`", _1c5);
        _1c6 = this.Activities.GetParentActivity(_1c3);
        if (_1c6.GetSequencingControlChoice() === false) {
            this.LogSeq("`424`", _1c5);
            _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-4", IntegrationImplementation.GetString("The activity '{0}' should be hidden and is not a valid selection.", _1c6.GetTitle()), false);
            this.LogSeqReturn(_1ce, _1c5);
            return _1ce;
        }
    }
    this.LogSeq("`579`", _1c5);
    if (this.IsCurrentActivityDefined(_1c5)) {
        this.LogSeq("`638`", _1c5);
        _1ca = this.GetCurrentActivity();
        _1c9 = this.FindCommonAncestor(_1ca, _1c3, _1c5);
    } else {
        this.LogSeq("`1721`", _1c5);
        this.LogSeq("`373`", _1c5);
        _1c9 = this.GetRootActivity(_1c5);
    }
    if (_1ca !== null && _1ca.LearningObject.ItemIdentifier == _1c3.LearningObject.ItemIdentifier) {
        this.LogSeq("`503`", _1c5);
        this.LogSeq("`940`", _1c5);
    } else {
        if (this.AreActivitiesSiblings(_1ca, _1c3, _1c5)) {
            this.LogSeq("`363`", _1c5);
            this.LogSeq("`10`", _1c5);
            var _1cf = _1c6.GetActivityListBetweenChildren(_1ca, _1c3, false);
            this.LogSeq("`831`", _1c5);
            if (_1cf.length === 0) {
                this.LogSeq("`427`", _1c5);
                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                this.LogSeqReturn(_1ce, _1c5);
                return _1ce;
            }
            this.LogSeq("`449`", _1c5);
            if (_1c3.Ordinal > _1ca.Ordinal) {
                this.LogSeq("`1351`", _1c5);
                _1cb = FLOW_DIRECTION_FORWARD;
            } else {
                this.LogSeq("`1691`", _1c5);
                this.LogSeq("`1325`", _1c5);
                _1cb = FLOW_DIRECTION_BACKWARD;
                _1cf.reverse();
            }
            this.LogSeq("`1011`", _1c5);
            for (i = 0; i < _1cf.length; i++) {
                this.LogSeq("`518`", _1c5);
                _1cc = this.ChoiceActivityTraversalSubprocess(_1cf[i], _1cb, _1c5);
                this.LogSeq("`712`", _1c5);
                if (_1cc.Reachable === false) {
                    this.LogSeq("`140`", _1c5);
                    _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, _1cc.Exception, "", false);
                    this.LogSeqReturn(_1ce, _1c5);
                    return _1ce;
                }
            }
            this.LogSeq("`1459`", _1c5);
        } else {
            if (_1ca === null || _1ca.LearningObject.ItemIdentifier == _1c9.LearningObject.ItemIdentifier) {
                this.LogSeq("`213`", _1c5);
                this.LogSeq("`248`", _1c5);
                _1c7 = this.GetPathToAncestorInclusive(_1c3, _1c9);
                this.LogSeq("`1095`", _1c5);
                if (_1c7.length === 0) {
                    this.LogSeq("`428`", _1c5);
                    _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                    this.LogSeqReturn(_1ce, _1c5);
                    return _1ce;
                }
                this.LogSeq("`1012`", _1c5);
                for (i = _1c7.length - 1; i >= 0; i--) {
                    this.LogSeq("`525`", _1c5);
                    _1cc = this.ChoiceActivityTraversalSubprocess(_1c7[i], FLOW_DIRECTION_FORWARD, _1c5);
                    this.LogSeq("`713`", _1c5);
                    if (_1cc.Reachable === false) {
                        this.LogSeq("`141`", _1c5);
                        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, _1cc.Exception, _1cc.ExceptionText, false);
                        this.LogSeqReturn(_1ce, _1c5);
                        return _1ce;
                    }
                    this.LogSeq("`19`", _1c5);
                    if (_1c7[i].IsActive() === false && _1c7[i].LearningObject.ItemIdentifier != _1c9.LearningObject.ItemIdentifier && _1c7[i].GetPreventActivation() === true) {
                        this.LogSeq("`603`" + PREVENT_ACTIVATION_ERROR + "`1565`", _1c5);
                        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _1c7[i].GetTitle()), false);
                        this.LogSeqReturn(_1ce, _1c5);
                        return _1ce;
                    }
                }
                this.LogSeq("`1460`", _1c5);
            } else {
                if (_1c3.LearningObject.ItemIdentifier == _1c9.LearningObject.ItemIdentifier) {
                    this.LogSeq("`287`", _1c5);
                    this.LogSeq("`344`", _1c5);
                    _1c7 = this.GetPathToAncestorInclusive(_1ca, _1c9);
                    this.LogSeq("`1072`", _1c5);
                    if (_1c7.length === 0) {
                        this.LogSeq("`410`", _1c5);
                        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to deliver"), false);
                        this.LogSeqReturn(_1ce, _1c5);
                        return _1ce;
                    }
                    this.LogSeq("`996`", _1c5);
                    for (i = 0; i < _1c7.length; i++) {
                        this.LogSeq("`663`", _1c5);
                        if (i != (_1c7.length - 1)) {
                            this.LogSeq("`196`", _1c5);
                            if (_1c7[i].GetSequencingControlChoiceExit() === false) {
                                this.LogSeq("`573`" + CONTROL_CHOICE_EXIT_ERROR_CHOICE + "`1565`", _1c5);
                                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONTROL_CHOICE_EXIT_ERROR_CHOICE, IntegrationImplementation.GetString("Your selection is not permitted.  Please select 'Next' or 'Previous' to move through '{0}'.", _1c7[i]), false);
                                this.LogSeqReturn(_1ce, _1c5);
                                return _1ce;
                            }
                        }
                    }
                    this.LogSeq("`1438`", _1c5);
                } else {
                    this.LogSeq("`289`", _1c5);
                    this.LogSeq("`345`", _1c5);
                    _1c7 = this.GetPathToAncestorExclusive(_1ca, _1c9, false);
                    this.LogSeq("`1009`", _1c5);
                    var _1d0 = null;
                    this.LogSeq("`574`", _1c5);
                    for (i = 0; i < _1c7.length; i++) {
                        this.LogSeq("`665`", _1c5);
                        if (i != (_1c7.length - 1)) {
                            this.LogSeq("`198`", _1c5);
                            if (_1c7[i].GetSequencingControlChoiceExit() === false) {
                                this.LogSeq("`575`" + CONTROL_CHOICE_EXIT_ERROR_CHOICE + "`1565`", _1c5);
                                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONTROL_CHOICE_EXIT_ERROR_CHOICE, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _1c7[i].GetTitle()), false);
                                this.LogSeqReturn(_1ce, _1c5);
                                return _1ce;
                            }
                        }
                        this.LogSeq("`402`", _1c5);
                        if (_1d0 === null) {
                            this.LogSeq("`734`", _1c5);
                            if (_1c7[i].GetConstrainedChoice() === true) {
                                this.LogSeq("`927`" + _1c7[i] + "'", _1c5);
                                _1d0 = _1c7[i];
                            }
                        }
                    }
                    this.LogSeq("`988`", _1c5);
                    if (_1d0 !== null) {
                        this.LogSeq("`469`", _1c5);
                        if (this.IsActivity1BeforeActivity2(_1d0, _1c3, _1c5)) {
                            this.LogSeq("`529`", _1c5);
                            _1cb = FLOW_DIRECTION_FORWARD;
                        } else {
                            this.LogSeq("`1612`", _1c5);
                            this.LogSeq("`516`", _1c5);
                            _1cb = FLOW_DIRECTION_BACKWARD;
                        }
                        this.LogSeq("`523`", _1c5);
                        var _1d1 = this.ChoiceFlowSubprocess(_1d0, _1cb, _1c5);
                        this.LogSeq("`559`", _1c5);
                        var _1d2 = _1d1;
                        this.LogSeq("`5`", _1c5);
                        if ((!_1d2.IsActivityAnAvailableDescendent(_1c3)) && (_1c3 != _1d0 && _1c3 != _1d2)) {
                            this.LogSeq("`595`" + CONSTRAINED_CHOICE_ERROR + ")", _1c5);
                            _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONSTRAINED_CHOICE_ERROR, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _1d0.GetTitle()), false);
                            this.LogSeqReturn(_1ce, _1c5);
                            return _1ce;
                        }
                    }
                    this.LogSeq("`243`", _1c5);
                    _1c7 = this.GetPathToAncestorInclusive(_1c3, _1c9);
                    this.LogSeq("`1074`", _1c5);
                    if (_1c7.length === 0) {
                        this.LogSeq("`412`", _1c5);
                        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                        this.LogSeqReturn(_1ce, _1c5);
                        return _1ce;
                    }
                    this.LogSeq("`305`", _1c5);
                    if (this.IsActivity1BeforeActivity2(_1ca, _1c3, _1c5)) {
                        this.LogSeq("`979`", _1c5);
                        for (i = (_1c7.length - 1); i >= 0; i--) {
                            if (i > 0) {
                                this.LogSeq("`234`" + i, _1c5);
                                _1cc = this.ChoiceActivityTraversalSubprocess(_1c7[i], FLOW_DIRECTION_FORWARD, _1c5);
                                this.LogSeq("`686`", _1c5);
                                if (_1cc.Reachable === false) {
                                    this.LogSeq("`132`", _1c5);
                                    _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, _1cc.Exception, _1cc.ExceptionText, false);
                                    this.LogSeqReturn(_1ce, _1c5);
                                    return _1ce;
                                }
                            }
                            this.LogSeq("`15`", _1c5);
                            if ((_1c7[i].IsActive() === false) && (_1c7[i] != _1c9) && (_1c7[i].GetPreventActivation() === true)) {
                                this.LogSeq("`576`" + PREVENT_ACTIVATION_ERROR + "`1565`", _1c5);
                                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _1c7[i].GetTitle()), false);
                                this.LogSeqReturn(_1ce, _1c5);
                                return _1ce;
                            }
                        }
                    } else {
                        this.LogSeq("`1665`", _1c5);
                        this.LogSeq("`980`", _1c5);
                        for (i = (_1c7.length - 1); i >= 0; i--) {
                            this.LogSeq("`13`", _1c5);
                            if ((_1c7[i].IsActive() === false) && (_1c7[i] != _1c9) && (_1c7[i].GetPreventActivation() === true)) {
                                this.LogSeq("`577`" + PREVENT_ACTIVATION_ERROR + "`1565`", _1c5);
                                _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _1c7[i].GetTitle()), false);
                                this.LogSeqReturn(_1ce, _1c5);
                                return _1ce;
                            }
                        }
                    }
                    this.LogSeq("`1417`", _1c5);
                }
            }
        }
    }
    this.LogSeq("`928`", _1c5);
    if (_1c3.IsALeaf() === true) {
        this.LogSeq("`492`", _1c5);
        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(_1c3, null, "", false);
        this.LogSeqReturn(_1ce, _1c5);
        return _1ce;
    }
    this.LogSeq("`51`", _1c5);
    var _1d3 = this.FlowSubprocess(_1c3, FLOW_DIRECTION_FORWARD, true, _1c5);
    this.LogSeq("`252`", _1c5);
    if (_1d3.Deliverable === false) {
        if (this.LookAhead === false) {
            this.LogSeq("`647`", _1c5);
            this.TerminateDescendentAttemptsProcess(_1c9, _1c5);
            this.LogSeq("`840`", _1c5);
            this.EndAttemptProcess(_1c9, false, _1c5);
            this.LogSeq("`886`", _1c5);
            this.SetCurrentActivity(_1c3, _1c5);
        }
        this.LogSeq("`438`", _1c5);
        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-9", IntegrationImplementation.GetString("Please select another item from the menu."), false);
        this.LogSeqReturn(_1ce, _1c5);
        return _1ce;
    } else {
        this.LogSeq("`1706`", _1c5);
        this.LogSeq("`310`", _1c5);
        _1ce = new Sequencer_ChoiceSequencingRequestProcessResult(_1d3.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_1ce, _1c5);
        return _1ce;
    }
}

function Sequencer_ChoiceSequencingRequestProcessResult(_1d4, _1d5, _1d6, _1d7) {
    if (_1d7 === undefined) {
        Debug.AssertError("no value passed for hidden");
    }
    this.DeliveryRequest = _1d4;
    this.Exception = _1d5;
    this.ExceptionText = _1d6;
    this.Hidden = _1d7;
}
Sequencer_ChoiceSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", Hidden=" + this.Hidden;
};

function Sequencer_ClearSuspendedActivitySubprocess(_1d8, _1d9) {
    Debug.AssertError("Calling log not passed.", (_1d9 === undefined || _1d9 === null));
    var _1da = this.LogSeqAudit("`1115`" + _1d8 + ")", _1d9);
    var _1db = null;
    var _1dc = null;
    var _1dd = null;
    this.LogSeq("`605`", _1da);
    if (this.IsSuspendedActivityDefined(_1da)) {
        this.LogSeq("`598`", _1da);
        _1dc = this.GetSuspendedActivity(_1da);
        _1db = this.FindCommonAncestor(_1d8, _1dc, _1da);
        this.LogSeq("`342`", _1da);
        _1dd = this.GetPathToAncestorInclusive(_1dc, _1db);
        this.LogSeq("`1002`", _1da);
        if (_1dd.length > 0) {
            this.LogSeq("`334`", _1da);
            for (var i = 0; i < _1dd.length; i++) {
                this.LogSeq("`1081`", _1da);
                if (_1dd[i].IsALeaf()) {
                    this.LogSeq("`788`", _1da);
                    _1dd[i].SetSuspended(false);
                } else {
                    this.LogSeq("`1589`", _1da);
                    this.LogSeq("`398`", _1da);
                    if (_1dd[i].HasSuspendedChildren() === false) {
                        this.LogSeq("`767`", _1da);
                        _1dd[i].SetSuspended(false);
                    }
                }
            }
        }
        this.LogSeq("`608`", _1da);
        this.ClearSuspendedActivity(_1da);
    }
    this.LogSeq("`1003`", _1da);
    this.LogSeqReturn("", _1da);
    return;
}

function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess(_1df, _1e0) {
    if (_1e0 === undefined || _1e0 === null) {
        _1e0 = this.LogSeqAudit("Content Delivery Environment Activity Data SubProcess for " + activity.StringIdentifier);
    }
    var _1e1 = (Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK || Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
    if (_1e1) {
        var _1e2 = this.PreviousActivity;
    } else {
        var _1e2 = this.CurrentActivity;
    }
    var _1e3 = this.GetSuspendedActivity(_1e0);
    var _1e4 = this.GetRootActivity(_1e0);
    var _1e5 = null;
    var _1e6 = false;
    this.LogSeq("`208`", _1e0);
    if (_1e3 != _1df) {
        this.LogSeq("`554`", _1e0);
        this.ClearSuspendedActivitySubprocess(_1df, _1e0);
    }
    this.LogSeq("`230`", _1e0);
    this.TerminateDescendentAttemptsProcess(_1df, _1e0);
    this.LogSeq("`66`", _1e0);
    _1e5 = this.GetPathToAncestorInclusive(_1df, _1e4);
    this.LogSeq("`1082`", _1e0);
    var _1e7 = ConvertDateToIso8601String(new Date());
    for (var i = (_1e5.length - 1); i >= 0; i--) {
        this.LogSeq("`1542`" + _1e5[i] + "`1175`", _1e0);
        if (_1e1) {
            var _1e9 = _1e5[i].WasActiveBeforeLaunchOnClick;
        } else {
            var _1e9 = _1e5[i].IsActive();
        }
        if (_1e9 === false) {
            this.LogSeq("`984`", _1e0);
            if (_1e5[i].IsTracked()) {
                this.LogSeq("`114`", _1e0);
                if (_1e5[i].IsSuspended()) {
                    this.LogSeq("`812`", _1e0);
                    _1e5[i].SetSuspended(false);
                } else {
                    this.LogSeq("`1623`", _1e0);
                    this.LogSeq("`485`", _1e0);
                    _1e5[i].IncrementAttemptCount();
                    this.LogSeq("`357`", _1e0);
                    if (_1e5[i].GetAttemptCount() == 1) {
                        this.LogSeq("`768`", _1e0);
                        _1e5[i].SetActivityProgressStatus(true);
                        _1e6 = true;
                    }
                    this.LogSeq("`161`", _1e0);
                    _1e5[i].InitializeForNewAttempt(true, true);
                    var atts = {
                        ev: "AttemptStart",
                        an: _1e5[i].GetAttemptCount(),
                        ai: _1e5[i].ItemIdentifier,
                        at: _1e5[i].LearningObject.Title
                    };
                    this.WriteHistoryLog("", atts);
                    _1e5[i].SetAttemptStartTimestampUtc(_1e7);
                    _1e5[i].SetAttemptAbsoluteDuration("PT0H0M0S");
                    _1e5[i].SetAttemptExperiencedDurationTracked("PT0H0M0S");
                    _1e5[i].SetAttemptExperiencedDurationReported("PT0H0M0S");
                    if (Control.Package.Properties.ResetRunTimeDataTiming == RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT) {
                        if (_1e5[i].IsDeliverable() === true) {
                            if (_1e6 === false) {
                                var atts = {
                                    ev: "ResetRuntime",
                                    ai: _1e5[i].ItemIdentifier,
                                    at: _1e5[i].LearningObject.Title
                                };
                                this.WriteHistoryLog("", atts);
                            }
                            _1e5[i].RunTime.ResetState();
                        }
                    }
                    this.LogSeq("`798`" + Control.Package.ObjectivesGlobalToSystem + "`943`", _1e0);
                    if (Control.Package.ObjectivesGlobalToSystem === false && _1e5[i].IsTheRoot() === true) {
                        this.LogSeq("`544`", _1e0);
                        this.ResetGlobalObjectives();
                    }
                }
            }
            _1e5[i].SetAttemptedDuringThisAttempt();
        }
    }
}

function Sequencer_ContentDeliveryEnvironmentProcess(_1eb, _1ec) {
    Debug.AssertError("Calling log not passed.", (_1ec === undefined || _1ec === null));
    var _1ed = this.LogSeqAudit("`1131`" + _1eb + ")", _1ec);
    var _1ee = (Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK || Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
    var _1ef = this.GetCurrentActivity();
    var _1f0 = this.GetSuspendedActivity(_1ed);
    var _1f1 = this.GetRootActivity(_1ed);
    var _1f2 = null;
    var _1f3;
    this.LogSeq("`200`", _1ed);
    if (_1ef !== null && _1ef.IsActive()) {
        this.LogSeq("`264`", _1ed);
        _1f3 = new Sequencer_ContentDeliveryEnvironmentProcessResult(false, "DB.2.1", IntegrationImplementation.GetString("The previous activity must be terminated before a new activity may be attempted"));
        this.LogSeqReturn(_1f3, _1ed);
        return _1f3;
    }
    if (!_1ee) {
        this.ContentDeliveryEnvironmentActivityDataSubProcess(_1eb, _1ec);
    } else {
        this.LogSeq("`224`", _1ed);
    }
    this.LogSeq("`66`", _1ed);
    _1f2 = this.GetPathToAncestorInclusive(_1eb, _1f1);
    this.LogSeq("`1082`", _1ed);
    for (var i = (_1f2.length - 1); i >= 0; i--) {
        if (_1ee) {
            _1f2[i].WasActiveBeforeLaunchOnClick = _1f2[i].IsActive();
        }
        this.LogSeq("`1542`" + _1f2[i] + "`1175`", _1ed);
        if (_1f2[i].IsActive() === false) {
            this.LogSeq("`890`", _1ed);
            _1f2[i].SetActive(true);
        }
    }
    this.LogSeq("`231`" + _1eb.GetItemIdentifier(), _1ed);
    if (_1ee) {
        this.PreviousActivity = _1ef;
    }
    this.SetCurrentActivity(_1eb, _1ed);
    this.LogSeq("`821`", _1ed);
    _1f3 = new Sequencer_ContentDeliveryEnvironmentProcessResult(true, null, "");
    this.LogSeqReturn(_1f3, _1ed);
    Control.DeliverActivity(_1eb);
    return _1f3;
}

function Sequencer_ContentDeliveryEnvironmentProcessResult(_1f5, _1f6, _1f7) {
    this.Valid = _1f5;
    this.Exception = _1f6;
    this.ExceptionText = _1f7;
}
Sequencer_ContentDeliveryEnvironmentProcessResult.prototype.toString = function() {
    return "Valid=" + this.Valid + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ContinueSequencingRequestProcess(_1f8) {
    Debug.AssertError("Calling log not passed.", (_1f8 === undefined || _1f8 === null));
    var _1f9 = this.LogSeqAudit("`1132`", _1f8);
    var _1fa;
    this.LogSeq("`500`", _1f9);
    if (!this.IsCurrentActivityDefined(_1f9)) {
        this.LogSeq("`422`", _1f9);
        _1fa = new Sequencer_ContinueSequencingRequestProcessResult(null, "SB.2.7-1", IntegrationImplementation.GetString("The sequencing session has not begun yet."), false);
        this.LogSeqReturn(_1fa, _1f9);
        return _1fa;
    }
    var _1fb = this.GetCurrentActivity();
    this.LogSeq("`709`", _1f9);
    if (!_1fb.IsTheRoot()) {
        var _1fc = this.Activities.GetParentActivity(_1fb);
        this.LogSeq("`299`", _1f9);
        if (_1fc.GetSequencingControlFlow() === false) {
            this.LogSeq("`585`", _1f9);
            _1fa = new Sequencer_ContinueSequencingRequestProcessResult(null, "SB.2.7-2", IntegrationImplementation.GetString("You cannot use 'Next' to enter {0}. Please select a menu item to continue.", _1fc.GetTitle()), false);
            this.LogSeqReturn(_1fa, _1f9);
            return _1fa;
        }
    }
    this.LogSeq("`136`", _1f9);
    var _1fd = this.FlowSubprocess(_1fb, FLOW_DIRECTION_FORWARD, false, _1f9);
    this.LogSeq("`994`", _1f9);
    if (_1fd.Deliverable === false) {
        this.LogSeq("`228`", _1f9);
        _1fa = new Sequencer_ContinueSequencingRequestProcessResult(null, _1fd.Exception, _1fd.ExceptionText, _1fd.EndSequencingSession);
        this.LogSeqReturn(_1fa, _1f9);
        return _1fa;
    } else {
        this.LogSeq("`1719`", _1f9);
        this.LogSeq("`319`", _1f9);
        _1fa = new Sequencer_ContinueSequencingRequestProcessResult(_1fd.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_1fa, _1f9);
        return _1fa;
    }
}

function Sequencer_ContinueSequencingRequestProcessResult(_1fe, _1ff, _200, _201) {
    Debug.AssertError("Invalid endSequencingSession (" + _201 + ") passed to ContinueSequencingRequestProcessResult.", (_201 != true && _201 != false));
    this.DeliveryRequest = _1fe;
    this.Exception = _1ff;
    this.ExceptionText = _200;
    this.EndSequencingSession = _201;
}
Sequencer_ContinueSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_DeliveryRequestProcess(_202, _203) {
    Debug.AssertError("Calling log not passed.", (_203 === undefined || _203 === null));
    var _204 = this.LogSeqAudit("`1330`" + _202 + ")", _203);
    var _205;
    var _206;
    this.LogSeq("`873`" + _202 + "`955`", _204);
    if (!_202.IsALeaf()) {
        this.LogSeq("`581`", _204);
        _206 = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-1", IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _202.GetTitle()));
        this.LogSeqReturn(_206, _204);
        return _206;
    }
    this.LogSeq("`207`", _204);
    var _207 = this.GetActivityPath(_202, true);
    this.LogSeq("`837`", _204);
    if (_207.length === 0) {
        this.LogSeq("`582`", _204);
        _206 = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-2", IntegrationImplementation.GetString("Nothing to open"));
        this.LogSeqReturn(_206, _204);
        return _206;
    }
    this.LogSeq("`528`", _204);
    for (var i = 0; i < _207.length; i++) {
        this.LogSeq("`858`" + _207[i], _204);
        _205 = this.CheckActivityProcess(_207[i], _204);
        this.LogSeq("`902`", _204);
        if (_205 === true) {
            this.LogSeq("`563`", _204);
            _206 = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-3", IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _202.GetTitle()));
            this.LogSeqReturn(_206, _204);
            return _206;
        }
    }
    this.LogSeq("`659`", _204);
    _206 = new Sequencer_DeliveryRequestProcessResult(true, null, "");
    this.LogSeqReturn(_206, _204);
    return _206;
}

function Sequencer_DeliveryRequestProcessResult(_209, _20a, _20b) {
    this.Valid = _209;
    this.Exception = _20a;
    this.ExceptionText = _20b;
}
Sequencer_DeliveryRequestProcessResult.prototype.toString = function() {
    return "Valid=" + this.Valid + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_EndAttemptProcess(_20c, _20d, _20e, _20f) {
    Debug.AssertError("Calling log not passed.", (_20e === undefined || _20e === null));
    if (_20f === undefined || _20f === null) {
        _20f = false;
    }
    var _210 = this.LogSeqAudit("`1480`" + _20c + ", " + _20d + ")", _20e);
    this.LogSeq("`1503`" + _20c.GetItemIdentifier() + "`1694`", _210);
    var i;
    var _212 = new Array();
    if (_20c.IsALeaf()) {
        this.LogSeq("`1019`", _210);
        if (_20c.IsTracked() && _20c.WasLaunchedThisSession()) {
            this.LogSeq("`863`", _210);
            _20c.TransferRteDataToActivity();
            this.LogSeq("`312`", _210);
            if (_20c.IsSuspended() === false) {
                this.LogSeq("`284`", _210);
                if (_20c.IsCompletionSetByContent() === false) {
                    this.LogSeq("`245`", _210);
                    if (_20c.GetAttemptProgressStatus() === false) {
                        this.LogSeq("`744`", _210);
                        _20c.SetAttemptProgressStatus(true);
                        this.LogSeq("`716`", _210);
                        _20c.SetAttemptCompletionStatus(true);
                        _20c.WasAutoCompleted = true;
                    }
                }
                this.LogSeq("`297`", _210);
                if (_20c.IsObjectiveSetByContent() === false) {
                    this.LogSeq("`596`", _210);
                    var _213 = _20c.GetPrimaryObjective();
                    this.LogSeq("`192`", _210);
                    if (_213.GetProgressStatus(_20c, false) === false) {
                        this.LogSeq("`668`", _210);
                        _213.SetProgressStatus(true, false, _20c);
                        this.LogSeq("`658`", _210);
                        _213.SetSatisfiedStatus(true, false, _20c);
                        _20c.WasAutoSatisfied = true;
                    }
                }
            }
        }
    } else {
        this.LogSeq("`1226`", _210);
        this.LogSeq("`109`", _210);
        if (this.ActivityHasSuspendedChildren(_20c, _210)) {
            this.LogSeq("`834`", _210);
            _20c.SetSuspended(true);
        } else {
            this.LogSeq("`1723`", _210);
            this.LogSeq("`820`", _210);
            _20c.SetSuspended(false);
        }
    }
    if (_20f === false) {
        this.LogSeq("`462`", _210);
        _20c.SetActive(false);
    }
    var _214;
    if (_20d === false) {
        this.LogSeq("`250`", _210);
        _214 = this.OverallRollupProcess(_20c, _210);
    } else {
        this.LogSeq("`527`", _210);
        _212[0] = _20c;
    }
    this.LogSeq("`235`", _210);
    var _215 = this.FindActivitiesAffectedByWriteMaps(_20c);
    var _216 = this.FindDistinctParentsOfActivitySet(_215);
    if (_20d === false) {
        this.LogSeq("`457`", _210);
        var _217 = this.GetMinimalSubsetOfActivitiesToRollup(_216, _214);
        for (i = 0; i < _217.length; i++) {
            if (_217[i] !== null) {
                this.OverallRollupProcess(_217[i], _210);
            }
        }
    } else {
        this.LogSeq("`218`", _210);
        _212 = _212.concat(_216);
    }
    if (this.LookAhead === false && _20f === false) {
        this.RandomizeChildrenProcess(_20c, true, _210);
    }
    this.LogSeq("`1310`", _210);
    this.LogSeqReturn("", _210);
    return _212;
}

function Sequencer_EvaluateRollupConditionsSubprocess(_218, _219, _21a) {
    Debug.AssertError("Calling log not passed.", (_21a === undefined || _21a === null));
    var _21b = this.LogSeqAudit("`1039`" + _218 + ", " + _219 + ")", _21a);
    var _21c;
    var _21d;
    this.LogSeq("`387`", _21b);
    var _21e = new Array();
    var i;
    this.LogSeq("`792`", _21b);
    for (i = 0; i < _219.Conditions.length; i++) {
        this.LogSeq("`36`", _21b);
        _21c = Sequencer_EvaluateRollupRuleCondition(_218, _219.Conditions[i]);
        this.LogSeq("`369`", _21b);
        if (_219.Conditions[i].Operator == RULE_CONDITION_OPERATOR_NOT && _21c != RESULT_UNKNOWN) {
            this.LogSeq("`1142`", _21b);
            _21c = (!_21c);
        }
        this.LogSeq("`973`" + _21c + "`532`", _21b);
        _21e[_21e.length] = _21c;
    }
    this.LogSeq("`308`", _21b);
    if (_21e.length === 0) {
        this.LogSeq("`692`", _21b);
        return RESULT_UNKNOWN;
    }
    this.LogSeq("`1107`" + _219.ConditionCombination + "`285`", _21b);
    if (_219.ConditionCombination == RULE_CONDITION_COMBINATION_ANY) {
        _21d = false;
        for (i = 0; i < _21e.length; i++) {
            _21d = Sequencer_LogicalOR(_21d, _21e[i]);
        }
    } else {
        _21d = true;
        for (i = 0; i < _21e.length; i++) {
            _21d = Sequencer_LogicalAND(_21d, _21e[i]);
        }
    }
    this.LogSeq("`497`", _21b);
    this.LogSeqReturn(_21d, _21b);
    return _21d;
}

function Sequencer_EvaluateRollupRuleCondition(_220, _221) {
    var _222 = null;
    switch (_221.Condition) {
        case ROLLUP_RULE_CONDITION_SATISFIED:
            _222 = _220.IsSatisfied("");
            break;
        case ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
            _222 = _220.IsObjectiveStatusKnown("", false);
            break;
        case ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
            _222 = _220.IsObjectiveMeasureKnown("", false);
            break;
        case ROLLUP_RULE_CONDITION_COMPLETED:
            _222 = _220.IsCompleted("", false);
            break;
        case ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
            _222 = _220.IsActivityProgressKnown("", false);
            break;
        case ROLLUP_RULE_CONDITION_ATTEMPTED:
            _222 = _220.IsAttempted();
            break;
        case ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
            _222 = _220.IsAttemptLimitExceeded();
            break;
        case ROLLUP_RULE_CONDITION_NEVER:
            _222 = false;
            break;
        default:
            this.LogSeq("`1368`", logParent);
            break;
    }
    return _222;
}

function Sequencer_ExitSequencingRequestProcess(_223) {
    Debug.AssertError("Calling log not passed.", (_223 === undefined || _223 === null));
    var _224 = this.LogSeqAudit("`1217`", _223);
    var _225;
    this.LogSeq("`490`", _224);
    if (!this.IsCurrentActivityDefined(_224)) {
        this.LogSeq("`512`", _224);
        _225 = new Sequencer_ExitSequencingRequestProcessResult(false, "SB.2.11-1", IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed until the sequencing session has begun."));
        this.LogSeqReturn(_225, _224);
        return _225;
    }
    var _226 = this.GetCurrentActivity();
    this.LogSeq("`323`", _224);
    if (_226.IsActive()) {
        this.LogSeq("`513`", _224);
        _225 = new Sequencer_ExitSequencingRequestProcessResult(false, "SB.2.11-2", IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed while an activity is still active."));
        this.LogSeqReturn(_225, _224);
        return _225;
    }
    this.LogSeq("`763`", _224);
    if (_226.IsTheRoot() || this.CourseIsSingleSco() === true) {
        this.LogSeq("`219`", _224);
        _225 = new Sequencer_ExitSequencingRequestProcessResult(true, null, "");
        this.LogSeqReturn(_225, _224);
        return _225;
    }
    this.LogSeq("`556`", _224);
    _225 = new Sequencer_ExitSequencingRequestProcessResult(false, null, "");
    this.LogSeqReturn(_225, _224);
    return _225;
}

function Sequencer_ExitSequencingRequestProcessResult(_227, _228, _229) {
    Debug.AssertError("Invalid endSequencingSession (" + _227 + ") passed to ExitSequencingRequestProcessResult.", (_227 != true && _227 != false));
    this.EndSequencingSession = _227;
    this.Exception = _228;
    this.ExceptionText = _229;
}
Sequencer_ExitSequencingRequestProcessResult.prototype.toString = function() {
    return "EndSequencingSession=" + this.EndSequencingSession + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_FlowActivityTraversalSubprocess(_22a, _22b, _22c, _22d) {
    Debug.AssertError("Calling log not passed.", (_22d === undefined || _22d === null));
    var _22e = this.LogSeqAudit("`1136`" + _22a + ", " + _22b + ", " + _22c + ")", _22d);
    var _22f;
    var _230;
    var _231;
    var _232;
    var _233;
    var _234 = this.Activities.GetParentActivity(_22a);
    this.LogSeq("`458`", _22e);
    if (_234.GetSequencingControlFlow() === false) {
        this.LogSeq("`388`", _22e);
        _233 = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _22a, "SB.2.2-1", IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _234.GetTitle()), false);
        this.LogSeqReturn(_233, _22e);
        return _233;
    }
    this.LogSeq("`535`", _22e);
    _22f = this.SequencingRulesCheckProcess(_22a, RULE_SET_SKIPPED, _22e);
    this.LogSeq("`358`", _22e);
    if (_22f !== null) {
        this.LogSeq("`185`", _22e);
        _230 = this.FlowTreeTraversalSubprocess(_22a, _22b, _22c, false, _22e);
        this.LogSeq("`636`", _22e);
        if (_230.NextActivity === null) {
            this.LogSeq("`157`", _22e);
            _233 = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _22a, _230.Exception, _230.ExceptionText, _230.EndSequencingSession);
            this.LogSeqReturn(_233, _22e);
            return _233;
        } else {
            this.LogSeq("`1688`", _22e);
            this.LogSeq("`67`", _22e);
            if (_22c == FLOW_DIRECTION_BACKWARD && _230.TraversalDirection == FLOW_DIRECTION_BACKWARD) {
                this.LogSeq("`35`", _22e);
                _231 = this.FlowActivityTraversalSubprocess(_230.NextActivity, _230.TraversalDirection, null, _22e);
            } else {
                this.LogSeq("`1636`", _22e);
                this.LogSeq("`9`", _22e);
                _231 = this.FlowActivityTraversalSubprocess(_230.NextActivity, _22b, _22c, _22e);
            }
            this.LogSeq("`232`", _22e);
            _233 = _231;
            this.LogSeqReturn(_233, _22e);
            return _233;
        }
    }
    this.LogSeq("`565`", _22e);
    _232 = this.CheckActivityProcess(_22a, _22e);
    this.LogSeq("`925`", _22e);
    if (_232 === true) {
        this.LogSeq("`389`", _22e);
        _233 = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _22a, "SB.2.2-2", IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", _22a.GetTitle()), false);
        this.LogSeqReturn(_233, _22e);
        return _233;
    }
    this.LogSeq("`280`", _22e);
    if (_22a.IsALeaf() === false) {
        this.LogSeq("`158`", _22e);
        _230 = this.FlowTreeTraversalSubprocess(_22a, _22b, null, true, _22e);
        this.LogSeq("`637`", _22e);
        if (_230.NextActivity === null) {
            this.LogSeq("`159`", _22e);
            _233 = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _22a, _230.Exception, _230.ExceptionText, _230.EndSequencingSession);
            this.LogSeqReturn(_233, _22e);
            return _233;
        } else {
            this.LogSeq("`1689`", _22e);
            this.LogSeq("`44`", _22e);
            if (_22b == FLOW_DIRECTION_BACKWARD && _230.TraversalDirection == FLOW_DIRECTION_FORWARD) {
                this.LogSeq("`22`", _22e);
                _231 = this.FlowActivityTraversalSubprocess(_230.NextActivity, FLOW_DIRECTION_FORWARD, FLOW_DIRECTION_BACKWARD, _22e);
            } else {
                this.LogSeq("`1637`", _22e);
                this.LogSeq("`29`", _22e);
                _231 = this.FlowActivityTraversalSubprocess(_230.NextActivity, _22b, null, _22e);
            }
            this.LogSeq("`227`", _22e);
            _233 = _231;
            this.LogSeqReturn(_233, _22e);
            return _233;
        }
    }
    this.LogSeq("`359`", _22e);
    _233 = new Sequencer_FlowActivityTraversalSubprocessReturnObject(true, _22a, null, "", false);
    this.LogSeqReturn(_233, _22e);
    return _233;
}

function Sequencer_FlowActivityTraversalSubprocessReturnObject(_235, _236, _237, _238, _239) {
    Debug.AssertError("Invalid endSequencingSession (" + _239 + ") passed to FlowActivityTraversalSubprocessReturnObject.", (_239 != true && _239 != false));
    this.Deliverable = _235;
    this.NextActivity = _236;
    this.Exception = _237;
    this.ExceptionText = _238;
    this.EndSequencingSession = _239;
}
Sequencer_FlowActivityTraversalSubprocessReturnObject.prototype.toString = function() {
    return "Deliverable=" + this.Deliverable + ", NextActivity=" + this.NextActivity + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_FlowSubprocess(_23a, _23b, _23c, _23d) {
    Debug.AssertError("Calling log not passed.", (_23d === undefined || _23d === null));
    var _23e = this.LogSeqAudit("`1516`" + _23a + ", " + _23b + ", " + _23c + ")", _23d);
    var _23f;
    this.LogSeq("`508`", _23e);
    var _240 = _23a;
    this.LogSeq("`4`", _23e);
    var _241 = this.FlowTreeTraversalSubprocess(_240, _23b, null, _23c, _23e);
    this.LogSeq("`491`", _23e);
    if (_241.NextActivity === null) {
        this.LogSeq("`205`", _23e);
        _23f = new Sequencer_FlowSubprocessResult(_240, false, _241.Exception, _241.ExceptionText, _241.EndSequencingSession);
        this.LogSeqReturn(_23f, _23e);
        return _23f;
    } else {
        this.LogSeq("`1718`", _23e);
        this.LogSeq("`557`", _23e);
        _240 = _241.NextActivity;
        this.LogSeq("`48`", _23e);
        var _242 = this.FlowActivityTraversalSubprocess(_240, _23b, null, _23e);
        this.LogSeq("`17`", _23e);
        _23f = new Sequencer_FlowSubprocessResult(_242.NextActivity, _242.Deliverable, _242.Exception, _242.ExceptionText, _242.EndSequencingSession);
        this.LogSeqReturn(_23f, _23e);
        return _23f;
    }
}

function Sequencer_FlowSubprocessResult(_243, _244, _245, _246, _247) {
    Debug.AssertError("Invalid endSequencingSession (" + _247 + ") passed to FlowSubprocessResult.", (_247 != true && _247 != false));
    this.IdentifiedActivity = _243;
    this.Deliverable = _244;
    this.Exception = _245;
    this.ExceptionText = _246;
    this.EndSequencingSession = _247;
}
Sequencer_FlowSubprocessResult.prototype.toString = function() {
    return "IdentifiedActivity=" + this.IdentifiedActivity + ", Deliverable=" + this.Deliverable + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_FlowTreeTraversalSubprocess(_248, _249, _24a, _24b, _24c) {
    Debug.AssertError("Calling log not passed.", (_24c === undefined || _24c === null));
    var _24d = this.LogSeqAudit("`1238`" + _248 + ", " + _249 + ", " + _24a + ", " + _24b + ")", _24c);
    var _24e;
    var _24f;
    var _250;
    var _251;
    var _252;
    var _253;
    var _254 = this.Activities.GetParentActivity(_248);
    this.LogSeq("`1202`", _24d);
    _24e = false;
    this.LogSeq("`24`", _24d);
    if (_24a !== null && _24a == FLOW_DIRECTION_BACKWARD && _254.IsActivityTheLastAvailableChild(_248)) {
        this.LogSeq("`1155`", _24d);
        _249 = FLOW_DIRECTION_BACKWARD;
        this.LogSeq("`552`", _24d);
        _248 = _254.GetFirstAvailableChild();
        this.LogSeq("`1174`", _24d);
        _24e = true;
    }
    this.LogSeq("`986`", _24d);
    if (_249 == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`266`", _24d);
        if ((this.IsActivityLastOverall(_248, _24d)) || (_24b === false && _248.IsTheRoot() === true)) {
            this.LogSeq("`572`", _24d);
            this.TerminateDescendentAttemptsProcess(this.Activities.GetRootActivity(), _24d);
            this.LogSeq("`174`", _24d);
            _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, null, null, true);
            this.LogSeqReturn(_253, _24d);
            return _253;
        }
        this.LogSeq("`764`", _24d);
        if (_248.IsALeaf() || _24b === false) {
            this.LogSeq("`478`", _24d);
            if (_254.IsActivityTheLastAvailableChild(_248)) {
                this.LogSeq("`28`", _24d);
                _24f = this.FlowTreeTraversalSubprocess(_254, FLOW_DIRECTION_FORWARD, null, false, _24d);
                this.LogSeq("`225`", _24d);
                _253 = _24f;
                this.LogSeqReturn(_253, _24d);
                return _253;
            } else {
                this.LogSeq("`1632`", _24d);
                this.LogSeq("`298`", _24d);
                _250 = _248.GetNextSibling();
                this.LogSeq("`201`", _24d);
                _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_250, _249, null, "", false);
                this.LogSeqReturn(_253, _24d);
                return _253;
            }
        } else {
            this.LogSeq("`1156`", _24d);
            this.LogSeq("`392`", _24d);
            _251 = _248.GetAvailableChildren();
            if (_251.length > 0) {
                this.LogSeq("`332`" + _251[0] + "); Traversal Direction: traversal direction (" + _249 + "); Exception: n/a )", _24d);
                _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_251[0], _249, null, "", false);
                this.LogSeqReturn(_253, _24d);
                return _253;
            } else {
                this.LogSeq("`1633`", _24d);
                this.LogSeq("`421`", _24d);
                _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-2", IntegrationImplementation.GetString("The activity '{0}' does not have any available children to deliver.", _248.GetTitle()), false);
                this.LogSeqReturn(_253, _24d);
                return _253;
            }
        }
    }
    this.LogSeq("`976`", _24d);
    if (_249 == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`465`", _24d);
        if (_248.IsTheRoot()) {
            this.LogSeq("`437`", _24d);
            _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-3", IntegrationImplementation.GetString("You have reached the beginning of the course."), false);
            this.LogSeqReturn(_253, _24d);
            return _253;
        }
        this.LogSeq("`765`", _24d);
        if (_248.IsALeaf() || _24b === false) {
            this.LogSeq("`337`", _24d);
            if (_24e === false) {
                this.LogSeq("`317`", _24d);
                if (_254.GetSequencingControlForwardOnly() === true) {
                    this.LogSeq("`393`", _24d);
                    _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-4", IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.", _254.GetTitle()), false);
                    this.LogSeqReturn(_253, _24d);
                    return _253;
                }
            }
            this.LogSeq("`471`", _24d);
            if (_254.IsActivityTheFirstAvailableChild(_248)) {
                this.LogSeq("`25`", _24d);
                _24f = this.FlowTreeTraversalSubprocess(_254, FLOW_DIRECTION_BACKWARD, null, false, _24d);
                this.LogSeq("`226`", _24d);
                _253 = _24f;
                this.LogSeqReturn(_253, _24d);
                return _253;
            } else {
                this.LogSeq("`1634`", _24d);
                this.LogSeq("`267`", _24d);
                _252 = _248.GetPreviousSibling();
                this.LogSeq("`809`" + _252 + "`1546`" + _249 + "`1644`", _24d);
                _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_252, _249, null, "", false);
                this.LogSeqReturn(_253, _24d);
                return _253;
            }
        } else {
            this.LogSeq("`1094`", _24d);
            this.LogSeq("`376`", _24d);
            _251 = _248.GetAvailableChildren();
            if (_251.length > 0) {
                this.LogSeq("`669`", _24d);
                if (_248.GetSequencingControlForwardOnly() === true) {
                    this.LogSeq("`49`", _24d);
                    _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_251[0], FLOW_DIRECTION_FORWARD, null, "", false);
                    this.LogSeqReturn(_253, _24d);
                    return _253;
                } else {
                    this.LogSeq("`1597`", _24d);
                    this.LogSeq("`43`", _24d);
                    _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_251[_251.length - 1], FLOW_DIRECTION_BACKWARD, null, "", false);
                    this.LogSeqReturn(_253, _24d);
                    return _253;
                }
            } else {
                this.LogSeq("`1635`", _24d);
                this.LogSeq("`408`", _24d);
                _253 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-2", IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.", _254.GetTitle()), false);
                this.LogSeqReturn(_253, _24d);
                return _253;
            }
        }
    }
}

function Sequencer_FlowTreeTraversalSubprocessReturnObject(_255, _256, _257, _258, _259) {
    Debug.AssertError("Invalid endSequencingSession (" + _259 + ") passed to FlowTreeTraversalSubprocessReturnObject.", (_259 != true && _259 != false));
    this.NextActivity = _255;
    this.TraversalDirection = _256;
    this.Exception = _257;
    this.ExceptionText = _258;
    this.EndSequencingSession = _259;
}
Sequencer_FlowTreeTraversalSubprocessReturnObject.prototype.toString = function() {
    return "NextActivity=" + this.NextActivity + ", TraversalDirection=" + this.TraversalDirection + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_LimitConditionsCheckProcess(_25a, _25b) {
    Debug.AssertError("Calling log not passed.", (_25b === undefined || _25b === null));
    var _25c = this.LogSeqAudit("`1272`" + _25a + ")", _25b);
    this.LogSeq("`384`", _25c);
    if (_25a.IsTracked() === false) {
        this.LogSeq("`296`", _25c);
        this.LogSeqReturn("`1759`", _25c);
        return false;
    }
    this.LogSeq("`144`", _25c);
    if (_25a.IsActive() || _25a.IsSuspended()) {
        this.LogSeq("`688`", _25c);
        this.LogSeqReturn("`1759`", _25c);
        return false;
    }
    this.LogSeq("`715`", _25c);
    if (_25a.GetLimitConditionAttemptControl() === true) {
        this.LogSeq("`89`", _25c);
        var _25d = _25a.GetAttemptCount();
        var _25e = _25a.GetLimitConditionAttemptLimit();
        if (_25a.GetActivityProgressStatus() === true && (_25d >= _25e)) {
            this.LogSeq("`429`", _25c);
            this.LogSeqReturn("`1763`", _25c);
            return true;
        }
    }
    this.LogSeq("`543`", _25c);
    this.LogSeq("`417`", _25c);
    this.LogSeqReturn("`1759`", _25c);
    return false;
}

function Sequencer_MeasureRollupProcess(_25f, _260) {
    Debug.AssertError("Calling log not passed.", (_260 === undefined || _260 === null));
    var _261 = this.LogSeqAudit("`1381`" + _25f + ")", _260);
    this.LogSeq("`959`", _261);
    var _262 = 0;
    this.LogSeq("`1349`", _261);
    var _263 = false;
    this.LogSeq("`1045`", _261);
    var _264 = 0;
    this.LogSeq("`1063`", _261);
    var _265 = null;
    var i;
    this.LogSeq("`627`", _261);
    var _265 = _25f.GetPrimaryObjective();
    this.LogSeq("`1105`", _261);
    if (_265 !== null) {
        this.LogSeq("`1171`", _261);
        var _267 = _25f.GetChildren();
        var _268 = null;
        var _269;
        var _26a;
        var _26b;
        for (i = 0; i < _267.length; i++) {
            this.LogSeq("`555`" + _267[i].IsTracked(), _261);
            if (_267[i].IsTracked()) {
                this.LogSeq("`985`", _261);
                _268 = null;
                this.LogSeq("`1172`", _261);
                var _268 = _267[i].GetPrimaryObjective();
                this.LogSeq("`960`", _261);
                if (_268 !== null) {
                    this.LogSeq("`545`", _261);
                    _26a = _267[i].GetRollupObjectiveMeasureWeight();
                    _264 += _26a;
                    this.LogSeq("`600`", _261);
                    if (_268.GetMeasureStatus(_267[i], false) === true) {
                        this.LogSeq("`121`", _261);
                        _26b = _268.GetNormalizedMeasure(_267[i], false);
                        this.LogSeq("`828`" + _26b + "`1462`" + _26a, _261);
                        _263 = true;
                        _262 += (_26b * _26a);
                    }
                } else {
                    this.LogSeq("`1593`", _261);
                    this.LogSeq("`495`", _261);
                    Debug.AssertError("Measure Rollup Process encountered an activity with no primary objective.");
                    this.LogSeqReturn("", _261);
                    return;
                }
            }
        }
        this.LogSeq("`1243`", _261);
        if (_263 === false || _264 == 0) {
            this.LogSeq("`103`" + _264 + ")", _261);
            _265.SetMeasureStatus(false, _25f);
        } else {
            this.LogSeq("`1682`", _261);
            this.LogSeq("`679`", _261);
            _265.SetMeasureStatus(true, _25f);
            this.LogSeq("`487`" + _262 + "`1387`" + _264 + "`1748`" + (_262 / _264), _261);
            var _26c = (_262 / _264);
            _26c = RoundToPrecision(_26c, 7);
            _265.SetNormalizedMeasure(_26c, _25f);
        }
        this.LogSeq("`1197`", _261);
        this.LogSeqReturn("", _261);
        return;
    }
    this.LogSeq("`539`", _261);
    this.LogSeqReturn("", _261);
    return;
}

function Sequencer_NavigationRequestProcess(_26d, _26e, _26f) {
    Debug.AssertError("Calling log not passed.", (_26f === undefined || _26f === null));
    var _270 = this.LogSeqAudit("`1306`" + _26d + ", " + _26e + ")", _26f);
    var _271 = this.GetCurrentActivity();
    var _272 = null;
    if (_271 !== null) {
        _272 = _271.ParentActivity;
    }
    var _273 = "";
    if (_272 !== null) {
        _273 = _272.GetTitle();
    }
    var _274;
    switch (_26d) {
        case NAVIGATION_REQUEST_START:
            this.LogSeq("`1168`", _270);
            this.LogSeq("`463`", _270);
            if (!this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`209`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_START, null, null, "");
                this.LogSeqReturn(_274, _270);
                return _274;
            } else {
                this.LogSeq("`1675`", _270);
                this.LogSeq("`176`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("The sequencing session has already been started."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_RESUME_ALL:
            this.LogSeq("`1043`", _270);
            this.LogSeq("`464`", _270);
            if (!this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`335`", _270);
                if (this.IsSuspendedActivityDefined(_270)) {
                    this.LogSeq("`170`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_RESUME_ALL, null, null, "");
                    this.LogSeqReturn(_274, _270);
                    return _274;
                } else {
                    this.LogSeq("`1611`", _270);
                    this.LogSeq("`163`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-3", null, IntegrationImplementation.GetString("There is no suspended activity to resume."));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1676`", _270);
                this.LogSeq("`177`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("The sequencing session has already been started."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_CONTINUE:
            this.LogSeq("`1085`", _270);
            this.LogSeq("`480`", _270);
            if (!this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`178`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("Cannot continue until the sequencing session has begun."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            this.LogSeq("`40`", _270);
            if ((!_271.IsTheRoot()) && (_272.LearningObject.SequencingData.ControlFlow === true)) {
                this.LogSeq("`212`", _270);
                if (_271.IsActive()) {
                    this.LogSeq("`183`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_CONTINUE, null, null, "");
                    this.LogSeqReturn(_274, _270);
                    return _274;
                } else {
                    this.LogSeq("`1625`", _270);
                    this.LogSeq("`186`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_CONTINUE, null, null, "");
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1677`", _270);
                this.LogSeq("`34`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-4", null, IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _273));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_PREVIOUS:
            this.LogSeq("`1086`", _270);
            this.LogSeq("`481`", _270);
            if (!this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`184`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("Cannot move backwards until the sequencing session has begun."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            this.LogSeq("`239`", _270);
            if (!_271.IsTheRoot()) {
                this.LogSeq("`12`", _270);
                if (_272.LearningObject.SequencingData.ControlFlow === true && _272.LearningObject.SequencingData.ControlForwardOnly === false) {
                    this.LogSeq("`202`", _270);
                    if (_271.IsActive()) {
                        this.LogSeq("`171`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_PREVIOUS, null, null, "");
                        this.LogSeqReturn(_274, _270);
                        return _274;
                    } else {
                        this.LogSeq("`1590`", _270);
                        this.LogSeq("`179`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_PREVIOUS, null, null, "");
                        this.LogSeqReturn(_274, _270);
                        return _274;
                    }
                } else {
                    this.LogSeq("`1626`", _270);
                    this.LogSeq("`100`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-5", null, IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _272.GetTitle()));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1678`", _270);
                this.LogSeq("`50`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-6", null, IntegrationImplementation.GetString("You have reached the beginning of the course."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_FORWARD:
            this.LogSeq("`799`", _270);
            this.LogSeq("`187`", _270);
            _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The 'Forward' navigation request is not supported, try using 'Continue'."));
            this.LogSeqReturn(_274, _270);
            return _274;
        case NAVIGATION_REQUEST_BACKWARD:
            this.LogSeq("`791`", _270);
            this.LogSeq("`188`", _270);
            _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The 'Backward' navigation request is not supported, try using 'Previous'."));
            this.LogSeqReturn(_274, _270);
            return _274;
        case NAVIGATION_REQUEST_CHOICE:
            this.LogSeq("`1103`", _270);
            this.LogSeq("`195`", _270);
            if (this.DoesActivityExist(_26e, _270)) {
                var _275 = this.GetActivityFromIdentifier(_26e, _270);
                var _276 = this.Activities.GetParentActivity(_275);
                if (_275.IsAvailable() === false) {
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The activity '{0}' was not selected to be delivered in this attempt.", _275));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
                this.LogSeq("`2`", _270);
                if (_275.IsTheRoot() || _276.LearningObject.SequencingData.ControlChoice === true) {
                    this.LogSeq("`443`", _270);
                    if (!this.IsCurrentActivityDefined(_270)) {
                        this.LogSeq("`59`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_CHOICE, null, _275, "");
                        this.LogSeqReturn(_274, _270);
                        return _274;
                    }
                    this.LogSeq("`399`", _270);
                    if (!this.AreActivitiesSiblings(_271, _275, _270)) {
                        this.LogSeq("`365`", _270);
                        var _277 = this.FindCommonAncestor(_271, _275, _270);
                        this.LogSeq("`1`", _270);
                        var _278 = this.GetPathToAncestorExclusive(_271, _277, true);
                        this.LogSeq("`932`", _270);
                        if (_278.length > 0) {
                            this.LogSeq("`96`", _270);
                            for (var i = 0; i < _278.length; i++) {
                                if (_278[i].GetItemIdentifier() == _277.GetItemIdentifier()) {
                                    break;
                                }
                                this.LogSeq("`216`" + _278[i].LearningObject.ItemIdentifier + ")", _270);
                                if (_278[i].IsActive() === true && _278[i].LearningObject.SequencingData.ControlChoiceExit === false) {
                                    this.LogSeq("`172`" + CONTROL_CHOICE_EXIT_ERROR_NAV + "`1505`", _270);
                                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, CONTROL_CHOICE_EXIT_ERROR_NAV, null, IntegrationImplementation.GetString("You must complete '{0}' before you can select another item.", _278[i]));
                                    this.LogSeqReturn(_274, _270);
                                    return _274;
                                }
                            }
                        } else {
                            this.LogSeq("`1559`", _270);
                            this.LogSeq("`145`", _270);
                            _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-9", null, IntegrationImplementation.GetString("Nothing to open"));
                            this.LogSeqReturn(_274, _270);
                            return _274;
                        }
                    }
                    this.LogSeq("`46`", _270);
                    if (_271.IsActive() && _271.GetSequencingControlChoiceExit() === false) {
                        this.LogSeq("`223`" + CONTROL_CHOICE_EXIT_ERROR_NAV + "`1523`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, CONTROL_CHOICE_EXIT_ERROR_NAV, null, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _271.GetTitle()));
                        return _274;
                    }
                    this.LogSeq("`204`", _270);
                    if (_271.IsActive()) {
                        this.LogSeq("`57`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_CHOICE, null, _275, "");
                        this.LogSeqReturn(_274, _270);
                        return _274;
                    } else {
                        this.LogSeq("`1592`", _270);
                        this.LogSeq("`61`", _270);
                        _274 = new Sequencer_NavigationRequestProcessResult(_26d, null, SEQUENCING_REQUEST_CHOICE, null, _275, "");
                        this.LogSeqReturn(_274, _270);
                        return _274;
                    }
                } else {
                    this.LogSeq("`1627`", _270);
                    this.LogSeq("`99`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-10", null, IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.", _276.GetTitle()));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1679`", _270);
                this.LogSeq("`87`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-11", null, IntegrationImplementation.GetString("The activity you selected ({0}) does not exist.", _26e));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_EXIT:
            this.LogSeq("`1169`", _270);
            this.LogSeq("`507`", _270);
            if (this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`292`", _270);
                if (_271.IsActive()) {
                    this.LogSeq("`193`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_EXIT, null, null, "");
                    this.LogSeqReturn(_274, _270);
                    return _274;
                } else {
                    this.LogSeq("`1628`", _270);
                    this.LogSeq("`75`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-12", null, IntegrationImplementation.GetString("The Exit navigation request is invalid because the current activity ({0}) is no longer active.", _271.GetTitle()));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1680`", _270);
                this.LogSeq("`173`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The Exit navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_EXIT_ALL:
            this.LogSeq("`1087`", _270);
            this.LogSeq("`269`", _270);
            if (this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`194`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_EXIT_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_274, _270);
                return _274;
            } else {
                this.LogSeq("`1681`", _270);
                this.LogSeq("`180`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The Exit All navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_ABANDON:
            this.LogSeq("`1084`", _270);
            this.LogSeq("`506`", _270);
            if (this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`286`", _270);
                if (_271.IsActive()) {
                    this.LogSeq("`182`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_ABANDON, SEQUENCING_REQUEST_EXIT, null, null, "");
                    this.LogSeqReturn(_274, _270);
                    return _274;
                } else {
                    this.LogSeq("`1610`", _270);
                    this.LogSeq("`153`", _270);
                    _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-12", null, IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because the current activity '{0}' is no longer active.", _271.GetTitle()));
                    this.LogSeqReturn(_274, _270);
                    return _274;
                }
            } else {
                this.LogSeq("`1624`", _270);
                this.LogSeq("`166`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_ABANDON_ALL:
            this.LogSeq("`1004`", _270);
            this.LogSeq("`277`", _270);
            if (this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`167`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_ABANDON_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_274, _270);
                return _274;
            } else {
                this.LogSeq("`1652`", _270);
                this.LogSeq("`162`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("You cannot use 'Abandon All' if no item is currently open."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        case NAVIGATION_REQUEST_SUSPEND_ALL:
            this.LogSeq("`1005`", _270);
            this.LogSeq("`538`", _270);
            if (this.IsCurrentActivityDefined(_270)) {
                this.LogSeq("`168`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(_26d, TERMINATION_REQUEST_SUSPEND_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_274, _270);
                return _274;
            } else {
                this.LogSeq("`1653`", _270);
                this.LogSeq("`169`", _270);
                _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The 'Suspend All' navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_274, _270);
                return _274;
            }
            break;
        default:
            this.LogSeq("`94`", _270);
            _274 = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-13", null, IntegrationImplementation.GetString("Undefined Navigation Request"));
            this.LogSeqReturn(_274, _270);
            return _274;
    }
}

function Sequencer_NavigationRequestProcessResult(_27a, _27b, _27c, _27d, _27e, _27f) {
    this.NavigationRequest = _27a;
    this.TerminationRequest = _27b;
    this.SequencingRequest = _27c;
    this.Exception = _27d;
    this.TargetActivity = _27e;
    this.ExceptionText = _27f;
}
Sequencer_NavigationRequestProcessResult.prototype.toString = function() {
    return "NavigationRequest=" + this.NavigationRequest + ", TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest + ", Exception=" + this.Exception + ", TargetActivity=" + this.TargetActivity + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ObjectiveRollupProcess(_280, _281) {
    Debug.AssertError("Calling log not passed.", (_281 === undefined || _281 === null));
    var _282 = this.LogSeqAudit("`1359`" + _280 + ")", _281);
    this.LogSeq("`1067`", _282);
    var _283 = null;
    this.LogSeq("`629`", _282);
    var _283 = _280.GetPrimaryObjective();
    this.LogSeq("`1064`", _282);
    if (_283 !== null) {
        this.LogSeq("`691`", _282);
        if (_283.GetSatisfiedByMeasure() === true) {
            this.LogSeq("`868`", _282);
            this.ObjectiveRollupUsingMeasureProcess(_280, _282);
            this.LogSeq("`1140`", _282);
            this.LogSeqReturn("", _282);
            return;
        }
        this.LogSeq("`590`", _282);
        if (Sequencer_GetApplicableSetofRollupRules(_280, RULE_SET_SATISFIED).length > 0 || Sequencer_GetApplicableSetofRollupRules(_280, RULE_SET_NOT_SATISFIED).length > 0) {
            this.LogSeq("`881`", _282);
            this.ObjectiveRollupUsingRulesProcess(_280, _282);
            this.LogSeq("`1141`", _282);
            this.LogSeqReturn("", _282);
            return;
        }
        this.LogSeq("`386`", _282);
        this.ObjectiveRollupUsingDefaultProcess(_280, _282);
        this.LogSeq("`1199`", _282);
        this.LogSeqReturn("", _282);
        return;
    } else {
        this.LogSeq("`1683`", _282);
        this.LogSeq("`482`", _282);
        this.LogSeqReturn("", _282);
        return;
    }
}

function Sequencer_ObjectiveRollupUsingDefaultProcess(_284, _285) {
    Debug.AssertError("Calling log not passed.", (_285 === undefined || _285 === null));
    var _286 = this.LogSeqAudit("`1026`" + _284 + ")", _285);
    var _287;
    var _288;
    var _289;
    this.LogSeq("`1244`", _286);
    if (_284.IsALeaf()) {
        this.LogSeq("`1255`", _286);
        this.LogSeqReturn("", _286);
        return;
    }
    this.LogSeq("`1032`", _286);
    var _28a = null;
    var i;
    this.LogSeq("`620`", _286);
    var _28a = _284.GetPrimaryObjective();
    this.LogSeq("`1088`", _286);
    var _28c = _284.GetChildren();
    this.LogSeq("`1048`", _286);
    var _28d = true;
    this.LogSeq("`1124`", _286);
    var _28e = true;
    this.LogSeq("`1279`", _286);
    var _28f = true;
    for (i = 0; i < _28c.length; i++) {
        this.LogSeq("`1364`" + _28c[i] + "`1566`" + _28c[i].IsTracked(), _286);
        if (_28c[i].IsTracked()) {
            this.LogSeq("`1256`" + (i + 1) + " - " + _28c[i], _286);
            this.LogSeq("`1049`", _286);
            _287 = _28c[i].IsSatisfied();
            this.LogSeq("`1050`", _286);
            _288 = _28c[i].IsAttempted();
            this.LogSeq("`729`", _286);
            _289 = (_287 === false || _288 === true);
            this.LogSeq("`1561`" + _287 + "`1725`" + _288 + "`1709`" + _289, _286);
            if (this.CheckChildForRollupSubprocess(_28c[i], ROLLUP_RULE_ACTION_SATISFIED, _286)) {
                this.LogSeq("`895`", _286);
                _28e = (_28e && (_287 === true));
                _28f = false;
            }
            if (this.CheckChildForRollupSubprocess(_28c[i], ROLLUP_RULE_ACTION_NOT_SATISFIED, _286)) {
                this.LogSeq("`778`", _286);
                _28d = (_28d && _289);
                _28f = false;
            }
        }
    }
    if (_28f && Control.Package.Properties.RollupEmptySetToUnknown) {
        this.LogSeq("`542`" + Control.Package.Properties.RollupEmptySetToUnknown + ")", _286);
    } else {
        this.LogSeq("`1008`" + _28d + ")", _286);
        if (_28d === true) {
            this.LogSeq("`674`", _286);
            _28a.SetProgressStatus(true, false, _284);
            this.LogSeq("`656`", _286);
            _28a.SetSatisfiedStatus(false, false, _284);
        }
        this.LogSeq("`1091`" + _28e + ")", _286);
        if (_28e === true) {
            this.LogSeq("`657`", _286);
            _28a.SetProgressStatus(true, false, _284);
            this.LogSeq("`645`", _286);
            _28a.SetSatisfiedStatus(true, false, _284);
        }
    }
    this.LogSeqReturn("", _286);
}

function Sequencer_ObjectiveRollupUsingMeasureProcess(_290, _291) {
    Debug.AssertError("Calling log not passed.", (_291 === undefined || _291 === null));
    var _292 = this.LogSeqAudit("`1027`" + _290 + ")", _291);
    this.LogSeq("`1031`", _292);
    var _293 = null;
    this.LogSeq("`617`", _292);
    var _293 = _290.GetPrimaryObjective();
    this.LogSeq("`1064`", _292);
    if (_293 !== null) {
        this.LogSeq("`127`", _292);
        if (_293.GetSatisfiedByMeasure() === true) {
            this.LogSeq("`303`", _292);
            if (_293.GetMeasureStatus(_290, false) === false) {
                this.LogSeq("`628`", _292);
                _293.SetProgressStatus(false, false, _290);
            } else {
                this.LogSeq("`1594`", _292);
                this.LogSeq("`130`", _292);
                if (_290.IsActive() === false || _290.GetMeasureSatisfactionIfActive() === true) {
                    this.LogSeq("`105`", _292);
                    if (_293.GetNormalizedMeasure(_290, false) >= _293.GetMinimumSatisfiedNormalizedMeasure()) {
                        this.LogSeq("`610`", _292);
                        _293.SetProgressStatus(true, false, _290);
                        this.LogSeq("`606`", _292);
                        _293.SetSatisfiedStatus(true, false, _290);
                    } else {
                        this.LogSeq("`1518`", _292);
                        this.LogSeq("`611`", _292);
                        _293.SetProgressStatus(true, false, _290);
                        this.LogSeq("`601`", _292);
                        _293.SetSatisfiedStatus(false, false, _290);
                    }
                } else {
                    this.LogSeq("`1560`", _292);
                    this.LogSeq("`270`", _292);
                    _293.SetProgressStatus(false, false, _290);
                }
            }
        }
        this.LogSeq("`917`", _292);
        this.LogSeqReturn("", _292);
        return;
    } else {
        this.LogSeq("`1683`", _292);
        this.LogSeq("`391`", _292);
        this.LogSeqReturn("", _292);
        return;
    }
}

function Sequencer_ObjectiveRollupUsingRulesProcess(_294, _295) {
    Debug.AssertError("Calling log not passed.", (_295 === undefined || _295 === null));
    var _296 = this.LogSeqAudit("`1060`" + _294 + ")", _295);
    var _297;
    this.LogSeq("`1046`", _296);
    var _298 = null;
    this.LogSeq("`618`", _296);
    var _298 = _294.GetPrimaryObjective();
    this.LogSeq("`1065`", _296);
    if (_298 !== null) {
        this.LogSeq("`294`", _296);
        _297 = this.RollupRuleCheckSubprocess(_294, RULE_SET_NOT_SATISFIED, _296);
        this.LogSeq("`801`", _296);
        if (_297 === true) {
            this.LogSeq("`652`", _296);
            _298.SetProgressStatus(true, false, _294);
            this.LogSeq("`632`", _296);
            _298.SetSatisfiedStatus(false, false, _294);
        }
        this.LogSeq("`327`", _296);
        _297 = this.RollupRuleCheckSubprocess(_294, RULE_SET_SATISFIED, _296);
        this.LogSeq("`802`", _296);
        if (_297 === true) {
            this.LogSeq("`653`", _296);
            _298.SetProgressStatus(true, false, _294);
            this.LogSeq("`643`", _296);
            _298.SetSatisfiedStatus(true, false, _294);
        }
        this.LogSeq("`948`", _296);
        this.LogSeqReturn("", _296);
        return;
    } else {
        this.LogSeq("`1684`", _296);
        this.LogSeq("`431`", _296);
        this.LogSeqReturn("", _296);
        return;
    }
}

function Sequencer_OverallRollupProcess(_299, _29a) {
    Debug.AssertError("Calling log not passed.", (_29a === undefined || _29a === null));
    var _29b = this.LogSeqAudit("`1382`" + _299 + ")", _29a);
    this.LogSeq("`256`", _29b);
    var _29c = this.GetActivityPath(_299, true);
    this.LogSeq("`1127`", _29b);
    if (_29c.length === 0) {
        this.LogSeq("`896`", _29b);
        this.LogSeqReturn("", _29b);
        return;
    }
    this.LogSeq("`1054`", _29b);
    var _29d;
    var _29e;
    var _29f;
    var _2a0;
    var _2a1;
    var _2a2;
    var _2a3;
    var _2a4;
    var _2a5;
    var _2a6;
    var _2a7;
    var _2a8;
    var _2a9;
    var _2aa = new Array();
    var _2ab = false;
    for (var i = 0; i < _29c.length; i++) {
        if (!_29c[i].IsALeaf()) {
            _29c[i].RollupDurations();
        }
        if (_2ab) {
            continue;
        }
        _29d = _29c[i].GetPrimaryObjective();
        _29e = _29d.GetMeasureStatus(_29c[i], false);
        _29f = _29d.GetNormalizedMeasure(_29c[i], false);
        _2a0 = _29d.GetProgressStatus(_29c[i], false);
        _2a1 = _29d.GetSatisfiedStatus(_29c[i], false);
        _2a2 = _29c[i].GetAttemptProgressStatus();
        _2a3 = _29c[i].GetAttemptCompletionStatus();
        this.LogSeq("`551`", _29b);
        if (!_29c[i].IsALeaf()) {
            this.LogSeq("`564`", _29b);
            this.MeasureRollupProcess(_29c[i], _29b);
        }
        this.LogSeq("`731`", _29b);
        this.ObjectiveRollupProcess(_29c[i], _29b);
        this.LogSeq("`782`", _29b);
        this.ActivityProgressRollupProcess(_29c[i], _29b);
        _2a4 = _29d.GetMeasureStatus(_29c[i], false);
        _2a5 = _29d.GetNormalizedMeasure(_29c[i], false);
        _2a6 = _29d.GetProgressStatus(_29c[i], false);
        _2a7 = _29d.GetSatisfiedStatus(_29c[i], false);
        _2a8 = _29c[i].GetAttemptProgressStatus();
        _2a9 = _29c[i].GetAttemptCompletionStatus();
        if (!this.LookAhead && _29c[i].IsTheRoot()) {
            if (_2a8 != _2a2 || _2a9 != _2a3) {
                var _2ad = (_2a8 ? (_2a9 ? SCORM_STATUS_COMPLETED : SCORM_STATUS_INCOMPLETE) : SCORM_STATUS_NOT_ATTEMPTED);
                this.WriteHistoryLog("", {
                    ev: "Rollup Completion",
                    v: _2ad,
                    ai: _29c[i].ItemIdentifier
                });
            }
            if (_2a6 != _2a0 || _2a7 != _2a1) {
                var _2ae = (_2a6 ? (_2a7 ? SCORM_STATUS_PASSED : SCORM_STATUS_FAILED) : SCORM_STATUS_UNKNOWN);
                this.WriteHistoryLog("", {
                    ev: "Rollup Satisfaction",
                    v: _2ae,
                    ai: _29c[i].ItemIdentifier
                });
            }
        }
        if (_2a7 != _2a1) {
            _29c[i].WasAutoSatisfied = _299.WasAutoSatisfied;
        }
        if (_2a9 != _2a3) {
            _29c[i].WasAutoCompleted = _299.WasAutoCompleted;
        }
        if (i > 0 && _2a4 == _29e && _2a5 == _29f && _2a6 == _2a0 && _2a7 == _2a1 && _2a8 == _2a2 && _2a9 == _2a3) {
            this.LogSeq("`905`", _29b);
            _2ab = true;
        } else {
            this.LogSeq("`869`", _29b);
            _2aa[_2aa.length] = _29c[i];
        }
    }
    this.LogSeq("`1282`", _29b);
    this.LogSeqReturn("", _29b);
    return _2aa;
}

function Sequencer_OverallSequencingProcess(_2af) {
    try {
        var _2b0 = null;
        var _2b1 = null;
        var _2b2 = null;
        var _2b3 = null;
        var _2b4 = null;
        this.ResetException();
        var _2b5 = this.LogSeqAudit("`1360`");
        this.LogSeq("`1414`" + this.NavigationRequest, _2b5);
        if (this.NavigationRequest === null) {
            var _2b6 = this.GetExitAction(this.GetCurrentActivity(), _2b5);
            this.LogSeq("`1044`" + _2b6, _2b5);
            var _2b7 = "";
            if (_2b6 == EXIT_ACTION_EXIT_CONFIRMATION || _2b6 == EXIT_ACTION_DISPLAY_MESSAGE) {
                var _2b8 = Control.Activities.GetRootActivity();
                var _2b9 = (_2b8.IsCompleted() || _2b8.IsSatisfied());
                if (_2b9 === true) {
                    _2b7 = IntegrationImplementation.GetString("The course is now complete. Please make a selection to continue.");
                } else {
                    _2b7 = IntegrationImplementation.GetString("Please make a selection.");
                }
            }
            switch (_2b6) {
                case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL, null, "");
                    break;
                case (EXIT_ACTION_EXIT_CONFIRMATION):
                    if (confirm("Would you like to exit the course now?")) {
                        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL, null, "");
                    } else {
                        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE, null, _2b7);
                    }
                    break;
                case (EXIT_ACTION_GO_TO_NEXT_SCO):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_CONTINUE, null, "");
                    break;
                case (EXIT_ACTION_DISPLAY_MESSAGE):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE, null, _2b7);
                    break;
                case (EXIT_ACTION_DO_NOTHING):
                    this.NavigationRequest = null;
                    break;
                case (EXIT_ACTION_REFRESH_PAGE):
                    Control.RefreshPage();
                    break;
            }
        }
        if (this.NavigationRequest == null) {
            this.LogSeqReturn("`1409`", _2b5);
            return;
        }
        if (this.NavigationRequest.Type == NAVIGATION_REQUEST_DISPLAY_MESSAGE) {
            this.LogSeq("`690`", _2b5);
            this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT, null, "");
        }
        if (this.NavigationRequest.Type == NAVIGATION_REQUEST_EXIT_PLAYER) {
            this.LogSeq("`814`", _2b5);
            Control.ExitScormPlayer("Sequencer");
            return;
        }
        this.LogSeq("`757`", _2b5);
        var _2ba = this.NavigationRequestProcess(this.NavigationRequest.Type, this.NavigationRequest.TargetActivity, _2b5);
        this.LogSeq("`626`", _2b5);
        if (_2ba.NavigationRequest == NAVIGATION_REQUEST_NOT_VALID) {
            this.LogSeq("`726`", _2b5);
            this.Exception = _2ba.Exception;
            this.ExceptionText = _2ba.ExceptionText;
            this.LogSeq("`847`", _2b5);
            this.LogSeqReturn("`1759`", _2b5);
            return false;
        }
        _2b0 = _2ba.TerminationRequest;
        _2b1 = _2ba.SequencingRequest;
        _2b2 = _2ba.TargetActivity;
        this.LogSeq("`368`", _2b5);
        if (_2b0 !== null) {
            this.LogSeq("`707`", _2b5);
            var _2bb = this.TerminationRequestProcess(_2b0, _2b5);
            this.LogSeq("`599`", _2b5);
            if (_2bb.TerminationRequest == TERMINATION_REQUEST_NOT_VALID) {
                this.LogSeq("`699`", _2b5);
                this.Exception = _2bb.Exception;
                this.ExceptionText = _2bb.ExceptionText;
                this.LogSeq("`823`", _2b5);
                this.LogSeqReturn("`1759`", _2b5);
                return false;
            }
            this.LogSeq("`700`", _2b5);
            if (_2bb.SequencingRequest !== null) {
                this.LogSeq("`39`", _2b5);
                _2b1 = _2bb.SequencingRequest;
            }
        }
        this.LogSeq("`1062`", _2b5);
        if (_2b1 !== null) {
            this.LogSeq("`727`", _2b5);
            var _2bc = this.SequencingRequestProcess(_2b1, _2b2, _2b5);
            this.LogSeq("`609`", _2b5);
            if (_2bc.SequencingRequest == SEQUENCING_REQUEST_NOT_VALID) {
                this.LogSeq("`708`", _2b5);
                this.Exception = _2bc.Exception;
                this.ExceptionText = _2bc.ExceptionText;
                this.LogSeq("`824`", _2b5);
                this.LogSeqReturn("`1759`", _2b5);
                return false;
            }
            this.LogSeq("`534`", _2b5);
            if (_2bc.EndSequencingSession === true) {
                this.LogSeq("`76`", _2b5);
                Control.ExitScormPlayer("Sequencer");
                this.LogSeqReturn("", _2b5);
                return;
            }
            this.LogSeq("`583`", _2b5);
            if (_2bc.DeliveryRequest === null) {
                this.LogSeq("`825`", _2b5);
                this.Exception = "OP.1.4";
                this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
                this.LogSeqReturn("", _2b5);
                return;
            }
            this.LogSeq("`571`", _2b5);
            _2b3 = _2bc.DeliveryRequest;
        }
        this.LogSeq("`1104`", _2b5);
        if (_2b3 !== null) {
            this.LogSeq("`777`", _2b5);
            var _2bd = this.DeliveryRequestProcess(_2b3, _2b5);
            this.LogSeq("`630`", _2b5);
            if (_2bd.Valid === false) {
                this.LogSeq("`728`", _2b5);
                this.Exception = "OP.1.5";
                this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
                this.LogSeq("`826`", _2b5);
                this.LogSeqReturn("`1759`", _2b5);
                return false;
            }
            this.LogSeq("`651`", _2b5);
            this.ContentDeliveryEnvironmentProcess(_2b3, _2b5);
        }
        this.LogSeq("`946`", _2b5);
        this.LogSeqReturn("", _2b5);
        return;
    } catch (error) {
        var _2be = "Error in OverallSequencingProcess for SCORM 2004 3rd Edition: ";
        if (typeof RegistrationToDeliver != "undefined" && typeof RegistrationToDeliver.Id != "undefined") {
            _2be = _2be + "RegistrationId: " + RegistrationToDeliver.Id + ", ";
        }
        Control.Comm.LogOnServer(_2be, error);
        throw error;
    }
}

function Sequencer_PreviousSequencingRequestProcess(_2bf) {
    Debug.AssertError("Calling log not passed.", (_2bf === undefined || _2bf === null));
    var _2c0 = this.LogSeqAudit("`1137`", _2bf);
    var _2c1;
    this.LogSeq("`501`", _2c0);
    if (!this.IsCurrentActivityDefined(_2c0)) {
        this.LogSeq("`409`", _2c0);
        _2c1 = new Sequencer_PreviousSequencingRequestProcessResult(null, "SB.2.8-1", IntegrationImplementation.GetString("You cannot use 'Previous' at this time."), false);
        this.LogSeqReturn(_2c1, _2c0);
        return _2c1;
    }
    var _2c2 = this.GetCurrentActivity();
    this.LogSeq("`710`", _2c0);
    if (!_2c2.IsTheRoot()) {
        var _2c3 = this.Activities.GetParentActivity(_2c2);
        this.LogSeq("`300`", _2c0);
        if (_2c3.GetSequencingControlFlow() === false) {
            this.LogSeq("`593`", _2c0);
            _2c1 = new Sequencer_PreviousSequencingRequestProcessResult(null, "SB.2.8-2", IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.", _2c3.GetTitle()), false);
            this.LogSeqReturn(_2c1, _2c0);
            return _2c1;
        }
    }
    this.LogSeq("`131`", _2c0);
    var _2c4 = this.FlowSubprocess(_2c2, FLOW_DIRECTION_BACKWARD, false, _2c0);
    this.LogSeq("`995`", _2c0);
    if (_2c4.Deliverable === false) {
        this.LogSeq("`229`", _2c0);
        _2c1 = new Sequencer_PreviousSequencingRequestProcessResult(null, _2c4.Exception, _2c4.ExceptionText, _2c4.EndSequencingSession);
        this.LogSeqReturn(_2c1, _2c0);
        return _2c1;
    } else {
        this.LogSeq("`1720`", _2c0);
        this.LogSeq("`324`", _2c0);
        _2c1 = new Sequencer_PreviousSequencingRequestProcessResult(_2c4.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_2c1, _2c0);
        return _2c1;
    }
}

function Sequencer_PreviousSequencingRequestProcessResult(_2c5, _2c6, _2c7, _2c8) {
    Debug.AssertError("Invalid endSequencingSession (" + _2c8 + ") passed to PreviousSequencingRequestProcessResult.", (_2c8 != true && _2c8 != false));
    this.DeliveryRequest = _2c5;
    this.Exception = _2c6;
    this.ExceptionText = _2c7;
    this.EndSequencingSession = _2c8;
}
Sequencer_PreviousSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RandomizeChildrenProcess(_2c9, _2ca, _2cb) {
    Debug.AssertError("Calling log not passed.", (_2cb === undefined || _2cb === null));
    var _2cc = this.LogSeqAudit("`1343`" + _2c9 + ")", _2cb);
    var _2cd;
    this.LogSeq("`537`", _2cc);
    if (_2c9.IsALeaf()) {
        this.LogSeq("`1203`", _2cc);
        this.LogSeqReturn("", _2cc);
        return;
    }
    this.LogSeq("`155`", _2cc);
    if (_2c9.IsActive() === true || _2c9.IsSuspended() === true) {
        this.LogSeq("`1204`", _2cc);
        this.LogSeqReturn("", _2cc);
        return;
    }
    var _2ce = _2c9.GetRandomizationTiming();
    switch (_2ce) {
        case TIMING_NEVER:
            this.LogSeq("`854`", _2cc);
            this.LogSeq("`1205`", _2cc);
            break;
        case TIMING_ONCE:
            this.LogSeq("`861`", _2cc);
            this.LogSeq("`783`", _2cc);
            if (_2c9.GetRandomizedChildren() === false) {
                this.LogSeq("`441`", _2cc);
                if (_2c9.GetActivityProgressStatus() === false) {
                    this.LogSeq("`862`", _2cc);
                    if (_2c9.GetRandomizeChildren() === true) {
                        this.LogSeq("`568`", _2cc);
                        _2cd = Sequencer_RandomizeArray(_2c9.GetAvailableChildren());
                        _2c9.SetAvailableChildren(_2cd);
                        _2c9.SetRandomizedChildren(true);
                    }
                }
            }
            this.LogSeq("`1206`", _2cc);
            break;
        case TIMING_ON_EACH_NEW_ATTEMPT:
            this.LogSeq("`696`", _2cc);
            this.LogSeq("`876`", _2cc);
            if (_2c9.GetRandomizeChildren() === true) {
                this.LogSeq("`586`", _2cc);
                _2cd = Sequencer_RandomizeArray(_2c9.GetAvailableChildren());
                _2c9.SetAvailableChildren(_2cd);
                _2c9.SetRandomizedChildren(true);
                if (_2ca === true) {
                    Control.RedrawChildren(_2c9);
                }
            }
            this.LogSeq("`1207`", _2cc);
            break;
        default:
            this.LogSeq("`833`", _2cc);
            break;
    }
    this.LogSeqReturn("", _2cc);
    return;
}

function Sequencer_RandomizeArray(ary) {
    var _2d0 = ary.length;
    var orig;
    var swap;
    for (var i = 0; i < _2d0; i++) {
        var _2d4 = Math.floor(Math.random() * _2d0);
        orig = ary[i];
        swap = ary[_2d4];
        ary[i] = swap;
        ary[_2d4] = orig;
    }
    return ary;
}

function Sequencer_ResumeAllSequencingRequestProcess(_2d5) {
    Debug.AssertError("Calling log not passed.", (_2d5 === undefined || _2d5 === null));
    var _2d6 = this.LogSeqAudit("`1102`", _2d5);
    var _2d7;
    this.LogSeq("`499`", _2d6);
    if (this.IsCurrentActivityDefined(_2d6)) {
        this.LogSeq("`400`", _2d6);
        _2d7 = new Sequencer_ResumeAllSequencingRequestProcessResult(null, "SB.2.6-1", IntegrationImplementation.GetString("A 'Resume All' sequencing request cannot be processed while there is a current activity defined."));
        this.LogSeqReturn(_2d7, _2d6);
        return _2d7;
    }
    this.LogSeq("`397`", _2d6);
    if (!this.IsSuspendedActivityDefined(_2d6)) {
        this.LogSeq("`401`", _2d6);
        _2d7 = new Sequencer_ResumeAllSequencingRequestProcessResult(null, "SB.2.6-2", IntegrationImplementation.GetString("There is no suspended activity to resume."));
        this.LogSeqReturn(_2d7, _2d6);
        return _2d7;
    }
    this.LogSeq("`58`", _2d6);
    var _2d8 = this.GetSuspendedActivity(_2d6);
    if (_2d8 !== null && _2d8.IsDeliverable() !== true && Control.Package.Properties.AlwaysFlowToFirstSco === true) {
        this.LogSeq("`604`", _2d6);
        var _2d9 = this.GetOrderedListOfActivities(_2d6);
        for (var i = 0; i < _2d9.length; i++) {
            if (_2d9[i] && _2d9[i].IsDeliverable() === true) {
                _2d7 = new Sequencer_ResumeAllSequencingRequestProcessResult(_2d9[i], null, "");
                this.LogSeqReturn(_2d7, _2d6);
                return _2d7;
            }
        }
    }
    _2d7 = new Sequencer_ResumeAllSequencingRequestProcessResult(_2d8, null, "");
    this.LogSeqReturn(_2d7, _2d6);
    return _2d7;
}

function Sequencer_ResumeAllSequencingRequestProcessResult(_2db, _2dc, _2dd) {
    this.DeliveryRequest = _2db;
    this.Exception = _2dc;
    this.ExceptionText = _2dd;
}
Sequencer_ResumeAllSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RetrySequencingRequestProcess(_2de) {
    Debug.AssertError("Calling log not passed.", (_2de === undefined || _2de === null));
    var _2df = this.LogSeqAudit("`1193`", _2de);
    var _2e0;
    var _2e1;
    this.LogSeq("`488`", _2df);
    if (!this.IsCurrentActivityDefined(_2df)) {
        this.LogSeq("`433`", _2df);
        _2e0 = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-1", IntegrationImplementation.GetString("You cannot use 'Resume All' while the current item is open."));
        this.LogSeqReturn(_2e0, _2df);
        return _2e0;
    }
    var _2e2 = this.GetCurrentActivity();
    this.LogSeq("`101`", _2df);
    if (_2e2.IsActive() || _2e2.IsSuspended()) {
        this.LogSeq("`434`", _2df);
        _2e0 = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-2", IntegrationImplementation.GetString("A 'Retry' sequencing request cannot be processed while there is an active or suspended activity."));
        this.LogSeqReturn(_2e0, _2df);
        return _2e0;
    }
    this.LogSeq("`975`", _2df);
    if (!_2e2.IsALeaf()) {
        this.LogSeq("`372`", _2df);
        flowSubProcessResult = this.FlowSubprocess(_2e2, FLOW_DIRECTION_FORWARD, true, _2df);
        this.LogSeq("`951`", _2df);
        if (flowSubProcessResult.Deliverable === false) {
            this.LogSeq("`407`", _2df);
            _2e0 = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-3", IntegrationImplementation.GetString("You cannot 'Retry' this item because: {1}", _2e2.GetTitle(), flowSubProcessResult.ExceptionText));
            this.LogSeqReturn(_2e0, _2df);
            return _2e0;
        } else {
            this.LogSeq("`1655`", _2df);
            this.LogSeq("`322`", _2df);
            _2e0 = new Sequencer_RetrySequencingRequestProcessResult(flowSubProcessResult.IdentifiedActivity, null, "");
            this.LogSeqReturn(_2e0, _2df);
            return _2e0;
        }
    } else {
        this.LogSeq("`1704`", _2df);
        this.LogSeq("`489`", _2df);
        _2e0 = new Sequencer_RetrySequencingRequestProcessResult(_2e2, null, "");
        this.LogSeqReturn(_2e0, _2df);
        return _2e0;
    }
}

function Sequencer_RetrySequencingRequestProcessResult(_2e3, _2e4, _2e5) {
    this.DeliveryRequest = _2e3;
    this.Exception = _2e4;
    this.ExceptionText = _2e5;
}
Sequencer_RetrySequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RollupRuleCheckSubprocess(_2e6, _2e7, _2e8) {
    Debug.AssertError("Calling log not passed.", (_2e8 === undefined || _2e8 === null));
    var _2e9 = this.LogSeqAudit("`1274`" + _2e6 + ", " + _2e7 + ")", _2e8);
    var _2ea;
    var _2eb;
    var _2ec;
    var _2ed;
    var _2ee = 0;
    var _2ef = 0;
    var _2f0 = 0;
    this.LogSeq("`331`", _2e9);
    var _2f1 = Sequencer_GetApplicableSetofRollupRules(_2e6, _2e7);
    if (_2f1.length > 0) {
        this.LogSeq("`214`", _2e9);
        _2ea = _2e6.GetChildren();
        this.LogSeq("`1145`", _2e9);
        for (var i = 0; i < _2f1.length; i++) {
            this.LogSeq("`748`", _2e9);
            contributingChldren = new Array();
            _2ee = 0;
            _2ef = 0;
            _2f0 = 0;
            this.LogSeq("`1126`", _2e9);
            for (var j = 0; j < _2ea.length; j++) {
                this.LogSeq("`974`", _2e9);
                if (_2ea[j].IsTracked() === true) {
                    this.LogSeq("`236`", _2e9);
                    _2eb = this.CheckChildForRollupSubprocess(_2ea[j], _2f1[i].Action, _2e9);
                    this.LogSeq("`749`", _2e9);
                    if (_2eb === true) {
                        this.LogSeq("`156`", _2e9);
                        _2ec = this.EvaluateRollupConditionsSubprocess(_2ea[j], _2f1[i], _2e9);
                        this.LogSeq("`309`", _2e9);
                        if (_2ec == RESULT_UNKNOWN) {
                            this.LogSeq("`721`", _2e9);
                            _2f0++;
                            if (_2f1[i].ChildActivitySet == CHILD_ACTIVITY_SET_ALL || _2f1[i].ChildActivitySet == CHILD_ACTIVITY_SET_NONE) {
                                j = _2ea.length;
                            }
                        } else {
                            this.LogSeq("`1519`", _2e9);
                            this.LogSeq("`682`", _2e9);
                            if (_2ec === true) {
                                this.LogSeq("`772`", _2e9);
                                _2ee++;
                                if (_2f1[i].ChildActivitySet == CHILD_ACTIVITY_SET_ANY || _2f1[i].ChildActivitySet == CHILD_ACTIVITY_SET_NONE) {
                                    j = _2ea.length;
                                }
                            } else {
                                this.LogSeq("`1520`", _2e9);
                                this.LogSeq("`762`", _2e9);
                                _2ef++;
                                if (_2f1[i].ChildActivitySet == CHILD_ACTIVITY_SET_ALL) {
                                    j = _2ea.length;
                                }
                            }
                        }
                    }
                }
            }
            switch (_2f1[i].ChildActivitySet) {
                case CHILD_ACTIVITY_SET_ALL:
                    this.LogSeq("`935`", _2e9);
                    this.LogSeq("`540`", _2e9);
                    if (_2ef === 0 && _2f0 === 0) {
                        this.LogSeq("`1146`", _2e9);
                        _2ed = true;
                    }
                    break;
                case CHILD_ACTIVITY_SET_ANY:
                    this.LogSeq("`937`", _2e9);
                    this.LogSeq("`693`", _2e9);
                    if (_2ee > 0) {
                        this.LogSeq("`1147`", _2e9);
                        _2ed = true;
                    }
                    break;
                case CHILD_ACTIVITY_SET_NONE:
                    this.LogSeq("`923`", _2e9);
                    this.LogSeq("`546`", _2e9);
                    if (_2ee === 0 && _2f0 === 0) {
                        this.LogSeq("`1148`", _2e9);
                        _2ed = true;
                    }
                    break;
                case CHILD_ACTIVITY_SET_AT_LEAST_COUNT:
                    this.LogSeq("`816`", _2e9);
                    this.LogSeq("`271`", _2e9);
                    if (_2ee >= _2f1[i].MinimumCount) {
                        this.LogSeq("`1149`", _2e9);
                        _2ed = true;
                    }
                    break;
                case CHILD_ACTIVITY_SET_AT_LEAST_PERCENT:
                    this.LogSeq("`793`", _2e9);
                    this.LogSeq("`118`", _2e9);
                    var _2f4 = (_2ee / (_2ee + _2ef + _2f0));
                    if (_2f4 >= _2f1[i].MinimumPercent) {
                        this.LogSeq("`1150`", _2e9);
                        _2ed = true;
                    }
                    break;
                default:
                    break;
            }
            this.LogSeq("`1151`", _2e9);
            if (_2ed === true) {
                this.LogSeq("`265`", _2e9);
                this.LogSeqReturn("`1763`", _2e9);
                return true;
            }
        }
    }
    this.LogSeq("`420`", _2e9);
    this.LogSeqReturn("`1759`", _2e9);
    return false;
}

function Sequencer_GetApplicableSetofRollupRules(_2f5, _2f6) {
    var _2f7 = new Array();
    var _2f8 = _2f5.GetRollupRules();
    for (var i = 0; i < _2f8.length; i++) {
        switch (_2f6) {
            case RULE_SET_SATISFIED:
                if (_2f8[i].Action == ROLLUP_RULE_ACTION_SATISFIED) {
                    _2f7[_2f7.length] = _2f8[i];
                }
                break;
            case RULE_SET_NOT_SATISFIED:
                if (_2f8[i].Action == ROLLUP_RULE_ACTION_NOT_SATISFIED) {
                    _2f7[_2f7.length] = _2f8[i];
                }
                break;
            case RULE_SET_COMPLETED:
                if (_2f8[i].Action == ROLLUP_RULE_ACTION_COMPLETED) {
                    _2f7[_2f7.length] = _2f8[i];
                }
                break;
            case RULE_SET_INCOMPLETE:
                if (_2f8[i].Action == ROLLUP_RULE_ACTION_INCOMPLETE) {
                    _2f7[_2f7.length] = _2f8[i];
                }
                break;
        }
    }
    return _2f7;
}

function Sequencer_SelectChildrenProcess(_2fa, _2fb) {
    Debug.AssertError("Calling log not passed.", (_2fb === undefined || _2fb === null));
    var _2fc = this.LogSeqAudit("`1396`" + _2fa + ")", _2fb);
    this.LogSeq("`561`", _2fc);
    if (_2fa.IsALeaf()) {
        this.LogSeq("`1257`", _2fc);
        this.LogSeqReturn("", _2fc);
        return;
    }
    this.LogSeq("`175`", _2fc);
    if (_2fa.IsActive() === true || _2fa.IsSuspended() === true) {
        this.LogSeq("`1258`", _2fc);
        this.LogSeqReturn("", _2fc);
        return;
    }
    var _2fd = _2fa.GetSelectionTiming();
    switch (_2fd) {
        case TIMING_NEVER:
            this.LogSeq("`888`", _2fc);
            this.LogSeq("`1259`", _2fc);
            break;
        case TIMING_ONCE:
            this.LogSeq("`897`", _2fc);
            this.LogSeq("`818`", _2fc);
            if (_2fa.GetSelectedChildren() === false) {
                this.LogSeq("`440`", _2fc);
                if (_2fa.GetActivityProgressStatus() === false) {
                    this.LogSeq("`773`", _2fc);
                    if (_2fa.GetSelectionCountStatus() === true) {
                        this.LogSeq("`889`", _2fc);
                        var _2fe = new Array();
                        var _2ff = _2fa.GetChildren();
                        var _300 = _2fa.GetSelectionCount();
                        if (_300 < _2ff.length) {
                            var _301 = Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_300, 0, _2ff.length - 1);
                            this.LogSeq("`870`", _2fc);
                            for (var i = 0; i < _301.length; i++) {
                                this.LogSeq("`536`", _2fc);
                                this.LogSeq("`339`", _2fc);
                                _2fe[i] = _2ff[_301[i]];
                            }
                        } else {
                            _2fe = _2ff;
                        }
                        this.LogSeq("`774`", _2fc);
                        _2fa.SetAvailableChildren(_2fe);
                        _2fa.SetSelectedChildren(true);
                    }
                }
            }
            this.LogSeq("`1260`", _2fc);
            break;
        case TIMING_ON_EACH_NEW_ATTEMPT:
            this.LogSeq("`739`", _2fc);
            this.LogSeq("`898`", _2fc);
            break;
        default:
            this.LogSeq("`842`", _2fc);
            break;
    }
    this.LogSeqReturn("", _2fc);
}

function Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_303, _304, _305) {
    if (_303 === null || _303 === undefined || _303 < _304) {
        _303 = _304;
    }
    if (_303 > _305) {
        _303 = _305;
    }
    var _306 = new Array(_303);
    var _307;
    var _308;
    for (var i = 0; i < _303; i++) {
        _308 = true;
        while (_308) {
            _307 = Sequencer_GetRandomNumberWithinRange(_304, _305);
            _308 = Sequencer_IsNumberAlreadyInArray(_307, _306);
        }
        _306[i] = _307;
    }
    _306.sort();
    return _306;
}

function Sequencer_GetRandomNumberWithinRange(_30a, _30b) {
    var diff = _30b - _30a;
    return Math.floor(Math.random() * (diff + _30a + 1));
}

function Sequencer_IsNumberAlreadyInArray(_30d, _30e) {
    for (var i = 0; i < _30e.length; i++) {
        if (_30e[i] == _30d) {
            return true;
        }
    }
    return false;
}

function Sequencer_SequencingExitActionRulesSubprocess(_310) {
    Debug.AssertError("Calling log not passed.", (_310 === undefined || _310 === null));
    var _311 = this.LogSeqAudit("`1061`", _310);
    this.LogSeq("`249`", _311);
    var _312 = this.GetCurrentActivity();
    var _313 = this.Activities.GetParentActivity(_312);
    var _314;
    if (_313 !== null) {
        _314 = this.GetActivityPath(_313, true);
    } else {
        _314 = this.GetActivityPath(_312, true);
    }
    this.LogSeq("`1225`", _311);
    var _315 = null;
    var _316 = null;
    this.LogSeq("`307`", _311);
    for (var i = (_314.length - 1); i >= 0; i--) {
        this.LogSeq("`553`", _311);
        _316 = this.SequencingRulesCheckProcess(_314[i], RULE_SET_EXIT, _311);
        this.LogSeq("`740`", _311);
        if (_316 !== null) {
            this.LogSeq("`415`", _311);
            _315 = _314[i];
            this.LogSeq("`1544`", _311);
            break;
        }
    }
    this.LogSeq("`1208`", _311);
    if (_315 !== null) {
        this.LogSeq("`352`", _311);
        this.TerminateDescendentAttemptsProcess(_315, _311);
        this.LogSeq("`466`", _311);
        this.EndAttemptProcess(_315, false, _311);
        this.LogSeq("`348`", _311);
        this.SetCurrentActivity(_315, _311);
    }
    this.LogSeq("`966`", _311);
    this.LogSeqReturn("", _311);
    return;
}

function Sequencer_SequencingPostConditionRulesSubprocess(_318) {
    Debug.AssertError("Calling log not passed.", (_318 === undefined || _318 === null));
    var _319 = this.LogSeqAudit("`1000`", _318);
    var _31a;
    this.LogSeq("`340`", _319);
    var _31b = this.GetCurrentActivity();
    if (_31b.IsSuspended()) {
        this.LogSeq("`899`", _319);
        _31a = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, null);
        this.LogSeqReturn(_31a, _319);
        return _31a;
    }
    this.LogSeq("`190`", _319);
    var _31c = this.SequencingRulesCheckProcess(_31b, RULE_SET_POST_CONDITION, _319);
    this.LogSeq("`766`", _319);
    if (_31c !== null) {
        this.LogSeq("`587`", _319);
        if (_31c == SEQUENCING_RULE_ACTION_RETRY || _31c == SEQUENCING_RULE_ACTION_CONTINUE || _31c == SEQUENCING_RULE_ACTION_PREVIOUS) {
            this.LogSeq("`47`", _319);
            _31a = new Sequencer_SequencingPostConditionRulesSubprocessResult(this.TranslateSequencingRuleActionIntoSequencingRequest(_31c), null);
            this.LogSeqReturn(_31a, _319);
            return _31a;
        }
        this.LogSeq("`621`", _319);
        if (_31c == SEQUENCING_RULE_ACTION_EXIT_PARENT || _31c == SEQUENCING_RULE_ACTION_EXIT_ALL) {
            this.LogSeq("`85`", _319);
            _31a = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, this.TranslateSequencingRuleActionIntoTerminationRequest(_31c));
            this.LogSeqReturn(_31a, _319);
            return _31a;
        }
        this.LogSeq("`752`", _319);
        if (_31c == SEQUENCING_RULE_ACTION_RETRY_ALL) {
            this.LogSeq("`30`", _319);
            _31a = new Sequencer_SequencingPostConditionRulesSubprocessResult(SEQUENCING_REQUEST_RETRY, TERMINATION_REQUEST_EXIT_ALL);
            this.LogSeqReturn(_31a, _319);
            return _31a;
        }
    }
    this.LogSeq("`484`", _319);
    _31a = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, null);
    this.LogSeqReturn(_31a, _319);
    return _31a;
}

function Sequencer_SequencingPostConditionRulesSubprocessResult(_31d, _31e) {
    this.TerminationRequest = _31e;
    this.SequencingRequest = _31d;
}
Sequencer_SequencingPostConditionRulesSubprocessResult.prototype.toString = function() {
    return "TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest;
};

function Sequencer_SequencingRequestProcess(_31f, _320, _321) {
    Debug.AssertError("Calling log not passed.", (_321 === undefined || _321 === null));
    var _322 = this.LogSeqAudit("`1293`" + _31f + ", " + _320 + ")", _321);
    var _323;
    switch (_31f) {
        case SEQUENCING_REQUEST_START:
            this.LogSeq("`1128`", _322);
            this.LogSeq("`952`", _322);
            var _324 = this.StartSequencingRequestProcess(_322);
            this.LogSeq("`695`", _322);
            if (_324.Exception !== null) {
                this.LogSeq("`81`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _324.Exception, _324.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1656`", _322);
                this.LogSeq("`122`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _324.DeliveryRequest, _324.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_RESUME_ALL:
            this.LogSeq("`1034`", _322);
            this.LogSeq("`885`", _322);
            var _325 = this.ResumeAllSequencingRequestProcess(_322);
            this.LogSeq("`646`", _322);
            if (_325.Exception !== null) {
                this.LogSeq("`71`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _325.Exception, _325.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1657`", _322);
                this.LogSeq("`108`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _325.DeliveryRequest, null, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_EXIT:
            this.LogSeq("`1153`", _322);
            this.LogSeq("`962`", _322);
            var _326 = this.ExitSequencingRequestProcess(_322);
            this.LogSeq("`701`", _322);
            if (_326.Exception !== null) {
                this.LogSeq("`83`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _326.Exception, _326.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1658`", _322);
                this.LogSeq("`125`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, null, _326.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_RETRY:
            this.LogSeq("`1129`", _322);
            this.LogSeq("`953`", _322);
            var _327 = this.RetrySequencingRequestProcess(_322);
            if (_327.Exception !== null) {
                this.LogSeq("`82`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _327.Exception, _327.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1659`", _322);
                this.LogSeq("`116`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _327.DeliveryRequest, null, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_CONTINUE:
            this.LogSeq("`1070`", _322);
            this.LogSeq("`906`", _322);
            var _328 = this.ContinueSequencingRequestProcess(_322);
            this.LogSeq("`661`", _322);
            if (_328.Exception !== null) {
                this.LogSeq("`27`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, _328.EndSequencingSession, _328.Exception, _328.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1660`", _322);
                this.LogSeq("`112`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _328.DeliveryRequest, _328.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_PREVIOUS:
            this.LogSeq("`1071`", _322);
            this.LogSeq("`907`", _322);
            var _329 = this.PreviousSequencingRequestProcess(_322);
            this.LogSeq("`662`", _322);
            if (_329.Exception !== null) {
                this.LogSeq("`73`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, _329.EndSequencingSession, _329.Exception, _329.ExceptionText, false);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1661`", _322);
                this.LogSeq("`113`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _329.DeliveryRequest, _329.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
        case SEQUENCING_REQUEST_CHOICE:
            this.LogSeq("`1110`", _322);
            this.LogSeq("`939`", _322);
            var _32a = this.ChoiceSequencingRequestProcess(_320, _322);
            this.LogSeq("`683`", _322);
            if (_32a.Exception !== null) {
                this.LogSeq("`77`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _32a.Exception, _32a.ExceptionText, _32a.Hidden);
                this.LogSeqReturn(_323, _322);
                return _323;
            } else {
                this.LogSeq("`1662`", _322);
                this.LogSeq("`120`", _322);
                _323 = new Sequencer_SequencingRequestProcessResult(_31f, _32a.DeliveryRequest, null, null, "", _32a.Hidden);
                this.LogSeqReturn(_323, _322);
                return _323;
            }
            break;
    }
    this.LogSeq("`150`", _322);
    _323 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, "SB.2.12-1", "The sequencing request (" + _31f + ") is not recognized.", false);
    this.LogSeqReturn(_323, _322);
    return _323;
}

function Sequencer_SequencingRequestProcessResult(_32b, _32c, _32d, _32e, _32f, _330) {
    Debug.AssertError("undefined hidden value", (_330 === undefined));
    Debug.AssertError("Invalid endSequencingSession (" + _32d + ") passed to SequencingRequestProcessResult.", (_32d != null && _32d != true && _32d != false));
    this.SequencingRequest = _32b;
    this.DeliveryRequest = _32c;
    this.EndSequencingSession = _32d;
    this.Exception = _32e;
    this.ExceptionText = _32f;
    this.Hidden = _330;
}
Sequencer_SequencingRequestProcessResult.prototype.toString = function() {
    return "SequencingRequest=" + this.SequencingRequest + ", DeliveryRequest=" + this.DeliveryRequest + ", EndSequencingSession=" + this.EndSequencingSession + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", Hidden=" + this.Hidden;
};

function Sequencer_SequencingRulesCheckProcess(_331, _332, _333) {
    Debug.AssertError("Calling log not passed.", (_333 === undefined || _333 === null));
    var _334 = this.LogSeqAudit("`1276`" + _331 + ", " + _332 + ")", _333);
    var _335;
    var _336 = Sequencer_GetApplicableSetofSequencingRules(_331, _332);
    this.LogSeq("`304`", _334);
    if (_336.length > 0) {
        this.LogSeq("`191`", _334);
        this.LogSeq("`1209`", _334);
        for (var i = 0; i < _336.length; i++) {
            this.LogSeq("`416`", _334);
            _335 = this.SequencingRulesCheckSubprocess(_331, _336[i], _334);
            this.LogSeq("`796`", _334);
            if (_335 === true) {
                this.LogSeq("`211`", _334);
                this.LogSeqReturn(_336[i].Action, _334);
                return _336[i].Action;
            }
        }
    }
    this.LogSeq("`460`", _334);
    this.LogSeqReturn("`1762`", _334);
    return null;
}

function Sequencer_GetApplicableSetofSequencingRules(_338, _339) {
    var _33a = new Array();
    if (_339 == RULE_SET_POST_CONDITION) {
        _33a = _338.GetPostConditionRules();
    } else {
        if (_339 == RULE_SET_EXIT) {
            _33a = _338.GetExitRules();
        } else {
            var _33b = _338.GetPreConditionRules();
            for (var i = 0; i < _33b.length; i++) {
                switch (_339) {
                    case RULE_SET_HIDE_FROM_CHOICE:
                        if (_33b[i].Action == SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE) {
                            _33a[_33a.length] = _33b[i];
                        }
                        break;
                    case RULE_SET_STOP_FORWARD_TRAVERSAL:
                        if (_33b[i].Action == SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL) {
                            _33a[_33a.length] = _33b[i];
                        }
                        break;
                    case RULE_SET_DISABLED:
                        if (_33b[i].Action == SEQUENCING_RULE_ACTION_DISABLED) {
                            _33a[_33a.length] = _33b[i];
                        }
                        break;
                    case RULE_SET_SKIPPED:
                        if (_33b[i].Action == SEQUENCING_RULE_ACTION_SKIP) {
                            _33a[_33a.length] = _33b[i];
                        }
                        break;
                    default:
                        Debug.AssertError("ERROR - invalid sequencing rule set - " + _339);
                        return null;
                }
            }
        }
    }
    return _33a;
}

function Sequencer_SequencingRulesCheckSubprocess(_33d, rule, _33f) {
    Debug.AssertError("Calling log not passed.", (_33f === undefined || _33f === null));
    var _340 = this.LogSeqAudit("`1166`" + _33d + ", " + rule + ")", _33f);
    this.LogSeq("`326`", _340);
    var _341 = new Array();
    var _342;
    var _343;
    var i;
    this.LogSeq("`742`", _340);
    for (i = 0; i < rule.RuleConditions.length; i++) {
        this.LogSeq("`102`", _340);
        _342 = this.EvaluateSequencingRuleCondition(_33d, rule.RuleConditions[i], _340);
        this.LogSeq("`704`", _340);
        if (rule.RuleConditions[i].Operator == RULE_CONDITION_OPERATOR_NOT) {
            this.LogSeq("`667`", _340);
            if (_342 != "unknown") {
                _342 = (!_342);
            }
        }
        this.LogSeq("`291`", _340);
        _341[_341.length] = _342;
    }
    this.LogSeq("`375`", _340);
    if (_341.length === 0) {
        this.LogSeq("`614`", _340);
        this.LogSeqReturn(RESULT_UNKNOWN, _340);
        return RESULT_UNKNOWN;
    }
    this.LogSeq("`62`", _340);
    if (rule.ConditionCombination == RULE_CONDITION_COMBINATION_ANY) {
        _343 = false;
        for (i = 0; i < _341.length; i++) {
            _343 = Sequencer_LogicalOR(_343, _341[i]);
        }
    } else {
        _343 = true;
        for (i = 0; i < _341.length; i++) {
            _343 = Sequencer_LogicalAND(_343, _341[i]);
        }
    }
    this.LogSeq("`622`", _340);
    this.LogSeqReturn(_343, _340);
    return _343;
}

function Sequencer_EvaluateSequencingRuleCondition(_345, _346, _347) {
    Debug.AssertError("Calling log not passed.", (_347 === undefined || _347 === null));
    var _348 = this.LogSeqAudit("`1319`" + _345 + ", " + _346 + ")", _347);
    var _349 = null;
    switch (_346.Condition) {
        case SEQUENCING_RULE_CONDITION_SATISFIED:
            _349 = _345.IsSatisfied(_346.ReferencedObjective, true);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
            _349 = _345.IsObjectiveStatusKnown(_346.ReferencedObjective, true);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
            _349 = _345.IsObjectiveMeasureKnown(_346.ReferencedObjective, true);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN:
            _349 = _345.IsObjectiveMeasureGreaterThan(_346.ReferencedObjective, _346.MeasureThreshold, true);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN:
            _349 = _345.IsObjectiveMeasureLessThan(_346.ReferencedObjective, _346.MeasureThreshold, true);
            break;
        case SEQUENCING_RULE_CONDITION_COMPLETED:
            _349 = _345.IsCompleted(_346.ReferencedObjective, true);
            break;
        case SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
            _349 = _345.IsActivityProgressKnown(_346.ReferencedObjective, true);
            break;
        case SEQUENCING_RULE_CONDITION_ATTEMPTED:
            _349 = _345.IsAttempted();
            break;
        case SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
            _349 = _345.IsAttemptLimitExceeded();
            break;
        case SEQUENCING_RULE_CONDITION_ALWAYS:
            _349 = true;
            break;
        default:
            Debug.AssertError("ERROR - Encountered unsupported rule condition - " + _346);
            _349 = RESULT_UNKNOWN;
            break;
    }
    _348.setReturn(_349 + "", _348);
    return _349;
}

function Sequencer_LogicalOR(_34a, _34b) {
    if (_34a == RESULT_UNKNOWN) {
        if (_34b === true) {
            return true;
        } else {
            return RESULT_UNKNOWN;
        }
    } else {
        if (_34b == RESULT_UNKNOWN) {
            if (_34a === true) {
                return true;
            } else {
                return RESULT_UNKNOWN;
            }
        } else {
            return (_34a || _34b);
        }
    }
}

function Sequencer_LogicalAND(_34c, _34d) {
    if (_34c == RESULT_UNKNOWN) {
        if (_34d === false) {
            return false;
        } else {
            return RESULT_UNKNOWN;
        }
    } else {
        if (_34d == RESULT_UNKNOWN) {
            if (_34c === false) {
                return false;
            } else {
                return RESULT_UNKNOWN;
            }
        } else {
            return (_34c && _34d);
        }
    }
}

function Sequencer_StartSequencingRequestProcess(_34e) {
    Debug.AssertError("Calling log not passed.", (_34e === undefined || _34e === null));
    var _34f = this.LogSeqAudit("`1222`", _34e);
    var _350;
    this.LogSeq("`498`", _34f);
    if (this.IsCurrentActivityDefined(_34f)) {
        this.LogSeq("`455`", _34f);
        _350 = new Sequencer_StartSequencingRequestProcessResult(null, "SB.2.5-1", IntegrationImplementation.GetString("You cannot 'Start' an item that is already open."), false);
        this.LogSeqReturn(_350, _34f);
        return _350;
    }
    var _351 = this.GetRootActivity(_34f);
    this.LogSeq("`318`", _34f);
    if (_351.IsALeaf()) {
        this.LogSeq("`240`", _34f);
        _350 = new Sequencer_StartSequencingRequestProcessResult(_351, null, "", false);
        this.LogSeqReturn(_350, _34f);
        return _350;
    } else {
        if (Control.Package.Properties.AlwaysFlowToFirstSco === true || Control.Package.Properties.ShowCourseStructure == false) {
            this.LogSeq("`315`", _34f);
            this.LogSeq("`1055`", _34f);
            var _352 = this.GetOrderedListOfActivities(_34f);
            this.LogSeq("`926`", _34f);
            for (var _353 in _352) {
                if (_352[_353].IsDeliverable() === true) {
                    _350 = new Sequencer_StartSequencingRequestProcessResult(_352[_353], null, "", false);
                    this.LogSeqReturn(_350, _34f);
                    return _350;
                }
            }
            _350 = new Sequencer_StartSequencingRequestProcessResult(null, "SB.2.5-2.5", "There are no deliverable activities in this course.", false);
            this.LogSeqReturn(_350, _34f);
            return _350;
        } else {
            this.LogSeq("`1705`", _34f);
            this.LogSeq("`164`", _34f);
            var _354 = this.FlowSubprocess(_351, FLOW_DIRECTION_FORWARD, true, _34f);
            this.LogSeq("`978`", _34f);
            if (_354.Deliverable === false) {
                this.LogSeq("`233`", _34f);
                _350 = new Sequencer_StartSequencingRequestProcessResult(null, _354.Exception, _354.ExceptionText, _354.EndSequencingSession);
                this.LogSeqReturn(_350, _34f);
                return _350;
            } else {
                this.LogSeq("`1664`", _34f);
                this.LogSeq("`325`", _34f);
                _350 = new Sequencer_StartSequencingRequestProcessResult(_354.IdentifiedActivity, null, "", false);
                this.LogSeqReturn(_350, _34f);
                return _350;
            }
        }
    }
}

function Sequencer_StartSequencingRequestProcessResult(_355, _356, _357, _358) {
    Debug.AssertError("Invalid endSequencingSession (" + _358 + ") passed to StartSequencingRequestProcessResult.", (_358 != true && _358 != false));
    this.DeliveryRequest = _355;
    this.Exception = _356;
    this.ExceptionText = _357;
    this.EndSequencingSession = _358;
}
Sequencer_StartSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_TerminateDescendentAttemptsProcess(_359, _35a) {
    Debug.AssertError("Calling log not passed.", (_35a === undefined || _35a === null));
    var _35b = this.LogSeqAudit("`1121`" + _359 + ")", _35a);
    this.LogSeq("`689`" + this.GetCurrentActivity() + "`1386`" + _359 + ")", _35b);
    var _35c = this.FindCommonAncestor(_359, this.GetCurrentActivity(), _35b);
    this.LogSeq("`152`" + _35c + "`967`", _35b);
    var _35d = this.GetPathToAncestorExclusive(this.GetCurrentActivity(), _35c, false);
    var _35e = new Array();
    this.LogSeq("`526`", _35b);
    if (_35d.length > 0) {
        this.LogSeq("`1057`", _35b);
        for (var i = 0; i < _35d.length; i++) {
            this.LogSeq("`474`" + _35d[i].LearningObject.ItemIdentifier, _35b);
            _35e = _35e.concat(this.EndAttemptProcess(_35d[i], true, _35b));
        }
    }
    this.LogSeq("`743`", _35b);
    var _360 = this.GetMinimalSubsetOfActivitiesToRollup(_35e, null);
    for (var _361 in _360) {
        this.OverallRollupProcess(_360[_361], _35b);
    }
    this.LogSeq("`1018`", _35b);
    this.LogSeqReturn("", _35b);
    return;
}

function Sequencer_TerminationRequestProcess(_362, _363) {
    Debug.AssertError("Calling log not passed.", (_363 === undefined || _363 === null));
    var _364 = this.LogSeqAudit("`1294`" + _362 + ")", _363);
    var _365;
    var _366 = this.GetCurrentActivity();
    var _367 = this.Activities.GetParentActivity(_366);
    var _368 = this.GetRootActivity(_364);
    var _369;
    var _36a = null;
    var _36b = false;
    this.LogSeq("`367`", _364);
    if (!this.IsCurrentActivityDefined(_364)) {
        this.LogSeq("`381`", _364);
        _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-1", IntegrationImplementation.GetString("You cannot use 'Terminate' because no item is currently open."));
        this.LogSeqReturn(_365, _364);
        return _365;
    }
    this.LogSeq("`88`", _364);
    if ((_362 == TERMINATION_REQUEST_EXIT || _362 == TERMINATION_REQUEST_ABANDON) && (_366.IsActive() === false)) {
        this.LogSeq("`382`", _364);
        _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-2", IntegrationImplementation.GetString("The current activity has already been terminated."));
        this.LogSeqReturn(_365, _364);
        return _365;
    }
    switch (_362) {
        case TERMINATION_REQUEST_EXIT:
            this.LogSeq("`1157`", _364);
            this.LogSeq("`383`", _364);
            this.EndAttemptProcess(_366, false, _364);
            this.LogSeq("`241`", _364);
            this.SequencingExitActionRulesSubprocess(_364);
            this.LogSeq("`1641`", _364);
            var _36c;
            do {
                this.LogSeq("`1112`", _364);
                _36c = false;
                this.LogSeq("`588`" + this.GetCurrentActivity() + ")", _364);
                _36a = this.SequencingPostConditionRulesSubprocess(_364);
                this.LogSeq("`473`", _364);
                if (_36a.TerminationRequest == TERMINATION_REQUEST_EXIT_ALL) {
                    this.LogSeq("`908`", _364);
                    _362 = TERMINATION_REQUEST_EXIT_ALL;
                    this.LogSeq("`675`", _364);
                    _36b = true;
                    break;
                }
                this.LogSeq("`53`", _364);
                if (_36a.TerminationRequest == TERMINATION_REQUEST_EXIT_PARENT) {
                    this.LogSeq("`281`", _364);
                    if (this.GetCurrentActivity() !== null && this.GetCurrentActivity().IsTheRoot() === false) {
                        this.LogSeq("`676`", _364);
                        this.SetCurrentActivity(this.Activities.GetParentActivity(this.GetCurrentActivity()), _364);
                        this.LogSeq("`775`", _364);
                        this.EndAttemptProcess(this.GetCurrentActivity(), false, _364);
                        this.LogSeq("`494`", _364);
                        _36c = true;
                    } else {
                        this.LogSeq("`1598`", _364);
                        this.LogSeq("`355`", _364);
                        _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-4", IntegrationImplementation.GetString("An 'Exit Parent' sequencing request cannot be processed on the root of the activity tree."));
                        this.LogSeqReturn(_365, _364);
                        return _365;
                    }
                } else {
                    this.LogSeq("`1642`", _364);
                    this.LogSeq("`8`", _364);
                    if (this.GetCurrentActivity() !== null && this.GetCurrentActivity().IsTheRoot() === true && _36a.SequencingRequest != SEQUENCING_REQUEST_RETRY) {
                        this.LogSeq("`404`", _364);
                        _365 = new Sequencer_TerminationRequestProcessResult(_362, SEQUENCING_REQUEST_EXIT, null, "");
                        this.LogSeqReturn(_365, _364);
                        return _365;
                    }
                }
                this.LogSeq("`912`" + _36c + ")", _364);
            } while (_36c !== false);
            if (!_36b) {
                this.LogSeq("`54`", _364);
                _365 = new Sequencer_TerminationRequestProcessResult(_362, _36a.SequencingRequest, null, "");
                this.LogSeqReturn(_365, _364);
                return _365;
                break;
            }
        case TERMINATION_REQUEST_EXIT_ALL:
            this.LogSeq("`1077`", _364);
            this.LogSeq("`238`", _364);
            if (_366.IsActive()) {
                this.LogSeq("`819`", _364);
                this.EndAttemptProcess(_366, false, _364);
            }
            this.LogSeq("`589`", _364);
            this.TerminateDescendentAttemptsProcess(_368, _364);
            this.LogSeq("`741`", _364);
            this.EndAttemptProcess(_368, false, _364);
            this.LogSeq("`353`", _364);
            this.SetCurrentActivity(_368, _364);
            this.LogSeq("`3`", _364);
            if (_36a !== null && _36a.SequencingRequest !== null) {
                this.LogSeq("`451`", _364);
                _365 = new Sequencer_TerminationRequestProcessResult(_362, _36a.SequencingRequest, null, "");
                this.LogSeqReturn(_365, _364);
                return _365;
            } else {
                this.LogSeq("`1036`", _364);
                _365 = new Sequencer_TerminationRequestProcessResult(_362, SEQUENCING_REQUEST_EXIT, null, "");
                this.LogSeqReturn(_365, _364);
                return _365;
            }
            break;
        case TERMINATION_REQUEST_SUSPEND_ALL:
            this.LogSeq("`1014`", _364);
            this.LogSeq("`45`", _364);
            if ((Control.Package.Properties.InvokeRollupAtSuspendAll === true || this.ReturnToLmsInvoked) && _366.IsActive()) {
                this.LogSeq("`510`", _364);
                this.EndAttemptProcess(_366, false, _364, true);
            }
            if (_366.IsActive() || _366.IsSuspended()) {
                this.LogSeq("`1096`", _364);
                this.OverallRollupProcess(_366, _364);
                this.LogSeq("`856`", _364);
                this.SetSuspendedActivity(_366);
            } else {
                this.LogSeq("`1693`", _364);
                this.LogSeq("`258`", _364);
                if (!_366.IsTheRoot()) {
                    this.LogSeq("`677`", _364);
                    this.SetSuspendedActivity(_367);
                } else {
                    this.LogSeq("`1643`", _364);
                    this.LogSeq("`263`", _364);
                    Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-3", "The suspend all termination request failed because there is no activity to suspend");
                }
            }
            this.LogSeq("`273`", _364);
            _369 = this.GetActivityPath(this.GetSuspendedActivity(_364), true);
            this.LogSeq("`1097`", _364);
            if (_369.length === 0) {
                this.LogSeq("`274`", _364);
                _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-5", IntegrationImplementation.GetString("Nothing to suspend"));
                this.LogSeqReturn(_365, _364);
                return _365;
            }
            this.LogSeq("`1015`", _364);
            for (var i = 0; i < _369.length; i++) {
                this.LogSeq("`640`" + _369[i].GetItemIdentifier() + ")", _364);
                _369[i].SetActive(false);
                this.LogSeq("`857`", _364);
                _369[i].SetSuspended(true);
            }
            this.LogSeq("`354`", _364);
            this.SetCurrentActivity(_368, _364);
            this.LogSeq("`160`", _364);
            _365 = new Sequencer_TerminationRequestProcessResult(_362, SEQUENCING_REQUEST_EXIT, null, "");
            this.LogSeqReturn(_365, _364);
            return _365;
            break;
        case TERMINATION_REQUEST_ABANDON:
            this.LogSeq("`1098`", _364);
            this.LogSeq("`810`", _364);
            _366.SetActive(false);
            this.LogSeq("`459`", _364);
            _365 = new Sequencer_TerminationRequestProcessResult(_362, null, null, "");
            this.LogSeqReturn(_365, _364);
            return _365;
            break;
        case TERMINATION_REQUEST_ABANDON_ALL:
            this.LogSeq("`1016`", _364);
            this.LogSeq("`282`", _364);
            _369 = this.GetActivityPath(_366, true);
            this.LogSeq("`1099`", _364);
            if (_369.length === 0) {
                this.LogSeq("`283`", _364);
                _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-6", IntegrationImplementation.GetString("Nothing to close"));
                this.LogSeqReturn(_365, _364);
                return _365;
            }
            this.LogSeq("`1017`", _364);
            for (var i = 0; i < _369.length; i++) {
                this.LogSeq("`871`", _364);
                _369[i].SetActive(false);
            }
            this.LogSeq("`360`", _364);
            this.SetCurrentActivity(_368, _364);
            this.LogSeq("`165`", _364);
            _365 = new Sequencer_TerminationRequestProcessResult(_362, SEQUENCING_REQUEST_EXIT, null, "");
            this.LogSeqReturn(_365, _364);
            return _365;
            break;
        default:
            this.LogSeq("`255`", _364);
            _365 = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-7", IntegrationImplementation.GetString("The 'Termination' request {0} is not recognized.", _362));
            this.LogSeqReturn(_365, _364);
            return _365;
            break;
    }
}

function Sequencer_TerminationRequestProcessResult(_36e, _36f, _370, _371) {
    this.TerminationRequest = _36e;
    this.SequencingRequest = _36f;
    this.Exception = _370;
    this.ExceptionText = _371;
}
Sequencer_TerminationRequestProcessResult.prototype.toString = function() {
    return "TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function SSPApi(_372, _373) {
    this.MaxSSPStorage = parseInt(_372, 10);
    this.ApiInstance = _373;
}
SSPApi.prototype.InitializeBuckets = SSPApi_InitializeBuckets;
SSPApi.prototype.CheckForGetValueError = SSPApi_CheckForGetValueError;
SSPApi.prototype.CheckForSetValueError = SSPApi_CheckForSetValueError;
SSPApi.prototype.RetrieveGetValueData = SSPApi_RetrieveGetValueData;
SSPApi.prototype.StoreValue = SSPApi_StoreValue;
SSPApi.prototype.GetBucketById = SSPApi_GetBucketById;
SSPApi.prototype.GetBucketByIndex = SSPApi_GetBucketByIndex;
SSPApi.prototype.GetAccessibleBucketCount = SSPApi_GetAccessibleBucketCount;
SSPApi.prototype.GetDelimiterValues = SSPApi_GetDelimiterValues;
SSPApi.prototype.RemoveDelimitersFromElementName = SSPApi_RemoveDelimitersFromElementName;
SSPApi.prototype.RemoveDelimitersFromValue = SSPApi_RemoveDelimitersFromValue;
SSPApi.prototype.GetDelimiterValues = SSPApi_GetDelimiterValues;
SSPApi.prototype.GetCurrentSCOItemIdentifier = SSPApi_GetCurrentSCOItemIdentifier;
SSPApi.prototype.AllocateBucket = SSPApi_AllocateBucket;
SSPApi.prototype.GetStorageAllowedByLms = SSPApi_GetStorageAllowedByLms;
SSPApi.prototype.ResetBucketsForActivity = SSPApi_ResetBucketsForActivity;
SSPApi.prototype.SetErrorState = SSPApi_SetErrorState;
SSPApi.prototype.WriteDetailedLog = SSPApi_WriteDetailedLog;

function SSPApi_InitializeBuckets() {
    var _374;
    var _375;
    var _376;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _374 = Control.SSPBuckets[i];
        if (_374.AllocationSuccess == SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED) {
            _375 = this.GetStorageAllowedByLms(_374.SizeMin, _374.SizeRequested);
            if (_375 == null) {
                _376 = SSP_ALLOCATION_SUCCESS_FAILURE;
            } else {
                if (_375 == _374.SizeMin) {
                    _376 = SSP_ALLOCATION_SUCCESS_MINIMUM;
                } else {
                    if (_375 == _374.SizeRequested) {
                        _376 = SSP_ALLOCATION_SUCCESS_REQUESTED;
                    } else {
                        Debug.AssertError("Invalid allocation");
                    }
                }
            }
            _374.AllocationSuccess = _376;
        }
    }
}

function SSPApi_CheckForGetValueError(_378, _379, _37a, _37b) {
    var _37c = this.RemoveDelimitersFromElementName(_379);
    var _37d = this.GetDelimiterValues(_378);
    var _37e;
    var _37f;
    var size;
    if (_37a !== "") {
        var _381 = this.GetAccessibleBucketCount();
        if (_37a >= _381) {
            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The SSP Bucket collection does not have an element at index " + _37a + ", the current element count is " + _381 + ".");
            return false;
        }
    }
    switch (_37c) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.allocate data model element is write-only.");
            return false;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _37e = this.GetBucketByIndex(_37a);
            _37f = _37d["offset"];
            size = _37d["size"];
            if (_37e.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_37f != null) {
                _37f = new String(_37f);
                if (_37f.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _37f = parseInt(_37f, 10);
                if (_37f % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_37f >= _37e.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _37e.SizeAllocated() + " bytes of storage. Bytes started at offset " + _37f + "were requested.");
                    return false;
                }
            }
            if (size != null) {
                size = new String(size);
                if (size.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be a valid even integer greater than 0.");
                    return false;
                }
                size = parseInt(size, 10);
                if (size % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be an even integer.");
                    return false;
                }
                if ((_37f + size) >= _37e.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Requested data exceeds available data. This bucket currently has allocated " + _37e.SizeAllocated() + " bytes of storage. " + size + " bytes starting at offset " + _37f + " were requested. Size + Offset = " + (size + _37f));
                    return false;
                }
            }
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.n.appendData data model element is write-only.");
            return false;
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            if (_37d["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _37e = this.GetBucketById(_37d["bucketID"], true);
            if (_37e == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_37d["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            _37f = _37d["offset"];
            size = _37d["size"];
            if (_37e.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_37f != null) {
                _37f = new String(_37f);
                if (_37f.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _37f = parseInt(_37f, 10);
                if (_37f % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_37f >= _37e.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _37e.SizeAllocated() + " bytes of storage. Bytes starting at offset " + _37f + " were requested.");
                    return false;
                }
            }
            if (size != null) {
                size = new String(size);
                if (size.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be a valid even integer greater than 0.");
                    return false;
                }
                size = parseInt(size, 10);
                if (size % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be an even integer.");
                    return false;
                }
                if ((_37f + size) >= _37e.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Requested data exceeds available data. This bucket currently has allocated " + _37e.SizeAllocated() + " bytes of storage. " + size + " bytes started at offset " + _37f + " were requested. Size + Offset = " + (size + _37f));
                    return false;
                }
            }
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            var _382 = _37d["bucketID"];
            if (_382 == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _37e = this.GetBucketById(_382, true);
            if (_37e == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_37d["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            if (_37e.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
            }
            break;
        case "ssp.appendData":
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.appendData data model element is write-only.");
            return false;
            break;
        default:
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _378 + "' does not exist.");
            return false;
            break;
    }
    this.WriteDetailedLog("`1558`");
    return true;
}

function SSPApi_CheckForSetValueError(_383, _384, _385, _386, _387) {
    var _388 = this.RemoveDelimitersFromElementName(_385);
    var _389 = this.GetDelimiterValues(_384);
    _384 = this.RemoveDelimitersFromValue(_384);
    var _38a;
    var _38b;
    var _38c;
    if (_386 !== "") {
        var _38d = this.GetAccessibleBucketCount();
        if (_386 >= _38d) {
            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The SSP Bucket collection does not have an element at index " + _386 + ", the current element count is " + _38d + ".");
            return false;
        }
    }
    switch (_388) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp._count data model element is read-only");
            return false;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            var _38e = _389["bucketID"];
            var _38f = _389["minimum"];
            var _390 = _389["requested"];
            var _391 = _389["reducible"];
            var _392 = _389["persistence"];
            var type = _389["type"];
            if (_38e == null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucketID delimiter must be included in calls to ssp.allocate.");
                return false;
            }
            _38e = new String(_38e);
            if (_38e.length > 4000) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucketID can only have a maximum of 4000 characters.");
                return false;
            }
            if (_390 == null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The requested delimiter must be included in calls to ssp.allocate.");
                return false;
            }
            _390 = new String(_390);
            if (_390.search(/\D/) >= 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be a valid integer greater than or equal to 0.");
                return false;
            }
            _390 = parseInt(_390, 10);
            if (_390 < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be greater than or equal to 0.");
                return false;
            }
            if (_390 % 2 != 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be an even number.");
                return false;
            }
            var _394 = (Math.pow(2, 32) - 1);
            if (_390 > _394) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested is bigger than the max size this LMS allows of " + _394 + ".");
                return false;
            }
            if (_38f != null) {
                _38f = new String(_38f);
                if (_38f.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be a valid integer greater than or equal to 0.");
                    return false;
                }
                _38f = parseInt(_38f, 10);
                if (_38f < 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be greater than or equal to 0.");
                    return false;
                }
                if (_38f % 2 != 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be an even number.");
                    return false;
                }
                if (_38f > _394) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum is bigger than the max size this LMS allows of " + _394 + ".");
                    return false;
                }
                if (_38f > _390) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The minimum requested amount of storage (" + _38f + ") cannot be greater than the requested amount (" + _390 + ").");
                    return false;
                }
            }
            if (_391 != null) {
                _391 = new String(_391);
                if (_391 != "true" && _391 != "false") {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The reducible delimiter ('" + _391 + "') must be 'true' or 'false'.");
                    return false;
                }
            }
            if (_392 != null) {
                _392 = new String(_392);
                if (_392 != SSP_PERSISTENCE_LEARNER && _392 != SSP_PERSISTENCE_COURSE && _392 != SSP_PERSISTENCE_SESSION) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The persistence delimiter ('" + _392 + "') must be " + SSP_PERSISTENCE_SESSION + ", '" + SSP_PERSISTENCE_COURSE + "' or '" + SSP_PERSISTENCE_LEARNER + "'.");
                    return false;
                }
            }
            type = new String(type);
            if (type.length > 3000) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucket type can only have a maximum of 3000 characters.");
                return false;
            }
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.allocation_success data model element is read-only");
            return false;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.bucket_id data model element is read-only");
            return false;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.bucket_state data model element is read-only");
            return false;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _38c = this.GetBucketByIndex(_386);
            _38b = _389["offset"];
            if (_38c.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_38b != null) {
                _38b = new String(_38b);
                if (_38b.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _38b = parseInt(_38b, 10);
                if (_38b % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_38b >= _38c.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _38c.SizeAllocated() + " bytes of storage. Setting bytes started at offset " + _38b + " was requested.");
                    return false;
                }
                if (_38b >= _38c.CurrentlyUsedStorage()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket not packed. There are currently " + _38c.CurrentlyUsedStorage() + " bytes of data stored in this bucket. The offset must be " + "less than this value.");
                    return false;
                }
            } else {
                _38b = 0;
            }
            _38a = _38b + (_384.length * 2);
            if (_38a > _38c.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_384.length * 2) + " bytes (each character is 2 bytes). Added to an offset of " + _38b + " bytes, gives a total size of " + _38a + ", which is greater than the allocated size of this bucket (" + _38c.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            _38c = this.GetBucketByIndex(_386);
            if (_38c.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            _38a = _38c.CurrentlyUsedStorage() + (_384.length * 2);
            if (_38a > _38c.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_384.length * 2) + " bytes (each character is 2 bytes). Added to the current value of size " + _38c.CurrentlyUsedStorage() + " bytes, gives a total size of " + _38a + ", which is greater than the allocated size of this bucket (" + _38c.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            if (_389["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _38c = this.GetBucketById(_389["bucketID"], true);
            if (_38c == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_389["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            _38b = _389["offset"];
            if (_38c.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_38b != null) {
                _38b = new String(_38b);
                if (_38b.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _38b = parseInt(_38b, 10);
                if (_38b % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_38b >= _38c.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _38c.SizeAllocated() + " bytes of storage. Setting bytes started at offset " + _38b + " was requested.");
                    return false;
                }
                if (_38b >= _38c.CurrentlyUsedStorage()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket not packed. There are currently " + _38c.CurrentlyUsedStorage() + " bytes of data stored in this bucket. The offset must be " + "less than this value.");
                    return false;
                }
            } else {
                _38b = 0;
            }
            _38a = _38b + (_384.length * 2);
            if (_38a > _38c.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_384.length * 2) + " bytes (each character is 2 bytes). Added to an offset of " + _38b + " bytes, gives a total size of " + _38a + ", which is greater than the allocated size of this bucket (" + _38c.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.bucket_state data model element is read-only");
            return false;
        case "ssp.appendData":
            this.WriteDetailedLog("`1493`");
            if (_389["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _38c = this.GetBucketById(_389["bucketID"], true);
            if (_38c == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_389["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            if (_38c.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            _38a = _38c.CurrentlyUsedStorage() + (_384.length * 2);
            if (_38a > _38c.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_384.length * 2) + " bytes (each character is 2 bytes). Added to the current value of size " + _38c.CurrentlyUsedStorage() + " bytes, gives a total size of " + _38a + ", which is greater than the allocated size of this bucket (" + _38c.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        default:
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _383 + "' does not exist.");
            return false;
            break;
    }
    this.WriteDetailedLog("`1558`");
    return true;
}

function SSPApi_RetrieveGetValueData(_395, _396, _397, _398) {
    var _399 = this.RemoveDelimitersFromElementName(_396);
    var _39a = this.GetDelimiterValues(_395);
    var _39b = "";
    switch (_399) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            _39b = this.GetAccessibleBucketCount();
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            Debug.AssertError("ERROR - Element is Write Only, ssp.allocate");
            blnReturn = false;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            var _39c = this.GetBucketByIndex(_397);
            _39b = _39c.AllocationSuccess;
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            _39c = this.GetBucketByIndex(_397);
            _39b = _39c.Id;
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            _39c = this.GetBucketByIndex(_397);
            _39b = _39c.GetBucketState();
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _39c = this.GetBucketByIndex(_397);
            _39b = _39c.GetData(_39a["offset"], _39a["size"]);
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            Debug.AssertError("ERROR - Element is Write Only, ssp.n.appendData");
            blnReturn = false;
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            _39c = this.GetBucketById(_39a["bucketID"], true);
            _39b = _39c.GetData(_39a["offset"], _39a["size"]);
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            _39c = this.GetBucketById(_39a["bucketID"], true);
            _39b = _39c.GetBucketState();
            break;
        case "ssp.appendData":
            Debug.AssertError("ERROR - Element is Write Only, ssp.appendData");
            blnReturn = false;
            break;
        default:
            Debug.AssertError("ERROR - Unrecognized data model element:" + _399);
            blnReturn = false;
            break;
    }
    return _39b;
}

function SSPApi_StoreValue(_39d, _39e, _39f, _3a0, _3a1) {
    var _3a2 = this.RemoveDelimitersFromElementName(_39f);
    var _3a3 = this.GetDelimiterValues(_39e);
    _39e = this.RemoveDelimitersFromValue(_39e);
    var _3a4 = true;
    switch (_3a2) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            Debug.AssertError("ERROR - Element is Read Only, ssp._count");
            _3a4 = false;
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            this.AllocateBucket(_3a3["bucketID"], _3a3["minimum"], _3a3["requested"], _3a3["reducible"], _3a3["persistence"], _3a3["type"]);
            _3a4 = true;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            Debug.AssertError("ERROR - Element is Read Only, ssp._count");
            _3a4 = false;
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
            _3a4 = false;
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_state");
            _3a4 = false;
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            bucket = this.GetBucketByIndex(_3a0);
            bucket.WriteData(_3a3["offset"], _39e);
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            bucket = this.GetBucketByIndex(_3a0);
            bucket.AppendData(_39e);
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            bucket = this.GetBucketById(_3a3["bucketID"], true);
            bucket.WriteData(_3a3["offset"], _39e);
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
            _3a4 = false;
            break;
        case "ssp.appendData":
            this.WriteDetailedLog("`1493`");
            bucket = this.GetBucketById(_3a3["bucketID"], true);
            bucket.AppendData(_39e);
            break;
        default:
            Debug.AssertError("ERROR - Unrecognized data model element:" + _3a2);
            _3a4 = false;
            break;
    }
    return _3a4;
}

function SSPApi_GetBucketById(_3a5, _3a6) {
    var _3a7 = null;
    for (var _3a8 in Control.SSPBuckets) {
        if ((_3a6 == false) || Control.SSPBuckets[_3a8].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            if (Control.SSPBuckets[_3a8].Id == _3a5) {
                return Control.SSPBuckets[_3a8];
            }
        }
    }
    return _3a7;
}

function SSPApi_GetBucketByIndex(_3a9) {
    var _3aa = null;
    i = 0;
    for (var _3ab in Control.SSPBuckets) {
        if (Control.SSPBuckets[_3ab].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            if (i == _3a9) {
                return Control.SSPBuckets[_3ab];
            }
            i++;
        }
    }
    return _3aa;
}

function SSPApi_GetAccessibleBucketCount() {
    var _3ac = 0;
    for (var _3ad in Control.SSPBuckets) {
        if (Control.SSPBuckets[_3ad].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            _3ac++;
        }
    }
    return _3ac;
}

function SSPApi_RemoveDelimitersFromElementName(_3ae) {
    var _3af;
    var _3b0;
    _3ae = new String(_3ae);
    _3b0 = _3ae;
    _3af = _3ae.indexOf("{");
    if (_3af > 0) {
        _3b0 = _3ae.substr(0, _3af - 1);
    }
    return _3b0.toString();
}

function SSPApi_RemoveDelimitersFromValue(_3b1) {
    var _3b2 = /^\{\w+=[^\s\}]+\}/;
    _3b1 = new String(_3b1);
    while (_3b1.match(_3b2)) {
        _3b1 = _3b1.replace(_3b2, "");
    }
    return _3b1;
}

function SSPApi_GetDelimiterValues(_3b3) {
    var _3b4 = /\{\w+=[^\s\}]+\}/g;
    var _3b5 = _3b3.match(_3b4);
    var _3b6 = new Array();
    if (_3b5 != null) {
        for (var i = 0; i < _3b5.length; i++) {
            var _3b8 = _3b5[i].slice(1, -1);
            var _3b9 = _3b8.split("=");
            _3b6[_3b9[0]] = [_3b9[1]];
        }
    }
    return _3b6;
}

function SSPApi_GetCurrentSCOItemIdentifier() {
    return Control.Sequencer.GetCurrentActivity().ItemIdentifier;
}

function SSPApi_AllocateBucket(_3ba, _3bb, _3bc, _3bd, _3be, type) {
    var _3c0 = this.GetBucketById(_3ba, false);
    var _3c1;
    if (_3bb == undefined || type == "minimum") {
        _3bb = 0;
    }
    if (_3bd == undefined || type == "reducible") {
        redicible = false;
    }
    if (_3be == undefined || type == "persistence") {
        _3be = "learner";
    }
    if (type == undefined || type == "undefined") {
        type = "";
    }
    if (_3c0 != null) {
        if (_3c0.SizeMin != _3bb || _3c0.SizeRequested != _3bc || _3c0.Reducible != _3bd || _3c0.Persistence != _3be || _3c0.BucketType != type) {
            _3c1 = Control.SSPBuckets.length;
            Control.SSPBuckets[_3c1] = new SSPBucket(_3c1, _3ba, type, _3be, _3bb, _3bc, _3bd, this.GetCurrentSCOItemIdentifier(), SSP_ALLOCATION_SUCCESS_FAILURE, "");
            Control.SSPBuckets[_3c1].SetDirtyData();
        }
    } else {
        var _3c2 = this.GetStorageAllowedByLms(_3bb, _3bc);
        var _3c3;
        if (_3c2 == null) {
            _3c3 = SSP_ALLOCATION_SUCCESS_FAILURE;
        } else {
            if (_3c2 == _3bb) {
                _3c3 = SSP_ALLOCATION_SUCCESS_MINIMUM;
            } else {
                if (_3c2 == _3bc) {
                    _3c3 = SSP_ALLOCATION_SUCCESS_REQUESTED;
                } else {
                    Debug.AssertError("Invalid allocation");
                }
            }
        }
        _3c1 = Control.SSPBuckets.length;
        Control.SSPBuckets[_3c1] = new SSPBucket(_3c1, _3ba, type, _3be, _3bb, _3bc, _3bd, (_3be == SSP_PERSISTENCE_SESSION ? this.GetCurrentSCOItemIdentifier() : ""), _3c3, "");
        Control.SSPBuckets[_3c1].SetDirtyData();
    }
}

function SSPApi_GetStorageAllowedByLms(_3c4, _3c5) {
    _3c4 = parseInt(_3c4, 10);
    _3c5 = parseInt(_3c5, 10);
    var _3c6 = 0;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _3c6 += Control.SSPBuckets[i].SizeAllocated();
    }
    if ((_3c6 + _3c5) <= this.MaxSSPStorage) {
        return _3c5;
    } else {
        if (_3c4 > 0 && ((_3c6 + _3c4) <= this.MaxSSPStorage)) {
            return _3c4;
        } else {
            return null;
        }
    }
}

function SSPApi_ResetBucketsForActivity(_3c8) {
    var _3c9;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _3c9 = Control.SSPBuckets[i];
        if (_3c9.LocalActivityId == _3c8 && _3c9.Persistence == SSP_PERSISTENCE_SESSION) {
            _3c9.ResetData();
        }
    }
}

function SSPApi_SetErrorState(_3cb, _3cc) {
    this.ApiInstance.SetErrorState(_3cb, _3cc);
}

function SSPApi_WriteDetailedLog(str) {
    this.ApiInstance.WriteDetailedLog(str);
}
