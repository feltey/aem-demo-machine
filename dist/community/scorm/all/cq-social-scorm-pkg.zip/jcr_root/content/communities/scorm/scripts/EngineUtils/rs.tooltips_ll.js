//Created by Rustici Software

//requires jquery 1.3.1 or later
//requires jquery.hoverIntent library

var tooltip = function(parent) {
    (function($) {
        var xOffset = 20;
        var yOffset = 20;

        if ($("#tooltip").length == 0) {
            $("body").append(
                '<div id="tooltip" class="tooltip" style="display:none"></div>');

        }
        //Hover tool tips
        var elementList = (parent) ? parent.find("[tooltipid]") : $("[tooltipid]");

        //alert(elementList.length);
        elementList.hoverIntent({
            sensitivity: 7,
            interval: 500,
            over: function() {
                var id = $(this).attr('tooltipid');
                if (helpTextDictionary && helpTextDictionary[id]) {
                    helpText = helpTextDictionary[id];
                } else helpText = id;
                $("#tooltip").html(helpText).fadeIn("fast");
            },
            timeout: 100,
            out: function() {
                $("#tooltip").fadeOut("fast");
            }
        });

        elementList.mousemove(function(e) {
            var x = (e.pageX + 350 > $(window).width()) ? e.pageX - 320 : e.pageX + xOffset;
            var y = (e.pageY + 200 > $(window).height()) ? e.pageY - 120 : e.pageY + yOffset;
            $("#tooltip").css("top", y + "px").css("left", x + "px");
        });

    })(jQuery);
};
