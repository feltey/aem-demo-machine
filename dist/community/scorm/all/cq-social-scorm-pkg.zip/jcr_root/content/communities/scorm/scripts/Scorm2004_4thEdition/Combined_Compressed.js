var SCORM_TRUE = "true";
var SCORM_FALSE = "false";
var SCORM_UNKNOWN = "unknown";
var SCORM2004_NO_ERROR = "0";
var SCORM2004_GENERAL_EXCEPTION_ERROR = "101";
var SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR = "102";
var SCORM2004_ALREADY_INTIAILIZED_ERROR = "103";
var SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR = "104";
var SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR = "111";
var SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR = "112";
var SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR = "113";
var SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR = "122";
var SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR = "123";
var SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR = "132";
var SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR = "133";
var SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR = "142";
var SCORM2004_COMMIT_AFTER_TERMINATION_ERROR = "143";
var SCORM2004_GENERAL_ARGUMENT_ERROR = "201";
var SCORM2004_GENERAL_GET_FAILURE_ERROR = "301";
var SCORM2004_GENERAL_SET_FAILURE_ERROR = "351";
var SCORM2004_GENERAL_COMMIT_FAILURE_ERROR = "391";
var SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR = "401";
var SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR = "402";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR = "403";
var SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR = "404";
var SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR = "405";
var SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR = "406";
var SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR = "407";
var SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR = "408";
var SCORM2004_ErrorStrings = new Array();
SCORM2004_ErrorStrings[SCORM2004_NO_ERROR] = "No Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_EXCEPTION_ERROR] = "General Exception";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_INITIALIZATION_FAILURE_ERROR] = "General Initialization Failure";
SCORM2004_ErrorStrings[SCORM2004_ALREADY_INTIAILIZED_ERROR] = "Already Initialized";
SCORM2004_ErrorStrings[SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR] = "Content Instance Terminated";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_TERMINATION_FAILURE_ERROR] = "General Termination Failure";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR] = "Termination Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR] = "Termination AFter Termination";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR] = "Retrieve Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR] = "Retrieve Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR] = "Store Data Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR] = "Store Data After Termination";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR] = "Commit Before Initialization";
SCORM2004_ErrorStrings[SCORM2004_COMMIT_AFTER_TERMINATION_ERROR] = "Commit After Termination";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_ARGUMENT_ERROR] = "General Argument Error";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_GET_FAILURE_ERROR] = "General Get Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_SET_FAILURE_ERROR] = "General Set Failure";
SCORM2004_ErrorStrings[SCORM2004_GENERAL_COMMIT_FAILURE_ERROR] = "General Commit Failure";
SCORM2004_ErrorStrings[SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR] = "Undefined Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_UNIMPLEMENTED_DATA_MODEL_ELEMENT_ERROR] = "Unimplemented Data Model Element";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR] = "Data Model Element Value Not Initialized";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR] = "Data Model Element Is Read Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR] = "Data Model Element Is Write Only";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR] = "Data Model Element Type Mismatch";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR] = "Data Model Element Value Out Of Range";
SCORM2004_ErrorStrings[SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR] = "Data Model Dependency Not Established";
var SCORM2004_VERSION = "1.0";
var SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN = "comment,location,timestamp";
var SCORM2004_COMMENTS_FROM_LMS_CHILDREN = "comment,location,timestamp";
var SCORM2004_INTERACTIONS_CHILDREN = "id,type,objectives,timestamp,correct_responses,weighting,learner_response,result,latency,description";
var SCORM2004_LEARNER_PREFERENCE_CHILDREN = "audio_level,language,delivery_speed,audio_captioning";
var SCORM2004_OBJECTIVES_CHILDREN = "progress_measure,description,score,id,success_status,completion_status";
var SCORM2004_OBJECTIVES_SCORE_CHILDREN = "scaled,raw,min,max";
var SCORM2004_SCORE_CHILDREN = "scaled,min,max,raw";
var SCORM2004_SHARED_DATA_CHILDREN = "id,store";

function RunTimeApi(_1, _2) {
    this.LearnerId = _1;
    this.LearnerName = _2;
    this.ErrorNumber = SCORM2004_NO_ERROR;
    this.ErrorString = "";
    this.ErrorDiagnostic = "";
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
    this.TrackedSessionTimePrevCall = 0;
    this.SessionTotalTimeReportedPrevCall = 0;
    this.Initialized = false;
    this.Terminated = false;
    this.ScoCalledFinish = false;
    this.CloseOutSessionCalled = false;
    this.RunTimeData = null;
    this.LearningObject = null;
    this.Activity = null;
    this.IsLookAheadSequencerDataDirty = false;
    this.IsLookAheadSequencerRunning = false;
    this.LearnerPrefsArray = new Object();
    if (SSP_ENABLED) {
        this.SSPApi = new SSPApi(MAX_SSP_STORAGE, this);
    }
}
RunTimeApi.prototype.GetNavigationRequest = RunTimeApi_GetNavigationRequest;
RunTimeApi.prototype.ResetState = RunTimeApi_ResetState;
RunTimeApi.prototype.InitializeForDelivery = RunTimeApi_InitializeForDelivery;
RunTimeApi.prototype.SetDirtyData = RunTimeApi_SetDirtyData;
RunTimeApi.prototype.WriteHistoryLog = RunTimeApi_WriteHistoryLog;
RunTimeApi.prototype.WriteHistoryReturnValue = RunTimeApi_WriteHistoryReturnValue;
RunTimeApi.prototype.WriteAuditLog = RunTimeApi_WriteAuditLog;
RunTimeApi.prototype.WriteAuditReturnValue = RunTimeApi_WriteAuditReturnValue;
RunTimeApi.prototype.WriteDetailedLog = RunTimeApi_WriteDetailedLog;
RunTimeApi.prototype.CloseOutSession = RunTimeApi_CloseOutSession;
RunTimeApi.prototype.NeedToCloseOutSession = RunTimeApi_NeedToCloseOutSession;
RunTimeApi.prototype.AccumulateTotalTimeTracked = RunTimeApi_AccumulateTotalTimeTracked;
RunTimeApi.prototype.InitTrackedTimeStart = RunTimeApi_InitTrackedTimeStart;

function RunTimeApi_GetNavigationRequest() {
    return null;
}

function RunTimeApi_ResetState(_3) {
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
}

function RunTimeApi_InitializeForDelivery(_4) {
    this.RunTimeData = _4.RunTime;
    this.LearningObject = _4.LearningObject;
    this.Activity = _4;
    this.CloseOutSessionCalled = false;
    if (Control.Package.Properties.ResetRunTimeDataTiming == RESET_RT_DATA_TIMING_WHEN_EXIT_IS_NOT_SUSPEND) {
        if (this.RunTimeData.Exit != SCORM_EXIT_SUSPEND && this.RunTimeData.Exit != SCORM_EXIT_LOGOUT) {
            var _5 = {
                ev: "ResetRuntime",
                ai: _4.ItemIdentifier,
                at: _4.LearningObject.Title
            };
            this.WriteHistoryLog("", _5);
            this.RunTimeData.ResetState();
        }
    }
    this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_NONE;
    this.Initialized = false;
    this.Terminated = false;
    this.ScoCalledFinish = false;
    this.TrackedStartDate = null;
    this.TrackedEndDate = null;
    this.ErrorNumber = SCORM2004_NO_ERROR;
    this.ErrorString = "";
    this.ErrorDiagnostic = "";
    var _6;
    var _7;
    var _8;
    for (var _9 in this.Activity.ActivityObjectives) {
        _8 = this.Activity.ActivityObjectives[_9];
        _6 = _8.GetIdentifier();
        if (_6 !== null && _6 !== undefined && _6.length > 0) {
            _7 = this.RunTimeData.FindObjectiveWithId(_6);
            if (_7 === null) {
                this.RunTimeData.AddObjective();
                _7 = this.RunTimeData.Objectives[this.RunTimeData.Objectives.length - 1];
                _7.Identifier = _6;
            }
            if (_8.GetProgressStatus(this.Activity, false) === true) {
                if (_8.GetSatisfiedStatus(this.Activity, false) === true) {
                    _7.SuccessStatus = SCORM_STATUS_PASSED;
                } else {
                    _7.SuccessStatus = SCORM_STATUS_FAILED;
                }
            }
            if (_8.GetMeasureStatus(this.Activity, false) === true) {
                _7.ScoreScaled = _8.GetNormalizedMeasure(this.Activity, false);
            }
            if (_8.GetScoreRaw() !== null) {
                _7.ScoreRaw = _8.GetScoreRaw();
            }
            if (_8.GetScoreMin() !== null) {
                _7.ScoreMin = _8.GetScoreMin();
            }
            if (_8.GetScoreMax() !== null) {
                _7.ScoreMax = _8.GetScoreMax();
            }
            var _a = _8.GetCompletionStatus(this.Activity, false);
            if (_a === true) {
                var _b = _8.GetCompletionStatusValue(this.Activity, false);
                if (_b === true) {
                    _7.CompletionStatus = SCORM_STATUS_COMPLETED;
                } else {
                    _7.CompletionStatus = SCORM_STATUS_INCOMPLETE;
                }
            }
            if (_8.GetProgressMeasure() !== null) {
                _7.ProgressMeasure = _8.GetProgressMeasure();
            }
            _7.SuccessStatusChangedDuringRuntime = false;
            _7.MeasureChangedDuringRuntime = false;
            _7.ProgressMeasureChangedDuringRuntime = false;
            _7.CompletionStatusChangedDuringRuntime = false;
        }
    }
}

function RunTimeApi_SetDirtyData() {
    this.Activity.DataState = DATA_STATE_DIRTY;
}

function RunTimeApi_WriteHistoryLog(_c, _d) {
    HistoryLog.WriteEventDetailed(_c, _d);
}

function RunTimeApi_WriteHistoryReturnValue(_e, _f) {
    HistoryLog.WriteEventDetailedReturnValue(_e, _f);
}

function RunTimeApi_WriteAuditLog(str) {
    Debug.WriteRteAudit(str);
}

function RunTimeApi_WriteAuditReturnValue(str) {
    Debug.WriteRteAuditReturnValue(str);
}

function RunTimeApi_WriteDetailedLog(str) {
    Debug.WriteRteDetailed(str);
}

function RunTimeApi_NeedToCloseOutSession() {
    return !this.CloseOutSessionCalled;
}
RunTimeApi.prototype.version = SCORM2004_VERSION;
RunTimeApi.prototype.Initialize = RunTimeApi_Initialize;
RunTimeApi.prototype.Terminate = RunTimeApi_Terminate;
RunTimeApi.prototype.GetValue = RunTimeApi_GetValue;
RunTimeApi.prototype.SetValue = RunTimeApi_SetValue;
RunTimeApi.prototype.Commit = RunTimeApi_Commit;
RunTimeApi.prototype.GetLastError = RunTimeApi_GetLastError;
RunTimeApi.prototype.GetErrorString = RunTimeApi_GetErrorString;
RunTimeApi.prototype.GetDiagnostic = RunTimeApi_GetDiagnostic;
RunTimeApi.prototype.RetrieveGetValueData = RunTimeApi_RetrieveGetValueData;
RunTimeApi.prototype.StoreValue = RunTimeApi_StoreValue;
RunTimeApi.prototype.SetErrorState = RunTimeApi_SetErrorState;
RunTimeApi.prototype.ClearErrorState = RunTimeApi_ClearErrorState;
RunTimeApi.prototype.CheckMaxLength = RunTimeApi_CheckMaxLength;
RunTimeApi.prototype.CheckLengthAndWarn = RunTimeApi_CheckLengthAndWarn;
RunTimeApi.prototype.CheckForInitializeError = RunTimeApi_CheckForInitializeError;
RunTimeApi.prototype.CheckForTerminateError = RunTimeApi_CheckForTerminateError;
RunTimeApi.prototype.CheckForGetValueError = RunTimeApi_CheckForGetValueError;
RunTimeApi.prototype.CheckForSetValueError = RunTimeApi_CheckForSetValueError;
RunTimeApi.prototype.CheckForCommitError = RunTimeApi_CheckForCommitError;
RunTimeApi.prototype.CheckCommentsCollectionLength = RunTimeApi_CheckCommentsCollectionLength;
RunTimeApi.prototype.CheckInteractionsCollectionLength = RunTimeApi_CheckInteractionsCollectionLength;
RunTimeApi.prototype.CheckInteractionObjectivesCollectionLength = RunTimeApi_CheckInteractionObjectivesCollectionLength;
RunTimeApi.prototype.CheckInteractionsCorrectResponsesCollectionLength = RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength;
RunTimeApi.prototype.CheckObjectivesCollectionLength = RunTimeApi_CheckObjectivesCollectionLength;
RunTimeApi.prototype.LookAheadSessionClose = RunTimeApi_LookAheadSessionClose;
RunTimeApi.prototype.ValidOtheresponse = RunTimeApi_ValidOtheresponse;
RunTimeApi.prototype.ValidNumericResponse = RunTimeApi_ValidNumericResponse;
RunTimeApi.prototype.ValidSequencingResponse = RunTimeApi_ValidSequencingResponse;
RunTimeApi.prototype.ValidPerformanceResponse = RunTimeApi_ValidPerformanceResponse;
RunTimeApi.prototype.ValidMatchingResponse = RunTimeApi_ValidMatchingResponse;
RunTimeApi.prototype.ValidLikeRTResponse = RunTimeApi_ValidLikeRTResponse;
RunTimeApi.prototype.ValidLongFillInResponse = RunTimeApi_ValidLongFillInResponse;
RunTimeApi.prototype.ValidFillInResponse = RunTimeApi_ValidFillInResponse;
RunTimeApi.prototype.IsValidArrayOfLocalizedStrings = RunTimeApi_IsValidArrayOfLocalizedStrings;
RunTimeApi.prototype.IsValidArrayOfShortIdentifiers = RunTimeApi_IsValidArrayOfShortIdentifiers;
RunTimeApi.prototype.IsValidCommaDelimitedArrayOfShortIdentifiers = RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers;
RunTimeApi.prototype.ValidMultipleChoiceResponse = RunTimeApi_ValidMultipleChoiceResponse;
RunTimeApi.prototype.ValidTrueFalseResponse = RunTimeApi_ValidTrueFalseResponse;
RunTimeApi.prototype.ValidTimeInterval = RunTimeApi_ValidTimeInterval;
RunTimeApi.prototype.ValidTime = RunTimeApi_ValidTime;
RunTimeApi.prototype.ValidReal = RunTimeApi_ValidReal;
RunTimeApi.prototype.IsValidUrn = RunTimeApi_IsValidUrn;
RunTimeApi.prototype.ValidIdentifier = RunTimeApi_ValidIdentifier;
RunTimeApi.prototype.ValidShortIdentifier = RunTimeApi_ValidShortIdentifier;
RunTimeApi.prototype.ValidLongIdentifier = RunTimeApi_ValidLongIdentifier;
RunTimeApi.prototype.ValidLanguage = RunTimeApi_ValidLanguage;
RunTimeApi.prototype.ExtractLanguageDelimiterFromLocalizedString = RunTimeApi_ExtractLanguageDelimiterFromLocalizedString;
RunTimeApi.prototype.ValidLocalizedString = RunTimeApi_ValidLocalizedString;
RunTimeApi.prototype.ValidCharString = RunTimeApi_ValidCharString;
RunTimeApi.prototype.TranslateBooleanIntoCMI = RunTimeApi_TranslateBooleanIntoCMI;
RunTimeApi.prototype.SetLookAheadDirtyDataFlagIfNeeded = RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded;
RunTimeApi.prototype.RunLookAheadSequencerIfNeeded = RunTimeApi_RunLookAheadSequencerIfNeeded;
RunTimeApi.prototype.GetCompletionStatus = RunTimeApi_GetCompletionStatus;
RunTimeApi.prototype.GetSuccessStatus = RunTimeApi_GetSuccessStatus;

function RunTimeApi_Initialize(arg) {
    this.WriteAuditLog("`1736`" + arg + "')");
    var _14 = {
        ev: "ApiInitialize"
    };
    if (this.Activity) {
        _14.ai = this.Activity.ItemIdentifier;
    }
    this.WriteHistoryLog("", _14);
    var _15;
    var _16;
    this.ClearErrorState();
    _15 = this.CheckForInitializeError(arg);
    if (!_15) {
        _16 = SCORM_FALSE;
    } else {
        if (this.TrackedStartDate == null) {
            this.TrackedStartDate = new Date();
        }
        if (this.StartSessionTotalTime == null && this.Activity) {
            this.StartSessionTotalTime = this.Activity.RunTime.TotalTime;
        }
        this.TrackedSessionTimePrevCall = 0;
        this.SessionTotalTimeReportedPrevCall = 0;
        this.RunTimeData.Exit = SCORM_EXIT_UNKNOWN;
        this.Initialized = true;
        _16 = SCORM_TRUE;
    }
    Control.ScoLoader.ScoLoaded = true;
    this.WriteAuditReturnValue(_16);
    return _16;
}

function RunTimeApi_Terminate(arg) {
    this.WriteAuditLog("`1746`" + arg + "')");
    var _18;
    var _19;
    var _1a;
    this.ClearErrorState();
    _18 = this.CheckForTerminateError(arg);
    var _1b = (_18 && (this.ScoCalledFinish === false));
    if (!_18) {
        _1a = SCORM_FALSE;
    } else {
        var _1c = {
            ev: "ApiTerminate"
        };
        if (this.Activity) {
            _1c.ai = this.Activity.ItemIdentifier;
        }
        this.WriteHistoryLog("", _1c);
        this.LookAheadSessionClose();
        this.CloseOutSession("Terminate");
        this.Terminated = true;
        this.ScoCalledFinish = true;
        this.SetDirtyData();
        _1a = SCORM_TRUE;
    }
    var _1d = Control.FindPossibleNavRequestForRuntimeNavRequest(this.RunTimeData.NavRequest);
    var _1e = false;
    if (_1b === true && this.RunTimeData.NavRequest != SCORM_RUNTIME_NAV_REQUEST_NONE && Control.IsThereAPendingNavigationRequest() === false && _1d.WillSucceed === true) {
        this.WriteDetailedLog("`442`" + Control.IsThereAPendingNavigationRequest());
        window.setTimeout("Control.ScoHasTerminatedSoUnload();", 150);
    } else {
        if (this.RunTimeData.NavRequest != SCORM_RUNTIME_NAV_REQUEST_NONE && _1d.WillSucceed !== true) {
            _1e = true;
            this.WriteDetailedLog("`1347`" + this.RunTimeData.NavRequest + "`38`");
        }
    }
    if (this.IsLookAheadSequencerDataDirty === true) {
        this.IsLookAheadSequencerDataDirty = false;
        if (_1e === true) {
            window.setTimeout("Control.EvaluatePossibleNavigationRequests(true, true);", 150);
        } else {
            window.setTimeout("Control.EvaluatePossibleNavigationRequests(true, false);", 150);
        }
    }
    Control.SignalTerminated();
    this.WriteAuditReturnValue(_1a);
    return _1a;
}

function RunTimeApi_GetValue(_1f) {
    this.WriteAuditLog("`1749`" + _1f + "')");
    var _20;
    var _21;
    this.ClearErrorState();
    _1f = CleanExternalString(_1f);
    var _22 = RemoveIndiciesFromCmiElement(_1f);
    var _23 = ExtractIndex(_1f);
    var _24 = ExtractSecondaryIndex(_1f);
    _21 = this.CheckForGetValueError(_1f, _22, _23, _24);
    if (!_21) {
        _20 = "";
    } else {
        _20 = this.RetrieveGetValueData(_1f, _22, _23, _24);
        if (_20 === null) {
            _20 = "";
        }
    }
    this.WriteAuditReturnValue(_20);
    return _20;
}

function RunTimeApi_SetValue(_25, _26) {
    this.WriteAuditLog("`1750`" + _25 + "`1761`" + _26 + "')");
    var _27;
    var _28;
    this.ClearErrorState();
    _25 = CleanExternalString(_25);
    _26 = CleanExternalString(_26);
    var _29 = RemoveIndiciesFromCmiElement(_25);
    var _2a = ExtractIndex(_25);
    var _2b = ExtractSecondaryIndex(_25);
    this.CheckMaxLength(_29, _26);
    _27 = this.CheckForSetValueError(_25, _26, _29, _2a, _2b);
    if (!_27) {
        _28 = SCORM_FALSE;
    } else {
        this.StoreValue(_25, _26, _29, _2a, _2b);
        this.SetDirtyData();
        _28 = SCORM_TRUE;
    }
    this.WriteAuditReturnValue(_28);
    return _28;
}

function RunTimeApi_Commit(arg) {
    this.WriteAuditLog("`1753`" + arg + "')");
    var _2d;
    var _2e;
    this.ClearErrorState();
    _2d = this.CheckForCommitError(arg);
    if (!_2d) {
        _2e = SCORM_FALSE;
    } else {
        _2e = SCORM_TRUE;
    }
    this.RunLookAheadSequencerIfNeeded(true);
    this.WriteAuditReturnValue(_2e);
    return _2e;
}

function RunTimeApi_GetLastError() {
    this.WriteAuditLog("`1727`");
    var _2f = this.ErrorNumber;
    this.WriteAuditReturnValue(_2f);
    return _2f;
}

function RunTimeApi_GetErrorString(arg) {
    this.WriteAuditLog("`1699`" + arg + "')");
    var _31 = "";
    if (arg === "") {
        _31 = "";
    } else {
        if (SCORM2004_ErrorStrings[arg] !== null && SCORM2004_ErrorStrings[arg] !== undefined) {
            _31 = SCORM2004_ErrorStrings[arg];
        }
    }
    this.WriteAuditReturnValue(_31);
    return _31;
}

function RunTimeApi_GetDiagnostic(arg) {
    this.WriteAuditLog("`1710`" + arg + "')");
    var _33;
    if (this.ErrorDiagnostic === "") {
        _33 = "No diagnostic information available";
    } else {
        _33 = this.ErrorDiagnostic;
    }
    this.WriteAuditReturnValue(_33);
    return _33;
}

function RunTimeApi_CloseOutSession(_34) {
    this.WriteDetailedLog("`1668`");
    this.WriteDetailedLog("`1755`" + this.RunTimeData.Mode);
    this.WriteDetailedLog("`1752`" + this.RunTimeData.Credit);
    this.WriteDetailedLog("`1453`" + this.RunTimeData.CompletionStatus);
    this.WriteDetailedLog("`1517`" + this.RunTimeData.SuccessStatus);
    this.WriteDetailedLog("`1588`" + this.LearningObject.GetScaledPassingScore());
    this.WriteDetailedLog("`1754`" + this.RunTimeData.ScoreScaled);
    this.WriteDetailedLog("`1582`" + this.LearningObject.CompletedByMeasure);
    if (this.LearningObject.CompletedByMeasure === true) {
        this.WriteDetailedLog("`1549`" + this.LearningObject.CompletionThreshold);
    }
    this.WriteDetailedLog("`1620`" + this.RunTimeData.ProgressMeasure);
    var _35 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTime);
    var _36 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime);
    var _37 = _35 + _36;
    var _38 = ConvertHundredthsToIso8601TimeSpan(_37);
    this.WriteDetailedLog("`1728`" + this.RunTimeData.SessionTime + " (" + _35 + "`1733`");
    this.WriteDetailedLog("`1713`" + this.RunTimeData.TotalTime + " (" + _36 + "`1733`");
    this.WriteDetailedLog("`1700`" + _38 + " (" + _37 + "`1733`");
    this.RunTimeData.TotalTime = _38;
    this.RunTimeData.SessionTime = "";
    this.AccumulateTotalTimeTracked();
    this.WriteDetailedLog("`1538`" + this.RunTimeData.TotalTimeTracked);
    if (Control.IsThereAPendingNavigationRequest()) {
        if (Control.PendingNavigationRequest.Type == NAVIGATION_REQUEST_SUSPEND_ALL) {
            this.WriteDetailedLog("`913`");
            this.RunTimeData.Exit = SCORM_EXIT_SUSPEND;
        }
    } else {
        if (this.RunTimeData.NavRequest == SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL) {
            this.WriteDetailedLog("`931`");
            this.RunTimeData.Exit = SCORM_EXIT_SUSPEND;
        }
    }
    if (this.RunTimeData.Exit == SCORM_EXIT_SUSPEND || this.RunTimeData.Exit == SCORM_EXIT_LOGOUT) {
        this.WriteDetailedLog("`1606`");
        this.RunTimeData.Entry = SCORM_ENTRY_RESUME;
    }
    var _39 = this.GetCompletionStatus();
    if (_39 != this.RunTimeData.CompletionStatus) {
        this.RunTimeData.CompletionStatus = _39;
        this.RunTimeData.CompletionStatusChangedDuringRuntime = true;
    }
    var _3a = this.GetSuccessStatus();
    if (_3a != this.RunTimeData.SuccessStatus) {
        this.RunTimeData.SuccessStatus = this.GetSuccessStatus();
        this.RunTimeData.SuccessStatusChangedDuringRuntime = true;
    }
    if (this.RunTimeData.Exit == SCORM_EXIT_TIME_OUT) {
        this.WriteDetailedLog("`1481`");
        this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_EXITALL;
    } else {
        if (this.RunTimeData.Exit == SCORM_EXIT_LOGOUT) {
            if (Control.Package.Properties.LogoutCausesPlayerExit === true) {
                this.WriteDetailedLog("`1341`");
                this.RunTimeData.NavRequest = SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL;
            } else {
                this.WriteDetailedLog("`341`");
                this.Activity.SetSuspended(true);
            }
        } else {
            if (this.RunTimeData.Exit == SCORM_EXIT_SUSPEND) {
                this.WriteDetailedLog("`1621`");
                this.Activity.SetSuspended(true);
            }
        }
    }
    this.CloseOutSessionCalled = true;
    return true;
}

function RunTimeApi_LookAheadSessionClose() {
    if (this.RunTimeData != null) {
        this.RunTimeData.LookAheadCompletionStatus = this.GetCompletionStatus();
        this.RunTimeData.LookAheadSuccessStatus = this.GetSuccessStatus();
    }
}

function RunTimeApi_RetrieveGetValueData(_3b, _3c, _3d, _3e) {
    this.WriteDetailedLog("`1576`" + _3b + ", " + _3c + ", " + _3d + ", " + _3e + ") ");
    var _3f;
    var _40 = "";
    var _41;
    if (_3b.indexOf("adl.nav.request_valid.choice") === 0 || _3b.indexOf("adl.nav.request_valid.jump") === 0) {
        this.WriteDetailedLog("`1177`");
        var _42 = (_3b.indexOf("jump") > 0);
        _3f = ((_3b.indexOf("{") >= 0) ? _3b.substring(_3b.indexOf("{")) : "");
        if (!Control.IsTargetValid(_3f)) {
            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The target of the choice/jump request (" + _3f + ") is invalid.");
            return SCORM_FALSE;
        }
        if (_42 === true) {
            _40 = Control.IsJumpRequestValid(_3f);
        } else {
            _40 = Control.IsChoiceRequestValid(_3f);
        }
        if (_40 == false) {
            var _43 = Control.ParseTargetStringIntoActivity(_3f);
            var _44 = "";
            var _45;
            if (_42 === true) {
                if (_43 != null) {
                    _44 = "The target activity for the jump navigation is not available.";
                } else {
                    _44 = "The target activity for the jump navigation does not exist.";
                }
            } else {
                _45 = Control.FindPossibleChoiceRequestForActivity(_43);
                _44 = _45.GetExceptionReason();
            }
            this.WriteDetailedLog(_44);
        }
        _40 = this.TranslateBooleanIntoCMI(_40);
        return _40;
    }
    switch (_3c) {
        case "cmi._version":
            this.WriteDetailedLog("`1510`");
            _40 = SCORM2004_VERSION;
            break;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1161`");
            _40 = SCORM2004_COMMENTS_FROM_LEARNER_CHILDREN;
            break;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            _40 = this.RunTimeData.Comments.length;
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1212`");
            _40 = this.RunTimeData.Comments[_3d].GetCommentValue();
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1186`");
            _40 = this.RunTimeData.Comments[_3d].Location;
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1163`");
            _40 = this.RunTimeData.Comments[_3d].Timestamp;
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            _40 = SCORM2004_COMMENTS_FROM_LMS_CHILDREN;
            break;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            _40 = this.RunTimeData.CommentsFromLMS.length;
            break;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1289`");
            _40 = this.RunTimeData.CommentsFromLMS[_3d].GetCommentValue();
            break;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1268`");
            _40 = this.RunTimeData.CommentsFromLMS[_3d].Location;
            break;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1249`");
            _40 = this.RunTimeData.CommentsFromLMS[_3d].Timestamp;
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            _40 = this.GetCompletionStatus();
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1370`");
            _40 = this.LearningObject.CompletionThreshold;
            break;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            _40 = this.RunTimeData.Credit;
            break;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            _40 = this.RunTimeData.Entry;
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            Debug.AssertError("Exit element is write only");
            _40 = "";
            break;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            _40 = SCORM2004_INTERACTIONS_CHILDREN;
            break;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            _40 = this.RunTimeData.Interactions.length;
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1474`");
            _40 = this.RunTimeData.Interactions[_3d].Id;
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1430`");
            _40 = this.RunTimeData.Interactions[_3d].Type;
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1189`");
            _40 = this.RunTimeData.Interactions[_3d].Objectives.length;
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1270`");
            _40 = this.RunTimeData.Interactions[_3d].Objectives[_3e];
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1334`");
            _40 = this.RunTimeData.Interactions[_3d].Timestamp;
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`1059`");
            _40 = this.RunTimeData.Interactions[_3d].CorrectResponses.length;
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`1024`");
            _40 = this.RunTimeData.Interactions[_3d].CorrectResponses[_3e];
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1335`");
            _40 = this.RunTimeData.Interactions[_3d].Weighting;
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1214`");
            _40 = this.RunTimeData.Interactions[_3d].LearnerResponse;
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1392`");
            _40 = this.RunTimeData.Interactions[_3d].Result;
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1372`");
            _40 = this.RunTimeData.Interactions[_3d].Latency;
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1301`");
            _40 = this.RunTimeData.Interactions[_3d].Description;
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            _40 = this.LearningObject.DataFromLms;
            break;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1569`");
            _40 = LearnerId;
            break;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1528`");
            _40 = LearnerName;
            break;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            _40 = SCORM2004_LEARNER_PREFERENCE_CHILDREN;
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1553`");
            _40 = this.RunTimeData.AudioLevel;
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1601`");
            _40 = this.RunTimeData.LanguagePreference;
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1492`");
            _40 = this.RunTimeData.DeliverySpeed;
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1445`");
            _40 = this.RunTimeData.AudioCaptioning;
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            _40 = this.RunTimeData.Location;
            var _46 = {
                ev: "Get",
                k: "location",
                v: (_40 == null ? "<null>" : _40)
            };
            if (this.Activity) {
                _46.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _46);
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1446`");
            _40 = "";
            if (this.LearningObject.SequencingData !== null && this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl === true) {
                _40 = this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationLimit;
            }
            break;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            _40 = this.RunTimeData.Mode;
            break;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            _40 = SCORM2004_OBJECTIVES_CHILDREN;
            break;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            _40 = this.RunTimeData.Objectives.length;
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1515`");
            _40 = this.RunTimeData.Objectives[_3d].Identifier;
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1271`");
            _40 = SCORM2004_OBJECTIVES_SCORE_CHILDREN;
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1317`");
            _40 = this.RunTimeData.Objectives[_3d].ScoreScaled;
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1376`");
            _40 = this.RunTimeData.Objectives[_3d].ScoreRaw;
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1375`");
            _40 = this.RunTimeData.Objectives[_3d].ScoreMin;
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1374`");
            _40 = this.RunTimeData.Objectives[_3d].ScoreMax;
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1291`");
            _40 = this.RunTimeData.Objectives[_3d].SuccessStatus;
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1235`");
            _40 = this.RunTimeData.Objectives[_3d].CompletionStatus;
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1252`");
            _40 = this.RunTimeData.Objectives[_3d].ProgressMeasure;
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1336`");
            _40 = this.RunTimeData.Objectives[_3d].Description;
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1448`");
            _40 = this.RunTimeData.ProgressMeasure;
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1377`");
            _40 = this.LearningObject.GetScaledPassingScore();
            if (_40 === null) {
                _40 = "";
            }
            break;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            _40 = SCORM2004_SCORE_CHILDREN;
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            _40 = this.RunTimeData.ScoreScaled;
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            _40 = this.RunTimeData.ScoreRaw;
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            _40 = this.RunTimeData.ScoreMax;
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            _40 = this.RunTimeData.ScoreMin;
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1531`");
            _40 = "";
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1494`");
            _40 = this.GetSuccessStatus();
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1535`");
            _40 = this.RunTimeData.SuspendData;
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1433`");
            _40 = this.LearningObject.TimeLimitAction;
            break;
        case "cmi.total_time":
            this.WriteDetailedLog("`1574`");
            _40 = this.RunTimeData.TotalTime;
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1471`");
            _40 = this.RunTimeData.NavRequest;
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1180`");
            _40 = Control.IsContinueRequestValid();
            if (_40 == false) {
                _41 = Control.GetPossibleContinueRequest();
                this.WriteDetailedLog(_41.GetExceptionReason());
            }
            _40 = this.TranslateBooleanIntoCMI(_40);
            break;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1181`");
            _40 = Control.IsPreviousRequestValid();
            if (_40 == false) {
                _41 = Control.GetPossiblePreviousRequest();
                this.WriteDetailedLog(_41.GetExceptionReason());
            }
            _40 = this.TranslateBooleanIntoCMI(_40);
            break;
        case "adl.nav.request_valid.choice":
            this.WriteDetailedLog("`1331`");
            Debug.AssertError("Entered invalid case in RunTimeApi_RetrieveGetValueData (choice)");
            break;
        case "adl.nav.request_valid.jump":
            this.WriteDetailedLog("`1369`");
            Debug.AssertError("Entered invalid case in RunTimeApi_RetrieveGetValueData (jump)");
            break;
        case "adl.data._children":
            this.WriteDetailedLog("`1405`");
            _40 = SCORM2004_SHARED_DATA_CHILDREN;
            break;
        case "adl.data._count":
            this.WriteDetailedLog("`1472`");
            _40 = this.LearningObject.SharedDataMaps.length;
            break;
        case "adl.data.n.id":
            this.WriteDetailedLog("`1552`");
            _40 = this.LearningObject.SharedDataMaps[_3d].Id;
            break;
        case "adl.data.n.store":
            this.WriteDetailedLog("`1509`");
            var id = this.LearningObject.SharedDataMaps[_3d].Id;
            for (var idx = 0; idx < RegistrationToDeliver.SharedData.length; idx++) {
                if (RegistrationToDeliver.SharedData[idx].SharedDataId == id) {
                    _40 = RegistrationToDeliver.SharedData[idx].GetData();
                    break;
                }
            }
            break;
        default:
            if (_3c.indexOf("ssp") === 0 && SSP_ENABLED) {
                _40 = this.SSPApi.RetrieveGetValueData(_3b, _3c, _3d, _3e);
            } else {
                Debug.AssertError("Entered default case in RunTimeApi_RetrieveGetValueData");
                _40 = "";
            }
            break;
    }
    return _40;
}

function RunTimeApi_StoreValue(_49, _4a, _4b, _4c, _4d) {
    this.WriteDetailedLog("`1738`" + _49 + ", " + _4a + ", " + _4b + ", " + _4c + ", " + _4d + ") ");
    var _4e = true;
    var _4f;
    switch (_4b) {
        case "cmi._version":
            this.WriteDetailedLog("`1599`");
            break;
        case "cmi.comments_from_learner._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._children");
            _4e = false;
            break;
        case "cmi.comments_from_learner._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_learner._count");
            _4e = false;
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1231`");
            this.CheckCommentsCollectionLength(_4c);
            this.RunTimeData.Comments[_4c].SetCommentValue(_4a);
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1184`");
            this.CheckCommentsCollectionLength(_4c);
            this.RunTimeData.Comments[_4c].Location = _4a;
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1160`");
            this.CheckCommentsCollectionLength(_4c);
            this.RunTimeData.Comments[_4c].Timestamp = _4a;
            break;
        case "cmi.comments_from_lms._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._children");
            _4e = false;
            break;
        case "cmi.comments_from_lms._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms._count");
            _4e = false;
            break;
        case "cmi.comments_from_lms.n.comment":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.comment");
            _4e = false;
            break;
        case "cmi.comments_from_lms.n.location":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.location");
            _4e = false;
            break;
        case "cmi.comments_from_lms.n.timestamp":
            Debug.AssertError("ERROR - Element is Read Only, cmi.comments_from_lms.timestamp");
            _4e = false;
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            _4f = {
                ev: "Set",
                k: "completion",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.CompletionStatus, _4a);
            this.RunTimeData.CompletionStatus = _4a;
            this.RunTimeData.CompletionStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.completion_threshold":
            Debug.AssertError("ERROR - Element is Read Only, cmi.completion_threshold");
            _4e = false;
            break;
        case "cmi.credit":
            Debug.AssertError("ERROR - Element is Read Only, cmi.credit");
            _4e = false;
            break;
        case "cmi.entry":
            Debug.AssertError("ERROR - Element is Read Only, cmi.entry");
            _4e = false;
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            _4f = {
                ev: "Set",
                k: "cmi.exit",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.RunTimeData.Exit = _4a;
            break;
        case "cmi.interactions._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._children");
            _4e = false;
            break;
        case "cmi.interactions._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions._count");
            _4e = false;
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1474`");
            _4f = {
                ev: "Set",
                k: "interactions id",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Id = _4a;
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1430`");
            _4f = {
                ev: "Set",
                k: "interactions type",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Type = _4a;
            break;
        case "cmi.interactions.n.objectives._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.objectives._count");
            _4e = false;
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1270`");
            _4f = {
                ev: "Set",
                k: "interactions objectives id",
                i: _4c,
                si: _4d,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionObjectivesCollectionLength(_4c, _4d);
            this.RunTimeData.Interactions[_4c].Objectives[_4d] = _4a;
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1334`");
            _4f = {
                ev: "Set",
                k: "interactions timestamp",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Timestamp = _4a;
            break;
        case "cmi.interactions.n.correct_responses._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.interactions.n.correct_responses._count");
            _4e = false;
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`1024`");
            _4f = {
                ev: "Set",
                k: "interactions correct_responses pattern",
                i: _4c,
                si: _4d,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCorrectResponsesCollectionLength(_4c, _4d);
            this.RunTimeData.Interactions[_4c].CorrectResponses[_4d] = _4a;
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1335`");
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Weighting = _4a;
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1214`");
            _4f = {
                ev: "Set",
                k: "interactions learner_response",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].LearnerResponse = _4a;
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1392`");
            _4f = {
                ev: "Set",
                k: "interactions result",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Result = _4a;
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1372`");
            _4f = {
                ev: "Set",
                k: "interactions latency",
                i: _4c,
                vh: ConvertIso8601TimeSpanToHundredths(_4a)
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Latency = _4a;
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1301`");
            _4f = {
                ev: "Set",
                k: "interactions description",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Interactions[_4c].Id) {
                _4f.intid = this.RunTimeData.Interactions[_4c].Id;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckInteractionsCollectionLength(_4c);
            this.RunTimeData.Interactions[_4c].Description = _4a;
            break;
        case "cmi.launch_data":
            Debug.AssertError("ERROR - Element is Read Only, cmi.launch_data");
            _4e = false;
            break;
        case "cmi.learner_id":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_id");
            _4e = false;
            break;
        case "cmi.learner_name":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_name");
            _4e = false;
            break;
        case "cmi.learner_preference._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.learner_preference._children");
            _4e = false;
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1527`");
            this.RunTimeData.AudioLevel = _4a;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.AudioLevel = _4a;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1601`");
            this.RunTimeData.LanguagePreference = _4a;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.LanguagePreference = _4a;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1511`");
            this.RunTimeData.DeliverySpeed = _4a;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.DeliverySpeed = _4a;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1445`");
            this.RunTimeData.AudioCaptioning = _4a;
            if (Control.Package.Properties.MakeStudentPrefsGlobalToCourse === true) {
                this.LearnerPrefsArray.AudioCaptioning = _4a;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            this.RunTimeData.Location = _4a;
            break;
        case "cmi.max_time_allowed":
            Debug.AssertError("ERROR - Element is Read Only, cmi.max_time_allowed");
            _4e = false;
            break;
        case "cmi.mode":
            Debug.AssertError("ERROR - Element is Read Only, cmi.mode");
            _4e = false;
            break;
        case "cmi.objectives._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._children");
            _4e = false;
            break;
        case "cmi.objectives._count":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives._count");
            _4e = false;
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1515`");
            _4f = {
                ev: "Set",
                k: "objectives id",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckObjectivesCollectionLength(_4c);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].Identifier, _4a);
            this.RunTimeData.Objectives[_4c].Identifier = _4a;
            break;
        case "cmi.objectives.n.score._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.objectives.n.score._children");
            _4e = false;
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1318`");
            this.CheckObjectivesCollectionLength(_4c);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].ScoreScaled, _4a);
            this.RunTimeData.Objectives[_4c].ScoreScaled = _4a;
            this.RunTimeData.Objectives[_4c].MeasureChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1376`");
            this.CheckObjectivesCollectionLength(_4c);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].ScoreRaw, _4a);
            }
            this.RunTimeData.Objectives[_4c].ScoreRaw = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1375`");
            this.CheckObjectivesCollectionLength(_4c);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].ScoreMin, _4a);
            }
            this.RunTimeData.Objectives[_4c].ScoreMin = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1374`");
            this.CheckObjectivesCollectionLength(_4c);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].ScoreMax, _4a);
            }
            this.RunTimeData.Objectives[_4c].ScoreMax = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1291`");
            _4f = {
                ev: "Set",
                k: "objectives success",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Objectives[_4c].Identifier) {
                _4f.intid = this.RunTimeData.Objectives[_4c].Identifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckObjectivesCollectionLength(_4c);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].SuccessStatus, _4a);
            this.RunTimeData.Objectives[_4c].SuccessStatus = _4a;
            this.RunTimeData.Objectives[_4c].SuccessStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1235`");
            _4f = {
                ev: "Set",
                k: "objectives completion",
                i: _4c,
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            if (this.RunTimeData.Objectives[_4c].Identifier) {
                _4f.intid = this.RunTimeData.Objectives[_4c].Identifier;
            }
            this.WriteHistoryLog("", _4f);
            this.CheckObjectivesCollectionLength(_4c);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].CompletionStatus, _4a);
            this.RunTimeData.Objectives[_4c].CompletionStatus = _4a;
            this.RunTimeData.Objectives[_4c].CompletionStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1252`");
            this.CheckObjectivesCollectionLength(_4c);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.Objectives[_4c].ProgressMeasure, _4a);
            this.RunTimeData.Objectives[_4c].ProgressMeasure = _4a;
            this.RunTimeData.Objectives[_4c].ProgressMeasureChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1336`");
            this.CheckObjectivesCollectionLength(_4c);
            this.RunTimeData.Objectives[_4c].Description = _4a;
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ProgressMeasure, _4a);
            this.RunTimeData.ProgressMeasure = _4a;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.scaled_passing_score":
            Debug.AssertError("ERROR - Element is Read Only, cmi.scaled_passing_score");
            _4e = false;
            break;
        case "cmi.score._children":
            Debug.AssertError("ERROR - Element is Read Only, cmi.score._children");
            _4e = false;
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            _4f = {
                ev: "Set",
                k: "score.scaled",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreScaled, _4a);
            this.RunTimeData.ScoreScaled = _4a;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            _4f = {
                ev: "Set",
                k: "score.raw",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreRaw, _4a);
            }
            this.RunTimeData.ScoreRaw = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            _4f = {
                ev: "Set",
                k: "score.max",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMax, _4a);
            }
            this.RunTimeData.ScoreMax = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            _4f = {
                ev: "Set",
                k: "score.min",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            if (Control.Package.Properties.ScaleRawScore) {
                this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.ScoreMin, _4a);
            }
            this.RunTimeData.ScoreMin = _4a;
            if (Control.Package.Properties.ScaleRawScore) {
                this.RunLookAheadSequencerIfNeeded();
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            _4f = {
                ev: "Set",
                k: "session time",
                vh: ConvertIso8601TimeSpanToHundredths(_4a)
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.RunTimeData.SessionTime = _4a;
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            _4f = {
                ev: "Set",
                k: "success",
                v: _4a
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            this.WriteHistoryLog("", _4f);
            this.SetLookAheadDirtyDataFlagIfNeeded(this.RunTimeData.SuccessStatus, _4a);
            this.RunTimeData.SuccessStatus = _4a;
            this.RunTimeData.SuccessStatusChangedDuringRuntime = true;
            this.RunLookAheadSequencerIfNeeded();
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            this.RunTimeData.SuspendData = _4a;
            break;
        case "cmi.time_limit_action":
            Debug.AssertError("ERROR - Element is Read Only, cmi.time_limit_action");
            _4e = false;
            break;
        case "cmi.total_time":
            Debug.AssertError("ERROR - Element is Read Only, cmi.total_time");
            _4e = false;
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            _4f = {
                ev: "Set",
                k: "nav.request"
            };
            if (this.Activity) {
                _4f.ai = this.Activity.ItemIdentifier;
            }
            var _50 = _4a.match(/target\s*=\s*(\S+)\s*}\s*(choice|jump)/);
            if (_50) {
                _4f.tai = _50[1];
                _4f.tat = Control.Activities.GetActivityFromIdentifier(_50[1]).LearningObject.Title;
                _4f.v = _50[2];
            } else {
                _4f.v = _4a;
            }
            this.WriteHistoryLog("", _4f);
            this.RunTimeData.NavRequest = _4a;
            break;
        case "adl.nav.request_valid.continue":
            Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.continue");
            break;
        case "adl.nav.request_valid.previous":
            Debug.AssertError("ERROR - Element is Read Only, adl.nav.request_valid.previous");
            break;
        case "adl.nav.request_valid.choice":
            Debug.AssertError("ERROR - Should never get here...handled above - Element is Read Only, adl.nav.request_valid.choice");
            break;
        case "adl.nav.request_valid.jump":
            Debug.AssertError("ERROR - Should never get here...handled above - Element is Read Only, adl.nav.request_valid.jump");
            break;
        case "adl.data._children":
            Debug.AssertError("ERROR - Element is Read Only, adl.data._children");
            _4e = false;
            break;
        case "adl.data._count":
            Debug.AssertError("ERROR - Element is Read Only, adl.data._count");
            _4e = false;
            break;
        case "adl.data.n.id":
            Debug.AssertError("ERROR - Element is Read Only, adl.data.n.id");
            _4e = false;
            break;
        case "adl.data.n.store":
            this.WriteDetailedLog("`1490`");
            var id = this.LearningObject.SharedDataMaps[_4c].Id;
            for (var idx = 0; idx < RegistrationToDeliver.SharedData.length; idx++) {
                if (RegistrationToDeliver.SharedData[idx].SharedDataId == id) {
                    RegistrationToDeliver.SharedData[idx].WriteData(_4a);
                    break;
                }
            }
            break;
        default:
            if (_4b.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.StoreValue(_49, _4a, _4b, _4c, _4d);
                }
            }
            Debug.AssertError("ERROR reached default case in RunTimeApi_StoreValue");
            returnData = "";
            break;
    }
    return _4e;
}

function RunTimeApi_CheckCommentsCollectionLength(_53) {
    if (this.RunTimeData.Comments.length <= _53) {
        this.WriteDetailedLog("`1130`" + _53);
        this.RunTimeData.Comments[_53] = new ActivityRunTimeComment(null, null, null, null, null);
    }
}

function RunTimeApi_CheckInteractionsCollectionLength(_54) {
    if (this.RunTimeData.Interactions.length <= _54) {
        this.WriteDetailedLog("`1313`" + _54);
        this.RunTimeData.Interactions[_54] = new ActivityRunTimeInteraction(null, null, null, null, null, null, null, null, null, new Array(), new Array());
    }
}

function RunTimeApi_CheckInteractionObjectivesCollectionLength(_55, _56) {
    if (this.RunTimeData.Interactions[_55].Objectives.length <= _56) {
        this.WriteDetailedLog("`1113`" + _56);
        this.RunTimeData.Interactions[_55].Objectives[_56] = null;
    }
}

function RunTimeApi_CheckInteractionsCorrectResponsesCollectionLength(_57, _58) {
    if (this.RunTimeData.Interactions[_57].CorrectResponses.length <= _58) {
        this.WriteDetailedLog("`990`" + _58);
        this.RunTimeData.Interactions[_57].CorrectResponses[_58] = null;
    }
}

function RunTimeApi_CheckObjectivesCollectionLength(_59) {
    if (this.RunTimeData.Objectives.length <= _59) {
        this.WriteDetailedLog("`1354`" + _59);
        this.RunTimeData.Objectives[_59] = new ActivityRunTimeObjective(null, "unknown", "unknown", null, null, null, null, null, null);
    }
}

function RunTimeApi_SetErrorState(_5a, _5b) {
    if (_5a != SCORM2004_NO_ERROR) {
        this.WriteDetailedLog("`1292`" + _5a + " - " + _5b);
    }
    this.ErrorNumber = _5a;
    this.ErrorString = SCORM2004_ErrorStrings[_5a];
    this.ErrorDiagnostic = _5b;
}

function RunTimeApi_ClearErrorState() {
    this.SetErrorState(SCORM2004_NO_ERROR, "");
}

function RunTimeApi_CheckForInitializeError(arg) {
    this.WriteDetailedLog("`1422`");
    if (this.Initialized) {
        this.SetErrorState(SCORM2004_ALREADY_INTIAILIZED_ERROR, "Initialize has already been called and may only be called once per session.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_CONTENT_INSTANCE_TERMINATED_ERROR, "Initialize cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Initialize must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForTerminateError(arg) {
    this.WriteDetailedLog("`1442`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_TERMINATION_BEFORE_INITIALIZATION_ERROR, "Terminate cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_TERMINATION_AFTER_TERMINATION_ERROR, "Terminate cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Terminate must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForCommitError(arg) {
    this.WriteDetailedLog("`1506`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_COMMIT_BEFORE_INITIALIZATION_ERROR, "Commit cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_COMMIT_AFTER_TERMINATION_ERROR, "Commit cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (arg !== "") {
        this.SetErrorState(SCORM2004_GENERAL_ARGUMENT_ERROR, "The argument to Commit must be an empty string (\"\"). The argument '" + arg + "' is invalid.");
        return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckMaxLength(_5f, _60) {
    switch (_5f) {
        case "cmi.comments_from_learner.n.comment":
            this.CheckLengthAndWarn(_60, 4250);
            break;
        case "cmi.comments_from_learner.n.location":
            this.CheckLengthAndWarn(_60, 250);
            break;
        case "cmi.interactions.n.id":
            this.CheckLengthAndWarn(_60, 4000);
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.CheckLengthAndWarn(_60, 4000);
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.CheckLengthAndWarn(_60, 7800);
            break;
        case "cmi.interactions.n.learner_response":
            this.CheckLengthAndWarn(_60, 7800);
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.CheckLengthAndWarn(_60, 500);
            break;
        case "cmi.learner_preference.language":
            this.CheckLengthAndWarn(_60, 250);
            break;
        case "cmi.location":
            this.CheckLengthAndWarn(_60, 1000);
            break;
        case "cmi.objectives.n.id":
            this.CheckLengthAndWarn(_60, 4000);
            break;
        case "cmi.objectives.n.description":
            this.CheckLengthAndWarn(_60, 500);
            break;
        case "cmi.suspend_data":
            this.CheckLengthAndWarn(_60, Control.Package.Properties.SuspendDataMaxLength);
            break;
        default:
            break;
    }
    return;
}

function RunTimeApi_CheckLengthAndWarn(str, len) {
    if (str.length > len) {
        this.SetErrorState(SCORM2004_NO_ERROR, "The string was trimmed to fit withing the SPM of " + len + " characters.");
    }
    return;
}

function RunTimeApi_CheckForGetValueError(_63, _64, _65, _66) {
    this.WriteDetailedLog("`1463`");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_RETRIEVE_DATA_BEFORE_INITIALIZATION_ERROR, "GetValue cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_RETRIEVE_DATA_AFTER_TERMINATION_ERROR, "GetValue cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (_63.length === 0) {
        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The data model element for GetValue was not specified.");
        return false;
    }
    if (_65 !== "") {
        if (_64.indexOf("cmi.comments_from_learner") >= 0) {
            if (_65 >= this.RunTimeData.Comments.length) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Comments From Learner collection does not have an element at index " + _65 + ", the current element count is " + this.RunTimeData.Comments.length + ".");
                return false;
            }
        } else {
            if (_64.indexOf("cmi.comments_from_lms") >= 0) {
                if (_65 >= this.RunTimeData.CommentsFromLMS.length) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Comments From LMS collection does not have an element at index " + _65 + ", the current element count is " + this.RunTimeData.CommentsFromLMS.length + ".");
                    return false;
                }
            } else {
                if (_64.indexOf("cmi.objectives") >= 0) {
                    if (_65 >= this.RunTimeData.Objectives.length) {
                        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Objectives collection does not have an element at index " + _65 + ", the current element count is " + this.RunTimeData.Objectives.length + ".");
                        return false;
                    }
                } else {
                    if (_64.indexOf("cmi.interactions") >= 0) {
                        if (_65 >= this.RunTimeData.Interactions.length) {
                            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Interactions collection does not have an element at index " + _65 + ", the current element count is " + this.RunTimeData.Interactions.length + ".");
                            return false;
                        }
                        if (_64.indexOf("cmi.interactions.n.correct_responses") >= 0) {
                            if (_66 !== "") {
                                if (_66 >= this.RunTimeData.Interactions[_65].CorrectResponses.length) {
                                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Correct Responses collection for Interaction #" + _65 + " does not have " + _66 + " elements in it, the current element count is " + this.RunTimeData.Interactions[_65].CorrectResponses.length + ".");
                                    return false;
                                }
                            }
                        } else {
                            if (_64.indexOf("cmi.interactions.n.objectives") >= 0) {
                                if (_66 !== "") {
                                    if (_66 >= this.RunTimeData.Interactions[_65].Objectives.length) {
                                        this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Objectives collection for Interaction #" + _65 + " does not have " + _66 + " elements in it, the current element count is " + this.RunTimeData.Interactions[_65].Objectives.length + ".");
                                        return false;
                                    }
                                }
                            }
                        }
                    } else {
                        if (_64.indexOf("adl.data") >= 0) {
                            if (_65 >= this.LearningObject.SharedDataMaps.length) {
                                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The Shared Data collection does not have an element at index " + _65 + ", the current element count is " + this.LearningObject.SharedDataMaps.length + ".");
                                return false;
                            }
                        }
                    }
                }
            }
        }
    }
    switch (_64) {
        case "cmi._version":
            this.WriteDetailedLog("`1618`");
            break;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1187`");
            break;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            break;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1162`");
            if (this.RunTimeData.Comments[_65].Comment === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Comment field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1134`");
            if (this.RunTimeData.Comments[_65].Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1119`");
            if (this.RunTimeData.Comments[_65].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The TimeStamp field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            break;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            break;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1248`");
            if (this.RunTimeData.CommentsFromLMS[_65].Comment === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Comment field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1233`");
            if (this.RunTimeData.CommentsFromLMS[_65].Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1213`");
            if (this.RunTimeData.CommentsFromLMS[_65].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Timestamp field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1371`");
            if (this.LearningObject.CompletedByMeasure === false || this.LearningObject.CompletionThreshold === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The completion threshold for this SCO was not specificed.");
                return false;
            }
            break;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            break;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            break;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The Exit data model element is write-only.");
            return false;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            break;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            break;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1427`");
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1391`");
            if (this.RunTimeData.Interactions[_65].Type === null || this.RunTimeData.Interactions[_65].Type === "") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Type field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1135`");
            break;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1188`");
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1302`");
            if (this.RunTimeData.Interactions[_65].Timestamp === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Time Stamp field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`999`");
            break;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`972`");
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1303`");
            if (this.RunTimeData.Interactions[_65].Weighting === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Weighting field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1191`");
            if (this.RunTimeData.Interactions[_65].LearnerResponse === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Learner Response field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1355`");
            if (this.RunTimeData.Interactions[_65].Result === null || this.RunTimeData.Interactions[_65].Result === "") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Result field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1333`");
            if (this.RunTimeData.Interactions[_65].Latency === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Latency field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1269`");
            if (this.RunTimeData.Interactions[_65].Description === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Description field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            if (this.LearningObject.DataFromLms === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Launch Data field was not specified for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1570`");
            break;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1529`");
            break;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            break;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1190`");
            if (this.RunTimeData.AudioLevel === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Audio Level field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1250`");
            if (this.RunTimeData.LanguagePreference === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Language Preference field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1120`");
            if (this.RunTimeData.DeliverySpeed === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Delivery Speed field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1079`");
            if (this.RunTimeData.AudioCaptioning === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Audio Captioning field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            if (this.RunTimeData.Location === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Location field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1447`");
            if (this.LearningObject.SequencingData === null || this.LearningObject.SequencingData.LimitConditionAttemptAbsoluteDurationControl === false) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Time Allowed field was not specified in the manifest for this SCO.");
                return false;
            }
            break;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            break;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            break;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            break;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1477`");
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1236`");
            break;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1290`");
            if (this.RunTimeData.Objectives[_65].ScoreScaled === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Score field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1339`");
            if (this.RunTimeData.Objectives[_65].ScoreRaw === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Raw Score field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1338`");
            if (this.RunTimeData.Objectives[_65].ScoreMin === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Min Score field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1337`");
            if (this.RunTimeData.Objectives[_65].ScoreMax === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Score field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1251`");
            if (this.RunTimeData.Objectives[_65].SuccessStatus === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The SuccessStatus field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1192`");
            if (this.RunTimeData.Objectives[_65].CompletionStatus === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The CompletionStatus field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1216`");
            if (this.RunTimeData.Objectives[_65].ProgressMeasure === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The ProgressMeasure field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1304`");
            if (this.RunTimeData.Objectives[_65].Description === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Description field has not been initialized for the objective at index " + _65);
                return false;
            }
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            if (this.RunTimeData.ProgressMeasure === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Progress Measure field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1378`");
            if (this.LearningObject.GetScaledPassingScore() === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Passing Score field was not specificed for this SCO.");
                return false;
            }
            break;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            break;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            if (this.RunTimeData.ScoreScaled === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Scaled Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            if (this.RunTimeData.ScoreRaw === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Raw Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            if (this.RunTimeData.ScoreMax === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Max Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            if (this.RunTimeData.ScoreMin === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Min Score field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The Exit data model element is write-only.");
            return false;
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            if (this.RunTimeData.SuspendData === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Suspend Data field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1434`");
            if (this.LearningObject.TimeLimitAction === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The Time Limit Action field has not been set for this SCO.");
                return false;
            }
            break;
        case "cmi.total_time":
            this.WriteDetailedLog("`1575`");
            break;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1182`");
            break;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1183`");
            break;
        case "adl.data._children":
            this.WriteDetailedLog("`1405`");
            break;
        case "adl.data._count":
            this.WriteDetailedLog("`1472`");
            break;
        case "adl.data.n.id":
            this.WriteDetailedLog("`1508`");
            break;
        case "adl.data.n.store":
            this.WriteDetailedLog("`1444`");
            if (this.LearningObject.SharedDataMaps[_65].ReadSharedData == false) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The specified shared data is write-only.");
                return false;
            }
            var id = this.LearningObject.SharedDataMaps[_65].Id;
            for (var idx = 0; idx < RegistrationToDeliver.SharedData.length; idx++) {
                if (RegistrationToDeliver.SharedData[idx].SharedDataId == id) {
                    var _69 = RegistrationToDeliver.SharedData[idx].GetData();
                    break;
                }
            }
            if (_69 === null || _69 === "") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_NOT_INITIALIZED_ERROR, "The store field has not been initialized for the element at index " + _65);
                return false;
            }
            break;
        default:
            if (_64.indexOf("adl.nav.request_valid.choice") === 0) {
                this.WriteDetailedLog("`1230`");
                return true;
            }
            if (_64.indexOf("adl.nav.request_valid.jump") === 0) {
                this.WriteDetailedLog("`1267`");
                return true;
            }
            if (_64.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.CheckForGetValueError(_63, _64, _65, _66);
                }
            }
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _63 + "' does not exist.");
            return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_CheckForSetValueError(_6a, _6b, _6c, _6d, _6e) {
    this.WriteDetailedLog("`1548`" + _6a + ", " + _6b + ", " + _6c + ", " + _6d + ", " + _6e + ") ");
    if (!this.Initialized) {
        this.SetErrorState(SCORM2004_STORE_DATA_BEFORE_INITIALIZATION_ERROR, "SetValue cannot be called before Initialize has been called.");
        return false;
    }
    if (this.Terminated) {
        this.SetErrorState(SCORM2004_STORE_DATA_AFTER_TERMINATION_ERROR, "SetValue cannot be called after Terminate has already beeen called.");
        return false;
    }
    if (_6a.length === 0) {
        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The data model element for SetValue was not specified.");
        return false;
    }
    if (_6a.indexOf("adl.nav.request_valid.choice.{") === 0) {
        this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.choice element is read only");
        return false;
    }
    if (_6a.indexOf("adl.nav.request_valid.jump.{") === 0) {
        this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.jump element is read only");
        return false;
    }
    if (_6d !== "") {
        if (_6c.indexOf("cmi.comments_from_learner") >= 0) {
            if (_6d > this.RunTimeData.Comments.length) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Comments From Learner collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.Comments.length + ".");
                return false;
            }
        } else {
            if (_6c.indexOf("cmi.comments_from_lms") >= 0) {
                if (_6d > this.RunTimeData.CommentsFromLMS.length) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Comments From LMS collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.CommentsFromLMS.length + ".");
                    return false;
                }
            } else {
                if (_6c.indexOf("cmi.objectives") >= 0) {
                    if (_6d > this.RunTimeData.Objectives.length) {
                        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Objectives collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.Objectives.length + ".");
                        return false;
                    }
                } else {
                    if (_6c.indexOf("cmi.interactions") >= 0) {
                        if (_6d > this.RunTimeData.Interactions.length) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Interactions collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                            return false;
                        } else {
                            if (_6c.indexOf("cmi.interactions.n.correct_responses") >= 0) {
                                if (_6d >= this.RunTimeData.Interactions.length) {
                                    this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The Interactions collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                                    return false;
                                }
                                if (_6e !== "") {
                                    if (_6e > this.RunTimeData.Interactions[_6d].CorrectResponses.length) {
                                        this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Correct Responses collection elements for Interaction #" + _6d + " must be set sequentially the index " + _6e + " is greater than the next available index of " + this.RunTimeData.Interactions[_6d].CorrectResponses.length + ".");
                                        return false;
                                    }
                                }
                            } else {
                                if (_6c.indexOf("cmi.interactions.n.objectives") >= 0) {
                                    if (_6d >= this.RunTimeData.Interactions.length) {
                                        this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The Interactions collection elements must be set sequentially, the index " + _6d + ", is greater than the next available index of " + this.RunTimeData.Interactions.length + ".");
                                        return false;
                                    }
                                    if (_6e !== "") {
                                        if (_6e > this.RunTimeData.Interactions[_6d].Objectives.length) {
                                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Objectives collection elements for Interaction #" + _6d + " must be set sequentially the index " + _6e + " is greater than the next available index of " + this.RunTimeData.Interactions[_6d].Objectives.length + ".");
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (_6c.indexOf("adl.data") >= 0) {
                            if (_6d >= this.LearningObject.SharedDataMaps.length) {
                                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The Shared Data index " + _6d + ", is greater than the maximum available index of " + this.LearningObject.SharedDataMaps.length + ".");
                                return false;
                            }
                        }
                    }
                }
            }
        }
    }
    var _6f;
    var i;
    switch (_6c) {
        case "cmi._version":
            this.WriteDetailedLog("`1599`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi._version data model element is read-only");
            return false;
        case "cmi.comments_from_learner._children":
            this.WriteDetailedLog("`1161`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_learner._children data model element is read-only");
            return false;
        case "cmi.comments_from_learner._count":
            this.WriteDetailedLog("`1232`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_learner._count data model element is read-only");
            return false;
        case "cmi.comments_from_learner.n.comment":
            this.WriteDetailedLog("`1162`");
            if (!this.ValidLocalizedString(_6b, 4000)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.comments_from_learner.n.comment data model element is not a valid localized string type (SPM 4000)");
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.location":
            this.WriteDetailedLog("`1134`");
            if (!this.ValidCharString(_6b, 250)) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The cmi.comments_from_learner.n.comment data model element is not a valid char string type (SPM 250)");
                return false;
            }
            break;
        case "cmi.comments_from_learner.n.timestamp":
            this.WriteDetailedLog("`1119`");
            if (!this.ValidTime(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.comments_from_learner.n.timestamp data model element is not a valid time");
                return false;
            }
            break;
        case "cmi.comments_from_lms._children":
            this.WriteDetailedLog("`1247`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms._children data model element is read-only");
            return false;
        case "cmi.comments_from_lms._count":
            this.WriteDetailedLog("`1300`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms._count data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.comment":
            this.WriteDetailedLog("`1248`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.comment data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.location":
            this.WriteDetailedLog("`1233`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.location data model element is read-only");
            return false;
        case "cmi.comments_from_lms.n.timestamp":
            this.WriteDetailedLog("`1213`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.comments_from_lms.timestamp data model element is read-only");
            return false;
        case "cmi.completion_status":
            this.WriteDetailedLog("`1425`");
            if (_6b != SCORM_STATUS_COMPLETED && _6b != SCORM_STATUS_INCOMPLETE && _6b != SCORM_STATUS_NOT_ATTEMPTED && _6b != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The completion_status data model element must be a proper vocabulary element.");
                return false;
            }
            break;
        case "cmi.completion_threshold":
            this.WriteDetailedLog("`1371`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The completion_threshold data model element is read-only");
            return false;
        case "cmi.credit":
            this.WriteDetailedLog("`1648`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The credit data model element is read-only");
            return false;
        case "cmi.entry":
            this.WriteDetailedLog("`1670`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The entry data model element is read-only");
            return false;
        case "cmi.exit":
            this.WriteDetailedLog("`1696`");
            if (_6b != SCORM_EXIT_TIME_OUT && _6b != SCORM_EXIT_SUSPEND && _6b != SCORM_EXIT_LOGOUT && _6b != SCORM_EXIT_NORMAL && _6b != SCORM_EXIT_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The exit data model element must be a proper vocabulary element.");
                return false;
            }
            if (_6b == SCORM_EXIT_LOGOUT) {
                this.WriteDetailedLog("`349`");
            }
            break;
        case "cmi.interactions._children":
            this.WriteDetailedLog("`1332`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions._children element is read-only");
            return false;
        case "cmi.interactions._count":
            this.WriteDetailedLog("`1390`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions._count element is read-only");
            return false;
        case "cmi.interactions.n.id":
            this.WriteDetailedLog("`1427`");
            if (!this.ValidLongIdentifier(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".id value of '" + _6b + "' is not a valid long identifier.");
                return false;
            }
            break;
        case "cmi.interactions.n.type":
            this.WriteDetailedLog("`1391`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (_6b != SCORM_TRUE_FALSE && _6b != SCORM_CHOICE && _6b != SCORM_FILL_IN && _6b != SCORM_LONG_FILL_IN && _6b != SCORM_LIKERT && _6b != SCORM_MATCHING && _6b != SCORM_PERFORMANCE && _6b != SCORM_SEQUENCING && _6b != SCORM_NUMERIC && _6b != SCORM_OTHER) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".type value of '" + _6b + "' is not a valid interaction type.");
                return false;
            }
            break;
        case "cmi.interactions.n.objectives._count":
            this.WriteDetailedLog("`1135`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions.objectives._count element is read-only");
            return false;
        case "cmi.interactions.n.objectives.n.id":
            this.WriteDetailedLog("`1188`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLongIdentifier(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".objectives." + _6e + ".id value of '" + _6b + "' is not a valid long identifier type.");
                return false;
            }
            for (i = 0; i < this.RunTimeData.Interactions[_6d].Objectives.length; i++) {
                if ((this.RunTimeData.Interactions[_6d].Objectives[i] == _6b) && (i != _6e)) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every interaction objective identifier must be unique. The value '" + _6b + "' has already been set in objective #" + i);
                    return false;
                }
            }
            break;
        case "cmi.interactions.n.timestamp":
            this.WriteDetailedLog("`1302`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidTime(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".timestamp value of '" + _6b + "' is not a valid time type.");
                return false;
            }
            break;
        case "cmi.interactions.n.correct_responses._count":
            this.WriteDetailedLog("`999`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The interactions.correct_responses._count element is read-only");
            return false;
        case "cmi.interactions.n.correct_responses.n.pattern":
            this.WriteDetailedLog("`972`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Type === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.type element must be set before a correct response can be set.");
                return false;
            }
            _6f = true;
            if (RegistrationToDeliver.Package.Properties.ValidateInteractionResponses) {
                switch (this.RunTimeData.Interactions[_6d].Type) {
                    case SCORM_TRUE_FALSE:
                        if (this.RunTimeData.Interactions[_6d].CorrectResponses.length > 0 && _6e > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A true-false interaction can only have one correct response.");
                            return false;
                        }
                        _6f = this.ValidTrueFalseResponse(_6b);
                        break;
                    case SCORM_CHOICE:
                        _6f = this.ValidMultipleChoiceResponse(_6b);
                        for (i = 0; i < this.RunTimeData.Interactions[_6d].CorrectResponses.length; i++) {
                            if (this.RunTimeData.Interactions[_6d].CorrectResponses[i] == _6b) {
                                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every correct response to a choice interaction must be unique. The value '" + _6b + "' has already been set in correct response #" + i);
                                return false;
                            }
                        }
                        break;
                    case SCORM_FILL_IN:
                        _6f = this.ValidFillInResponse(_6b, true);
                        break;
                    case SCORM_LONG_FILL_IN:
                        _6f = this.ValidLongFillInResponse(_6b, true);
                        break;
                    case SCORM_LIKERT:
                        if (this.RunTimeData.Interactions[_6d].CorrectResponses.length > 0 && _6e > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A likert interaction can only have one correct response.");
                            return false;
                        }
                        _6f = this.ValidLikeRTResponse(_6b);
                        break;
                    case SCORM_MATCHING:
                        _6f = this.ValidMatchingResponse(_6b);
                        break;
                    case SCORM_PERFORMANCE:
                        _6f = this.ValidPerformanceResponse(_6b, true);
                        break;
                    case SCORM_SEQUENCING:
                        _6f = this.ValidSequencingResponse(_6b);
                        break;
                    case SCORM_NUMERIC:
                        if (this.RunTimeData.Interactions[_6d].CorrectResponses.length > 0 && _6e > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "A numeric interaction can only have one correct response.");
                            return false;
                        }
                        _6f = this.ValidNumericResponse(_6b, true);
                        break;
                    case SCORM_OTHER:
                        if (this.RunTimeData.Interactions[_6d].CorrectResponses.length > 0 && _6e > 0) {
                            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "An 'other' interaction can only have one correct response.");
                            return false;
                        }
                        _6f = this.ValidOtheresponse(_6b);
                        break;
                }
            }
            if (!_6f) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".correct_responses." + _6e + ".pattern value of '" + _6b + "' is not a valid correct response to an interaction of type " + this.RunTimeData.Interactions[_6d].Type + ".");
                return false;
            }
            break;
        case "cmi.interactions.n.weighting":
            this.WriteDetailedLog("`1303`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".weighting value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.interactions.n.learner_response":
            this.WriteDetailedLog("`1164`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (this.RunTimeData.Interactions[_6d].Type === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.type element must be set before a learner response can be set.");
                return false;
            }
            _6f = true;
            if (RegistrationToDeliver.Package.Properties.ValidateInteractionResponses) {
                switch (this.RunTimeData.Interactions[_6d].Type) {
                    case "true-false":
                        _6f = this.ValidTrueFalseResponse(_6b);
                        break;
                    case "choice":
                        _6f = this.ValidMultipleChoiceResponse(_6b);
                        break;
                    case "fill-in":
                        _6f = this.ValidFillInResponse(_6b, false);
                        break;
                    case "long-fill-in":
                        _6f = this.ValidLongFillInResponse(_6b, false);
                        break;
                    case "likert":
                        _6f = this.ValidLikeRTResponse(_6b);
                        break;
                    case "matching":
                        _6f = this.ValidMatchingResponse(_6b);
                        break;
                    case "performance":
                        _6f = this.ValidPerformanceResponse(_6b, false);
                        break;
                    case "sequencing":
                        _6f = this.ValidSequencingResponse(_6b);
                        break;
                    case "numeric":
                        _6f = this.ValidNumericResponse(_6b, false);
                        break;
                    case "other":
                        _6f = this.ValidOtheresponse(_6b);
                        break;
                }
            }
            if (!_6f) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".learner_response value of '" + _6b + "' is not a valid response to an interaction of type " + this.RunTimeData.Interactions[_6d].Type + ".");
                return false;
            }
            break;
        case "cmi.interactions.n.result":
            this.WriteDetailedLog("`1355`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (_6b != SCORM_CORRECT && _6b != SCORM_INCORRECT && _6b != SCORM_UNANTICIPATED && _6b != SCORM_NEUTRAL) {
                if (!this.ValidReal(_6b)) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".result value of '" + _6b + "' is not a valid interaction result.");
                    return false;
                }
            }
            break;
        case "cmi.interactions.n.latency":
            this.WriteDetailedLog("`1333`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidTimeInterval(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".latency value of '" + _6b + "' is not a valid timespan.");
                return false;
            }
            break;
        case "cmi.interactions.n.description":
        case "cmi.interactions.n.text":
            this.WriteDetailedLog("`1269`");
            if (this.RunTimeData.Interactions[_6d] === undefined || this.RunTimeData.Interactions[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The interactions.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLocalizedString(_6b, 250)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.interactions." + _6d + ".description value of '" + _6b + "' is not a valid localized string SPM 250.");
                return false;
            }
            break;
        case "cmi.launch_data":
            this.WriteDetailedLog("`1555`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.launch_data element is read-only");
            return false;
        case "cmi.learner_id":
            this.WriteDetailedLog("`1570`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_id element is read-only");
            return false;
        case "cmi.learner_name":
            this.WriteDetailedLog("`1529`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_name element is read-only");
            return false;
        case "cmi.learner_preference._children":
            this.WriteDetailedLog("`1234`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.learner_preference._children element is read-only");
            return false;
        case "cmi.learner_preference.audio_level":
            this.WriteDetailedLog("`1190`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.audio_level value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.learner_preference.audio_level value of '" + _6b + "' must be greater than zero.");
                return false;
            }
            break;
        case "cmi.learner_preference.language":
            this.WriteDetailedLog("`1250`");
            if (!this.ValidLanguage(_6b, true)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.language value of '" + _6b + "' is not a valid language.");
                return false;
            }
            break;
        case "cmi.learner_preference.delivery_speed":
            this.WriteDetailedLog("`1120`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.delivery_speed value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.learner_preference.delivery_speed value of '" + _6b + "' must be greater than zero.");
                return false;
            }
            break;
        case "cmi.learner_preference.audio_captioning":
            this.WriteDetailedLog("`1079`");
            if (_6b != "-1" && _6b != "0" && _6b != "1") {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.learner_preference.audio_captioning value of '" + _6b + "' must be -1, 0 or 1.");
                return false;
            }
            break;
        case "cmi.location":
            this.WriteDetailedLog("`1602`");
            if (!this.ValidCharString(_6b, 1000)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.location value of '" + _6b + "' is not a valid char string SPM 1000.");
                return false;
            }
            break;
        case "cmi.max_time_allowed":
            this.WriteDetailedLog("`1447`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.max_time_allowed element is read only");
            return false;
        case "cmi.mode":
            this.WriteDetailedLog("`1697`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.mode element is read only");
            return false;
        case "cmi.objectives._children":
            this.WriteDetailedLog("`1373`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives._children element is read only");
            return false;
        case "cmi.objectives._count":
            this.WriteDetailedLog("`1431`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives._count element is read only");
            return false;
        case "cmi.objectives.n.id":
            this.WriteDetailedLog("`1477`");
            if (!this.ValidLongIdentifier(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives.n.id value of '" + _6b + "' is not a valid long identifier.");
                return false;
            }
            if (this.RunTimeData.Objectives[_6d] != undefined && this.RunTimeData.Objectives[_6d].Identifier != null) {
                if (this.RunTimeData.Objectives[_6d].Identifier !== null && this.RunTimeData.Objectives[_6d].Identifier != _6b) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Objective identifiers may only be set once and may not be overwritten. The objective at index " + _6d + " already has the identifier " + this.RunTimeData.Objectives[_6d].Identifier);
                    return false;
                }
            }
            for (i = 0; i < this.RunTimeData.Objectives.length; i++) {
                if ((this.RunTimeData.Objectives[i].Identifier == _6b) && (i != _6d)) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Every objective identifier must be unique. The value '" + _6b + "' has already been set in objective #" + i);
                    return false;
                }
            }
            break;
        case "cmi.objectives.n.score._children":
            this.WriteDetailedLog("`1236`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.objectives.n.score._children element is read only");
            return false;
        case "cmi.objectives.n.score.scaled":
            this.WriteDetailedLog("`1290`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".score.scaled value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < -1 || parseFloat(_6b) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.objectives." + _6d + ".score.scaled value of '" + _6b + "' must be between -1 and 1.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.raw":
            this.WriteDetailedLog("`1339`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".score.raw value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.min":
            this.WriteDetailedLog("`1338`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".score.min value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.score.max":
            this.WriteDetailedLog("`1337`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".score.max value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.objectives.n.success_status":
            this.WriteDetailedLog("`1251`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (_6b != SCORM_STATUS_PASSED && _6b != SCORM_STATUS_FAILED && _6b != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".success_status value of '" + _6b + "' is not a valid success status.");
                return false;
            }
            break;
        case "cmi.objectives.n.completion_status":
            this.WriteDetailedLog("`1192`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (_6b != SCORM_STATUS_COMPLETED && _6b != SCORM_STATUS_INCOMPLETE && _6b != SCORM_STATUS_NOT_ATTEMPTED && _6b != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".completion_status value of '" + _6b + "' is not a valid completion status.");
                return false;
            }
            break;
        case "cmi.objectives.n.progress_measure":
            this.WriteDetailedLog("`1216`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".progress_measure value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < 0 || parseFloat(_6b) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.objectives." + _6d + ".progress_measure value of '" + _6b + "' must be between 0 and 1.");
                return false;
            }
            break;
        case "cmi.objectives.n.description":
            this.WriteDetailedLog("`1304`");
            if (this.RunTimeData.Objectives[_6d] === undefined || this.RunTimeData.Objectives[_6d].Identifier === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The objectives.id element must be set before other elements can be set.");
                return false;
            }
            if (!this.ValidLocalizedString(_6b, 250)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.objectives." + _6d + ".description value of '" + _6b + "' is not a valid localized string SPM 250.");
                return false;
            }
            break;
        case "cmi.progress_measure":
            this.WriteDetailedLog("`1449`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.progress_measure value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < 0 || parseFloat(_6b) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi.pogress_measure value of '" + _6b + "' must be between 0 and 1.");
                return false;
            }
            break;
        case "cmi.scaled_passing_score":
            this.WriteDetailedLog("`1378`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.scaled_passing_score element is read only");
            return false;
        case "cmi.score._children":
            this.WriteDetailedLog("`1478`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.score._children element is read only");
            return false;
        case "cmi.score.scaled":
            this.WriteDetailedLog("`1530`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.scaled value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            if (parseFloat(_6b) < -1 || parseFloat(_6b) > 1) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_VALUE_OUT_OF_RANGE_ERROR, "The cmi..score.scaled value of '" + _6b + "' must be between -1 and 1.");
                return false;
            }
            break;
        case "cmi.score.raw":
            this.WriteDetailedLog("`1585`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.score.max":
            this.WriteDetailedLog("`1583`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.score.min":
            this.WriteDetailedLog("`1584`");
            if (!this.ValidReal(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.score.raw value of '" + _6b + "' is not a valid real number.");
                return false;
            }
            break;
        case "cmi.session_time":
            this.WriteDetailedLog("`1532`");
            if (!this.ValidTimeInterval(_6b)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.session_time value of '" + _6b + "' is not a valid time intervals.");
                return false;
            }
            break;
        case "cmi.success_status":
            this.WriteDetailedLog("`1495`");
            if (_6b != SCORM_STATUS_PASSED && _6b != SCORM_STATUS_FAILED && _6b != SCORM_STATUS_UNKNOWN) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.success_status value of '" + _6b + "' is not a valid success status.");
                return false;
            }
            break;
        case "cmi.suspend_data":
            this.WriteDetailedLog("`1536`");
            if (!this.ValidCharString(_6b, Control.Package.Properties.SuspendDataMaxLength)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The cmi.suspend_data value of '" + _6b + "' is not a valid char string SPM " + Control.Package.Properties.SuspendDataMaxLength + ".");
                return false;
            }
            break;
        case "cmi.time_limit_action":
            this.WriteDetailedLog("`1434`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.time_limit_action element is read only");
            return false;
        case "cmi.total_time":
            this.WriteDetailedLog("`1575`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The cmi.total_time element is read only");
            return false;
        case "adl.nav.request":
            this.WriteDetailedLog("`1473`");
            if (_6b.substring(0, 1) == "{") {
                var _71 = _6b.substring(0, _6b.indexOf("}") + 1);
                if (Control.IsTargetValid(_71) === false) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value '" + _71 + "' is not a valid target of a choice/jump request.");
                    return false;
                }
                if (_6b.indexOf("choice") != _71.length && _6b.indexOf("jump") != _71.length) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "A target may only be provided for a choice or jump request.");
                    return false;
                }
            } else {
                if (_6b != SCORM_RUNTIME_NAV_REQUEST_CONTINUE && _6b != SCORM_RUNTIME_NAV_REQUEST_PREVIOUS && _6b != SCORM_RUNTIME_NAV_REQUEST_CHOICE && _6b != SCORM_RUNTIME_NAV_REQUEST_JUMP && _6b != SCORM_RUNTIME_NAV_REQUEST_EXIT && _6b != SCORM_RUNTIME_NAV_REQUEST_EXITALL && _6b != SCORM_RUNTIME_NAV_REQUEST_ABANDON && _6b != SCORM_RUNTIME_NAV_REQUEST_ABANDONALL && _6b != SCORM_RUNTIME_NAV_REQUEST_SUSPENDALL && _6b != SCORM_RUNTIME_NAV_REQUEST_NONE) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The adl.nav.request value of '" + _6b + "' is not a valid nav request.");
                    return false;
                }
            }
            break;
        case "adl.nav.request_valid.continue":
            this.WriteDetailedLog("`1182`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.continue element is read only");
            return false;
        case "adl.nav.request_valid.previous":
            this.WriteDetailedLog("`1183`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.nav.request_valid.previous element is read only");
            return false;
        case "adl.nav.request_valid.choice":
            this.WriteDetailedLog("`1230`");
            break;
        case "adl.nav.request_valid.jump":
            this.WriteDetailedLog("`1267`");
            break;
        case "adl.data._children":
            this.WriteDetailedLog("`1405`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.data._children element is read-only");
            return false;
        case "adl.data._count":
            this.WriteDetailedLog("`1472`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.data._count element is read-only");
            return false;
        case "adl.data.n.id":
            this.WriteDetailedLog("`1508`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The adl.data.n.id element is read-only");
            return false;
            break;
        case "adl.data.n.store":
            this.WriteDetailedLog("`1444`");
            if (this.LearningObject.SharedDataMaps[_6d] === undefined || this.LearningObject.SharedDataMaps[_6d].Id === null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_DEPENDENCY_NOT_ESTABLISHED_ERROR, "The adl.data.id element must be set before other elements can be set.");
                return false;
            }
            if (this.LearningObject.SharedDataMaps[_6d].WriteSharedData == false) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The specified shared data is read-only.");
                return false;
            }
            if (!this.ValidCharString(_6b, Control.Package.Properties.SuspendDataMaxLength)) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The adl.data." + _6d + ".store value is not a valid char string SPM " + Control.Package.Properties.SuspendDataMaxLength + ".");
                return false;
            }
            break;
        default:
            if (_6c.indexOf("ssp") === 0) {
                if (SSP_ENABLED) {
                    return this.SSPApi.CheckForSetValueError(_6a, _6b, _6c, _6d, _6e);
                }
            }
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _6a + "' is not defined in SCORM 2004");
            return false;
    }
    this.WriteDetailedLog("`1615`");
    return true;
}

function RunTimeApi_ValidCharString(str, _73) {
    this.WriteDetailedLog("`1496`");
    return true;
}

function RunTimeApi_ValidLocalizedString(str, _75) {
    this.WriteDetailedLog("`1393`");
    var _76;
    var _77 = new String();
    var _78;
    _76 = str;
    if (str.indexOf("{lang=") === 0) {
        _78 = str.indexOf("}");
        if (_78 > 0) {
            _77 = str.substr(0, _78);
            _77 = _77.replace(/\{lang=/, "");
            _77 = _77.replace(/\}/, "");
            if (!this.ValidLanguage(_77, false)) {
                return false;
            }
            if (str.length >= (_78 + 2)) {
                _76 = str.substring(_78 + 1);
            } else {
                _76 = "";
            }
        }
    }
    return true;
}

function RunTimeApi_ExtractLanguageDelimiterFromLocalizedString(str) {
    var _7a;
    var _7b = "";
    if (str.indexOf("{lang=") === 0) {
        _7a = str.indexOf("}");
        if (_7a > 0) {
            _7b = str.substr(0, _7a + 1);
        }
    }
    return _7b;
}

function RunTimeApi_ValidLanguage(str, _7d) {
    this.WriteDetailedLog("`1540`");
    var _7e;
    if (str.length === 0) {
        if (_7d) {
            return true;
        } else {
            return false;
        }
    }
    _7e = str.split("-");
    for (var i = 0; i < _7e.length; i++) {
        if (_7e[i].length > 8) {
            return false;
        }
        if (_7e[i].length < 2) {
            if (_7e[i] != "i" && _7e[i] != "x") {
                return false;
            }
        }
    }
    var _80 = new Iso639LangCodes_LangCodes();
    if (!_80.IsValid(_7e[0].toLowerCase())) {
        return false;
    }
    if (str.length > 250) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidLongIdentifier(str) {
    this.WriteDetailedLog("`1412`");
    str = str.trim();
    if (!this.ValidIdentifier(str)) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidShortIdentifier(str) {
    this.WriteDetailedLog("`1395`");
    if (!this.ValidIdentifier(str)) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidIdentifier(str) {
    this.WriteDetailedLog("`1497`");
    str = str.trim();
    if (str.length === 0) {
        return false;
    }
    if (str.toLowerCase().indexOf("urn:") === 0) {
        return this.IsValidUrn(str);
    }
    if (str.search(/\w/) < 0) {
        return false;
    }
    if (str.search(/[^\w\-\(\)\+\.\:\=\@\;\$\_\!\*\'\%\/]/) >= 0) {
        return false;
    }
    return true;
}

function RunTimeApi_IsValidUrn(str) {
    this.WriteDetailedLog("`1587`");
    var _85 = str.split(":");
    var nid = new String("");
    var nss = "";
    if (_85.length > 1) {
        nid = _85[1];
    } else {
        return false;
    }
    if (_85.length > 2) {
        nss = _85[2];
    }
    if (nid.length === 0) {
        return false;
    }
    if (nid.indexOf(" ") > 0 || nss.indexOf(" ") > 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidReal(str) {
    this.WriteDetailedLog("`1607`");
    if (str.search(/[^.\d-]/) > -1) {
        return false;
    }
    if (str.search("-") > -1) {
        if (str.indexOf("-", 1) > -1) {
            return false;
        }
    }
    if (str.indexOf(".") != str.lastIndexOf(".")) {
        return false;
    }
    if (str.search(/\d/) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidTime(str) {
    this.WriteDetailedLog("`1608`");
    var _8a = "";
    var _8b = "";
    var day = "";
    var _8d = "";
    var _8e = "";
    var _8f = "";
    var _90 = "";
    var _91 = "";
    var _92 = "";
    var _93 = "";
    var _94;
    str = new String(str);
    var _95 = /^(\d\d\d\d)(-(\d\d)(-(\d\d)(T(\d\d)(:(\d\d)(:(\d\d))?)?)?)?)?/;
    if (str.search(_95) !== 0) {
        return false;
    }
    if (str.substr(str.length - 1, 1).search(/[\-T\:]/) >= 0) {
        return false;
    }
    var len = str.length;
    if (len != 4 && len != 7 && len != 10 && len != 13 && len != 16 && len < 19) {
        return false;
    }
    if (len >= 5) {
        if (str.substr(4, 1) != "-") {
            return false;
        }
    }
    if (len >= 8) {
        if (str.substr(7, 1) != "-") {
            return false;
        }
    }
    if (len >= 11) {
        if (str.substr(10, 1) != "T") {
            return false;
        }
    }
    if (len >= 14) {
        if (str.substr(13, 1) != ":") {
            return false;
        }
    }
    if (len >= 17) {
        if (str.substr(16, 1) != ":") {
            return false;
        }
    }
    var _97 = str.match(_95);
    _8a = _97[1];
    _8b = _97[3];
    day = _97[5];
    _8d = _97[7];
    _8e = _97[9];
    _8f = _97[11];
    if (str.length > 19) {
        if (str.length < 21) {
            return false;
        }
        if (str.substr(19, 1) != ".") {
            return false;
        }
        _94 = str.substr(20, 1);
        if (_94.search(/\d/) < 0) {
            return false;
        } else {
            _90 += _94;
        }
        for (var i = 21; i < str.length; i++) {
            _94 = str.substr(i, 1);
            if ((i == 21) && (_94.search(/\d/) === 0)) {
                _90 += _94;
            } else {
                _91 += _94;
            }
        }
    }
    if (_91.length === 0) {} else {
        if (_91.length == 1) {
            if (_91 != "Z") {
                return false;
            }
        } else {
            if (_91.length == 3) {
                if (_91.search(/[\+\-]\d\d/) !== 0) {
                    return false;
                } else {
                    _92 = _91.substr(1, 2);
                }
            } else {
                if (_91.length == 6) {
                    if (_91.search(/[\+\-]\d\d:\d\d/) !== 0) {
                        return false;
                    } else {
                        _92 = _91.substr(1, 2);
                        _93 = _91.substr(4, 2);
                    }
                } else {
                    return false;
                }
            }
        }
    }
    if (_8a < 1970 || _8a > 2038) {
        return false;
    }
    if (_8b !== undefined && _8b !== "") {
        _8b = parseInt(_8b, 10);
        if (_8b < 1 || _8b > 12) {
            return false;
        }
    }
    if (day !== undefined && day !== "") {
        var dtm = new Date(_8a, (_8b - 1), day);
        if (dtm.getDate() != day) {
            return false;
        }
    }
    if (_8d !== undefined && _8d !== "") {
        _8d = parseInt(_8d, 10);
        if (_8d < 0 || _8d > 23) {
            return false;
        }
    }
    if (_8e !== undefined && _8e !== "") {
        _8e = parseInt(_8e, 10);
        if (_8e < 0 || _8e > 59) {
            return false;
        }
    }
    if (_8f !== undefined && _8f !== "") {
        _8f = parseInt(_8f, 10);
        if (_8f < 0 || _8f > 59) {
            return false;
        }
    }
    if (_92 !== undefined && _92 !== "") {
        _92 = parseInt(_92, 10);
        if (_92 < 0 || _92 > 23) {
            return false;
        }
    }
    if (_93 !== undefined && _93 !== "") {
        _93 = parseInt(_93, 10);
        if (_93 < 0 || _93 > 59) {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidTimeInterval(str) {
    this.WriteDetailedLog("`1455`");
    var _9b = /^P(\d+Y)?(\d+M)?(\d+D)?(T(\d+H)?(\d+M)?(\d+(.\d\d?)?S)?)?$/;
    if (str == "P") {
        return false;
    }
    if (str.lastIndexOf("T") == (str.length - 1)) {
        return false;
    }
    if (str.search(_9b) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidTrueFalseResponse(str) {
    this.WriteDetailedLog("`1362`");
    var _9d = /^(true|false)$/;
    if (str.search(_9d) < 0) {
        return false;
    }
    return true;
}

function RunTimeApi_ValidMultipleChoiceResponse(str) {
    this.WriteDetailedLog("`1275`");
    if (str.length === 0) {
        return true;
    }
    return (this.IsValidArrayOfShortIdentifiers(str, 36, true) || this.IsValidCommaDelimitedArrayOfShortIdentifiers(str, 36, true));
}

function RunTimeApi_IsValidCommaDelimitedArrayOfShortIdentifiers(str, _a0, _a1) {
    this.WriteDetailedLog("`1221`");
    var _a2 = ",";
    var _a3 = str.split(_a2);
    for (var i = 0; i < _a3.length; i++) {
        if (!this.ValidShortIdentifier(_a3[i])) {
            return false;
        }
        if (_a1) {
            for (var j = 0; j < _a3.length; j++) {
                if (j != i) {
                    if (_a3[j] == _a3[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_IsValidArrayOfShortIdentifiers(str, _a7, _a8) {
    this.WriteDetailedLog("`1221`");
    var _a9 = "[,]";
    var _aa = str.split(_a9);
    for (var i = 0; i < _aa.length; i++) {
        if (!this.ValidShortIdentifier(_aa[i])) {
            return false;
        }
        if (_a8) {
            for (var j = 0; j < _aa.length; j++) {
                if (j != i) {
                    if (_aa[j] == _aa[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_IsValidArrayOfLocalizedStrings(str, _ae, _af) {
    this.WriteDetailedLog("`1220`");
    var _b0 = "[,]";
    var _b1 = str.split(_b0);
    for (var i = 0; i < _b1.length; i++) {
        if (!this.ValidLocalizedString(_b1[i], 0)) {
            return false;
        }
        if (_af) {
            for (var j = 0; j < _b1.length; j++) {
                if (j != i) {
                    if (_b1[j] == _b1[i]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

function RunTimeApi_ValidFillInResponse(str, _b5) {
    this.WriteDetailedLog("`1410`");
    if (str.length === 0) {
        return true;
    }
    var _b6 = /^\{case_matters=/;
    var _b7 = /^\{order_matters=/;
    var _b8 = /^\{lang=[\w\-]+\}\{/;
    var _b9 = /^\{case_matters=(true|false)\}/;
    var _ba = /^\{order_matters=(true|false)\}/;
    var _bb = new String(str);
    if (_b5) {
        if (_bb.search(_b6) >= 0) {
            if (_bb.search(_b9) < 0) {
                return false;
            }
            _bb = _bb.replace(_b9, "");
        }
        if (_bb.search(_b7) >= 0) {
            if (_bb.search(_ba) < 0) {
                return false;
            }
            _bb = _bb.replace(_ba, "");
        }
        if (_bb.search(_b6) >= 0) {
            if (_bb.search(_b9) < 0) {
                return false;
            }
            _bb = _bb.replace(_b9, "");
        }
    }
    return this.IsValidArrayOfLocalizedStrings(_bb, 10, false);
}

function RunTimeApi_ValidLongFillInResponse(str, _bd) {
    this.WriteDetailedLog("`1344`");
    var _be = /^\{case_matters=/;
    var _bf = /^\{case_matters=(true|false)\}/;
    var _c0 = new String(str);
    if (_bd) {
        if (_c0.search(_be) >= 0) {
            if (_c0.search(_bf) < 0) {
                return false;
            }
            _c0 = _c0.replace(_bf, "");
        }
    }
    return this.ValidLocalizedString(_c0, 4000);
}

function RunTimeApi_ValidLikeRTResponse(str) {
    this.WriteDetailedLog("`1411`");
    return this.ValidShortIdentifier(str);
}

function RunTimeApi_ValidMatchingResponse(str) {
    this.WriteDetailedLog("`1383`");
    var _c3 = "[,]";
    var _c4 = "[.]";
    var _c5;
    var _c6;
    _c5 = str.split(_c3);
    for (var i = 0; i < _c5.length; i++) {
        _c6 = _c5[i].split(_c4);
        if (_c6.length != 2) {
            return false;
        }
        if (!this.ValidShortIdentifier(_c6[0])) {
            return false;
        }
        if (!this.ValidShortIdentifier(_c6[1])) {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidPerformanceResponse(str, _c9) {
    this.WriteDetailedLog("`1322`");
    var _ca = /^\{order_matters=/;
    var _cb = /^\{order_matters=(true|false)\}/;
    var _cc;
    var _cd;
    var _ce;
    var _cf;
    var _d0;
    var _d1 = new String(str);
    if (str.length === 0) {
        return false;
    }
    if (_c9) {
        if (_d1.search(_ca) >= 0) {
            if (_d1.search(_cb) < 0) {
                return false;
            }
            _d1 = _d1.replace(_cb, "");
        }
    }
    _cc = _d1.split("[,]");
    if (_cc.length === 0) {
        return false;
    }
    for (var i = 0; i < _cc.length; i++) {
        _cd = _cc[i];
        if (_cd.length === 0) {
            return false;
        }
        _ce = _cd.split("[.]");
        if (_ce.length == 2) {
            _cf = _ce[0];
            _d0 = _ce[1];
            if (_cf.length === 0 && _d0 === 0) {
                return false;
            }
            if (_cf.length > 0) {
                if (!this.ValidShortIdentifier(_cf)) {
                    return false;
                }
            }
        } else {
            return false;
        }
    }
    return true;
}

function RunTimeApi_ValidSequencingResponse(str) {
    this.WriteDetailedLog("`1345`");
    return this.IsValidArrayOfShortIdentifiers(str, 36, false);
}

function RunTimeApi_ValidNumericResponse(str, _d5) {
    this.WriteDetailedLog("`1394`");
    var _d6 = "[:]";
    var _d7 = str.split(_d6);
    if (_d5) {
        if (_d7.length > 2) {
            return false;
        }
    } else {
        if (_d7.length > 1) {
            return false;
        }
    }
    for (var i = 0; i < _d7.length; i++) {
        if (!this.ValidReal(_d7[i])) {
            return false;
        }
    }
    if (_d7.length >= 2) {
        if (_d7[0].length > 0 && _d7[1].length > 0) {
            if (parseFloat(_d7[0]) > parseFloat(_d7[1])) {
                return false;
            }
        }
    }
    return true;
}

function RunTimeApi_ValidOtheresponse(str) {
    this.WriteDetailedLog("`1454`");
    return true;
}

function RunTimeApi_TranslateBooleanIntoCMI(_da) {
    if (_da === true) {
        return SCORM_TRUE;
    } else {
        if (_da === false) {
            return SCORM_FALSE;
        } else {
            return SCORM_UNKNOWN;
        }
    }
}

function RunTimeApi_GetCompletionStatus() {
    if (this.LearningObject.CompletedByMeasure === true) {
        if (this.LearningObject.CompletionThreshold !== null) {
            if (this.RunTimeData.ProgressMeasure !== null) {
                if (parseFloat(this.RunTimeData.ProgressMeasure) >= parseFloat(this.LearningObject.CompletionThreshold)) {
                    this.WriteDetailedLog("`616`");
                    return SCORM_STATUS_COMPLETED;
                } else {
                    this.WriteDetailedLog("`569`");
                    return SCORM_STATUS_INCOMPLETE;
                }
            } else {
                this.WriteDetailedLog("`998`" + this.LearningObject.CompletionThreshold + "`670`");
                return SCORM_STATUS_UNKNOWN;
            }
        } else {
            this.WriteDetailedLog("`624`" + this.RunTimeData.CompletionStatus);
            return this.RunTimeData.CompletionStatus;
        }
    } else {
        this.WriteDetailedLog("`649`" + this.RunTimeData.CompletionStatus);
        return this.RunTimeData.CompletionStatus;
    }
}

function RunTimeApi_GetSuccessStatus() {
    var _db = this.LearningObject.GetScaledPassingScore();
    if (_db !== null) {
        if (this.RunTimeData.ScoreScaled !== null) {
            if (parseFloat(this.RunTimeData.ScoreScaled) >= parseFloat(_db)) {
                this.WriteDetailedLog("`697`");
                return SCORM_STATUS_PASSED;
            } else {
                this.WriteDetailedLog("`650`");
                return SCORM_STATUS_FAILED;
            }
        } else {
            this.WriteDetailedLog("`570`");
            return SCORM_STATUS_UNKNOWN;
        }
    }
    this.WriteDetailedLog("`641`" + this.RunTimeData.SuccessStatus);
    return this.RunTimeData.SuccessStatus;
}

function RunTimeApi_InitTrackedTimeStart(_dc) {
    this.TrackedStartDate = new Date();
    this.StartSessionTotalTime = _dc.RunTime.TotalTime;
}

function RunTimeApi_AccumulateTotalTimeTracked() {
    this.TrackedEndDate = new Date();
    var _dd = Math.round((this.TrackedEndDate - this.TrackedStartDate) / 10);
    var _de = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTimeTracked);
    var _df = 0;
    if ((_dd + _de) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`1299`");
        _df = _dd + _de;
    } else {
        _df = _dd + _de - this.TrackedSessionTimePrevCall;
    }
    this.RunTimeData.TotalTimeTracked = ConvertHundredthsToIso8601TimeSpan(_df);
    var _e0 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.SessionTimeTracked);
    var _e1 = 0;
    if ((_dd + _e0) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`1266`");
        _e1 = _dd + _e0;
    } else {
        _e1 = _dd + _e0 - this.TrackedSessionTimePrevCall;
    }
    this.RunTimeData.SessionTimeTracked = ConvertHundredthsToIso8601TimeSpan(_e1);
    this.Activity.ActivityEndedDate = this.TrackedEndDate;
    var _e2 = GetDateFromUtcIso8601Time(this.Activity.GetActivityStartTimestampUtc());
    var _e3 = GetDateFromUtcIso8601Time(this.Activity.GetAttemptStartTimestampUtc());
    this.Activity.SetActivityAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate - _e2) / 10));
    this.Activity.SetAttemptAbsoluteDuration(ConvertHundredthsToIso8601TimeSpan((this.TrackedEndDate - _e3) / 10));
    var _e4 = ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationTracked());
    var _e5 = null;
    if ((_e4 + _dd) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`970`");
        _e5 = ConvertHundredthsToIso8601TimeSpan(_e4 + _dd);
    } else {
        _e5 = ConvertHundredthsToIso8601TimeSpan(_e4 + _dd - this.TrackedSessionTimePrevCall);
    }
    this.Activity.SetActivityExperiencedDurationTracked(_e5);
    var _e6 = ConvertIso8601TimeSpanToHundredths(this.Activity.GetActivityExperiencedDurationReported());
    var _e7 = ConvertIso8601TimeSpanToHundredths(this.RunTimeData.TotalTime) - ConvertIso8601TimeSpanToHundredths(this.StartSessionTotalTime);
    var _e8 = null;
    if ((_e6 + _e7) < this.SessionTotalTimeReportedPrevCall) {
        this.WriteDetailedLog("`956`");
        _e8 = ConvertHundredthsToIso8601TimeSpan(_e6 + _e7);
    } else {
        _e8 = ConvertHundredthsToIso8601TimeSpan(_e6 + _e7 - this.SessionTotalTimeReportedPrevCall);
    }
    this.Activity.SetActivityExperiencedDurationReported(_e8);
    var _e9 = ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationTracked());
    var _ea = null;
    if ((_e9 + _dd) < this.TrackedSessionTimePrevCall) {
        this.WriteDetailedLog("`983`");
        _ea = ConvertHundredthsToIso8601TimeSpan(_e9 + _dd);
    } else {
        _ea = ConvertHundredthsToIso8601TimeSpan(_e9 + _dd - this.TrackedSessionTimePrevCall);
    }
    this.Activity.SetAttemptExperiencedDurationTracked(_ea);
    var _eb = ConvertIso8601TimeSpanToHundredths(this.Activity.GetAttemptExperiencedDurationReported());
    var _ec = null;
    if ((_eb + _e7) < this.SessionTotalTimeReportedPrevCall) {
        this.WriteDetailedLog("`971`");
        attemptReportedTimeSpan = ConvertHundredthsToIso8601TimeSpan(_eb + _e7);
    } else {
        attemptReportedTimeSpan = ConvertHundredthsToIso8601TimeSpan(_eb + _e7 - this.SessionTotalTimeReportedPrevCall);
    }
    this.Activity.SetAttemptExperiencedDurationReported(attemptReportedTimeSpan);
    this.TrackedSessionTimePrevCall = _dd;
    this.SessionTotalTimeReportedPrevCall = _e7;
}

function RunTimeApi_SetLookAheadDirtyDataFlagIfNeeded(_ed, _ee) {
    if (this.IsLookAheadSequencerDataDirty == false && _ed != _ee) {
        this.IsLookAheadSequencerDataDirty = true;
    }
}

function RunTimeApi_RunLookAheadSequencerIfNeeded(_ef) {
    if ((Control.Package.Properties.LookaheadSequencerMode != LOOKAHEAD_SEQUENCER_MODE_REALTIME && _ef !== true) || Control.Package.Properties.LookaheadSequencerMode == LOOKAHEAD_SEQUENCER_MODE_DISABLE) {
        return;
    }
    if (this.RunTimeData != null) {
        this.LookAheadSessionClose();
    }
    if (this.IsLookAheadSequencerDataDirty === true && !this.IsLookAheadSequencerRunning) {
        this.IsLookAheadSequencerDataDirty = false;
        this.IsLookAheadSequencerRunning = true;
        window.setTimeout("Control.EvaluatePossibleNavigationRequests(true);", 150);
    }
}
var TERMINATION_REQUEST_EXIT = "EXIT";
var TERMINATION_REQUEST_EXIT_ALL = "EXIT ALL";
var TERMINATION_REQUEST_SUSPEND_ALL = "SUSPEND ALL";
var TERMINATION_REQUEST_ABANDON = "ABANDON";
var TERMINATION_REQUEST_ABANDON_ALL = "ABANDON ALL";
var TERMINATION_REQUEST_EXIT_PARENT = "EXIT PARENT";
var TERMINATION_REQUEST_NOT_VALID = "INVALID";
var SEQUENCING_REQUEST_START = "START";
var SEQUENCING_REQUEST_RESUME_ALL = "RESUME ALL";
var SEQUENCING_REQUEST_CONTINUE = "CONTINUE";
var SEQUENCING_REQUEST_PREVIOUS = "PREVIOUS";
var SEQUENCING_REQUEST_CHOICE = "CHOICE";
var SEQUENCING_REQUEST_RETRY = "RETRY";
var SEQUENCING_REQUEST_EXIT = "EXIT";
var SEQUENCING_REQUEST_NOT_VALID = "INVALID";
var SEQUENCING_REQUEST_JUMP = "JUMP";
var RULE_SET_POST_CONDITION = "POST_CONDITION";
var RULE_SET_EXIT = "EXIT";
var RULE_SET_HIDE_FROM_CHOICE = "HIDE_FROM_CHOICE";
var RULE_SET_STOP_FORWARD_TRAVERSAL = "STOP_FORWARD_TRAVERSAL";
var RULE_SET_DISABLED = "DISABLED";
var RULE_SET_SKIPPED = "SKIPPED";
var RULE_SET_SATISFIED = "SATISFIED";
var RULE_SET_NOT_SATISFIED = "NOT_SATISFIED";
var RULE_SET_COMPLETED = "COMPLETED";
var RULE_SET_INCOMPLETE = "INCOMPLETE";
var SEQUENCING_RULE_ACTION_SKIP = "Skip";
var SEQUENCING_RULE_ACTION_DISABLED = "Disabled";
var SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE = "Hidden From Choice";
var SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL = "Stop Forward Traversal";
var SEQUENCING_RULE_ACTION_EXIT = "Exit";
var SEQUENCING_RULE_ACTION_EXIT_PARENT = "Exit Parent";
var SEQUENCING_RULE_ACTION_EXIT_ALL = "Exit All";
var SEQUENCING_RULE_ACTION_RETRY = "Retry";
var SEQUENCING_RULE_ACTION_RETRY_ALL = "Retry All";
var SEQUENCING_RULE_ACTION_CONTINUE = "Continue";
var SEQUENCING_RULE_ACTION_PREVIOUS = "Previous";
var FLOW_DIRECTION_FORWARD = "FORWARD";
var FLOW_DIRECTION_BACKWARD = "BACKWARD";
var RULE_CONDITION_OPERATOR_NOT = "Not";
var RULE_CONDITION_OPERATOR_NOOP = "No Op";
var RULE_CONDITION_COMBINATION_ALL = "All";
var RULE_CONDITION_COMBINATION_ANY = "Any";
var RESULT_UNKNOWN = "unknown";
var SEQUENCING_RULE_CONDITION_SATISFIED = "Satisfied";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN = "Objective Status Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN = "Objective Measure Known";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN = "Objective Measure Greater Than";
var SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN = "Objective Measure Less Than";
var SEQUENCING_RULE_CONDITION_COMPLETED = "Completed";
var SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN = "Activity Progress Known";
var SEQUENCING_RULE_CONDITION_ATTEMPTED = "Attempted";
var SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED = "Attempt Limit Exceeded";
var SEQUENCING_RULE_CONDITION_ALWAYS = "Always";
var ROLLUP_RULE_ACTION_SATISFIED = "Satisfied";
var ROLLUP_RULE_ACTION_NOT_SATISFIED = "Not Satisfied";
var ROLLUP_RULE_ACTION_COMPLETED = "Completed";
var ROLLUP_RULE_ACTION_INCOMPLETE = "Incomplete";
var ROLLUP_RULE_MINIMUM_COUNT_DEFAULT = 0;
var ROLLUP_RULE_MINIMUM_PERCENT_DEFAULT = 0;
var CHILD_ACTIVITY_SET_ALL = "All";
var CHILD_ACTIVITY_SET_ANY = "Any";
var CHILD_ACTIVITY_SET_NONE = "None";
var CHILD_ACTIVITY_SET_AT_LEAST_COUNT = "At Least Count";
var CHILD_ACTIVITY_SET_AT_LEAST_PERCENT = "At Least Percent";
var ROLLUP_RULE_CONDITION_SATISFIED = "Satisfied";
var ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN = "Objective Status Known";
var ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN = "Objective Measure Known";
var ROLLUP_RULE_CONDITION_COMPLETED = "Completed";
var ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN = "Activity Progress Known";
var ROLLUP_RULE_CONDITION_ATTEMPTED = "Attempted";
var ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED = "Attempt Limit Exceeded";
var ROLLUP_RULE_CONDITION_NEVER = "Never";
var ROLLUP_CONSIDERATION_ALWAYS = "Always";
var ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED = "If Not Suspended";
var ROLLUP_CONSIDERATION_IF_ATTEMPTED = "If Attempted";
var ROLLUP_CONSIDERATION_IF_NOT_SKIPPED = "If Not Skipped";
var TIMING_NEVER = "Never";
var TIMING_ONCE = "Once";
var TIMING_ON_EACH_NEW_ATTEMPT = "On Each New Attempt";
var CONTROL_CHOICE_EXIT_ERROR_NAV = "NB.2.1-8";
var CONTROL_CHOICE_EXIT_ERROR_CHOICE = "SB.2.9-7";
var PREVENT_ACTIVATION_ERROR = "SB.2.9-6";
var CONSTRAINED_CHOICE_ERROR = "SB.2.9-8";

function Sequencer(_f0, _f1) {
    this.LookAhead = _f0;
    this.Activities = _f1;
    this.NavigationRequest = null;
    this.ChoiceTargetIdentifier = null;
    this.SuspendedActivity = null;
    this.CurrentActivity = null;
    this.Exception = null;
    this.ExceptionText = null;
    this.GlobalObjectives = new Array();
    this.SharedData = new Array();
    this.ReturnToLmsInvoked = false;
}
Sequencer.prototype.OverallSequencingProcess = Sequencer_OverallSequencingProcess;
Sequencer.prototype.SetSuspendedActivity = Sequencer_SetSuspendedActivity;
Sequencer.prototype.GetSuspendedActivity = Sequencer_GetSuspendedActivity;
Sequencer.prototype.Start = Sequencer_Start;
Sequencer.prototype.InitialRandomizationAndSelection = Sequencer_InitialRandomizationAndSelection;
Sequencer.prototype.GetCurrentActivity = Sequencer_GetCurrentActivity;
Sequencer.prototype.GetExceptionText = Sequencer_GetExceptionText;
Sequencer.prototype.GetExitAction = Sequencer_GetExitAction;
Sequencer.prototype.EvaluatePossibleNavigationRequests = Sequencer_EvaluatePossibleNavigationRequests;
Sequencer.prototype.InitializePossibleNavigationRequestAbsolutes = Sequencer_InitializePossibleNavigationRequestAbsolutes;
Sequencer.prototype.SetAllDescendentsToDisabled = Sequencer_SetAllDescendentsToDisabled;
Sequencer.prototype.SetAllDescendentsToNotSucceed = Sequencer_SetAllDescendentsToNotSucceed;
Sequencer.prototype.SetAllDescendentsToSkipped = Sequencer_SetAllDescendentsToSkipped;
Sequencer.prototype.ContentDeliveryEnvironmentActivityDataSubProcess = Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess;

function Sequencer_SetSuspendedActivity(_f2, _f3) {
    if (_f3 !== null && _f3 !== undefined) {
        this.LogSeqSimple("Setting Suspended Activity to \"" + _f2 + "\".", _f3);
    }
    this.SuspendedActivity = _f2;
}

function Sequencer_GetSuspendedActivity(_f4) {
    var _f5 = this.SuspendedActivity;
    if (_f4 !== null && _f4 !== undefined) {
        this.LogSeq("`1578`" + _f5, _f4);
    }
    return _f5;
}

function Sequencer_Start() {
    if (this.SuspendedActivity === null) {
        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_START, null, "");
    } else {
        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_RESUME_ALL, null, "");
    }
    this.OverallSequencingProcess();
}

function Sequencer_InitialRandomizationAndSelection() {
    var _f6 = this.LogSeqAudit("`1321`");
    var _f7 = false;
    var _f8;
    if (this.SuspendedActivity === null) {
        for (var _f9 in this.Activities.ActivityList) {
            var _fa = this.Activities.ActivityList[_f9];
            if (_fa.GetRandomizationTiming() != TIMING_NEVER || _fa.GetSelectionTiming() != TIMING_NEVER) {
                if (_f7 === false) {
                    _f8 = this.LogSeqSimpleAudit("Initial selection and randomization of activities.");
                }
                this.SelectChildrenProcess(_fa, _f6, _f8);
                this.RandomizeChildrenProcess(_fa, false, _f6, _f8);
            }
        }
    }
}

function Sequencer_GetCurrentActivity() {
    return this.CurrentActivity;
}

function Sequencer_GetExceptionText() {
    if (this.ExceptionText !== null && this.ExceptionText !== undefined) {
        return this.ExceptionText;
    } else {
        return "";
    }
}

function Sequencer_GetExitAction(_fb, _fc) {
    return EXIT_ACTION_DISPLAY_MESSAGE;
}
Sequencer.prototype.NavigationRequestProcess = Sequencer_NavigationRequestProcess;
Sequencer.prototype.SequencingExitActionRulesSubprocess = Sequencer_SequencingExitActionRulesSubprocess;
Sequencer.prototype.SequencingPostConditionRulesSubprocess = Sequencer_SequencingPostConditionRulesSubprocess;
Sequencer.prototype.TerminationRequestProcess = Sequencer_TerminationRequestProcess;
Sequencer.prototype.MeasureRollupProcess = Sequencer_MeasureRollupProcess;
Sequencer.prototype.CompletionMeasureRollupProcess = Sequencer_CompletionMeasureRollupProcess;
Sequencer.prototype.ObjectiveRollupProcess = Sequencer_ObjectiveRollupProcess;
Sequencer.prototype.ObjectiveRollupUsingMeasureProcess = Sequencer_ObjectiveRollupUsingMeasureProcess;
Sequencer.prototype.ObjectiveRollupUsingRulesProcess = Sequencer_ObjectiveRollupUsingRulesProcess;
Sequencer.prototype.ActivityProgressRollupProcess = Sequencer_ActivityProgressRollupProcess;
Sequencer.prototype.ActivityProgressRollupUsingMeasureProcess = Sequencer_ActivityProgressRollupUsingMeasureProcess;
Sequencer.prototype.ActivityProgressRollupUsingRulesProcess = Sequencer_ActivityProgressRollupUsingRulesProcess;
Sequencer.prototype.RollupRuleCheckSubprocess = Sequencer_RollupRuleCheckSubprocess;
Sequencer.prototype.EvaluateRollupConditionsSubprocess = Sequencer_EvaluateRollupConditionsSubprocess;
Sequencer.prototype.EvaluateRollupRuleCondition = Sequencer_EvaluateRollupRuleCondition;
Sequencer.prototype.CheckChildForRollupSubprocess = Sequencer_CheckChildForRollupSubprocess;
Sequencer.prototype.OverallRollupProcess = Sequencer_OverallRollupProcess;
Sequencer.prototype.SelectChildrenProcess = Sequencer_SelectChildrenProcess;
Sequencer.prototype.RandomizeChildrenProcess = Sequencer_RandomizeChildrenProcess;
Sequencer.prototype.FlowTreeTraversalSubprocess = Sequencer_FlowTreeTraversalSubprocess;
Sequencer.prototype.FlowActivityTraversalSubprocess = Sequencer_FlowActivityTraversalSubprocess;
Sequencer.prototype.FlowSubprocess = Sequencer_FlowSubprocess;
Sequencer.prototype.JumpSequencingRequestProcess = Sequencer_JumpSequencingRequestProcess;
Sequencer.prototype.ChoiceActivityTraversalSubprocess = Sequencer_ChoiceActivityTraversalSubprocess;
Sequencer.prototype.StartSequencingRequestProcess = Sequencer_StartSequencingRequestProcess;
Sequencer.prototype.ResumeAllSequencingRequestProcess = Sequencer_ResumeAllSequencingRequestProcess;
Sequencer.prototype.ContinueSequencingRequestProcess = Sequencer_ContinueSequencingRequestProcess;
Sequencer.prototype.PreviousSequencingRequestProcess = Sequencer_PreviousSequencingRequestProcess;
Sequencer.prototype.ChoiceSequencingRequestProcess = Sequencer_ChoiceSequencingRequestProcess;
Sequencer.prototype.ChoiceFlowSubprocess = Sequencer_ChoiceFlowSubprocess;
Sequencer.prototype.ChoiceFlowTreeTraversalSubprocess = Sequencer_ChoiceFlowTreeTraversalSubprocess;
Sequencer.prototype.RetrySequencingRequestProcess = Sequencer_RetrySequencingRequestProcess;
Sequencer.prototype.ExitSequencingRequestProcess = Sequencer_ExitSequencingRequestProcess;
Sequencer.prototype.SequencingRequestProcess = Sequencer_SequencingRequestProcess;
Sequencer.prototype.DeliveryRequestProcess = Sequencer_DeliveryRequestProcess;
Sequencer.prototype.ContentDeliveryEnvironmentProcess = Sequencer_ContentDeliveryEnvironmentProcess;
Sequencer.prototype.ClearSuspendedActivitySubprocess = Sequencer_ClearSuspendedActivitySubprocess;
Sequencer.prototype.LimitConditionsCheckProcess = Sequencer_LimitConditionsCheckProcess;
Sequencer.prototype.SequencingRulesCheckProcess = Sequencer_SequencingRulesCheckProcess;
Sequencer.prototype.SequencingRulesCheckSubprocess = Sequencer_SequencingRulesCheckSubprocess;
Sequencer.prototype.TerminateDescendentAttemptsProcess = Sequencer_TerminateDescendentAttemptsProcess;
Sequencer.prototype.EndAttemptProcess = Sequencer_EndAttemptProcess;
Sequencer.prototype.CheckActivityProcess = Sequencer_CheckActivityProcess;
Sequencer.prototype.EvaluateSequencingRuleCondition = Sequencer_EvaluateSequencingRuleCondition;
Sequencer.prototype.ResetException = Sequencer_ResetException;
Sequencer.prototype.LogSeq = Sequencer_LogSeq;
Sequencer.prototype.LogSeqAudit = Sequencer_LogSeqAudit;
Sequencer.prototype.LogSeqReturn = Sequencer_LogSeqReturn;
Sequencer.prototype.WriteHistoryLog = Sequencer_WriteHistoryLog;
Sequencer.prototype.WriteHistoryReturnValue = Sequencer_WriteHistoryReturnValue;
Sequencer.prototype.LogSeqSimple = Sequencer_LogSeqSimple;
Sequencer.prototype.LogSeqSimpleAudit = Sequencer_LogSeqSimpleAudit;
Sequencer.prototype.LogSeqSimpleReturn = Sequencer_LogSeqSimpleReturn;
Sequencer.prototype.SetCurrentActivity = Sequencer_SetCurrentActivity;
Sequencer.prototype.IsCurrentActivityDefined = Sequencer_IsCurrentActivityDefined;
Sequencer.prototype.IsSuspendedActivityDefined = Sequencer_IsSuspendedActivityDefined;
Sequencer.prototype.ClearSuspendedActivity = Sequencer_ClearSuspendedActivity;
Sequencer.prototype.GetRootActivity = Sequencer_GetRootActivity;
Sequencer.prototype.DoesActivityExist = Sequencer_DoesActivityExist;
Sequencer.prototype.GetActivityFromIdentifier = Sequencer_GetActivityFromIdentifier;
Sequencer.prototype.AreActivitiesSiblings = Sequencer_AreActivitiesSiblings;
Sequencer.prototype.FindCommonAncestor = Sequencer_FindCommonAncestor;
Sequencer.prototype.GetActivityPath = Sequencer_GetActivityPath;
Sequencer.prototype.GetPathToAncestorExclusive = Sequencer_GetPathToAncestorExclusive;
Sequencer.prototype.GetPathToAncestorInclusive = Sequencer_GetPathToAncestorInclusive;
Sequencer.prototype.ActivityHasSuspendedChildren = Sequencer_ActivityHasSuspendedChildren;
Sequencer.prototype.CourseIsSingleSco = Sequencer_CourseIsSingleSco;
Sequencer.prototype.TranslateSequencingRuleActionIntoSequencingRequest = Sequencer_TranslateSequencingRuleActionIntoSequencingRequest;
Sequencer.prototype.TranslateSequencingRuleActionIntoTerminationRequest = Sequencer_TranslateSequencingRuleActionIntoTerminationRequest;
Sequencer.prototype.IsActivity1BeforeActivity2 = Sequencer_IsActivity1BeforeActivity2;
Sequencer.prototype.GetOrderedListOfActivities = Sequencer_GetOrderedListOfActivities;
Sequencer.prototype.PreOrderTraversal = Sequencer_PreOrderTraversal;
Sequencer.prototype.PostOrderTraversal = Sequencer_PostOrderTraversal;
Sequencer.prototype.IsActivityLastOverall = Sequencer_IsActivityLastOverall;
Sequencer.prototype.GetGlobalObjectiveByIdentifier = Sequencer_GetGlobalObjectiveByIdentifier;
Sequencer.prototype.AddGlobalObjective = Sequencer_AddGlobalObjective;
Sequencer.prototype.ResetGlobalObjectives = Sequencer_ResetGlobalObjectives;
Sequencer.prototype.ResetSharedData = Sequencer_ResetSharedData;
Sequencer.prototype.FindActivitiesAffectedByWriteMaps = Sequencer_FindActivitiesAffectedByWriteMaps;
Sequencer.prototype.FindDistinctParentsOfActivitySet = Sequencer_FindDistinctParentsOfActivitySet;
Sequencer.prototype.FindDistinctAncestorsOfActivitySet = Sequencer_FindDistinctAncestorsOfActivitySet;
Sequencer.prototype.GetMinimalSubsetOfActivitiesToRollup = Sequencer_GetMinimalSubsetOfActivitiesToRollup;
Sequencer.prototype.CheckForRelevantSequencingRules = Sequencer_CheckForRelevantSequencingRules;
Sequencer.prototype.DoesThisActivityHaveSequencingRulesRelevantToChoice = Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice;
Sequencer.prototype.GetArrayOfDescendents = Sequencer_GetArrayOfDescendents;
Sequencer.prototype.IsActivity1AParentOfActivity2 = Sequencer_IsActivity1AParentOfActivity2;

function Sequencer_ResetException() {
    this.Exception = null;
    this.ExceptionText = null;
}

function Sequencer_LogSeq(str, _fe) {
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteLookAheadDetailed(str, _fe);
    } else {
        return Debug.WriteSequencingDetailed(str, _fe);
    }
}

function Sequencer_LogSeqAudit(str, _100) {
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteLookAheadAudit(str, _100);
    } else {
        return Debug.WriteSequencingAudit(str, _100);
    }
}

function Sequencer_LogSeqReturn(str, _102) {
    if (_102 === null || _102 === undefined) {
        Debug.AssertError("`1564`");
    }
    str = str + "";
    if (this.LookAhead === true) {
        return _102.setReturn(str);
    } else {
        return _102.setReturn(str);
    }
}

function Sequencer_LogSeqSimple(str, _104) {
    if (_104 === null || _104 === undefined) {
        Debug.AssertError("failed to pass logEntry");
    }
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteSequencingSimpleDetailed(str, _104);
    } else {
        return Debug.WriteSequencingSimpleDetailed(str, _104);
    }
}

function Sequencer_LogSeqSimpleAudit(str, _106) {
    str = str + "";
    if (this.LookAhead === true) {
        return Debug.WriteSequencingSimpleAudit(str, _106);
    } else {
        return Debug.WriteSequencingSimpleAudit(str, _106);
    }
}

function Sequencer_LogSeqSimpleReturn(str, _108) {
    if (_108 === null || _108 === undefined) {
        Debug.AssertError("failed to pass logEntry");
    }
    str = str + "";
    if (this.LookAhead === true) {
        return _108.setReturn(str);
    } else {
        return _108.setReturn(str);
    }
}

function Sequencer_WriteSequencingSimple(str) {
    str = str + "";
    return Debug.WriteSequencingSimple(str);
}

function Sequencer_WriteHistoryLog(str, atts) {
    HistoryLog.WriteEventDetailed(str, atts);
}

function Sequencer_WriteHistoryReturnValue(str, atts) {
    HistoryLog.WriteEventDetailedReturnValue(str, atts);
}

function Sequencer_SetCurrentActivity(_10e, _10f, _110) {
    Debug.AssertError("Parent log not passed.", (_10f === undefined || _10f === null));
    this.LogSeq("`1456`" + _10e, _10f);
    this.LogSeqSimple("Setting Current Activity to \"" + _10e + "\".", _110);
    this.CurrentActivity = _10e;
}

function Sequencer_IsCurrentActivityDefined(_111) {
    Debug.AssertError("Parent log not passed.", (_111 === undefined || _111 === null));
    var _112 = this.GetCurrentActivity();
    var _113 = (_112 !== null);
    if (_113) {
        this.LogSeq("`1470`", _111);
    } else {
        this.LogSeq("`1388`", _111);
    }
    return _113;
}

function Sequencer_IsSuspendedActivityDefined(_114) {
    Debug.AssertError("Parent log not passed.", (_114 === undefined || _114 === null));
    var _115 = this.GetSuspendedActivity(_114);
    var _116 = (_115 !== null);
    if (_116) {
        this.LogSeq("`1436`", _114);
    } else {
        this.LogSeq("`1363`", _114);
    }
    return _116;
}

function Sequencer_ClearSuspendedActivity(_117) {
    Debug.AssertError("Parent log not passed.", (_117 === undefined || _117 === null));
    this.LogSeq("`1464`", _117);
    this.SuspendedActivity = null;
}

function Sequencer_GetRootActivity(_118) {
    Debug.AssertError("Parent log not passed.", (_118 === undefined || _118 === null));
    var _119 = this.Activities.GetRootActivity();
    return _119;
}

function Sequencer_DoesActivityExist(_11a, _11b) {
    Debug.AssertError("Parent log not passed.", (_11b === undefined || _11b === null));
    var _11c = this.Activities.DoesActivityExist(_11a, _11b);
    if (_11c) {
        this.LogSeq("`1702`" + _11a + "`1399`", _11b);
    } else {
        this.LogSeq("`1702`" + _11a + "`1261`", _11b);
    }
    return _11c;
}

function Sequencer_GetActivityFromIdentifier(_11d, _11e) {
    Debug.AssertError("Parent log not passed.", (_11e === undefined || _11e === null));
    var _11f = this.Activities.GetActivityFromIdentifier(_11d, _11e);
    return _11f;
}

function Sequencer_AreActivitiesSiblings(_120, _121, _122) {
    Debug.AssertError("Parent log not passed.", (_122 === undefined || _122 === null));
    if (_120 === null || _120 === undefined || _121 === null || _121 === undefined) {
        return false;
    }
    var _123 = _120.ParentActivity;
    var _124 = _121.ParentActivity;
    var _125 = (_123 == _124);
    if (_125) {
        this.LogSeq("`1714`" + _120 + "`1758`" + _121 + "`1724`", _122);
    } else {
        this.LogSeq("`1714`" + _120 + "`1758`" + _121 + "`1645`", _122);
    }
    return _125;
}

function Sequencer_FindCommonAncestor(_126, _127, _128) {
    Debug.AssertError("Parent log not passed.", (_128 === undefined || _128 === null));
    var _129 = new Array();
    var _12a = new Array();
    if (_126 !== null && _126.IsTheRoot()) {
        this.LogSeq(_126 + "`942`" + _126 + "`1758`" + _127 + "`1760`" + _126, _128);
        return _126;
    }
    if (_127 !== null && _127.IsTheRoot()) {
        this.LogSeq(_127 + "`942`" + _126 + "`1758`" + _127 + "`1760`" + _127, _128);
        return _127;
    }
    if (_126 !== null) {
        _129 = this.Activities.GetActivityPath(_126, false);
    }
    if (_127 !== null) {
        _12a = this.Activities.GetActivityPath(_127, false);
    }
    for (var i = 0; i < _129.length; i++) {
        for (var j = 0; j < _12a.length; j++) {
            if (_129[i] == _12a[j]) {
                this.LogSeq("`1346`" + _126 + "`1758`" + _127 + "`1760`" + _129[i], _128);
                return _129[i];
            }
        }
    }
    this.LogSeq("`1739`" + _126 + "`1758`" + _127 + "`1398`", _128);
    return null;
}

function Sequencer_GetActivityPath(_12d, _12e) {
    return this.Activities.GetActivityPath(_12d, _12e);
}

function Sequencer_GetPathToAncestorExclusive(_12f, _130, _131) {
    var _132 = new Array();
    var _133 = 0;
    if (_12f !== null && _130 !== null && _12f !== _130) {
        if (_131 === true) {
            _132[_133] = _12f;
            _133++;
        }
        while (_12f.ParentActivity !== null && _12f.ParentActivity !== _130) {
            _12f = _12f.ParentActivity;
            _132[_133] = _12f;
            _133++;
        }
    }
    return _132;
}

function Sequencer_GetPathToAncestorInclusive(_134, _135, _136) {
    var _137 = new Array();
    var _138 = 0;
    if (_136 == null || _136 == undefined) {
        _136 === true;
    }
    _137[_138] = _134;
    _138++;
    while (_134.ParentActivity !== null && _134 != _135) {
        _134 = _134.ParentActivity;
        _137[_138] = _134;
        _138++;
    }
    if (_136 === false) {
        _137.splice(0, 1);
    }
    return _137;
}

function Sequencer_ActivityHasSuspendedChildren(_139, _13a) {
    Debug.AssertError("Parent log not passed.", (_13a === undefined || _13a === null));
    var _13b = _139.GetChildren();
    var _13c = false;
    for (var i = 0; i < _13b.length; i++) {
        if (_13b[i].IsSuspended()) {
            _13c = true;
        }
    }
    if (_13c) {
        this.LogSeq("`1732`" + _139 + "`1521`", _13a);
    } else {
        this.LogSeq("`1732`" + _139 + "`1327`", _13a);
    }
    return _13c;
}

function Sequencer_CourseIsSingleSco() {
    if (this.Activities.ActivityList.length <= 2) {
        return true;
    } else {
        return false;
    }
}

function Sequencer_TranslateSequencingRuleActionIntoSequencingRequest(_13e) {
    switch (_13e) {
        case SEQUENCING_RULE_ACTION_RETRY:
            return SEQUENCING_REQUEST_RETRY;
        case SEQUENCING_RULE_ACTION_CONTINUE:
            return SEQUENCING_REQUEST_CONTINUE;
        case SEQUENCING_RULE_ACTION_PREVIOUS:
            return SEQUENCING_REQUEST_PREVIOUS;
        default:
            Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoSequencingRequest - should never have an untranslatable sequencing request. ruleAction=" + _13e);
            return null;
    }
}

function Sequencer_TranslateSequencingRuleActionIntoTerminationRequest(_13f) {
    switch (_13f) {
        case SEQUENCING_RULE_ACTION_EXIT_PARENT:
            return TERMINATION_REQUEST_EXIT_PARENT;
        case SEQUENCING_RULE_ACTION_EXIT_ALL:
            return TERMINATION_REQUEST_EXIT_ALL;
        default:
            Debug.AssertError("ERROR in TranslateSequencingRuleActionIntoTerminationRequest - should never have an untranslatable sequencing request. ruleAction=" + _13f);
            return null;
    }
}

function Sequencer_IsActivity1BeforeActivity2(_140, _141, _142) {
    Debug.AssertError("Parent log not passed.", (_142 === undefined || _142 === null));
    var _143 = this.GetOrderedListOfActivities(false, _142);
    for (var i = 0; i < _143.length; i++) {
        if (_143[i] == _140) {
            this.LogSeq("`1732`" + _140 + "`1522`" + _141, _142);
            return true;
        }
        if (_143[i] == _141) {
            this.LogSeq("`1732`" + _140 + "`1545`" + _141, _142);
            return false;
        }
    }
    Debug.AssertError("ERROR IN Sequencer_IsActivity1BeforeActivity2");
    return null;
}

function Sequencer_GetOrderedListOfActivities(_145, _146) {
    Debug.AssertError("Parent log not passed.", (_146 === undefined || _146 === null));
    Debug.AssertError("Traversal Direction Not Passed.", (_145 === undefined || _145 === null));
    var list;
    var root = this.GetRootActivity(_146);
    if (_145 === false) {
        list = this.PreOrderTraversal(root);
    } else {
        list = this.PostOrderTraversal(root);
    }
    return list;
}

function Sequencer_PreOrderTraversal(_149) {
    var list = new Array();
    list[0] = _149;
    var _14b = _149.GetAvailableChildren();
    var _14c;
    for (var i = 0; i < _14b.length; i++) {
        _14c = this.PreOrderTraversal(_14b[i]);
        list = list.concat(_14c);
    }
    return list;
}

function Sequencer_PostOrderTraversal(_14e) {
    var list = new Array();
    var _150 = _14e.GetAvailableChildren();
    var _151;
    for (var i = 0; i < _150.length; i++) {
        _151 = this.PostOrderTraversal(_150[i]);
        list = list.concat(_151);
    }
    list = list.concat(_14e);
    return list;
}

function Sequencer_IsActivityLastOverall(_153, _154) {
    Debug.AssertError("Parent log not passed.", (_154 === undefined || _154 === null));
    var _155 = this.GetOrderedListOfActivities(false, _154);
    var _156 = null;
    for (var i = (_155.length - 1); i >= 0; i--) {
        if (_155[i].IsAvailable()) {
            _156 = _155[i];
            i = -1;
        }
    }
    if (_153 == _156) {
        this.LogSeq("`1732`" + _153 + "`1419`", _154);
        return true;
    }
    this.LogSeq("`1732`" + _153 + "`1353`", _154);
    return false;
}

function Sequencer_GetGlobalObjectiveByIdentifier(_158) {
    for (var obj in this.GlobalObjectives) {
        if (this.GlobalObjectives[obj].ID == _158) {
            return this.GlobalObjectives[obj];
        }
    }
    return null;
}

function Sequencer_AddGlobalObjective(ID, _15b, _15c, _15d, _15e) {
    var _15f = this.GlobalObjectives.length;
    var obj = new GlobalObjective(_15f, ID, _15b, _15c, _15d, _15e);
    this.GlobalObjectives[_15f] = obj;
    this.GlobalObjectives[_15f].SetDirtyData();
}

function Sequencer_ResetGlobalObjectives() {
    var _161;
    for (var obj in this.GlobalObjectives) {
        _161 = this.GlobalObjectives[obj];
        _161.ResetState();
    }
}

function Sequencer_ResetSharedData() {
    var sd;
    for (var _164 in this.SharedData) {
        sd = this.SharedData[_164];
        sd.WriteData("");
    }
}

function Sequencer_FindActivitiesAffectedByWriteMaps(_165) {
    var _166 = new Array();
    var _167;
    var _168 = _165.GetObjectives();
    var _169 = new Array();
    var i;
    var j;
    for (i = 0; i < _168.length; i++) {
        _167 = _168[i].GetMaps();
        for (j = 0; j < _167.length; j++) {
            if (_167[j].WriteSatisfiedStatus === true || _167[j].WriteNormalizedMeasure === true || _167[j].WriteCompletionStatus === true || _167[j].WriteProgressMeasure === true) {
                _166[_166.length] = _167[j].TargetObjectiveId;
            }
        }
    }
    if (_166.length === 0) {
        return _169;
    }
    var _16c;
    var _16d;
    var _16e;
    var _16f;
    for (var _170 in this.Activities.ActivityList) {
        _16c = this.Activities.ActivityList[_170];
        if (_16c != _165) {
            _16d = _16c.GetObjectives();
            for (var _171 = 0; _171 < _16d.length; _171++) {
                _16e = _16d[_171].GetMaps();
                for (var map = 0; map < _16e.length; map++) {
                    if (_16e[map].ReadSatisfiedStatus === true || _16e[map].ReadNormalizedMeasure === true || _16e[map].ReadCompletionStatus === true || _16e[map].ReadProgressMeasure === true) {
                        _16f = _16e[map].TargetObjectiveId;
                        for (var _173 = 0; _173 < _166.length; _173++) {
                            if (_166[_173] == _16f) {
                                _169[_169.length] = _16c;
                            }
                        }
                    }
                }
            }
        }
    }
    return _169;
}

function Sequencer_FindDistinctAncestorsOfActivitySet(_174) {
    var _175 = new Array();
    for (var _176 = 0; _176 < _174.length; _176++) {
        var _177 = _174[_176];
        if (_177 !== null) {
            var _178 = this.GetActivityPath(_177, true);
            for (var i = 0; i < _178.length; i++) {
                var _17a = true;
                for (var j = 0; j < _175.length; j++) {
                    if (_178[i] == _175[j]) {
                        _17a = false;
                        break;
                    }
                }
                if (_17a) {
                    _175[_175.length] = _178[i];
                }
            }
        }
    }
    return _175;
}

function Sequencer_FindDistinctParentsOfActivitySet(_17c) {
    var _17d = new Array();
    var _17e;
    var _17f;
    for (var _180 in _17c) {
        _17f = true;
        _17e = this.Activities.GetParentActivity(_17c[_180]);
        if (_17e !== null) {
            for (var i = 0; i < _17d.length; i++) {
                if (_17d[i] == _17e) {
                    _17f = false;
                    break;
                }
            }
            if (_17f) {
                _17d[_17d.length] = _17e;
            }
        }
    }
    return _17d;
}

function Sequencer_GetMinimalSubsetOfActivitiesToRollup(_182, _183) {
    var _184 = new Array();
    var _185 = new Array();
    var _186;
    var _187;
    var _188;
    if (_183 !== null) {
        _184 = _184.concat(_183);
    }
    for (var _189 in _182) {
        _187 = _182[_189];
        _188 = false;
        for (var _18a in _184) {
            if (_184[_18a] == _187) {
                _188 = true;
                break;
            }
        }
        if (_188 === false) {
            _185[_185.length] = _187;
            _186 = this.GetActivityPath(_187, true);
            _184 = _184.concat(_186);
        }
    }
    return _185;
}

function Sequencer_EvaluatePossibleNavigationRequests(_18b) {
    var _18c = this.LogSeqAudit("`991`");
    var _18d;
    var _18e = null;
    var _18f;
    var _190;
    var id;
    var i;
    var j;
    var _194;
    var _195;
    var _196 = this.LogSeqSimpleAudit("Start of simple logs in lookahead sequencer.", _196);
    if (Control.Package.Properties.UseQuickLookaheadSequencer === true) {
        var _197 = false;
        this.LogSeq("`1030`", _18c);
        this.LogSeq("`992`", _18c);
        for (id in _18b) {
            _18b[id].ResetForNewEvaluation();
        }
        var _198 = this.GetOrderedListOfActivities(false, _18c);
        var _199 = this.GetOrderedListOfActivities(true, _18c);
        var _19a;
        var _19b = new Array();
        for (i = 0; i < _198.length; i++) {
            if (_198[i].IsActive() === true) {
                _19b[_198[i].GetItemIdentifier()] = true;
            }
        }
        _195 = this.GetCurrentActivity();
        this.LogSeq("`1397`" + _195, _18c);
        var _19c = null;
        if (_195 !== null) {
            _19c = _195.ParentActivity;
        }
        if (_195 !== null && _195.IsActive() === true) {
            this.LogSeq("`521`", _18c);
            _18e = this.TerminationRequestProcess(TERMINATION_REQUEST_EXIT, _18c, _196);
        }
        var _19d = this.LogSeqAudit("`390`", _18c);
        for (i = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; i < _18b.length; i++) {
            _194 = _18b[i];
            _194.TargetActivity = this.GetActivityFromIdentifier(_194.TargetActivityItemIdentifier, _18c);
            var _19e = _194.TargetActivity;
            var _19f = _19e.ParentActivity;
            var _1a0 = this.LogSeqAudit("`1756`" + _19e, _19d);
            if (_19f !== null && _19f.GetSequencingControlChoice() === false) {
                this.LogSeq("`1756`" + _19e + "`797`" + _19f + "`1227`", _1a0);
                _194.WillSucceed = false;
                _194.ControlChoiceViolation = true;
                _194.Exception = "NB.2.1-10";
                _194.ExceptionText = IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.", _19f.GetTitle());
            }
            if (_19e.IsALeaf() === false && _19e.GetSequencingControlFlow() === false) {
                this.LogSeq("`1756`" + _19e + "`361`", _1a0);
                _194.WillSucceed = false;
                _194.NoDeliverablieActivityViolation = true;
                _194.Exception = "SB.2.2-1";
                _194.ExceptionText = _19e + " does not allow flow navigation so it's children must be selected explicitly.";
            }
            if (_19e.LearningObject.Visible === false) {
                this.LogSeq("`1756`" + _19e + "`845`", _1a0);
                _194.WillSucceed = true;
                _194.IsVisibleViolation = true;
                _194.Exception = "n/a";
                _194.ExceptionText = _19e + " is set to be invisible to the user.";
            }
            if (this.LimitConditionsCheckProcess(_19e, _1a0, _196) === true) {
                this.LogSeq("`1756`" + _19e + "`597`", _1a0);
                _194.WillSucceed = false;
                _194.LimitConditionViolation = true;
                _194.Exception = "DB.1.1-3";
                _194.ExceptionText = IntegrationImplementation.GetString("{0} has been attempted the maximum allowed number of times.", _19e.GetTitle());
                this.SetAllDescendentsToNotSucceed(_18b, _19e, "LimitConditionViolation", _194.Exception, _194.ExceptionText, _18c);
            }
            this.LogSeq("`790`", _1a0);
            var _1a1 = this.SequencingRulesCheckProcess(_18b[i].TargetActivity, RULE_SET_HIDE_FROM_CHOICE, _1a0, _196);
            if (_1a1 !== null) {
                this.LogSeq("`1195`" + _19e + "`1058`", _1a0);
                _194.WillSucceed = false;
                _194.PreConditionHiddenFromChoice = true;
                _18b[id].Exception = "SB.2.9-3";
                _18b[id].ExceptionText = "The activity " + _19e.GetTitle() + " (and all of its descendents) should be hidden and is not a valid selection";
                this.SetAllDescendentsToNotSucceed(_18b, _19e, "PreConditionHiddenFromChoice", _194.Exception, _194.ExceptionText, _1a0);
            }
            _1a1 = this.SequencingRulesCheckProcess(_18b[i].TargetActivity, RULE_SET_DISABLED, _1a0, _196);
            if (_1a1 !== null) {
                this.LogSeq("`1195`" + _19e + "`1020`", _1a0);
                _194.WillSucceed = false;
                _194.PreConditionDisabled = true;
                _18b[i].Exception = "DB.1.1-3";
                _18b[i].ExceptionText = IntegrationImplementation.GetString("{0} (and all of its descendents) are not valid selections because of sequencing rules in this course.", _19e.GetTitle());
                this.SetAllDescendentsToNotSucceed(_18b, _19e, "PreConditionDisabled", _194.Exception, _194.ExceptionText, _1a0);
            }
            _1a1 = this.SequencingRulesCheckProcess(_18b[i].TargetActivity, RULE_SET_STOP_FORWARD_TRAVERSAL, _1a0, _196);
            if (_1a1 !== null) {
                this.LogSeq("`1413`" + _19e + "`1420`", _1a0);
                _194.PreConditionStopForwardTraversal = true;
                _197 = true;
            }
            _1a1 = this.SequencingRulesCheckProcess(_18b[i].TargetActivity, RULE_SET_SKIPPED, _1a0, _196);
            if (_1a1 !== null) {
                this.LogSeq("`1756`" + _19e + "`1158`", _1a0);
                _194.PreConditionSkipped = true;
                this.SetAllDescendentsToSkipped(_18b, _19e, _19b, _1a0);
            }
        }
        for (i = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; i < _18b.length; i++) {
            _194 = _18b[i];
            _19e = _194.TargetActivity;
            if (_19e.GetPreventActivation() === true) {
                if (_19b[_19e.GetItemIdentifier()] !== true) {
                    this.LogSeq("`1756`" + _19e + "`520`", _18c);
                    this.SetAllDescendentsToNotSucceed(_18b, _19e, "PreventActivationViolation", "SB.2.9-6", _19e + " (and all of its descendents) can not be activated with a choice request.", _18c);
                }
            }
        }
        for (i = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; i < _18b.length; i++) {
            _194 = _18b[i];
            var _1a2 = (_194.PreConditionDisabled === false && _194.PreConditionHiddenFromChoice === false && _194.LimitConditionViolation === false && _194.PreventActivationViolation === false);
            if (_1a2 === true) {
                _19e = _194.TargetActivity;
                var _1a3 = -1;
                for (j = 0; j < _198.length; j++) {
                    if (_198[j] == _19e) {
                        _1a3 = j;
                        break;
                    }
                }
                if (_1a3 === -1) {
                    _194.WillSucceed = false;
                    _194.NoDeliverablieActivityViolation = true;
                    _194.Exception = "NB.2.1-7";
                    _194.ExceptionText = _19e + " was not selected to be delivered in this attempt.";
                    _1a4 = false;
                    _1a2 = false;
                }
            }
            if (_1a2 === true) {
                var _1a5;
                var _1a6;
                var _1a4 = false;
                for (j = _1a3; j < _198.length; j++) {
                    _1a5 = _198[j];
                    _19a = Control.FindPossibleChoiceRequestForActivity(_1a5);
                    if (_19a.PreConditionSkipped === false) {
                        if (_1a5.IsALeaf() === false && _1a5.GetSequencingControlFlow() === false) {
                            this.LogSeq("`1674`" + _19e + "`1484`" + _1a5 + "`1021`", _18c);
                            _194.WillSucceed = false;
                            _194.NoDeliverablieActivityViolation = true;
                            _194.Exception = _19a.Exception;
                            _194.ExceptionText = "Selecting " + _19e + " is not currently allowed. Please select another activity or use the previous/next button to navigate.";
                            _1a4 = false;
                            break;
                        } else {
                            if (_19a.PreConditionDisabled === true) {
                                this.LogSeq("`1674`" + _19e + "`1441`" + _1a5 + "`1400`", _18c);
                                _194.WillSucceed = false;
                                _194.NoDeliverablieActivityViolation = true;
                                _194.Exception = _19a.Exception;
                                _194.ExceptionText = "Selecting " + _19e + " is not currently allowed. Please select another activity or use the previous/next button to navigate.";
                                _1a4 = false;
                                break;
                            } else {
                                if (_19a.LimitConditionViolation === true) {
                                    this.LogSeq("`1674`" + _19e + "`1441`" + _1a5 + "`1022`", _18c);
                                    _194.WillSucceed = false;
                                    _194.NoDeliverablieActivityViolation = true;
                                    _194.Exception = _19a.Exception;
                                    _194.ExceptionText = "Selecting " + _19e + " is not currently allowed. Please select another activity or use the previous/next button to navigate.";
                                    _1a4 = false;
                                    break;
                                } else {
                                    if (_1a5.IsALeaf() === true) {
                                        _1a4 = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.LogSeq("`813`", _18c);
        if (_195 === null) {
            this.LogSeq("`725`", _18c);
        } else {
            var _1a7 = -1;
            var _1a8 = -1;
            for (i = 0; i < _198.length; i++) {
                if (_198[i] == _195) {
                    _1a7 = i;
                    break;
                }
            }
            for (i = 0; i < _199.length; i++) {
                if (_199[i] == _195) {
                    _1a8 = i;
                    break;
                }
            }
            if (_19c !== null && _19c.GetSequencingControlForwardOnly() === true) {
                this.LogSeq("`302`", _18c);
                var _1a9 = _19c.GetAvailableChildren();
                for (j = 0; j < _1a9.length; j++) {
                    var _1aa = _1a9[j];
                    if (_19b[_1aa.GetItemIdentifier()] === true) {
                        this.LogSeq("`1756`" + _1aa + "`1284`", _18c);
                        break;
                    } else {
                        this.LogSeq("`1715`" + _1aa + "`1440`", _18c);
                        _19a = Control.FindPossibleChoiceRequestForActivity(_1aa);
                        _19a.WillSucceed = false;
                        _19a.ForwardOnlyViolation = true;
                        _19a.Exception = "SB.2.1-4";
                        _19a.ExceptionText = IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.", _19c.GetTitle());
                        this.SetAllDescendentsToNotSucceed(_18b, _1aa, "ForwardOnlyViolation", _19a.Exception, _19a.ExceptionText, _18c);
                    }
                }
            }
            if (_197 === true) {
                var _1ab;
                for (i = _1a7; i < _198.length; i++) {
                    _1ab = _198[i];
                    _19a = Control.FindPossibleChoiceRequestForActivity(_1ab);
                    if (_19a.PreConditionStopForwardTraversal === true) {
                        if (_1ab.IsALeaf() === true) {
                            if (_1ab != _195) {
                                this.LogSeq("`1715`" + _1ab + "`754`", _18c);
                                _19a.WillSucceed = false;
                                _19a.Exception = "SB.2.4-1";
                                _19a.PreConditionStopForwardTraversalViolation = true;
                                _19a.ExceptionText = IntegrationImplementation.GetString("You are not allowed to move into {0} yet.", _1ab.GetTitle());
                            }
                        } else {
                            this.LogSeq("`1348`" + _1ab + "`717`", _18c);
                            this.SetAllDescendentsToNotSucceed(_18b, _1ab, "PreConditionStopForwardTraversalViolation", _19a.Exception, _19a.ExceptionText, _18c);
                        }
                        if (_1ab.IsTheRoot() === false) {
                            this.LogSeq("`1253`" + _1ab + "`900`", _18c);
                            var _1ac = _1ab.ParentActivity;
                            var _1ad = _1ac.GetAvailableChildren();
                            var _1ae = false;
                            for (j = 0; j < _1ad.length; j++) {
                                if (_1ae === true) {
                                    this.LogSeq("`1757`" + _1ad[j] + "`844`", _18c);
                                    _19a = Control.FindPossibleChoiceRequestForActivity(_1ad[j]);
                                    _19a.PreConditionStopForwardTraversalViolation = true;
                                    _19a.WillSucceed = false;
                                    _19a.Exception = "SB.2.4-1";
                                    _19a.ExceptionText = IntegrationImplementation.GetString("You are not allowed to move into {0} yet.", _1ad[j].GetTitle());
                                    this.SetAllDescendentsToNotSucceed(_18b, _1ad[j], "PreConditionStopForwardTraversalViolation", _19a.Exception, _19a.ExceptionText, _18c);
                                }
                                if (_1ad[j] == _1ab) {
                                    _1ae = true;
                                }
                            }
                        }
                    }
                }
            }
            var _1af = this.GetActivityPath(_195, true);
            for (i = 0; i < _1af.length; i++) {
                if (_1af[i].GetSequencingControlChoiceExit() === false) {
                    this.LogSeq("`1757`" + _1af[i] + "`607`", _18c);
                    var _1b0 = _1af[i];
                    for (j = 0; j < _198.length; j++) {
                        if (this.IsActivity1AParentOfActivity2(_1b0, _198[j]) === false) {
                            this.LogSeq("`1757`" + _198[j] + "`1228`", _18c);
                            _19a = Control.FindPossibleChoiceRequestForActivity(_198[j]);
                            _19a.WillSucceed = false;
                            _19a.ChoiceExitViolation = true;
                            _19a.Exception = CONTROL_CHOICE_EXIT_ERROR_CHOICE;
                            _19a.ExceptionText = IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _1b0.GetTitle());
                        }
                    }
                    break;
                }
            }
            for (i = 0; i < _1af.length; i++) {
                if (_1af[i].IsALeaf() === false && _1af[i].GetConstrainedChoice() === true) {
                    var _1b1 = _1af[i];
                    this.LogSeq("`1757`" + _1af[i] + "`55`", _18c);
                    var _1b2 = null;
                    var _1b3 = -1;
                    for (j = 0; j < _198.length; j++) {
                        if (_198[j] == _1b1) {
                            _1b3 = j;
                            break;
                        }
                    }
                    for (j = (_1b3 + 1); j < _198.length; j++) {
                        if (_1b1.IsActivityAnAvailableDescendent(_198[j]) === false) {
                            _1b2 = _198[j];
                            break;
                        }
                    }
                    var _1b4 = null;
                    var _1b5 = -1;
                    for (j = 0; j < _199.length; j++) {
                        if (_199[j] == _1b1) {
                            _1b5 = j;
                            break;
                        }
                    }
                    for (j = (_1b5 - 1); j > 0; j--) {
                        if (_1b1.IsActivityAnAvailableDescendent(_199[j]) === false) {
                            _1b4 = _199[j];
                            break;
                        }
                    }
                    var _1b6 = this.GetArrayOfDescendents(_1b1);
                    _1b6 = _1b6.concat(_1af[_1af.length - 1]);
                    if (_1b4 !== null) {
                        this.LogSeq("`1196`" + _1b4, _18c);
                        _1b6 = _1b6.concat(this.GetArrayOfDescendents(_1b4));
                    } else {
                        this.LogSeq("`1083`", _18c);
                    }
                    if (_1b2 !== null) {
                        this.LogSeq("`1278`" + _1b2, _18c);
                        _1b6 = _1b6.concat(this.GetArrayOfDescendents(_1b2));
                    } else {
                        this.LogSeq("`1167`", _18c);
                    }
                    var _1b7 = new Array();
                    for (j = 0; j < _1b6.length; j++) {
                        _1b7[_1b6[j].GetItemIdentifier()] = _1b6[j];
                    }
                    for (j = 0; j < _198.length; j++) {
                        var _1b8 = _1b7[_198[j].GetItemIdentifier()];
                        if (_1b8 === null || _1b8 === undefined) {
                            this.LogSeq("`1757`" + _198[j] + "`785`", _18c);
                            _19a = Control.FindPossibleChoiceRequestForActivity(_198[j]);
                            _19a.WillSucceed = false;
                            _19a.ConstrainedChoiceViolation = true;
                            _19a.Exception = CONSTRAINED_CHOICE_ERROR;
                            _19a.ExceptionText = IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _1af[i].GetTitle());
                        }
                    }
                    break;
                }
            }
        }
        var _1b9 = _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE];
        var _1ba = _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS];
        if (_195 === null) {
            this.LogSeq("`839`", _18c);
            _1b9.WillSucceed = false;
            _1b9.Exception = "NB.2.1-1";
            _1b9.ExceptionText = IntegrationImplementation.GetString("Cannot continue until the sequencing session has begun.");
            _1b9.Disabled = true;
            _1ba.WillSucceed = false;
            _1ba.Exception = "NB.2.1-2";
            _1ba.ExceptionText = IntegrationImplementation.GetString("Cannot move backwards until the sequencing session has begun.");
            _1ba.Disabled = true;
        } else {
            if (_19c !== null) {
                if (_19c.GetSequencingControlFlow() === false) {
                    this.LogSeq("`1756`" + _19c + "`877`", _18c);
                    _1b9.WillSucceed = false;
                    _1b9.Exception = "NB.2.1-4";
                    _1b9.ExceptionText = IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _19c.GetTitle());
                    _1b9.Disabled = true;
                    _1ba.WillSucceed = false;
                    _1ba.Exception = "NB.2.1-5";
                    _1ba.ExceptionText = IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _19c.GetTitle());
                    _1ba.Disabled = true;
                }
                if (_19c.GetSequencingControlForwardOnly() === true) {
                    this.LogSeq("`1756`" + _19c + "`843`", _18c);
                    _1ba.WillSucceed = false;
                    _1ba.Exception = "NB.2.1-5";
                    _1ba.ExceptionText = IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _19c.GetTitle());
                    _1ba.Disabled = true;
                }
            }
            var _1bb = null;
            var _1bc;
            var _1bd = true;
            for (i = (_1a8 - 1); i >= 0; i--) {
                _1bc = _199[i].ParentActivity;
                if (_1bc !== null && _1bc.GetSequencingControlFlow() === false) {
                    this.LogSeq("`1483`" + _1bc + "`786`", _18c);
                    _1ba.WillSucceed = false;
                    _1ba.Exception = "NB.2.1-5";
                    _1ba.ExceptionText = IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _1bc.GetTitle());
                    _1ba.Disabled = true;
                    break;
                }
                _19a = Control.FindPossibleChoiceRequestForActivity(_199[i]);
                if (_19a.PreConditionSkipped === false) {
                    if (_1bd === true) {
                        if (_199[i].IsALeaf() === false && _199[i].GetSequencingControlForwardOnly() === true) {
                            _1bd = false;
                            this.LogSeq("`26`", _18c);
                        } else {
                            if (_1bc !== null && _1bc.GetSequencingControlForwardOnly() === true) {
                                this.LogSeq("`1296`" + _1bc + "`787`", _18c);
                                _1ba.WillSucceed = false;
                                _1ba.Exception = "NB.2.1-5";
                                _1ba.ExceptionText = IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _1bc.GetTitle());
                                _1ba.Disabled = true;
                                break;
                            }
                        }
                    }
                    if (_199[i].IsALeaf() === true) {
                        _1bb = _199[i];
                        break;
                    }
                }
            }
            if (_1bb === null) {
                this.LogSeq("`486`", _18c);
                _1ba.WillSucceed = false;
                _1ba.Exception = "SB.2.1-3";
                _1ba.ExceptionText = IntegrationImplementation.GetString("You have reached the beginning of the course.");
                _1ba.Disabled = true;
            } else {
                if (_1bd === true) {
                    _19a = Control.FindPossibleChoiceRequestForActivity(_1bb);
                    if (_19a.PreConditionDisabled === true) {
                        this.LogSeq("`1254`" + _1bb + "`866`", _18c);
                        _1ba.WillSucceed = false;
                        _1ba.Exception = "SB.2.2-2";
                        _1ba.ExceptionText = IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", activity.GetTitle());
                        _1ba.Disabled = true;
                    } else {
                        if (_19a.LimitConditionViolation === true) {
                            this.LogSeq("`1254`" + _1bb + "`671`", _18c);
                            _1ba.WillSucceed = false;
                            _1ba.Exception = "SB.2.2-2";
                            _1ba.ExceptionText = IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", activity.GetTitle());
                            _1ba.Disabled = true;
                        }
                    }
                }
            }
            var _1be = null;
            for (i = (_1a7 + 1); i < _198.length; i++) {
                _1bc = _198[i].ParentActivity;
                if (_1bc !== null && _1bc.GetSequencingControlFlow() === false) {
                    this.LogSeq("`1483`" + _1bc + "`129`", _18c);
                    _19a = Control.FindPossibleChoiceRequestForActivity(_1bc);
                    if (_19a.PreConditionSkipped === false) {
                        _1be = _198[i];
                        break;
                    }
                }
                if (_198[i].IsALeaf() === true) {
                    _19a = Control.FindPossibleChoiceRequestForActivity(_198[i]);
                    if (_19a.PreConditionSkipped === false) {
                        _1be = _198[i];
                        break;
                    }
                }
            }
            if (_1be !== null) {
                _19a = Control.FindPossibleChoiceRequestForActivity(_1be);
                if (_19a.PreConditionDisabled === true) {
                    this.LogSeq("`1324`" + _1be + "`901`", _18c);
                    _1b9.WillSucceed = false;
                    _1b9.Exception = "SB.2.2-2";
                    _1b9.ExceptionText = IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", activity.GetTitle());
                    _1b9.Disabled = true;
                } else {
                    if (_19a.LimitConditionViolation === true) {
                        this.LogSeq("`1324`" + _1be + "`705`", _18c);
                        _1b9.WillSucceed = false;
                        _1b9.Exception = "SB.2.2-2";
                        _1b9.ExceptionText = IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", activity.GetTitle());
                        _1b9.Disabled = true;
                    }
                }
            }
        }
        for (i = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; i < _18b.length; i++) {
            if (_18b[i].PreConditionStopForwardTraversalViolation || _18b[i].PreConditionDisabled || _18b[i].LimitConditionViolation || _18b[i].ControlChoiceViolation || _18b[i].ForwardOnlyViolation || _18b[i].NoDeliverablieActivityViolation) {
                _18b[i].Disabled = true;
            }
            if (_18b[i].PreConditionHiddenFromChoice || _18b[i].IsVisibleViolation || _18b[i].PreventActivationViolation || _18b[i].ConstrainedChoiceViolation || _18b[i].ChoiceExitViolation) {
                _18b[i].Hidden = true;
            }
        }
    } else {
        for (id in _18b) {
            if (_18b[id].WillAlwaysSucceed === true) {
                _18b[id].WillSucceed = true;
            } else {
                if (_18b[id].WillNeverSucceed === true) {
                    _18b[id].WillSucceed = false;
                    _18b[id].Exception = "NB.2.1-10";
                    _18b[id].ExceptionText = IntegrationImplementation.GetString("Your selection is not permitted. Please select 'Next' or 'Previous' to move through '{0}.'");
                } else {
                    _18b[id].WillSucceed = null;
                }
            }
            _18b[id].Hidden = false;
            _18b[id].Disabled = false;
        }
        this.LogSeq("`789`", _18c);
        for (id in _18b) {
            if (_18b[id].WillSucceed === null) {
                _18d = this.NavigationRequestProcess(_18b[id].NavigationRequest, _18b[id].TargetActivityItemIdentifier, _18c, _196);
                if (_18d.NavigationRequest == NAVIGATION_REQUEST_NOT_VALID) {
                    this.LogSeq("`756`", _18c);
                    _18b[id].WillSucceed = false;
                    _18b[id].TargetActivity = this.GetActivityFromIdentifier(_18b[id].TargetActivityItemIdentifier, _18c);
                    _18b[id].Exception = _18d.Exception;
                    _18b[id].ExceptionText = _18d.ExceptionText;
                } else {
                    this.LogSeq("`724`", _18c);
                    _18b[id].WillSucceed = true;
                    _18b[id].TargetActivity = _18d.TargetActivity;
                    _18b[id].SequencingRequest = _18d.SequencingRequest;
                    _18b[id].Exception = "";
                    _18b[id].ExceptionText = "";
                }
            }
        }
        this.LogSeq("`215`", _18c);
        _195 = this.GetCurrentActivity();
        if (_195 !== null && _195.IsActive() === true) {
            this.LogSeq("`958`", _18c);
            _18e = this.TerminationRequestProcess(TERMINATION_REQUEST_EXIT, _18c, _196);
            this.LogSeq("`914`", _18c);
            if (_18e.TerminationRequest == TERMINATION_REQUEST_NOT_VALID) {
                this.LogSeq("`718`", _18c);
                if (_18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed) {
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = false;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = _18e.Exception;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = _18e.ExceptionText;
                }
                if (_18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed) {
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].WillSucceed = false;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].Exception = _18e.Exception;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].ExceptionText = _18e.ExceptionText;
                }
                if (_18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed) {
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].WillSucceed = false;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].Exception = _18e.Exception;
                    _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].ExceptionText = _18e.ExceptionText;
                }
                for (id = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; id < _18b.length; id++) {
                    if (_18b[id].WillSucceed) {
                        _18b[id].WillSucceed = false;
                        _18b[id].Exception = _18e.Exception;
                        _18b[id].ExceptionText = terminatonRequestResult.ExceptionText;
                    } else {
                        _18b[id].TerminationSequencingRequest = _18e.SequencingRequest;
                    }
                }
            }
            _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].TerminationSequencingRequest = _18e.SequencingRequest;
            _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_PREVIOUS].TerminationSequencingRequest = _18e.SequencingRequest;
            _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_EXIT].TerminationSequencingRequest = _18e.SequencingRequest;
            for (id = POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE; id < _18b.length; id++) {
                _18b[id].TerminationSequencingRequest = _18e.SequencingRequest;
            }
        }
        this.LogSeq("`660`", _18c);
        for (id in _18b) {
            if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE && _18b[id].WillSucceed === true && _18b[id].WillAlwaysSucceed === false && _18b[id].WillNeverSucceed === false) {
                this.LogSeq("`867`", _18c);
                var _1bf = this.CheckActivityProcess(_18b[id].TargetActivity, _18c, _196);
                if (_1bf === true) {
                    this.LogSeq("`746`", _18c);
                    _18b[id].WillSucceed = false;
                    _18b[id].Disabled = true;
                    this.SetAllDescendentsToDisabled(_18b, _18b[id].TargetActivity);
                }
            }
        }
        this.LogSeq("`678`", _18c);
        var _1c0 = null;
        for (id in _18b) {
            if (_18b[id].WillAlwaysSucceed === false && _18b[id].WillNeverSucceed === false) {
                this.LogSeq("`625`", _18c);
                if (_18b[id].TerminationSequencingRequest !== null) {
                    this.LogSeq("`418`", _18c);
                    if (_1c0 === null) {
                        _18f = this.SequencingRequestProcess(_18b[id].TerminationSequencingRequest, null, _18c, _196);
                    } else {
                        _18f = _1c0;
                    }
                    if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE) {
                        this.LogSeq("`1042`", _18c);
                        _1a1 = this.SequencingRulesCheckProcess(_18b[id].TargetActivity, RULE_SET_HIDE_FROM_CHOICE, _18c, _196);
                        if (_1a1 !== null) {
                            _18b[id].Exception = "SB.2.9-3";
                            _18b[id].ExceptionText = "The activity " + _18b[id].TargetActivity.GetTitle() + " should be hidden and is not a valid selection";
                            _18b[id].Hidden = true;
                        }
                    }
                } else {
                    if (_18b[id].WillSucceed === true) {
                        this.LogSeq("`1651`", _18c);
                        this.LogSeq("`719`", _18c);
                        _18f = this.SequencingRequestProcess(_18b[id].SequencingRequest, _18b[id].TargetActivity, _18c, _196);
                    }
                }
                if (_18b[id].WillSucceed === true) {
                    this.LogSeq("`838`", _18c);
                    if (_18f.Exception !== null) {
                        this.LogSeq("`1295`", _18c);
                        _18b[id].WillSucceed = false;
                        _18b[id].Exception = _18f.Exception;
                        _18b[id].ExceptionText = _18f.ExceptionText;
                        _18b[id].Hidden = _18f.Hidden;
                    } else {
                        if (_18f.DeliveryRequest !== null) {
                            this.LogSeq("`1123`", _18c);
                            _190 = this.DeliveryRequestProcess(_18f.DeliveryRequest, _18c, _196);
                            this.LogSeq("`706`" + _190.Valid + ")", _18c);
                            _18b[id].WillSucceed = _190.Valid;
                        }
                    }
                }
            }
        }
        this.LogSeq("`362`", _18c);
        var _1c1;
        for (id in _18b) {
            if (id >= POSSIBLE_NAVIGATION_REQUEST_INDEX_CHOICE) {
                if (_18b[id].WillSucceed === false) {
                    _1c1 = _18b[id].Exception;
                    if (_1c1 == CONTROL_CHOICE_EXIT_ERROR_NAV || _1c1 == CONTROL_CHOICE_EXIT_ERROR_CHOICE || _1c1 == PREVENT_ACTIVATION_ERROR || _1c1 == CONSTRAINED_CHOICE_ERROR) {
                        this.LogSeq("`1498`" + id + "`1735`" + _1c1, _18c);
                        _18b[id].Hidden = true;
                    }
                }
            }
        }
        _19c = this.Activities.GetParentActivity(_195);
        if (_19c != null) {
            if (_19c.GetSequencingControlFlow() === true) {
                this.LogSeq("`430`", _18c);
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = true;
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = "";
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = "";
            } else {
                this.LogSeq("`405`", _18c);
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].WillSucceed = false;
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].Exception = "SB.2.2-1";
                _18b[POSSIBLE_NAVIGATION_REQUEST_INDEX_CONTINUE].ExceptionText = "Parent activity does not allow flow traversal";
            }
        }
    }
    this.LogSeqReturn("", _18c);
    return _18b;
}

function Sequencer_SetAllDescendentsToDisabled(_1c2, _1c3) {
    for (var i = 0; i < _1c3.ChildActivities.length; i++) {
        var _1c5 = Control.FindPossibleChoiceRequestForActivity(_1c3.ChildActivities[i]);
        _1c5.WillSucceed = false;
        _1c5.Disabled = true;
        this.SetAllDescendentsToDisabled(_1c2, _1c3.ChildActivities[i]);
    }
}

function Sequencer_SetAllDescendentsToNotSucceed(_1c6, _1c7, _1c8, _1c9, _1ca, _1cb) {
    for (var i = 0; i < _1c7.ChildActivities.length; i++) {
        var _1cd = Control.FindPossibleChoiceRequestForActivity(_1c7.ChildActivities[i]);
        _1cd.WillSucceed = false;
        _1cd.Exception = _1c9;
        _1cd.ExceptionText = _1ca;
        switch (_1c8) {
            case "PreventActivationViolation":
                _1cd.PreventActivationViolation = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1283`", _1cb);
                break;
            case "LimitConditionViolation":
                _1cd.LimitConditionViolation = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1245`", _1cb);
                break;
            case "PreConditionHiddenFromChoice":
                _1cd.PreConditionHiddenFromChoice = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1283`", _1cb);
                break;
            case "PreConditionDisabled":
                _1cd.PreConditionDisabled = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1245`", _1cb);
                break;
            case "ForwardOnlyViolation":
                _1cd.ForwardOnlyViolation = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1245`", _1cb);
                break;
            case "PreConditionStopForwardTraversalViolation":
                _1cd.PreConditionStopForwardTraversalViolation = true;
                this.LogSeq("`1756`" + _1c7.ChildActivities[i] + "`1245`", _1cb);
                break;
        }
        this.SetAllDescendentsToNotSucceed(_1c6, _1c7.ChildActivities[i], _1c8, _1c9, _1ca, _1cb);
    }
}

function Sequencer_SetAllDescendentsToSkipped(_1ce, _1cf, _1d0, _1d1) {
    this.LogSeq("`1716`" + _1cf + "`1100`" + _1d0[_1cf.GetItemIdentifier()], _1d1);
    if (_1d0[_1cf.GetItemIdentifier()] === true) {
        return;
    }
    for (var i = 0; i < _1cf.ChildActivities.length; i++) {
        var _1d3 = Control.FindPossibleChoiceRequestForActivity(_1cf.ChildActivities[i]);
        _1d3.PreConditionSkipped = true;
        this.SetAllDescendentsToSkipped(_1ce, _1cf.ChildActivities[i], _1d0, _1d1);
    }
}

function Sequencer_InitializePossibleNavigationRequestAbsolutes(_1d4, _1d5, _1d6) {
    var _1d7 = this.LogSeqAudit("`1025`");
    this.CheckForRelevantSequencingRules(_1d5, false);
    var _1d8;
    var _1d9;
    var _1da = false;
    for (var _1db in _1d6) {
        _1d8 = _1d6[_1db];
        var _1dc = this.LogSeqAudit(_1d8.StringIdentifier, _1d7);
        if (_1d8.GetSequencingControlChoice() === false) {
            this.LogSeqAudit("`1320`", _1dc);
            var _1dd = this.LogSeqAudit("`835`" + _1d8.ChildActivities.length + ")", _1dc);
            for (var i = 0; i < _1d8.ChildActivities.length; i++) {
                _1d9 = Control.FindPossibleChoiceRequestForActivity(_1d8.ChildActivities[i]);
                _1d9.WillNeverSucceed = true;
                this.LogSeqAudit(_1d8.ChildActivities[i].StringIdentifier, _1dd);
            }
        }
        _1da = _1da || (_1d8.GetSequencingControlChoiceExit() === true);
        this.LogSeqAudit("`1504`" + _1da, _1dc);
        _1d9 = Control.FindPossibleChoiceRequestForActivity(_1d8);
        if (_1d8.IsDeliverable() === false && _1d8.GetSequencingControlFlow() === false) {
            this.LogSeqAudit("`356`", _1dc);
            _1d9.WillNeverSucceed = true;
        }
        if (_1d8.HasChildActivitiesDeliverableViaFlow === false) {
            this.LogSeqAudit("`505`", _1dc);
            _1d9.WillNeverSucceed = true;
        }
        if (_1d8.HasSeqRulesRelevantToChoice === false && _1d9.WillNeverSucceed === false) {
            this.LogSeqAudit("`275`", _1dc);
            _1d9.WillAlwaysSucceed = true;
        } else {
            this.LogSeqAudit("`246`", _1dc);
            _1d9.WillAlwaysSucceed = false;
        }
        this.LogSeqAudit("`1609`" + _1d9.WillAlwaysSucceed, _1dc);
        this.LogSeqAudit("`1622`" + _1d9.WillNeverSucceed, _1dc);
    }
    if (_1da === true) {
        this.LogSeqAudit("`549`", _1d7);
        for (var id in _1d4) {
            _1d4[id].WillAlwaysSucceed = false;
        }
    }
}

function Sequencer_CheckForRelevantSequencingRules(_1e0, _1e1) {
    if (_1e1 === true) {
        _1e0.HasSeqRulesRelevantToChoice = true;
    } else {
        if (this.DoesThisActivityHaveSequencingRulesRelevantToChoice(_1e0)) {
            _1e0.HasSeqRulesRelevantToChoice = true;
        } else {
            _1e0.HasSeqRulesRelevantToChoice = false;
        }
    }
    var _1e2 = false;
    for (var i = 0; i < _1e0.ChildActivities.length; i++) {
        this.CheckForRelevantSequencingRules(_1e0.ChildActivities[i], _1e0.HasSeqRulesRelevantToChoice);
        _1e2 = (_1e2 || _1e0.ChildActivities[i].HasChildActivitiesDeliverableViaFlow);
    }
    _1e0.HasChildActivitiesDeliverableViaFlow = (_1e0.IsDeliverable() || (_1e0.GetSequencingControlFlow() && _1e2));
}

function Sequencer_DoesThisActivityHaveSequencingRulesRelevantToChoice(_1e4) {
    if (_1e4.GetSequencingControlForwardOnly() === true) {
        return true;
    }
    if (_1e4.GetPreventActivation() === true) {
        return true;
    }
    if (_1e4.GetConstrainedChoice() === true) {
        return true;
    }
    if (_1e4.GetSequencingControlChoiceExit() === false) {
        return true;
    }
    var _1e5 = _1e4.GetPreConditionRules();
    for (var i = 0; i < _1e5.length; i++) {
        if (_1e5[i].Action == SEQUENCING_RULE_ACTION_DISABLED || _1e5[i].Action == SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE || _1e5[i].Action == SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL) {
            return true;
        }
    }
    return false;
}

function Sequencer_GetArrayOfDescendents(_1e7) {
    var _1e8 = new Array();
    _1e8[_1e8.length] = _1e7;
    var _1e9 = _1e7.GetChildren();
    for (var i = 0; i < _1e9.length; i++) {
        var _1eb = this.GetArrayOfDescendents(_1e9[i]);
        _1e8 = _1e8.concat(_1eb);
    }
    return _1e8;
}

function Sequencer_IsActivity1AParentOfActivity2(_1ec, _1ed) {
    var _1ee = false;
    var _1ef = null;
    if (_1ed.ParentActivity !== null) {
        _1ef = _1ed.ParentActivity;
    }
    while (_1ef !== null) {
        if (_1ef.GetItemIdentifier() == _1ec.GetItemIdentifier()) {
            _1ee = true;
            break;
        }
        _1ef = _1ef.ParentActivity;
    }
    return _1ee;
}

function Sequencer_ActivityProgressRollupProcess(_1f0, _1f1, _1f2) {
    Debug.AssertError("Calling log not passed.", (_1f1 === undefined || _1f1 === null));
    Debug.AssertError("Simple calling log not passed.", (_1f2 === undefined || _1f2 === null));
    var _1f3 = this.LogSeqAudit("`1176`" + _1f0 + ")", _1f1);
    _1f2 = this.LogSeqSimpleAudit("Rolling up the completion status of \"" + _1f0 + "\".", _1f2);
    this.LogSeq("`91`", _1f3);
    if (_1f0.GetCompletedByMeasure() === true) {
        this.LogSeq("`849`", _1f3);
        this.ActivityProgressRollupUsingMeasureProcess(_1f0, _1f3, _1f2);
    } else {
        this.LogSeq("`1717`", _1f3);
        this.LogSeq("`851`", _1f3);
        this.ActivityProgressRollupUsingRulesProcess(_1f0, _1f3, _1f2);
    }
    this.LogSeq("`1068`", _1f3);
    this.LogSeqReturn("", _1f3);
    return;
}

function Sequencer_ActivityProgressRollupUsingMeasureProcess(_1f4, _1f5, _1f6) {
    Debug.AssertError("Calling log not passed.", (_1f5 === undefined || _1f5 === null));
    Debug.AssertError("Simple calling log not passed.", (_1f6 === undefined || _1f6 === null));
    var _1f7 = this.LogSeqAudit("`910`" + _1f4 + ")", _1f5);
    this.LogSeq("`1092`", _1f7);
    if (_1f4.IsTracked() === false) {
        this.LogSeqReturn("", _1f7);
        return;
    }
    this.LogSeq("`1051`", _1f7);
    _1f4.SetAttemptProgressStatus(false);
    this.LogSeq("`993`", _1f7);
    _1f4.SetAttemptCompletionStatus(false);
    this.LogSeq("`134`", _1f7);
    if (_1f4.GetCompletedByMeasure() === true) {
        this.LogSeq("`371`", _1f7);
        if (_1f4.GetAttemptCompletionAmountStatus() === false) {
            this.LogSeq("`903`", _1f7);
            _1f4.SetAttemptCompletionStatus(false);
            this.LogSeqSimple("\"" + _1f4 + "\" is completed by measure, but does not have a known progress measure so its completion status will be unknown.", _1f6);
        } else {
            this.LogSeq("`1631`", _1f7);
            this.LogSeq("`444`", _1f7);
            var _1f8 = _1f4.GetAttemptCompletionAmount();
            var _1f9 = _1f4.GetMinProgressMeasure();
            if (_1f8 >= _1f9) {
                this.LogSeq("`934`", _1f7);
                _1f4.SetAttemptProgressStatus(true);
                this.LogSeq("`874`", _1f7);
                _1f4.SetAttemptCompletionStatus(true);
                this.LogSeqSimple("\"" + _1f4 + "\" is completed by measure, and its progress measure (" + _1f8 + ") is greater than the minimum progress measure (" + _1f9 + ") so its completion status will be completed.", _1f6);
            } else {
                this.LogSeq("`1581`", _1f7);
                this.LogSeq("`961`", _1f7);
                _1f4.SetAttemptProgressStatus(true);
                this.LogSeq("`882`", _1f7);
                _1f4.SetAttemptCompletionStatus(false);
                this.LogSeqSimple("\"" + _1f4 + "\" is completed by measure, and its progress measure (" + _1f8 + ") is less than the minimum progress measure (" + _1f9 + ") so its completion status will be incomplete.", _1f6);
            }
        }
    } else {
        this.LogSeq("`1687`", _1f7);
        this.LogSeq("`461`", _1f7);
        _1f4.SetAttemptProgressStatus(false);
    }
    this.LogSeq("`860`", _1f7);
    this.LogSeqReturn("", _1f7);
    return;
}

function Sequencer_ActivityProgressRollupUsingRulesProcess(_1fa, _1fb, _1fc) {
    Debug.AssertError("Calling log not passed.", (_1fb === undefined || _1fb === null));
    Debug.AssertError("Simple calling log not passed.", (_1fc === undefined || _1fc === null));
    var _1fd = this.LogSeqAudit("`944`" + _1fa + ")", _1fb);
    this.LogSeq("`31`", _1fd);
    if (Sequencer_GetApplicableSetofRollupRules(_1fa, RULE_SET_INCOMPLETE).length === 0 && Sequencer_GetApplicableSetofRollupRules(_1fa, RULE_SET_COMPLETED).length === 0) {
        this.LogSeqSimple("Applying the default set of completion rollup rules to \"" + _1fa + "\".", _1fc);
        this.LogSeq("`111`", _1fd);
        _1fa.ApplyRollupRule(new SequencingRollupRule(RULE_CONDITION_COMBINATION_ANY, CHILD_ACTIVITY_SET_ALL, ROLLUP_RULE_MINIMUM_COUNT_DEFAULT, ROLLUP_RULE_MINIMUM_PERCENT_DEFAULT, ROLLUP_RULE_ACTION_COMPLETED, new Array(new SequencingRollupRuleCondition(RULE_CONDITION_OPERATOR_NOOP, SEQUENCING_RULE_CONDITION_COMPLETED))));
        this.LogSeq("`70`", _1fd);
        _1fa.ApplyRollupRule(new SequencingRollupRule(RULE_CONDITION_COMBINATION_ANY, CHILD_ACTIVITY_SET_ALL, ROLLUP_RULE_MINIMUM_COUNT_DEFAULT, ROLLUP_RULE_MINIMUM_PERCENT_DEFAULT, ROLLUP_RULE_ACTION_INCOMPLETE, new Array(new SequencingRollupRuleCondition(RULE_CONDITION_OPERATOR_NOOP, SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN))));
    } else {
        if (_1fa.UsesDefaultCompletionRollupRules() === true) {
            this.LogSeqSimple("Applying the default set of completion rollup rules to \"" + _1fa + "\".", _1fc);
        }
    }
    var _1fe;
    this.LogSeq("`314`", _1fd);
    _1fe = this.RollupRuleCheckSubprocess(_1fa, RULE_SET_INCOMPLETE, _1fd, _1fc);
    this.LogSeq("`806`", _1fd);
    if (_1fe === true) {
        this.LogSeqSimple("Setting \"" + _1fa + "\" to incomplete.", _1fc);
        this.LogSeq("`760`", _1fd);
        _1fa.SetAttemptProgressStatus(true);
        this.LogSeq("`720`", _1fd);
        _1fa.SetAttemptCompletionStatus(false);
    }
    this.LogSeq("`321`", _1fd);
    _1fe = this.RollupRuleCheckSubprocess(_1fa, RULE_SET_COMPLETED, _1fd, _1fc);
    this.LogSeq("`829`", _1fd);
    if (_1fe === true) {
        this.LogSeqSimple("Setting \"" + _1fa + "\" to completed.", _1fc);
        this.LogSeq("`761`", _1fd);
        _1fa.SetAttemptProgressStatus(true);
        this.LogSeq("`730`", _1fd);
        _1fa.SetAttemptCompletionStatus(true);
    }
    this.LogSeq("`1033`", _1fd);
    this.LogSeqReturn("", _1fd);
    return;
}

function Sequencer_CheckActivityProcess(_1ff, _200, _201) {
    Debug.AssertError("Calling log not passed.", (_200 === undefined || _200 === null));
    Debug.AssertError("Simple calling log not passed.", (_201 === undefined || _201 === null));
    var _202 = this.LogSeqAudit("`1402`" + _1ff + ")", _200);
    this.LogSeq("`313`", _202);
    var _203 = this.SequencingRulesCheckProcess(_1ff, RULE_SET_DISABLED, _202, _201);
    this.LogSeq("`784`", _202);
    if (_203 !== null) {
        this.LogSeq("`722`", _202);
        this.LogSeqReturn("`1763`", _202);
        this.LogSeqSimple("\"" + _1ff + "\" (and its descendents) can not be delivered because sequencing rules make it currently disabled.", _201);
        return true;
    }
    this.LogSeq("`396`", _202);
    var _204 = this.LimitConditionsCheckProcess(_1ff, _202, _201);
    this.LogSeq("`865`", _202);
    if (_204) {
        this.LogSeq("`615`", _202);
        this.LogSeqReturn("`1763`", _202);
        this.LogSeqSimple("\"" + _1ff + "\" (and its descendents) can not be delivered because has exceeded its attempt limit.", _201);
        return true;
    }
    this.LogSeq("`753`", _202);
    this.LogSeqReturn("`1759`", _202);
    return false;
}

function Sequencer_CheckChildForRollupSubprocess(_205, _206, _207, _208) {
    Debug.AssertError("Calling log not passed.", (_207 === undefined || _207 === null));
    Debug.AssertError("Simple calling log not passed.", (_208 === undefined || _208 === null));
    var _209 = this.LogSeqAudit("`1114`" + _205 + ", " + _206 + ")", _207);
    var _20a;
    this.LogSeq("`1350`", _209);
    var _20b = false;
    this.LogSeq("`815`", _209);
    if (_206 == ROLLUP_RULE_ACTION_SATISFIED || _206 == ROLLUP_RULE_ACTION_NOT_SATISFIED) {
        this.LogSeq("`406`", _209);
        if (_205.GetRollupObjectiveSatisfied() === true) {
            this.LogSeq("`591`", _209);
            _20b = true;
            var _20c = _205.GetRequiredForSatisfied();
            var _20d = _205.GetRequiredForNotSatisfied();
            this.LogSeq("`97`", _209);
            if ((_206 == ROLLUP_RULE_ACTION_SATISFIED && _20c == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED) || (_206 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _20d == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)) {
                this.LogSeq("`92`", _209);
                if (_205.GetActivityProgressStatus() === false || (_205.GetAttemptCount() > 0 && _205.IsSuspended() === true)) {
                    this.LogSeq("`1200`", _209);
                    _20b = false;
                    this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it is currently suspended and the sequencing rules indicate that it should only be included if it is not suspended.", _208);
                }
            } else {
                this.LogSeq("`1595`", _209);
                this.LogSeq("`104`", _209);
                if ((_206 == ROLLUP_RULE_ACTION_SATISFIED && _20c == ROLLUP_CONSIDERATION_IF_ATTEMPTED) || (_206 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _20d == ROLLUP_CONSIDERATION_IF_ATTEMPTED)) {
                    this.LogSeq("`329`", _209);
                    if (_205.GetActivityProgressStatus() === false || _205.GetAttemptCount() === 0) {
                        this.LogSeq("`1143`", _209);
                        _20b = false;
                        this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it has not been attempted yet and the sequencing rules indicate that it should only be included if it has been attempted.", _208);
                    }
                } else {
                    this.LogSeq("`1562`", _209);
                    this.LogSeq("`98`", _209);
                    if ((_206 == ROLLUP_RULE_ACTION_SATISFIED && _20c == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED) || (_206 == ROLLUP_RULE_ACTION_NOT_SATISFIED && _20d == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)) {
                        this.LogSeq("`467`", _209);
                        _20a = this.SequencingRulesCheckProcess(_205, RULE_SET_SKIPPED, _209, _208);
                        this.LogSeq("`634`", _209);
                        if (_20a !== null) {
                            this.LogSeq("`1108`", _209);
                            _20b = false;
                            this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it is currently skipped and the sequencing rules indicate that it should only be included if it is not skipped.", _208);
                        }
                    }
                }
            }
        }
    }
    this.LogSeq("`853`", _209);
    if (_206 == ROLLUP_RULE_ACTION_COMPLETED || _206 == ROLLUP_RULE_ACTION_INCOMPLETE) {
        this.LogSeq("`419`", _209);
        if (_205.RollupProgressCompletion() === true) {
            this.LogSeq("`592`", _209);
            _20b = true;
            var _20e = _205.GetRequiredForCompleted();
            var _20f = _205.GetRequiredForIncomplete();
            this.LogSeq("`106`", _209);
            if ((_206 == ROLLUP_RULE_ACTION_COMPLETED && _20e == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED) || (_206 == ROLLUP_RULE_ACTION_INCOMPLETE && _20f == ROLLUP_CONSIDERATION_IF_NOT_SUSPENDED)) {
                this.LogSeq("`93`", _209);
                if (_205.GetActivityProgressStatus() === false || (_205.GetAttemptCount() > 0 && _205.IsSuspended() === true)) {
                    this.LogSeq("`1384`", _209);
                    _20b = false;
                    this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it is currently suspended and the sequencing rules indicate that it should only be included if it is not suspended.", _208);
                }
            } else {
                this.LogSeq("`1596`", _209);
                this.LogSeq("`117`", _209);
                if ((_206 == ROLLUP_RULE_ACTION_COMPLETED && _20e == ROLLUP_CONSIDERATION_IF_ATTEMPTED) || (_206 == ROLLUP_RULE_ACTION_INCOMPLETE && _20f == ROLLUP_CONSIDERATION_IF_ATTEMPTED)) {
                    this.LogSeq("`330`", _209);
                    if (_205.GetActivityProgressStatus() === false || _205.GetAttemptCount() === 0) {
                        this.LogSeq("`1144`", _209);
                        _20b = false;
                        this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it is has not been attempted yet and the sequencing rules indicate that it should only be included if it has been attempted.", _208);
                    }
                } else {
                    this.LogSeq("`1563`", _209);
                    this.LogSeq("`107`", _209);
                    if ((_206 == ROLLUP_RULE_ACTION_COMPLETED && _20e == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED) || (_206 == ROLLUP_RULE_ACTION_INCOMPLETE && _20f == ROLLUP_CONSIDERATION_IF_NOT_SKIPPED)) {
                        this.LogSeq("`468`", _209);
                        _20a = this.SequencingRulesCheckProcess(_205, RULE_SET_SKIPPED, _209, _208);
                        this.LogSeq("`635`", _209);
                        if (_20a !== null) {
                            this.LogSeq("`1109`", _209);
                            _20b = false;
                            this.LogSeqSimple("\"" + _205 + "\" is not included in rollup because it is currently skipped and the sequencing rules indicate that it should only be included if it is not skipped.", _208);
                        }
                    }
                }
            }
        }
    }
    this.LogSeq("`602`", _209);
    this.LogSeqReturn(_20b, _209);
    return _20b;
}

function Sequencer_ChoiceActivityTraversalSubprocess(_210, _211, _212, _213) {
    Debug.AssertError("Calling log not passed.", (_212 === undefined || _212 === null));
    Debug.AssertError("Simple calling log not passed.", (_213 === undefined || _213 === null));
    var _214 = this.LogSeqAudit("`1101`" + _210 + ", " + _211 + ")", _212);
    var _215 = null;
    var _216 = null;
    var _217;
    this.LogSeq("`987`", _214);
    if (_211 == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`445`", _214);
        _215 = this.SequencingRulesCheckProcess(_210, RULE_SET_STOP_FORWARD_TRAVERSAL, _214, _213);
        this.LogSeq("`732`", _214);
        if (_215 !== null) {
            this.LogSeqSimple("Moving beyond \"" + _210 + "\" is curently disallowed because of a stop forward traversal sequencing rule. This choice request is not allowed.", _213);
            this.LogSeq("`558`", _214);
            _217 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-1", IntegrationImplementation.GetString("You are not allowed to move into {0} yet.", _210.GetTitle()));
            this.LogSeqReturn(_217, _214);
            return _217;
        }
        this.LogSeq("`612`", _214);
        _217 = new Sequencer_ChoiceActivityTraversalSubprocessResult(true, null);
        this.LogSeqReturn(_217, _214);
        return _217;
    }
    this.LogSeq("`977`", _214);
    if (_211 == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`1111`", _214);
        if (!_210.IsTheRoot()) {
            _216 = this.Activities.GetParentActivity(_210);
            this.LogSeq("`584`", _214);
            if (_216.GetSequencingControlForwardOnly()) {
                this.LogSeqSimple("Moving to \"" + _210 + "\" from a subesequent activity is not allowed because " + _216 + " has sequencing control forward only. This choice request is not allowed.", _213);
                this.LogSeq("`548`", _214);
                _217 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-2", IntegrationImplementation.GetString("You must start {0} at the beginning.", _216.GetTitle()));
                this.LogSeqReturn(_217, _214);
                return _217;
            }
        } else {
            this.LogSeq("`1638`", _214);
            this.LogSeq("`237`", _214);
            _217 = new Sequencer_ChoiceActivityTraversalSubprocessResult(false, "SB.2.4-3", IntegrationImplementation.GetString("You have reached the beginning of the course."));
            this.LogSeqReturn(_217, _214);
            return _217;
        }
        this.LogSeq("`613`", _214);
        _217 = new Sequencer_ChoiceActivityTraversalSubprocessResult(true, null);
        this.LogSeqReturn(_217, _214);
        return _217;
    }
}

function Sequencer_ChoiceActivityTraversalSubprocessResult(_218, _219, _21a) {
    this.Reachable = _218;
    this.Exception = _219;
    this.ExceptionText = _21a;
}
Sequencer_ChoiceActivityTraversalSubprocessResult.prototype.toString = function() {
    return "Reachable=" + this.Reachable + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ChoiceFlowSubprocess(_21b, _21c, _21d, _21e) {
    Debug.AssertError("Calling log not passed.", (_21d === undefined || _21d === null));
    Debug.AssertError("Simple calling log not passed.", (_21e === undefined || _21e === null));
    var _21f = this.LogSeqAudit("`1328`" + _21b + ", " + _21c + ")", _21d);
    this.LogSeq("`128`", _21f);
    var _220 = this.ChoiceFlowTreeTraversalSubprocess(_21b, _21c, _21f, _21e);
    this.LogSeq("`733`", _21f);
    if (_220 === null) {
        this.LogSeq("`711`", _21f);
        this.LogSeqReturn(_21b, _21f);
        return _21b;
    } else {
        this.LogSeq("`1690`", _21f);
        this.LogSeq("`338`", _21f);
        this.LogSeqReturn(_220, _21f);
        return _220;
    }
}

function Sequencer_ChoiceFlowTreeTraversalSubprocess(_221, _222, _223, _224) {
    Debug.AssertError("Calling log not passed.", (_223 === undefined || _223 === null));
    Debug.AssertError("Simple calling log not passed.", (_224 === undefined || _224 === null));
    var _225 = this.LogSeqAudit("`1037`" + _221 + ", " + _222 + ")", _223);
    var _226 = this.Activities.GetParentActivity(_221);
    var _227 = null;
    var _228 = null;
    var _229 = null;
    this.LogSeq("`964`", _225);
    if (_222 == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`74`", _225);
        if (this.IsActivityLastOverall(_221, _225) || _221.IsTheRoot() === true) {
            this.LogSeq("`684`", _225);
            this.LogSeqReturn("`1762`", _225);
            return null;
        }
        this.LogSeq("`479`", _225);
        if (_226.IsActivityTheLastAvailableChild(_221)) {
            this.LogSeq("`137`", _225);
            _227 = this.ChoiceFlowTreeTraversalSubprocess(_226, FLOW_DIRECTION_FORWARD, _225, _224);
            this.LogSeq("`143`", _225);
            this.LogSeqReturn(_227, _225);
            return _227;
        } else {
            this.LogSeq("`1639`", _225);
            this.LogSeq("`301`", _225);
            _228 = _221.GetNextSibling();
            this.LogSeq("`446`", _225);
            this.LogSeqReturn(_228, _225);
            return _228;
        }
    }
    this.LogSeq("`954`", _225);
    if (_222 == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`456`", _225);
        if (_221.IsTheRoot()) {
            this.LogSeq("`685`", _225);
            this.LogSeqReturn("`1762`", _225);
            return null;
        }
        this.LogSeq("`472`", _225);
        if (_226.IsActivityTheFirstAvailableChild(_221)) {
            this.LogSeq("`135`", _225);
            _227 = this.ChoiceFlowTreeTraversalSubprocess(_226, FLOW_DIRECTION_BACKWARD, _225, _224);
            this.LogSeq("`138`", _225);
            this.LogSeqReturn(_227, _225);
            return _227;
        } else {
            this.LogSeq("`1640`", _225);
            this.LogSeq("`268`", _225);
            _229 = _221.GetPreviousSibling();
            this.LogSeq("`447`", _225);
            this.LogSeqReturn(_229, _225);
            return _229;
        }
    }
}

function Sequencer_ChoiceSequencingRequestProcess(_22a, _22b, _22c) {
    Debug.AssertError("Calling log not passed.", (_22b === undefined || _22b === null));
    Debug.AssertError("Simple calling log not passed.", (_22c === undefined || _22c === null));
    var _22d = this.LogSeqAudit("`1159`" + _22a + ")", _22b);
    var _22e = null;
    var _22f;
    var _230 = null;
    var _231 = null;
    var _232 = null;
    var _233 = null;
    var _234;
    var i;
    var _236;
    this.LogSeq("`502`" + _22a.LearningObject.ItemIdentifier, _22d);
    if (_22a === null) {
        this.LogSeq("`448`", _22d);
        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-1", IntegrationImplementation.GetString("Your selection is not permitted.  Please select an available menu item to continue."), false);
        this.LogSeqReturn(_236, _22d);
        return _236;
    }
    this.LogSeq("`333`", _22d);
    _22f = this.GetActivityPath(_22a, true);
    this.LogSeq("`1035`", _22d);
    for (i = (_22f.length - 1); i >= 0; i--) {
        this.LogSeq("`795`", _22d);
        if (_22f[i].IsTheRoot() == false) {
            this.LogSeq("`262`", _22d);
            if (_22f[i].IsAvailable === false) {
                this.LogSeq("`395`", _22d);
                this.LogSeqSimple("\"" + _22f[i] + "\" is not currently available (it was not selected during the selection and randomization process). It and all of its descendents are not available targets for choice navigation.", _22c);
                _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-2", "The activity " + _22a.GetTitle() + " should not be available and is not a valid selection", true);
                this.LogSeqReturn(_236, _22d);
                return _236;
            }
        }
        this.LogSeq("`247`", _22d);
        _230 = this.SequencingRulesCheckProcess(_22f[i], RULE_SET_HIDE_FROM_CHOICE, _22d, _22c);
        this.LogSeq("`737`", _22d);
        if (_230 !== null) {
            this.LogSeq("`220`", _22d);
            this.LogSeqSimple("Sequencing rules indicate that \"" + _22f[i] + "\" should currently be hidden. It and all of its descendents are not valid targets for choice navigation.", _22c);
            _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-3", "The activity " + _22a.GetTitle() + " should be hidden and is not a valid selection", true);
            this.LogSeqReturn(_236, _22d);
            return _236;
        }
    }
    this.LogSeq("`750`", _22d);
    if (!_22a.IsTheRoot()) {
        this.LogSeq("`221`", _22d);
        _22e = this.Activities.GetParentActivity(_22a);
        if (_22e.GetSequencingControlChoice() === false) {
            this.LogSeq("`424`", _22d);
            this.LogSeqSimple("\"" + _22e + "\" does not allow its children to be selected using choice navigation.", _22c);
            _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-4", IntegrationImplementation.GetString("The activity '{0}' should be hidden and is not a valid selection.", _22e.GetTitle()), false);
            this.LogSeqReturn(_236, _22d);
            return _236;
        }
    }
    this.LogSeq("`579`", _22d);
    if (this.IsCurrentActivityDefined(_22d)) {
        this.LogSeq("`638`", _22d);
        _232 = this.GetCurrentActivity();
        _231 = this.FindCommonAncestor(_232, _22a, _22d);
    } else {
        this.LogSeq("`1721`", _22d);
        this.LogSeq("`373`", _22d);
        _231 = this.GetRootActivity(_22d);
    }
    if (_232 !== null && _232.LearningObject.ItemIdentifier == _22a.LearningObject.ItemIdentifier) {
        this.LogSeq("`503`", _22d);
        this.LogSeq("`940`", _22d);
    } else {
        if (this.AreActivitiesSiblings(_232, _22a, _22d)) {
            this.LogSeq("`363`", _22d);
            this.LogSeq("`10`", _22d);
            var _237 = _22e.GetActivityListBetweenChildren(_232, _22a, false);
            this.LogSeq("`831`", _22d);
            if (_237.length === 0) {
                this.LogSeq("`427`", _22d);
                _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                this.LogSeqReturn(_236, _22d);
                return _236;
            }
            this.LogSeq("`449`", _22d);
            if (_22a.Ordinal > _232.Ordinal) {
                this.LogSeq("`1351`", _22d);
                _233 = FLOW_DIRECTION_FORWARD;
            } else {
                this.LogSeq("`1691`", _22d);
                this.LogSeq("`1325`", _22d);
                _233 = FLOW_DIRECTION_BACKWARD;
                _237.reverse();
            }
            this.LogSeq("`1011`", _22d);
            for (i = 0; i < _237.length; i++) {
                this.LogSeq("`518`", _22d);
                _234 = this.ChoiceActivityTraversalSubprocess(_237[i], _233, _22d, _22c);
                this.LogSeq("`712`", _22d);
                if (_234.Reachable === false) {
                    this.LogSeq("`140`", _22d);
                    _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, _234.Exception, "", false);
                    this.LogSeqReturn(_236, _22d);
                    return _236;
                }
            }
            this.LogSeq("`1459`", _22d);
        } else {
            if (_232 === null || _232.LearningObject.ItemIdentifier == _231.LearningObject.ItemIdentifier) {
                this.LogSeq("`213`", _22d);
                this.LogSeq("`248`", _22d);
                _22f = this.GetPathToAncestorInclusive(_22a, _231, false);
                this.LogSeq("`1095`", _22d);
                if (_22f.length === 0) {
                    this.LogSeq("`428`", _22d);
                    _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                    this.LogSeqReturn(_236, _22d);
                    return _236;
                }
                this.LogSeq("`1012`", _22d);
                for (i = _22f.length - 1; i >= 0; i--) {
                    this.LogSeq("`525`", _22d);
                    _234 = this.ChoiceActivityTraversalSubprocess(_22f[i], FLOW_DIRECTION_FORWARD, _22d, _22c);
                    this.LogSeq("`713`", _22d);
                    if (_234.Reachable === false) {
                        this.LogSeq("`141`", _22d);
                        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, _234.Exception, _234.ExceptionText, false);
                        this.LogSeqReturn(_236, _22d);
                        return _236;
                    }
                    this.LogSeq("`19`", _22d);
                    if (_22f[i].IsActive() === false && _22f[i].LearningObject.ItemIdentifier != _231.LearningObject.ItemIdentifier && _22f[i].GetPreventActivation() === true) {
                        this.LogSeqSimple("\"" + _22f[i] + "\" cannot be entered as a result of a choice request because of its prevent activation attribute. This choice request is not allowed.", _22c);
                        this.LogSeq("`603`" + PREVENT_ACTIVATION_ERROR + "`1565`", _22d);
                        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _22f[i].GetTitle()), false);
                        this.LogSeqReturn(_236, _22d);
                        return _236;
                    }
                }
                this.LogSeq("`1460`", _22d);
            } else {
                if (_22a.LearningObject.ItemIdentifier == _231.LearningObject.ItemIdentifier) {
                    this.LogSeq("`287`", _22d);
                    this.LogSeq("`344`", _22d);
                    _22f = this.GetPathToAncestorInclusive(_232, _231);
                    this.LogSeq("`1072`", _22d);
                    if (_22f.length === 0) {
                        this.LogSeq("`410`", _22d);
                        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to deliver"), false);
                        this.LogSeqReturn(_236, _22d);
                        return _236;
                    }
                    this.LogSeq("`996`", _22d);
                    for (i = 0; i < _22f.length; i++) {
                        this.LogSeq("`663`", _22d);
                        if (i != (_22f.length - 1)) {
                            this.LogSeq("`196`", _22d);
                            if (_22f[i].GetSequencingControlChoiceExit() === false) {
                                this.LogSeqSimple("\"" + _22f[i] + "\" cannot be exited as a result of a choice request because of its control choice exit attribute. This choice request is not allowed.", _22c);
                                this.LogSeq("`573`" + CONTROL_CHOICE_EXIT_ERROR_CHOICE + "`1565`", _22d);
                                _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONTROL_CHOICE_EXIT_ERROR_CHOICE, IntegrationImplementation.GetString("Your selection is not permitted.  Please select 'Next' or 'Previous' to move through '{0}'.", _22f[i]), false);
                                this.LogSeqReturn(_236, _22d);
                                return _236;
                            }
                        }
                    }
                    this.LogSeq("`1438`", _22d);
                } else {
                    this.LogSeq("`289`", _22d);
                    this.LogSeq("`251`", _22d);
                    _22f = this.GetPathToAncestorExclusive(_232, _231, false);
                    this.LogSeq("`1009`", _22d);
                    var _238 = null;
                    this.LogSeq("`574`", _22d);
                    for (i = 0; i < _22f.length; i++) {
                        this.LogSeq("`206`", _22d);
                        if (_22f[i].GetSequencingControlChoiceExit() === false) {
                            this.LogSeqSimple("\"" + _22f[i] + "\" cannot be exited as a result of a choice request because of its control choice exit attribute. This choice request is not allowed.", _22c);
                            this.LogSeq("`594`" + CONTROL_CHOICE_EXIT_ERROR_CHOICE + "`1565`", _22d);
                            _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONTROL_CHOICE_EXIT_ERROR_CHOICE, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _22f[i].GetTitle()), false);
                            this.LogSeqReturn(_236, _22d);
                            return _236;
                        }
                        this.LogSeq("`402`", _22d);
                        if (_238 === null) {
                            this.LogSeq("`734`", _22d);
                            if (_22f[i].GetConstrainedChoice() === true) {
                                this.LogSeq("`927`" + _22f[i] + "'", _22d);
                                _238 = _22f[i];
                            }
                        }
                    }
                    this.LogSeq("`988`", _22d);
                    if (_238 !== null) {
                        this.LogSeq("`469`", _22d);
                        if (this.IsActivity1BeforeActivity2(_238, _22a, _22d)) {
                            this.LogSeq("`529`", _22d);
                            _233 = FLOW_DIRECTION_FORWARD;
                        } else {
                            this.LogSeq("`1612`", _22d);
                            this.LogSeq("`516`", _22d);
                            _233 = FLOW_DIRECTION_BACKWARD;
                        }
                        this.LogSeq("`523`", _22d);
                        var _239 = this.ChoiceFlowSubprocess(_238, _233, _22d, _22c);
                        this.LogSeq("`559`", _22d);
                        var _23a = _239;
                        this.LogSeq("`7`", _22d);
                        if ((!_23a.IsActivityAnAvailableDescendent(_22a)) && (_22a != _238 && _22a != _23a)) {
                            this.LogSeqSimple("\"" + _238 + "\" has a constrained choice sequencing control so only activities which are logically next or previous are allowed to be targets of choice navigation. This choice request is not allowed.", _22c);
                            if (_233 == FLOW_DIRECTION_FORWARD) {
                                this.LogSeqSimple("The logically next activity is \"" + _23a + "\".", _22c);
                            } else {
                                this.LogSeqSimple("The logically previous activity is \"" + _23a + "\".", _22c);
                            }
                            this.LogSeq("`595`" + CONSTRAINED_CHOICE_ERROR + ")", _22d);
                            _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, CONSTRAINED_CHOICE_ERROR, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _238.GetTitle()), false);
                            this.LogSeqReturn(_236, _22d);
                            return _236;
                        }
                    }
                    this.LogSeq("`243`", _22d);
                    _22f = this.GetPathToAncestorInclusive(_22a, _231);
                    this.LogSeq("`1074`", _22d);
                    if (_22f.length === 0) {
                        this.LogSeq("`412`", _22d);
                        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-5", IntegrationImplementation.GetString("Nothing to open"), false);
                        this.LogSeqReturn(_236, _22d);
                        return _236;
                    }
                    this.LogSeq("`305`", _22d);
                    if (this.IsActivity1BeforeActivity2(_232, _22a, _22d)) {
                        this.LogSeq("`979`", _22d);
                        for (i = (_22f.length - 1); i >= 0; i--) {
                            if (i > 0) {
                                this.LogSeq("`234`" + i, _22d);
                                _234 = this.ChoiceActivityTraversalSubprocess(_22f[i], FLOW_DIRECTION_FORWARD, _22d, _22c);
                                this.LogSeq("`686`", _22d);
                                if (_234.Reachable === false) {
                                    this.LogSeq("`132`", _22d);
                                    _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, _234.Exception, _234.ExceptionText, false);
                                    this.LogSeqReturn(_236, _22d);
                                    return _236;
                                }
                            }
                            this.LogSeq("`15`", _22d);
                            if ((_22f[i].IsActive() === false) && (_22f[i] != _231) && (_22f[i].GetPreventActivation() === true)) {
                                this.LogSeqSimple("\"" + _22f[i] + "\" cannot be entered as a result of a choice request because of its prevent activation attribute. This choice request is not allowed.", _22c);
                                this.LogSeq("`576`" + PREVENT_ACTIVATION_ERROR + "`1565`", _22d);
                                _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _22f[i].GetTitle()), false);
                                this.LogSeqReturn(_236, _22d);
                                return _236;
                            }
                        }
                    } else {
                        this.LogSeq("`1665`", _22d);
                        this.LogSeq("`980`", _22d);
                        for (i = (_22f.length - 1); i >= 0; i--) {
                            this.LogSeq("`13`", _22d);
                            if ((_22f[i].IsActive() === false) && (_22f[i] != _231) && (_22f[i].GetPreventActivation() === true)) {
                                this.LogSeqSimple("\"" + _22f[i] + "\" cannot be entered as a result of a choice request because of its prevent activation attribute. This choice request is not allowed.", _22c);
                                this.LogSeq("`577`" + PREVENT_ACTIVATION_ERROR + "`1565`", _22d);
                                _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, PREVENT_ACTIVATION_ERROR, IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _22f[i].GetTitle()), false);
                                this.LogSeqReturn(_236, _22d);
                                return _236;
                            }
                        }
                    }
                    this.LogSeq("`1417`", _22d);
                }
            }
        }
    }
    this.LogSeq("`928`", _22d);
    if (_22a.IsALeaf() === true) {
        this.LogSeq("`492`", _22d);
        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(_22a, null, "", false);
        this.LogSeqReturn(_236, _22d);
        return _236;
    }
    this.LogSeq("`51`", _22d);
    var _23b = this.FlowSubprocess(_22a, FLOW_DIRECTION_FORWARD, true, _22d, _22c);
    this.LogSeq("`252`", _22d);
    if (_23b.Deliverable === false) {
        this.LogSeqSimple("A choice request for the \"" + _22a + "\" cluster did not flow to a deliverable SCO. Setting it to be the curent activity and prompting the user to make another selection.", _22c);
        if (this.LookAhead === false) {
            this.LogSeq("`647`", _22d);
            this.TerminateDescendentAttemptsProcess(_231, _22d, _22c);
            this.LogSeq("`840`", _22d);
            this.EndAttemptProcess(_231, false, _22d, false, _22c);
            this.LogSeq("`886`", _22d);
            this.SetCurrentActivity(_22a, _22d, _22c);
        }
        this.LogSeq("`438`", _22d);
        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(null, "SB.2.9-9", IntegrationImplementation.GetString("Please select another item from the menu."), false);
        this.LogSeqReturn(_236, _22d);
        return _236;
    } else {
        this.LogSeq("`1706`", _22d);
        this.LogSeq("`310`", _22d);
        _236 = new Sequencer_ChoiceSequencingRequestProcessResult(_23b.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_236, _22d);
        return _236;
    }
}

function Sequencer_ChoiceSequencingRequestProcessResult(_23c, _23d, _23e, _23f) {
    if (_23f === undefined) {
        Debug.AssertError("no value passed for hidden");
    }
    this.DeliveryRequest = _23c;
    this.Exception = _23d;
    this.ExceptionText = _23e;
    this.Hidden = _23f;
}
Sequencer_ChoiceSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", Hidden=" + this.Hidden;
};

function Sequencer_ClearSuspendedActivitySubprocess(_240, _241) {
    Debug.AssertError("Calling log not passed.", (_241 === undefined || _241 === null));
    var _242 = this.LogSeqAudit("`1115`" + _240 + ")", _241);
    var _243 = null;
    var _244 = null;
    var _245 = null;
    this.LogSeq("`605`", _242);
    if (this.IsSuspendedActivityDefined(_242)) {
        this.LogSeq("`598`", _242);
        _244 = this.GetSuspendedActivity(_242);
        _243 = this.FindCommonAncestor(_240, _244, _242);
        this.LogSeq("`342`", _242);
        _245 = this.GetPathToAncestorInclusive(_244, _243);
        this.LogSeq("`1002`", _242);
        if (_245.length > 0) {
            this.LogSeq("`334`", _242);
            for (var i = 0; i < _245.length; i++) {
                this.LogSeq("`1081`", _242);
                if (_245[i].IsALeaf()) {
                    this.LogSeq("`788`", _242);
                    _245[i].SetSuspended(false);
                } else {
                    this.LogSeq("`1589`", _242);
                    this.LogSeq("`398`", _242);
                    if (_245[i].HasSuspendedChildren() === false) {
                        this.LogSeq("`767`", _242);
                        _245[i].SetSuspended(false);
                    }
                }
            }
        }
        this.LogSeq("`608`", _242);
        this.ClearSuspendedActivity(_242);
    }
    this.LogSeq("`1003`", _242);
    this.LogSeqReturn("", _242);
    return;
}

function Sequencer_CompletionMeasureRollupProcess(_247, _248, _249) {
    Debug.AssertError("Calling log not passed.", (_248 === undefined || _248 === null));
    Debug.AssertError("Simple calling log not passed.", (_249 === undefined || _249 === null));
    var _24a = this.LogSeqAudit("`1116`" + _247 + ")", _248);
    _249 = this.LogSeqSimpleAudit("Rolling up the progress measure for \"" + _247 + "\".", _249);
    this.LogSeq("`933`", _24a);
    var _24b = 0;
    this.LogSeq("`1309`", _24a);
    var _24c = false;
    this.LogSeq("`1006`", _24a);
    var _24d = 0;
    this.LogSeq("`1170`", _24a);
    var _24e = _247.GetAvailableChildren();
    for (var i = 0; i < _24e.length; i++) {
        this.LogSeq("`631`", _24a);
        if (_24e[i].IsTracked() === true) {
            this.LogSeq("`259`", _24a);
            var _250 = _24e[i].GetCompletionProgressWeight();
            _24d += _250;
            this.LogSeq("`800`", _24a);
            if (_24e[i].GetAttemptCompletionAmountStatus() === true) {
                this.LogSeq("`90`", _24a);
                _24b += (_24e[i].GetAttemptCompletionAmount() * _250);
                this.LogSeqSimple("\"" + _24e[i] + "\" has a progress measure of " + _24e[i].GetAttemptCompletionAmount() + " and a weight of " + _250 + " so it contributes a weighted measure of " + (_24e[i].GetAttemptCompletionAmount() * _250) + ".", _249);
                this.LogSeq("`1223`", _24a);
                _24c = true;
            }
        } else {
            this.LogSeqSimple("\"" + _24e[i] + "\" is not tracked and will not contribute to progress measure rollup.", _249);
        }
    }
    this.LogSeq("`1242`", _24a);
    if (!_24c) {
        this.LogSeq("`320`", _24a);
        this.LogSeqSimple("No children had a progress measure to rollup, setting the completion amount status to unknown.", _249);
        this.LogSeqSimpleReturn("unknown", _249);
        _247.SetAttemptCompletionAmountStatus(false);
    } else {
        this.LogSeq("`1629`", _24a);
        this.LogSeq("`522`", _24a);
        if (_24d > 0) {
            this.LogSeq("`827`", _24a);
            _247.SetAttemptCompletionAmountStatus(true);
            this.LogSeq("`476`", _24a);
            var _251 = (_24b / _24d);
            _251 = RoundToPrecision(_251, 7);
            _247.SetAttemptCompletionAmount(_251);
            this.LogSeqSimple("Setting the attempt completion amount to the new weighted value of " + _251 + ".", _249);
            this.LogSeqSimpleReturn(_251, _249);
        } else {
            this.LogSeq("`1580`", _24a);
            this.LogSeq("`366`", _24a);
            _247.SetAttemptCompletionAmountStatus(false);
        }
    }
    this.LogSeq("`1007`", _24a);
    this.LogSeqReturn("", _24a);
    return;
}

function Sequencer_ContentDeliveryEnvironmentActivityDataSubProcess(_252, _253, _254) {
    if (_253 === undefined || _253 === null) {
        _253 = this.LogSeqAudit("Content Delivery Environment Activity Data SubProcess for " + activity.StringIdentifier);
    }
    if (_254 === undefined || _254 === null) {
        _254 = this.LogSeqSimpleAudit("Preparing data for delivery of \"" + _252 + "\".");
    }
    var _255 = (Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK || Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
    if (_255) {
        var _256 = this.PreviousActivity;
    } else {
        var _256 = this.CurrentActivity;
    }
    var _257 = this.GetSuspendedActivity(_253);
    var _258 = this.GetRootActivity(_253);
    var _259 = null;
    var _25a = false;
    this.LogSeq("`208`", _253);
    if (_257 != _252) {
        this.LogSeqSimple("Clearing out suspended activities.", _254);
        this.LogSeq("`554`", _253);
        this.ClearSuspendedActivitySubprocess(_252, _253);
    }
    this.LogSeq("`230`", _253);
    this.TerminateDescendentAttemptsProcess(_252, _253, _254);
    this.LogSeq("`66`", _253);
    _259 = this.GetPathToAncestorInclusive(_252, _258);
    this.LogSeqSimple("Setting activities along the current activity path to active and incrementing their attempt count if the activity was not previously active.", _254);
    this.LogSeq("`1082`", _253);
    var _25b = ConvertDateToIso8601String(new Date());
    for (var i = (_259.length - 1); i >= 0; i--) {
        this.LogSeq("`1542`" + _259[i] + "`1175`", _253);
        if (_255) {
            var _25d = _259[i].WasActiveBeforeLaunchOnClick;
        } else {
            var _25d = _259[i].IsActive();
        }
        if (_25d === false) {
            this.LogSeq("`984`", _253);
            if (_259[i].IsTracked()) {
                this.LogSeq("`114`", _253);
                if (_259[i].IsSuspended()) {
                    this.LogSeq("`812`", _253);
                    _259[i].SetSuspended(false);
                } else {
                    this.LogSeq("`1623`", _253);
                    this.LogSeq("`485`", _253);
                    _259[i].IncrementAttemptCount();
                    this.LogSeq("`357`", _253);
                    if (_259[i].GetAttemptCount() == 1) {
                        this.LogSeq("`768`", _253);
                        _259[i].SetActivityProgressStatus(true);
                        _25a = true;
                    }
                    this.LogSeqSimple("Started a new attempt with fresh sequencing data for \"" + _259[i] + "\" (attempt number " + _259[i].GetAttemptCount() + ") .", _254);
                    this.LogSeq("`161`", _253);
                    _259[i].InitializeForNewAttempt(true, true);
                    var atts = {
                        ev: "AttemptStart",
                        an: _259[i].GetAttemptCount(),
                        ai: _259[i].ItemIdentifier,
                        at: _259[i].LearningObject.Title
                    };
                    this.WriteHistoryLog("", atts);
                    _259[i].SetAttemptStartTimestampUtc(_25b);
                    _259[i].SetAttemptAbsoluteDuration("PT0H0M0S");
                    _259[i].SetAttemptExperiencedDurationTracked("PT0H0M0S");
                    _259[i].SetAttemptExperiencedDurationReported("PT0H0M0S");
                    if (Control.Package.Properties.ResetRunTimeDataTiming == RESET_RT_DATA_TIMING_ON_EACH_NEW_SEQUENCING_ATTEMPT) {
                        if (_259[i].IsDeliverable() === true) {
                            if (_25a === false) {
                                this.LogSeqSimple("Resetting the CMI runtime data for \"" + _259[i] + "\".", _254);
                                var atts = {
                                    ev: "ResetRuntime",
                                    ai: _259[i].ItemIdentifier,
                                    at: _259[i].LearningObject.Title
                                };
                                this.WriteHistoryLog("", atts);
                            }
                            _259[i].RunTime.ResetState();
                        }
                    }
                    this.LogSeq("`798`" + Control.Package.ObjectivesGlobalToSystem + "`943`", _253);
                    if (Control.Package.ObjectivesGlobalToSystem === false && _259[i].IsTheRoot() === true) {
                        this.LogSeq("`544`", _253);
                        this.LogSeqSimple("A new attempt on the root activity is starting, so reset all global objectives (since objectives global to system is false).", _254);
                        this.ResetGlobalObjectives();
                    }
                    this.LogSeq("`698`" + Control.Package.SharedDataGlobalToSystem + "`943`", _253);
                    if (Control.Package.SharedDataGlobalToSystem === false && _259[i].IsTheRoot() === true) {
                        this.LogSeq("`672`", _253);
                        this.LogSeqSimple("A new attempt on the root activity is starting, so reset all shared data (since shared data global to system is false).", _254);
                        this.ResetSharedData();
                    }
                }
            }
            _259[i].SetAttemptedDuringThisAttempt();
        }
    }
}

function Sequencer_ContentDeliveryEnvironmentProcess(_25f, _260, _261) {
    Debug.AssertError("Calling log not passed.", (_260 === undefined || _260 === null));
    Debug.AssertError("Simple calling log not passed.", (_261 === undefined || _261 === null));
    var _262 = this.LogSeqAudit("`1131`" + _25f + ")", _260);
    var _263 = (Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK || Control.Package.Properties.ScoLaunchType === LAUNCH_TYPE_POPUP_AFTER_CLICK_WITHOUT_BROWSER_TOOLBAR);
    var _264 = this.GetCurrentActivity();
    var _265 = this.GetSuspendedActivity(_262);
    var _266 = this.GetRootActivity(_262);
    var _267 = null;
    var _268;
    this.LogSeq("`200`", _262);
    if (_264 !== null && _264.IsActive()) {
        this.LogSeq("`264`", _262);
        _268 = new Sequencer_ContentDeliveryEnvironmentProcessResult(false, "DB.2.1", IntegrationImplementation.GetString("The previous activity must be terminated before a new activity may be attempted"));
        this.LogSeqReturn(_268, _262);
        return _268;
    }
    if (!_263) {
        this.ContentDeliveryEnvironmentActivityDataSubProcess(_25f, _260);
    } else {
        this.LogSeq("`224`", _262);
    }
    this.LogSeq("`66`", _262);
    _267 = this.GetPathToAncestorInclusive(_25f, _266);
    this.LogSeq("`1082`", _262);
    for (var i = (_267.length - 1); i >= 0; i--) {
        if (_263) {
            _267[i].WasActiveBeforeLaunchOnClick = _267[i].IsActive();
        }
        this.LogSeq("`1542`" + _267[i] + "`1175`", _262);
        if (_267[i].IsActive() === false) {
            this.LogSeq("`890`", _262);
            _267[i].SetActive(true);
        }
    }
    this.LogSeq("`231`" + _25f.GetItemIdentifier(), _262);
    if (_263) {
        this.PreviousActivity = _264;
    }
    this.SetCurrentActivity(_25f, _262, _261);
    this.LogSeq("`1138`", _262);
    this.SetSuspendedActivity(null);
    this.LogSeq("`822`", _262);
    _268 = new Sequencer_ContentDeliveryEnvironmentProcessResult(true, null, "");
    this.LogSeqReturn(_268, _262);
    this.LogSeqSimple("Delivering activity \"" + _25f + "\".", _261);
    Control.DeliverActivity(_25f);
    return _268;
}

function Sequencer_ContentDeliveryEnvironmentProcessResult(_26a, _26b, _26c) {
    this.Valid = _26a;
    this.Exception = _26b;
    this.ExceptionText = _26c;
}
Sequencer_ContentDeliveryEnvironmentProcessResult.prototype.toString = function() {
    return "Valid=" + this.Valid + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ContinueSequencingRequestProcess(_26d, _26e) {
    Debug.AssertError("Calling log not passed.", (_26d === undefined || _26d === null));
    Debug.AssertError("Simple calling log not passed.", (_26e === undefined || _26e === null));
    var _26f = this.LogSeqAudit("`1132`", _26d);
    var _270;
    this.LogSeq("`500`", _26f);
    if (!this.IsCurrentActivityDefined(_26f)) {
        this.LogSeq("`422`", _26f);
        _270 = new Sequencer_ContinueSequencingRequestProcessResult(null, "SB.2.7-1", IntegrationImplementation.GetString("The sequencing session has not begun yet."), false);
        this.LogSeqReturn(_270, _26f);
        return _270;
    }
    var _271 = this.GetCurrentActivity();
    this.LogSeq("`709`", _26f);
    if (!_271.IsTheRoot()) {
        var _272 = this.Activities.GetParentActivity(_271);
        this.LogSeq("`299`", _26f);
        if (_272.GetSequencingControlFlow() === false) {
            this.LogSeq("`566`", _26f);
            this.LogSeqSimple("Flow navigation is not allowed within \"" + _272 + "\". Prompting the used to make a different selection.", _26e);
            _270 = new Sequencer_ContinueSequencingRequestProcessResult(null, "SB.2.7-2", IntegrationImplementation.GetString("You cannot use 'Next' to enter {0}. Please select a menu item to continue.", _272.GetTitle()), false);
            this.LogSeqReturn(_270, _26f);
            return _270;
        }
    }
    this.LogSeq("`136`", _26f);
    var _273 = this.FlowSubprocess(_271, FLOW_DIRECTION_FORWARD, false, _26f, _26e);
    this.LogSeq("`994`", _26f);
    if (_273.Deliverable === false) {
        this.LogSeq("`63`", _26f);
        _270 = new Sequencer_ContinueSequencingRequestProcessResult(null, _273.Exception, _273.ExceptionText, _273.EndSequencingSession);
        this.LogSeqReturn(_270, _26f);
        return _270;
    } else {
        this.LogSeq("`1719`", _26f);
        this.LogSeq("`319`", _26f);
        _270 = new Sequencer_ContinueSequencingRequestProcessResult(_273.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_270, _26f);
        return _270;
    }
}

function Sequencer_ContinueSequencingRequestProcessResult(_274, _275, _276, _277) {
    Debug.AssertError("Invalid endSequencingSession (" + _277 + ") passed to ContinueSequencingRequestProcessResult.", (_277 != true && _277 != false));
    this.DeliveryRequest = _274;
    this.Exception = _275;
    this.ExceptionText = _276;
    this.EndSequencingSession = _277;
}
Sequencer_ContinueSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_DeliveryRequestProcess(_278, _279, _27a) {
    Debug.AssertError("Calling log not passed.", (_279 === undefined || _279 === null));
    Debug.AssertError("Simple calling log not passed.", (_27a === undefined || _27a === null));
    var _27b = this.LogSeqAudit("`1330`" + _278 + ")", _279);
    var _27c;
    var _27d;
    this.LogSeq("`873`" + _278 + "`955`", _27b);
    if (!_278.IsALeaf()) {
        this.LogSeq("`581`", _27b);
        _27d = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-1", IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _278.GetTitle()));
        this.LogSeqReturn(_27d, _27b);
        return _27d;
    }
    this.LogSeq("`207`", _27b);
    var _27e = this.GetActivityPath(_278, true);
    this.LogSeq("`837`", _27b);
    if (_27e.length === 0) {
        this.LogSeq("`582`", _27b);
        _27d = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-2", IntegrationImplementation.GetString("Nothing to open"));
        this.LogSeqReturn(_27d, _27b);
        return _27d;
    }
    this.LogSeq("`528`", _27b);
    for (var i = 0; i < _27e.length; i++) {
        this.LogSeq("`858`" + _27e[i], _27b);
        _27c = this.CheckActivityProcess(_27e[i], _27b, _27a);
        this.LogSeq("`902`", _27b);
        if (_27c === true) {
            this.LogSeq("`563`", _27b);
            _27d = new Sequencer_DeliveryRequestProcessResult(false, "DB.1.1-3", IntegrationImplementation.GetString("You cannot select '{0}' at this time.  Please select another menu item to continue with '{0}.'", _278.GetTitle()));
            this.LogSeqReturn(_27d, _27b);
            return _27d;
        }
    }
    this.LogSeq("`659`", _27b);
    _27d = new Sequencer_DeliveryRequestProcessResult(true, null, "");
    this.LogSeqReturn(_27d, _27b);
    return _27d;
}

function Sequencer_DeliveryRequestProcessResult(_280, _281, _282) {
    this.Valid = _280;
    this.Exception = _281;
    this.ExceptionText = _282;
}
Sequencer_DeliveryRequestProcessResult.prototype.toString = function() {
    return "Valid=" + this.Valid + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_EndAttemptProcess(_283, _284, _285, _286, _287) {
    Debug.AssertError("Calling log not passed.", (_285 === undefined || _285 === null));
    Debug.AssertError("Simple calling log not passed.", (_287 === undefined || _287 === null));
    if (_286 === undefined || _286 === null) {
        _286 = false;
    }
    var _288 = this.LogSeqAudit("`1480`" + _283 + ", " + _284 + ")", _285);
    _287 = this.LogSeqSimpleAudit("Ending the current attempt on \"" + _283 + "\".", _287);
    this.LogSeq("`1503`" + _283.GetItemIdentifier() + "`1694`", _288);
    var i;
    var _28a = new Array();
    if (_283.IsALeaf()) {
        this.LogSeq("`1019`", _288);
        if (_283.IsTracked() && _283.WasLaunchedThisSession()) {
            this.LogSeq("`863`", _288);
            this.LogSeqSimple("Transferring run-time data to the activity tree.", _287);
            _283.TransferRteDataToActivity();
            this.LogSeq("`312`", _288);
            if (_283.IsSuspended() === false) {
                this.LogSeq("`284`", _288);
                if (_283.IsCompletionSetByContent() === false) {
                    this.LogSeq("`78`", _288);
                    if (_283.GetAttemptProgressStatus() === false && _283.GetCompletionStatusChangedDuringRuntime() === false) {
                        this.LogSeqSimple("The activity did not set completion status and indicates that it will not so automatically marking the activity as completed.", _287);
                        this.LogSeq("`744`", _288);
                        _283.SetAttemptProgressStatus(true);
                        this.LogSeq("`716`", _288);
                        _283.SetAttemptCompletionStatus(true);
                        _283.WasAutoCompleted = true;
                    }
                }
                this.LogSeq("`297`", _288);
                if (_283.IsObjectiveSetByContent() === false) {
                    this.LogSeq("`596`", _288);
                    var _28b = _283.GetPrimaryObjective();
                    this.LogSeq("`64`", _288);
                    if (_28b.GetProgressStatus(_283, false) === false && _283.GetSuccessStatusChangedDuringRuntime() === false && _28b.GetSuccessStatusChangedDuringRuntime(_283) === false) {
                        this.LogSeqSimple("The activity did not set satisfaction status and indicates that it will not so automatically marking the activity as satisfied.", _287);
                        this.LogSeq("`668`", _288);
                        _28b.SetProgressStatus(true, false, _283, true, true);
                        this.LogSeq("`658`", _288);
                        _28b.SetSatisfiedStatus(true, false, _283);
                        _283.WasAutoSatisfied = true;
                    }
                }
            }
        }
    } else {
        this.LogSeq("`1226`", _288);
        this.LogSeq("`109`", _288);
        if (this.ActivityHasSuspendedChildren(_283, _288)) {
            this.LogSeq("`834`", _288);
            _283.SetSuspended(true);
            this.LogSeqSimple("\"" + _283 + "\" has suspend children and will be marked as suspended.", _287);
        } else {
            this.LogSeq("`1723`", _288);
            this.LogSeq("`820`", _288);
            _283.SetSuspended(false);
            this.LogSeqSimple("\"" + _283 + "\" does not have suspend children and will not be marked as suspended.", _287);
        }
    }
    if (_286 === false) {
        this.LogSeq("`462`", _288);
        _283.SetActive(false);
    }
    var _28c;
    if (_284 === false) {
        this.LogSeq("`250`", _288);
        _28c = this.OverallRollupProcess(_283, _288, _287);
    } else {
        this.LogSeq("`527`", _288);
        _28a[0] = _283;
    }
    this.LogSeq("`235`", _288);
    var _28d = this.FindActivitiesAffectedByWriteMaps(_283);
    var _28e = this.FindDistinctParentsOfActivitySet(_28d);
    if (_284 === false) {
        this.LogSeq("`457`", _288);
        var _28f = this.GetMinimalSubsetOfActivitiesToRollup(_28e, _28c);
        if (_28f.length > 0) {
            this.LogSeqSimple("Invoking rollup for activities that are affected by write maps.", _287);
        }
        for (i = 0; i < _28f.length; i++) {
            if (_28f[i] !== null) {
                this.OverallRollupProcess(_28f[i], _288, _287);
            }
        }
    } else {
        this.LogSeq("`218`", _288);
        _28a = _28a.concat(_28e);
    }
    if (this.LookAhead === false && _286 === false) {
        this.RandomizeChildrenProcess(_283, true, _288, _287);
    }
    this.LogSeq("`1310`", _288);
    this.LogSeqReturn("", _288);
    return _28a;
}

function Sequencer_EvaluateRollupConditionsSubprocess(_290, _291, _292, _293) {
    Debug.AssertError("Calling log not passed.", (_292 === undefined || _292 === null));
    Debug.AssertError("Simple calling log not passed.", (_293 === undefined || _293 === null));
    var _294 = this.LogSeqAudit("`1039`" + _290 + ", " + _291 + ")", _292);
    var _295;
    var _296;
    this.LogSeq("`387`", _294);
    var _297 = new Array();
    var i;
    this.LogSeq("`792`", _294);
    for (i = 0; i < _291.Conditions.length; i++) {
        this.LogSeq("`36`", _294);
        _295 = this.EvaluateRollupRuleCondition(_290, _291.Conditions[i], _293);
        this.LogSeq("`369`", _294);
        if (_291.Conditions[i].Operator == RULE_CONDITION_OPERATOR_NOT && _295 != RESULT_UNKNOWN) {
            this.LogSeq("`1142`", _294);
            _295 = (!_295);
        }
        this.LogSeq("`973`" + _295 + "`532`", _294);
        _297[_297.length] = _295;
    }
    this.LogSeq("`308`", _294);
    if (_297.length === 0) {
        this.LogSeq("`692`", _294);
        return RESULT_UNKNOWN;
    }
    this.LogSeq("`1107`" + _291.ConditionCombination + "`285`", _294);
    if (_291.ConditionCombination == RULE_CONDITION_COMBINATION_ANY) {
        _296 = false;
        for (i = 0; i < _297.length; i++) {
            _296 = Sequencer_LogicalOR(_296, _297[i]);
        }
        if (_291.Conditions.length > 1) {
            this.LogSeqSimple("Are ANY of the conditions true=" + _296, _293);
        }
    } else {
        _296 = true;
        for (i = 0; i < _297.length; i++) {
            _296 = Sequencer_LogicalAND(_296, _297[i]);
        }
        if (_291.Conditions.length > 1) {
            this.LogSeqSimple("Are ALL of the conditions true=" + _296, _293);
        }
    }
    this.LogSeq("`497`", _294);
    this.LogSeqReturn(_296, _294);
    return _296;
}

function Sequencer_EvaluateRollupRuleCondition(_299, _29a, _29b) {
    var _29c = null;
    switch (_29a.Condition) {
        case ROLLUP_RULE_CONDITION_SATISFIED:
            _29c = _299.IsSatisfied("");
            this.LogSeqSimple("\"" + _299 + "\" satisfied = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
            _29c = _299.IsObjectiveStatusKnown("", false);
            this.LogSeqSimple("\"" + _299 + "\" objective status known = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
            _29c = _299.IsObjectiveMeasureKnown("", false);
            this.LogSeqSimple("\"" + _299 + "\" objective measure known = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_COMPLETED:
            _29c = _299.IsCompleted("", false);
            this.LogSeqSimple("\"" + _299 + "\" completed = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
            _29c = _299.IsActivityProgressKnown("", false);
            this.LogSeqSimple("\"" + _299 + "\" activity progress known = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_ATTEMPTED:
            _29c = _299.IsAttempted();
            this.LogSeqSimple("\"" + _299 + "\" attempted = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
            _29c = _299.IsAttemptLimitExceeded();
            this.LogSeqSimple("\"" + _299 + "\" attempt limit exceeded = " + _29c, _29b);
            break;
        case ROLLUP_RULE_CONDITION_NEVER:
            _29c = false;
            this.LogSeqSimple("\"" + _299 + "\": 'never' condition always equals false", _29b);
            break;
        default:
            this.LogSeq("`1368`", logParent);
            break;
    }
    return _29c;
}

function Sequencer_ExitSequencingRequestProcess(_29d, _29e) {
    Debug.AssertError("Calling log not passed.", (_29d === undefined || _29d === null));
    Debug.AssertError("Simple calling log not passed.", (_29e === undefined || _29e === null));
    var _29f = this.LogSeqAudit("`1217`", _29d);
    var _2a0;
    this.LogSeq("`490`", _29f);
    if (!this.IsCurrentActivityDefined(_29f)) {
        this.LogSeq("`512`", _29f);
        _2a0 = new Sequencer_ExitSequencingRequestProcessResult(false, "SB.2.11-1", IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed until the sequencing session has begun."));
        this.LogSeqReturn(_2a0, _29f);
        return _2a0;
    }
    var _2a1 = this.GetCurrentActivity();
    this.LogSeq("`323`", _29f);
    if (_2a1.IsActive()) {
        this.LogSeq("`513`", _29f);
        _2a0 = new Sequencer_ExitSequencingRequestProcessResult(false, "SB.2.11-2", IntegrationImplementation.GetString("An 'Exit Sequencing' request cannot be processed while an activity is still active."));
        this.LogSeqReturn(_2a0, _29f);
        return _2a0;
    }
    this.LogSeq("`763`", _29f);
    if (_2a1.IsTheRoot() || this.CourseIsSingleSco() === true) {
        this.LogSeq("`219`", _29f);
        if (_2a1.IsTheRoot()) {
            this.LogSeqSimple("Exiting the root activity causes the entire course to exit.", _29e);
        } else {
            this.LogSeqSimple("Exiting a SCO that is the only SCO in the course causes the entire course to exit.", _29e);
        }
        _2a0 = new Sequencer_ExitSequencingRequestProcessResult(true, null, "");
        this.LogSeqReturn(_2a0, _29f);
        return _2a0;
    }
    this.LogSeq("`556`", _29f);
    _2a0 = new Sequencer_ExitSequencingRequestProcessResult(false, null, "");
    this.LogSeqReturn(_2a0, _29f);
    return _2a0;
}

function Sequencer_ExitSequencingRequestProcessResult(_2a2, _2a3, _2a4) {
    Debug.AssertError("Invalid endSequencingSession (" + _2a2 + ") passed to ExitSequencingRequestProcessResult.", (_2a2 != true && _2a2 != false));
    this.EndSequencingSession = _2a2;
    this.Exception = _2a3;
    this.ExceptionText = _2a4;
}
Sequencer_ExitSequencingRequestProcessResult.prototype.toString = function() {
    return "EndSequencingSession=" + this.EndSequencingSession + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_FlowActivityTraversalSubprocess(_2a5, _2a6, _2a7, _2a8, _2a9) {
    Debug.AssertError("Calling log not passed.", (_2a8 === undefined || _2a8 === null));
    Debug.AssertError("Simple calling log not passed.", (_2a9 === undefined || _2a9 === null));
    var _2aa = this.LogSeqAudit("`1136`" + _2a5 + ", " + _2a6 + ", " + _2a7 + ")", _2a8);
    var _2ab;
    var _2ac;
    var _2ad;
    var _2ae;
    var _2af;
    var _2b0 = this.Activities.GetParentActivity(_2a5);
    this.LogSeq("`458`", _2aa);
    if (_2b0.GetSequencingControlFlow() === false) {
        this.LogSeqSimple("\"" + _2b0 + "\" does not allow flow navigation, stopping and prompting the user to make another selection.", _2a9);
        this.LogSeq("`388`", _2aa);
        _2af = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _2a5, "SB.2.2-1", IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _2b0.GetTitle()), false);
        this.LogSeqReturn(_2af, _2aa);
        return _2af;
    }
    this.LogSeq("`535`", _2aa);
    _2ab = this.SequencingRulesCheckProcess(_2a5, RULE_SET_SKIPPED, _2aa, _2a9);
    this.LogSeq("`358`", _2aa);
    if (_2ab !== null) {
        this.LogSeqSimple("\"" + _2a5 + "\" is skipped, considering the next activity for delivery.", _2a9);
        this.LogSeq("`185`", _2aa);
        _2ac = this.FlowTreeTraversalSubprocess(_2a5, _2a6, _2a7, false, _2aa, _2a9);
        this.LogSeq("`636`", _2aa);
        if (_2ac.NextActivity === null) {
            this.LogSeq("`32`", _2aa);
            _2af = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _2a5, _2ac.Exception, _2ac.ExceptionText, _2ac.EndSequencingSession);
            this.LogSeqReturn(_2af, _2aa);
            return _2af;
        } else {
            this.LogSeq("`1688`", _2aa);
            this.LogSeq("`67`", _2aa);
            if (_2a7 == FLOW_DIRECTION_BACKWARD && _2ac.TraversalDirection == FLOW_DIRECTION_BACKWARD) {
                this.LogSeq("`35`", _2aa);
                _2ad = this.FlowActivityTraversalSubprocess(_2ac.NextActivity, _2ac.TraversalDirection, null, _2aa, _2a9);
            } else {
                this.LogSeq("`1636`", _2aa);
                this.LogSeq("`9`", _2aa);
                _2ad = this.FlowActivityTraversalSubprocess(_2ac.NextActivity, _2a6, _2a7, _2aa, _2a9);
            }
            this.LogSeq("`232`", _2aa);
            _2af = _2ad;
            this.LogSeqReturn(_2af, _2aa);
            return _2af;
        }
    }
    this.LogSeq("`565`", _2aa);
    _2ae = this.CheckActivityProcess(_2a5, _2aa, _2a9);
    this.LogSeq("`925`", _2aa);
    if (_2ae === true) {
        this.LogSeq("`389`", _2aa);
        _2af = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _2a5, "SB.2.2-2", IntegrationImplementation.GetString("'{0}' is not available at this time.  Please select another menu item to continue.", _2a5.GetTitle()), false);
        this.LogSeqReturn(_2af, _2aa);
        return _2af;
    }
    this.LogSeq("`280`", _2aa);
    if (_2a5.IsALeaf() === false) {
        this.LogSeq("`158`", _2aa);
        _2ac = this.FlowTreeTraversalSubprocess(_2a5, _2a6, null, true, _2aa, _2a9);
        this.LogSeq("`637`", _2aa);
        if (_2ac.NextActivity === null) {
            this.LogSeq("`33`", _2aa);
            _2af = new Sequencer_FlowActivityTraversalSubprocessReturnObject(false, _2a5, _2ac.Exception, _2ac.ExceptionText, _2ac.EndSequencingSession);
            this.LogSeqReturn(_2af, _2aa);
            return _2af;
        } else {
            this.LogSeq("`1689`", _2aa);
            this.LogSeq("`44`", _2aa);
            if (_2a6 == FLOW_DIRECTION_BACKWARD && _2ac.TraversalDirection == FLOW_DIRECTION_FORWARD) {
                this.LogSeq("`22`", _2aa);
                _2ad = this.FlowActivityTraversalSubprocess(_2ac.NextActivity, FLOW_DIRECTION_FORWARD, FLOW_DIRECTION_BACKWARD, _2aa, _2a9);
            } else {
                this.LogSeq("`1637`", _2aa);
                this.LogSeq("`29`", _2aa);
                _2ad = this.FlowActivityTraversalSubprocess(_2ac.NextActivity, _2a6, null, _2aa, _2a9);
            }
            this.LogSeq("`227`", _2aa);
            _2af = _2ad;
            this.LogSeqReturn(_2af, _2aa);
            return _2af;
        }
    }
    this.LogSeq("`359`", _2aa);
    _2af = new Sequencer_FlowActivityTraversalSubprocessReturnObject(true, _2a5, null, "", false);
    this.LogSeqReturn(_2af, _2aa);
    return _2af;
}

function Sequencer_FlowActivityTraversalSubprocessReturnObject(_2b1, _2b2, _2b3, _2b4, _2b5) {
    Debug.AssertError("Invalid endSequencingSession (" + _2b5 + ") passed to FlowActivityTraversalSubprocessReturnObject.", (_2b5 != true && _2b5 != false));
    this.Deliverable = _2b1;
    this.NextActivity = _2b2;
    this.Exception = _2b3;
    this.ExceptionText = _2b4;
    this.EndSequencingSession = _2b5;
}
Sequencer_FlowActivityTraversalSubprocessReturnObject.prototype.toString = function() {
    return "Deliverable=" + this.Deliverable + ", NextActivity=" + this.NextActivity + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_FlowSubprocess(_2b6, _2b7, _2b8, _2b9, _2ba) {
    Debug.AssertError("Calling log not passed.", (_2b9 === undefined || _2b9 === null));
    Debug.AssertError("Simple calling log not passed.", (_2ba === undefined || _2ba === null));
    var _2bb = this.LogSeqAudit("`1516`" + _2b6 + ", " + _2b7 + ", " + _2b8 + ")", _2b9);
    var _2bc;
    this.LogSeq("`508`", _2bb);
    var _2bd = _2b6;
    this.LogSeq("`4`", _2bb);
    var _2be = this.FlowTreeTraversalSubprocess(_2bd, _2b7, null, _2b8, _2bb, _2ba);
    this.LogSeq("`491`", _2bb);
    if (_2be.NextActivity === null) {
        this.LogSeq("`41`", _2bb);
        _2bc = new Sequencer_FlowSubprocessResult(_2bd, false, _2be.Exception, _2be.ExceptionText, _2be.EndSequencingSession);
        this.LogSeqReturn(_2bc, _2bb);
        return _2bc;
    } else {
        this.LogSeq("`1718`", _2bb);
        this.LogSeq("`557`", _2bb);
        _2bd = _2be.NextActivity;
        this.LogSeq("`48`", _2bb);
        var _2bf = this.FlowActivityTraversalSubprocess(_2bd, _2b7, null, _2bb, _2ba);
        this.LogSeq("`0`", _2bb);
        _2bc = new Sequencer_FlowSubprocessResult(_2bf.NextActivity, _2bf.Deliverable, _2bf.Exception, _2bf.ExceptionText, _2bf.EndSequencingSession);
        this.LogSeqReturn(_2bc, _2bb);
        return _2bc;
    }
}

function Sequencer_FlowSubprocessResult(_2c0, _2c1, _2c2, _2c3, _2c4) {
    Debug.AssertError("Invalid endSequencingSession (" + _2c4 + ") passed to FlowSubprocessResult.", (_2c4 != true && _2c4 != false));
    this.IdentifiedActivity = _2c0;
    this.Deliverable = _2c1;
    this.Exception = _2c2;
    this.ExceptionText = _2c3;
    this.EndSequencingSession = _2c4;
}
Sequencer_FlowSubprocessResult.prototype.toString = function() {
    return "IdentifiedActivity=" + this.IdentifiedActivity + ", Deliverable=" + this.Deliverable + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_FlowTreeTraversalSubprocess(_2c5, _2c6, _2c7, _2c8, _2c9, _2ca) {
    Debug.AssertError("Calling log not passed.", (_2c9 === undefined || _2c9 === null));
    Debug.AssertError("Simple calling log not passed.", (_2ca === undefined || _2ca === null));
    var _2cb = this.LogSeqAudit("`1238`" + _2c5 + ", " + _2c6 + ", " + _2c7 + ", " + _2c8 + ")", _2c9);
    var _2cc;
    var _2cd;
    var _2ce;
    var _2cf;
    var _2d0;
    var _2d1;
    var _2d2 = this.Activities.GetParentActivity(_2c5);
    this.LogSeq("`1202`", _2cb);
    _2cc = false;
    this.LogSeq("`24`", _2cb);
    if (_2c7 !== null && _2c7 == FLOW_DIRECTION_BACKWARD && _2d2.IsActivityTheLastAvailableChild(_2c5)) {
        this.LogSeq("`1155`", _2cb);
        _2c6 = FLOW_DIRECTION_BACKWARD;
        this.LogSeq("`552`", _2cb);
        _2c5 = _2d2.GetFirstAvailableChild();
        this.LogSeq("`1174`", _2cb);
        _2cc = true;
    }
    this.LogSeq("`986`", _2cb);
    if (_2c6 == FLOW_DIRECTION_FORWARD) {
        this.LogSeq("`20`", _2cb);
        if ((this.IsActivityLastOverall(_2c5, _2cb)) || (_2c8 === false && _2c5.IsTheRoot() === true)) {
            this.LogSeqSimple("A continue request from the end of the course results in exiting the entire course.", _2ca);
            this.LogSeq("`572`", _2cb);
            this.TerminateDescendentAttemptsProcess(this.Activities.GetRootActivity(), _2cb, _2ca);
            this.LogSeq("`174`", _2cb);
            _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, null, null, true);
            this.LogSeqReturn(_2d1, _2cb);
            return _2d1;
        }
        this.LogSeq("`764`", _2cb);
        if (_2c5.IsALeaf() || _2c8 === false) {
            this.LogSeq("`478`", _2cb);
            if (_2d2.IsActivityTheLastAvailableChild(_2c5)) {
                this.LogSeq("`28`", _2cb);
                _2cd = this.FlowTreeTraversalSubprocess(_2d2, FLOW_DIRECTION_FORWARD, null, false, _2cb, _2ca);
                this.LogSeq("`225`", _2cb);
                _2d1 = _2cd;
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            } else {
                this.LogSeq("`1632`", _2cb);
                this.LogSeq("`298`", _2cb);
                _2ce = _2c5.GetNextSibling();
                this.LogSeq("`201`", _2cb);
                _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_2ce, _2c6, null, "", false);
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            }
        } else {
            this.LogSeq("`1156`", _2cb);
            this.LogSeq("`392`", _2cb);
            _2cf = _2c5.GetAvailableChildren();
            if (_2cf.length > 0) {
                this.LogSeq("`332`" + _2cf[0] + "); Traversal Direction: traversal direction (" + _2c6 + "); Exception: n/a )", _2cb);
                _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_2cf[0], _2c6, null, "", false);
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            } else {
                this.LogSeq("`1633`", _2cb);
                this.LogSeq("`421`", _2cb);
                _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-2", IntegrationImplementation.GetString("The activity '{0}' does not have any available children to deliver.", _2c5.GetTitle()), false);
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            }
        }
    }
    this.LogSeq("`976`", _2cb);
    if (_2c6 == FLOW_DIRECTION_BACKWARD) {
        this.LogSeq("`465`", _2cb);
        if (_2c5.IsTheRoot()) {
            this.LogSeq("`437`", _2cb);
            _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-3", IntegrationImplementation.GetString("You have reached the beginning of the course."), false);
            this.LogSeqReturn(_2d1, _2cb);
            return _2d1;
        }
        this.LogSeq("`765`", _2cb);
        if (_2c5.IsALeaf() || _2c8 === false) {
            this.LogSeq("`337`", _2cb);
            if (_2cc === false) {
                this.LogSeq("`317`", _2cb);
                if (_2d2.GetSequencingControlForwardOnly() === true) {
                    this.LogSeqSimple("\"" + _2d2 + "\" cannot be moved through backwards (sequencing control forward only). It must be entered from the beginning and proceed forward. Navigation request not allowed.", _2ca);
                    this.LogSeq("`393`", _2cb);
                    _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-4", IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.", _2d2.GetTitle()), false);
                    this.LogSeqReturn(_2d1, _2cb);
                    return _2d1;
                }
            }
            this.LogSeq("`471`", _2cb);
            if (_2d2.IsActivityTheFirstAvailableChild(_2c5)) {
                this.LogSeq("`25`", _2cb);
                _2cd = this.FlowTreeTraversalSubprocess(_2d2, FLOW_DIRECTION_BACKWARD, null, false, _2cb, _2ca);
                this.LogSeq("`226`", _2cb);
                _2d1 = _2cd;
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            } else {
                this.LogSeq("`1634`", _2cb);
                this.LogSeq("`267`", _2cb);
                _2d0 = _2c5.GetPreviousSibling();
                this.LogSeq("`809`" + _2d0 + "`1546`" + _2c6 + "`1644`", _2cb);
                _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_2d0, _2c6, null, "", false);
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            }
        } else {
            this.LogSeq("`1094`", _2cb);
            this.LogSeq("`376`", _2cb);
            _2cf = _2c5.GetAvailableChildren();
            if (_2cf.length > 0) {
                this.LogSeq("`669`", _2cb);
                if (_2c5.GetSequencingControlForwardOnly() === true) {
                    this.LogSeqSimple("\"" + _2c5 + "\" cannot be entered backwards (sequencing control forward only), it must be entered from the beginning. Attempting to deliver its first child (" + _2cf[0] + ").", _2ca);
                    this.LogSeq("`49`", _2cb);
                    _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_2cf[0], FLOW_DIRECTION_FORWARD, null, "", false);
                    this.LogSeqReturn(_2d1, _2cb);
                    return _2d1;
                } else {
                    this.LogSeq("`1597`", _2cb);
                    this.LogSeq("`43`", _2cb);
                    _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(_2cf[_2cf.length - 1], FLOW_DIRECTION_BACKWARD, null, "", false);
                    this.LogSeqReturn(_2d1, _2cb);
                    return _2d1;
                }
            } else {
                this.LogSeq("`1635`", _2cb);
                this.LogSeq("`408`", _2cb);
                _2d1 = new Sequencer_FlowTreeTraversalSubprocessReturnObject(null, null, "SB.2.1-2", IntegrationImplementation.GetString("The activity '{0}' may only be entered from the beginning.", _2d2.GetTitle()), false);
                this.LogSeqReturn(_2d1, _2cb);
                return _2d1;
            }
        }
    }
}

function Sequencer_FlowTreeTraversalSubprocessReturnObject(_2d3, _2d4, _2d5, _2d6, _2d7) {
    Debug.AssertError("Invalid endSequencingSession (" + _2d7 + ") passed to FlowTreeTraversalSubprocessReturnObject.", (_2d7 != true && _2d7 != false));
    this.NextActivity = _2d3;
    this.TraversalDirection = _2d4;
    this.Exception = _2d5;
    this.ExceptionText = _2d6;
    this.EndSequencingSession = _2d7;
}
Sequencer_FlowTreeTraversalSubprocessReturnObject.prototype.toString = function() {
    return "NextActivity=" + this.NextActivity + ", TraversalDirection=" + this.TraversalDirection + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_JumpSequencingRequestProcess(_2d8, _2d9, _2da) {
    Debug.AssertError("Calling log not passed.", (_2d9 === undefined || _2d9 === null));
    Debug.AssertError("Simple calling log not passed.", (_2da === undefined || _2da === null));
    var _2db = this.LogSeqAudit("`1219`", _2d9);
    var _2dc;
    this.LogSeq("`483`", _2db);
    if (!this.IsCurrentActivityDefined(_2db)) {
        this.LogSeq("`435`", _2db);
        _2dc = new Sequencer_JumpSequencingRequestProcessResult(null, "SB.2.13-1", IntegrationImplementation.GetString("The sequencing session has not begun yet."), false);
        this.LogSeqReturn(_2dc, _2db);
        return _2dc;
    }
    this.LogSeq("`351`", _2db);
    _2dc = new Sequencer_JumpSequencingRequestProcessResult(_2d8, null, "", false);
    this.LogSeqReturn(_2dc, _2db);
    return _2dc;
}

function Sequencer_JumpSequencingRequestProcessResult(_2dd, _2de, _2df, _2e0) {
    Debug.AssertError("Invalid endSequencingSession (" + _2e0 + ") passed to JumpSequencingRequestProcessResult.", (_2e0 != true && _2e0 != false));
    this.DeliveryRequest = _2dd;
    this.Exception = _2de;
    this.ExceptionText = _2df;
    this.EndSequencingSession = _2e0;
}
Sequencer_JumpSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_LimitConditionsCheckProcess(_2e1, _2e2) {
    Debug.AssertError("Calling log not passed.", (_2e2 === undefined || _2e2 === null));
    var _2e3 = this.LogSeqAudit("`1272`" + _2e1 + ")", _2e2);
    this.LogSeq("`384`", _2e3);
    if (_2e1.IsTracked() === false) {
        this.LogSeq("`296`", _2e3);
        this.LogSeqReturn("`1759`", _2e3);
        return false;
    }
    this.LogSeq("`144`", _2e3);
    if (_2e1.IsActive() || _2e1.IsSuspended()) {
        this.LogSeq("`688`", _2e3);
        this.LogSeqReturn("`1759`", _2e3);
        return false;
    }
    this.LogSeq("`715`", _2e3);
    if (_2e1.GetLimitConditionAttemptControl() === true) {
        this.LogSeq("`89`", _2e3);
        var _2e4 = _2e1.GetAttemptCount();
        var _2e5 = _2e1.GetLimitConditionAttemptLimit();
        if (_2e1.GetActivityProgressStatus() === true && (_2e4 >= _2e5)) {
            this.LogSeq("`429`", _2e3);
            this.LogSeqReturn("`1763`", _2e3);
            return true;
        }
    }
    this.LogSeq("`543`", _2e3);
    this.LogSeq("`417`", _2e3);
    this.LogSeqReturn("`1759`", _2e3);
    return false;
}

function Sequencer_MeasureRollupProcess(_2e6, _2e7, _2e8) {
    Debug.AssertError("Calling log not passed.", (_2e7 === undefined || _2e7 === null));
    Debug.AssertError("Simple calling log not passed.", (_2e8 === undefined || _2e8 === null));
    var _2e9 = this.LogSeqAudit("`1381`" + _2e6 + ")", _2e7);
    _2e8 = this.LogSeqSimpleAudit("Rolling up the score (measure) for \"" + _2e6 + "\".", _2e8);
    this.LogSeq("`959`", _2e9);
    var _2ea = 0;
    this.LogSeq("`1349`", _2e9);
    var _2eb = false;
    this.LogSeq("`1045`", _2e9);
    var _2ec = 0;
    this.LogSeq("`1063`", _2e9);
    var _2ed = null;
    var i;
    this.LogSeq("`627`", _2e9);
    var _2ed = _2e6.GetPrimaryObjective();
    this.LogSeq("`1105`", _2e9);
    if (_2ed !== null) {
        this.LogSeq("`1171`", _2e9);
        var _2ef = _2e6.GetAvailableChildren();
        var _2f0 = null;
        var _2f1;
        var _2f2;
        var _2f3;
        for (i = 0; i < _2ef.length; i++) {
            this.LogSeq("`555`" + _2ef[i].IsTracked(), _2e9);
            if (_2ef[i].IsTracked()) {
                this.LogSeq("`985`", _2e9);
                _2f0 = null;
                this.LogSeq("`1172`", _2e9);
                var _2f0 = _2ef[i].GetPrimaryObjective();
                this.LogSeq("`960`", _2e9);
                if (_2f0 !== null) {
                    this.LogSeq("`545`", _2e9);
                    _2f2 = _2ef[i].GetRollupObjectiveMeasureWeight();
                    _2ec += _2f2;
                    this.LogSeq("`600`", _2e9);
                    if (_2f0.GetMeasureStatus(_2ef[i], false) === true) {
                        this.LogSeq("`121`", _2e9);
                        _2f3 = _2f0.GetNormalizedMeasure(_2ef[i], false);
                        this.LogSeq("`828`" + _2f3 + "`1462`" + _2f2, _2e9);
                        _2eb = true;
                        _2ea += (_2f3 * _2f2);
                        this.LogSeqSimple("\"" + _2ef[i] + "\" has a score of " + _2f3 + " and a weight of " + _2f2 + " so it contributes a weighted measure of " + (_2f3 * _2f2) + ".", _2e8);
                    }
                } else {
                    this.LogSeq("`1593`", _2e9);
                    this.LogSeq("`495`", _2e9);
                    Debug.AssertError("Measure Rollup Process encountered an activity with no primary objective.");
                    this.LogSeqReturn("", _2e9);
                    return;
                }
            } else {
                this.LogSeqSimple("\"" + _2ef[i] + "\" is not tracked and will not contribute a score to rollup.", _2e8);
            }
        }
        this.LogSeq("`1243`", _2e9);
        if (_2eb === false || _2ec == 0) {
            this.LogSeq("`103`" + _2ec + ")", _2e9);
            this.LogSeqSimple("No children had a score to rollup, setting the measure status to unknown.", _2e8);
            this.LogSeqSimpleReturn("unknown.", _2e8);
            _2ed.SetMeasureStatus(false, _2e6);
        } else {
            this.LogSeq("`1682`", _2e9);
            this.LogSeq("`385`", _2e9);
            if (_2ec > 0) {
                this.LogSeq("`673`", _2e9);
                _2ed.SetMeasureStatus(true, _2e6);
                this.LogSeq("`477`" + _2ea + "`1387`" + _2ec + "`1748`" + (_2ea / _2ec), _2e9);
                var _2f4 = (_2ea / _2ec);
                _2f4 = RoundToPrecision(_2f4, 7);
                _2ed.SetNormalizedMeasure(_2f4, _2e6);
                this.LogSeqSimple("Setting the score to the new weighted measure of " + _2f4 + ".", _2e8);
                this.LogSeqSimpleReturn(_2f4, _2e8);
            } else {
                this.LogSeq("`1630`", _2e9);
                this.LogSeq("`453`", _2e9);
                _2ed.SetMeasureStatus(false, _2e6);
            }
        }
    }
    this.LogSeq("`539`", _2e9);
    this.LogSeqReturn("", _2e9);
    return;
}

function Sequencer_NavigationRequestProcess(_2f5, _2f6, _2f7, _2f8) {
    Debug.AssertError("Calling log not passed.", (_2f7 === undefined || _2f7 === null));
    Debug.AssertError("Simple calling log not passed.", (_2f8 === undefined || _2f8 === null));
    var _2f9 = this.LogSeqAudit("`1306`" + _2f5 + ", " + _2f6 + ")", _2f7);
    var _2fa = this.GetCurrentActivity();
    if (_2fa !== null) {
        this.LogSeqSimple("The current activity is \"" + _2fa + "\".", _2f8, _2f8);
    } else {
        this.LogSeqSimple("There is no current activity.", _2f8, _2f8);
    }
    var _2fb = null;
    if (_2fa !== null) {
        _2fb = _2fa.ParentActivity;
    }
    var _2fc = "";
    if (_2fb !== null) {
        _2fc = _2fb.GetTitle();
    }
    var _2fd;
    switch (_2f5) {
        case NAVIGATION_REQUEST_START:
            this.LogSeq("`1168`", _2f9);
            this.LogSeq("`463`", _2f9);
            if (!this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`209`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_START, null, null, "");
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            } else {
                this.LogSeq("`1675`", _2f9);
                this.LogSeq("`176`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("The sequencing session has already been started."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_RESUME_ALL:
            this.LogSeq("`1043`", _2f9);
            this.LogSeq("`464`", _2f9);
            if (!this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`335`", _2f9);
                if (this.IsSuspendedActivityDefined(_2f9)) {
                    this.LogSeq("`170`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_RESUME_ALL, null, null, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                } else {
                    this.LogSeq("`1611`", _2f9);
                    this.LogSeq("`163`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-3", null, IntegrationImplementation.GetString("There is no suspended activity to resume."));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1676`", _2f9);
                this.LogSeq("`177`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("The sequencing session has already been started."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_CONTINUE:
            this.LogSeq("`1085`", _2f9);
            this.LogSeq("`480`", _2f9);
            if (!this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`178`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-1", null, IntegrationImplementation.GetString("Cannot continue until the sequencing session has begun."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            this.LogSeq("`40`", _2f9);
            if ((!_2fa.IsTheRoot()) && (_2fb.LearningObject.SequencingData.ControlFlow === true)) {
                this.LogSeq("`212`", _2f9);
                if (_2fa.IsActive()) {
                    this.LogSeq("`183`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_CONTINUE, null, null, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                } else {
                    this.LogSeq("`1625`", _2f9);
                    this.LogSeq("`186`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_CONTINUE, null, null, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1677`", _2f9);
                this.LogSeq("`34`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-4", null, IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _2fc));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_PREVIOUS:
            this.LogSeq("`1086`", _2f9);
            this.LogSeq("`481`", _2f9);
            if (!this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`184`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("Cannot move backwards until the sequencing session has begun."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            this.LogSeq("`239`", _2f9);
            if (!_2fa.IsTheRoot()) {
                this.LogSeq("`12`", _2f9);
                if (_2fb.LearningObject.SequencingData.ControlFlow === true && _2fb.LearningObject.SequencingData.ControlForwardOnly === false) {
                    this.LogSeq("`202`", _2f9);
                    if (_2fa.IsActive()) {
                        this.LogSeq("`171`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_PREVIOUS, null, null, "");
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    } else {
                        this.LogSeq("`1590`", _2f9);
                        this.LogSeq("`179`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_PREVIOUS, null, null, "");
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    }
                } else {
                    this.LogSeq("`1626`", _2f9);
                    this.LogSeq("`100`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-5", null, IntegrationImplementation.GetString("Please select a menu item to continue with {0}.", _2fb.GetTitle()));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1678`", _2f9);
                this.LogSeq("`50`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-6", null, IntegrationImplementation.GetString("You have reached the beginning of the course."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_FORWARD:
            this.LogSeq("`799`", _2f9);
            this.LogSeq("`187`", _2f9);
            _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The 'Forward' navigation request is not supported, try using 'Continue'."));
            this.LogSeqReturn(_2fd, _2f9);
            return _2fd;
        case NAVIGATION_REQUEST_BACKWARD:
            this.LogSeq("`791`", _2f9);
            this.LogSeq("`188`", _2f9);
            _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The 'Backward' navigation request is not supported, try using 'Previous'."));
            this.LogSeqReturn(_2fd, _2f9);
            return _2fd;
        case NAVIGATION_REQUEST_CHOICE:
            this.LogSeq("`1103`", _2f9);
            this.LogSeq("`195`", _2f9);
            if (this.DoesActivityExist(_2f6, _2f9)) {
                var _2fe = this.GetActivityFromIdentifier(_2f6, _2f9);
                var _2ff = this.Activities.GetParentActivity(_2fe);
                var _300 = this.GetActivityPath(_2fe, true);
                for (var _301 = 0; _301 < _300.length; _301++) {
                    if (_300[_301].IsAvailable() === false) {
                        _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-7", null, IntegrationImplementation.GetString("The activity '{0}' was not selected to be delivered in this attempt.", _300[i]));
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    }
                }
                this.LogSeq("`2`", _2f9);
                if (_2fe.IsTheRoot() || _2ff.LearningObject.SequencingData.ControlChoice === true) {
                    this.LogSeq("`443`", _2f9);
                    if (!this.IsCurrentActivityDefined(_2f9)) {
                        this.LogSeq("`59`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_CHOICE, null, _2fe, "");
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    }
                    this.LogSeq("`399`", _2f9);
                    if (!this.AreActivitiesSiblings(_2fa, _2fe, _2f9)) {
                        this.LogSeq("`365`", _2f9);
                        var _303 = this.FindCommonAncestor(_2fa, _2fe, _2f9);
                        this.LogSeq("`1`", _2f9);
                        var _304 = this.GetPathToAncestorExclusive(_2fa, _303, true);
                        this.LogSeq("`932`", _2f9);
                        if (_304.length > 0) {
                            this.LogSeq("`96`", _2f9);
                            for (var i = 0; i < _304.length; i++) {
                                if (_304[i].GetItemIdentifier() == _303.GetItemIdentifier()) {
                                    break;
                                }
                                this.LogSeq("`216`" + _304[i].LearningObject.ItemIdentifier + ")", _2f9);
                                if (_304[i].IsActive() === true && _304[i].LearningObject.SequencingData.ControlChoiceExit === false) {
                                    this.LogSeq("`172`" + CONTROL_CHOICE_EXIT_ERROR_NAV + "`1505`", _2f9);
                                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, CONTROL_CHOICE_EXIT_ERROR_NAV, null, IntegrationImplementation.GetString("You must complete '{0}' before you can select another item.", _304[i]));
                                    this.LogSeqReturn(_2fd, _2f9);
                                    return _2fd;
                                }
                            }
                        } else {
                            this.LogSeq("`1559`", _2f9);
                            this.LogSeq("`145`", _2f9);
                            _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-9", null, IntegrationImplementation.GetString("Nothing to open"));
                            this.LogSeqReturn(_2fd, _2f9);
                            return _2fd;
                        }
                    }
                    this.LogSeq("`46`", _2f9);
                    if (_2fa.IsActive() && _2fa.GetSequencingControlChoiceExit() === false) {
                        this.LogSeq("`223`" + CONTROL_CHOICE_EXIT_ERROR_NAV + "`1523`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, CONTROL_CHOICE_EXIT_ERROR_NAV, null, IntegrationImplementation.GetString("You are not allowed to jump out of {0}.", _2fa.GetTitle()));
                        return _2fd;
                    }
                    this.LogSeq("`204`", _2f9);
                    if (_2fa.IsActive()) {
                        this.LogSeq("`57`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_CHOICE, null, _2fe, "");
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    } else {
                        this.LogSeq("`1592`", _2f9);
                        this.LogSeq("`61`", _2f9);
                        _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, null, SEQUENCING_REQUEST_CHOICE, null, _2fe, "");
                        this.LogSeqReturn(_2fd, _2f9);
                        return _2fd;
                    }
                } else {
                    this.LogSeq("`1627`", _2f9);
                    this.LogSeq("`99`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-10", null, IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.", _2ff.GetTitle()));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1679`", _2f9);
                this.LogSeq("`87`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-11", null, IntegrationImplementation.GetString("The activity you selected ({0}) does not exist.", _2f6));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_EXIT:
            this.LogSeq("`1169`", _2f9);
            this.LogSeq("`507`", _2f9);
            if (this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`292`", _2f9);
                if (_2fa.IsActive()) {
                    this.LogSeq("`193`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_EXIT, null, null, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                } else {
                    this.LogSeq("`1628`", _2f9);
                    this.LogSeq("`75`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-12", null, IntegrationImplementation.GetString("The Exit navigation request is invalid because the current activity ({0}) is no longer active.", _2fa.GetTitle()));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1680`", _2f9);
                this.LogSeq("`173`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The Exit navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_EXIT_ALL:
            this.LogSeq("`1087`", _2f9);
            this.LogSeq("`269`", _2f9);
            if (this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`194`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            } else {
                this.LogSeq("`1681`", _2f9);
                this.LogSeq("`180`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The Exit All navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_ABANDON:
            this.LogSeq("`1084`", _2f9);
            this.LogSeq("`506`", _2f9);
            if (this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`286`", _2f9);
                if (_2fa.IsActive()) {
                    this.LogSeq("`182`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_ABANDON, SEQUENCING_REQUEST_EXIT, null, null, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                } else {
                    this.LogSeq("`1610`", _2f9);
                    this.LogSeq("`153`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-12", null, IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because the current activity '{0}' is no longer active.", _2fa.GetTitle()));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1624`", _2f9);
                this.LogSeq("`166`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The 'Abandon' navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_ABANDON_ALL:
            this.LogSeq("`1004`", _2f9);
            this.LogSeq("`277`", _2f9);
            if (this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`167`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_ABANDON_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            } else {
                this.LogSeq("`1652`", _2f9);
                this.LogSeq("`162`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("You cannot use 'Abandon All' if no item is currently open."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_SUSPEND_ALL:
            this.LogSeq("`1005`", _2f9);
            this.LogSeq("`538`", _2f9);
            if (this.IsCurrentActivityDefined(_2f9)) {
                this.LogSeq("`168`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_SUSPEND_ALL, SEQUENCING_REQUEST_EXIT, null, null, "");
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            } else {
                this.LogSeq("`1653`", _2f9);
                this.LogSeq("`169`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-2", null, IntegrationImplementation.GetString("The 'Suspend All' navigation request is invalid because there is no current activity."));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        case NAVIGATION_REQUEST_JUMP:
            this.LogSeq("`1139`", _2f9);
            this.LogSeq("`21`", _2f9);
            if (this.DoesActivityExist(_2f6, _2f9)) {
                var _2fe = this.GetActivityFromIdentifier(_2f6, _2f9);
                if (_2fe.IsAvailable() === true) {
                    this.LogSeq("`68`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(_2f5, TERMINATION_REQUEST_EXIT, SEQUENCING_REQUEST_JUMP, null, _2fe, "");
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                } else {
                    this.LogSeq("`79`", _2f9);
                    _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-11", null, IntegrationImplementation.GetString("The Jump target activity requested '{0}' is not available.", _2ff.GetTitle()));
                    this.LogSeqReturn(_2fd, _2f9);
                    return _2fd;
                }
            } else {
                this.LogSeq("`1654`", _2f9);
                this.LogSeq("`80`", _2f9);
                _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-11", null, IntegrationImplementation.GetString("The Jump target activity requested '{0}' does not exist.", _2ff.GetTitle()));
                this.LogSeqReturn(_2fd, _2f9);
                return _2fd;
            }
            break;
        default:
            this.LogSeq("`95`", _2f9);
            _2fd = new Sequencer_NavigationRequestProcessResult(NAVIGATION_REQUEST_NOT_VALID, null, null, "NB.2.1-13", null, IntegrationImplementation.GetString("Undefined Navigation Request"));
            this.LogSeqReturn(_2fd, _2f9);
            return _2fd;
    }
}

function Sequencer_NavigationRequestProcessResult(_305, _306, _307, _308, _309, _30a) {
    this.NavigationRequest = _305;
    this.TerminationRequest = _306;
    this.SequencingRequest = _307;
    this.Exception = _308;
    this.TargetActivity = _309;
    this.ExceptionText = _30a;
}
Sequencer_NavigationRequestProcessResult.prototype.toString = function() {
    return "NavigationRequest=" + this.NavigationRequest + ", TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest + ", Exception=" + this.Exception + ", TargetActivity=" + this.TargetActivity + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_ObjectiveRollupProcess(_30b, _30c, _30d) {
    Debug.AssertError("Calling log not passed.", (_30c === undefined || _30c === null));
    Debug.AssertError("Simple calling log not passed.", (_30d === undefined || _30d === null));
    var _30e = this.LogSeqAudit("`1359`" + _30b + ")", _30c);
    _30d = this.LogSeqSimpleAudit("Rolling up the satisfaction status of \"" + _30b + "\".", _30d);
    this.LogSeq("`1067`", _30e);
    var _30f = null;
    this.LogSeq("`629`", _30e);
    var _30f = _30b.GetPrimaryObjective();
    this.LogSeq("`1064`", _30e);
    if (_30f !== null) {
        this.LogSeq("`691`", _30e);
        if (_30f.GetSatisfiedByMeasure() === true) {
            this.LogSeq("`868`", _30e);
            this.ObjectiveRollupUsingMeasureProcess(_30b, _30e, _30d);
        } else {
            this.LogSeq("`1686`", _30e);
            this.LogSeq("`496`", _30e);
            this.ObjectiveRollupUsingRulesProcess(_30b, _30e, _30d);
        }
        this.LogSeq("`1198`", _30e);
        this.LogSeqReturn("", _30e);
        return;
    } else {
        this.LogSeq("`1683`", _30e);
        this.LogSeq("`482`", _30e);
        this.LogSeqReturn("", _30e);
        return;
    }
}

function Sequencer_ObjectiveRollupUsingMeasureProcess(_310, _311, _312) {
    Debug.AssertError("Calling log not passed.", (_311 === undefined || _311 === null));
    Debug.AssertError("Simple calling log not passed.", (_312 === undefined || _312 === null));
    var _313 = this.LogSeqAudit("`1027`" + _310 + ")", _311);
    this.LogSeq("`1031`", _313);
    var _314 = null;
    this.LogSeq("`617`", _313);
    var _314 = _310.GetPrimaryObjective();
    this.LogSeq("`1064`", _313);
    if (_314 !== null) {
        this.LogSeq("`127`", _313);
        if (_314.GetSatisfiedByMeasure() === true) {
            this.LogSeq("`303`", _313);
            if (_314.GetMeasureStatus(_310, false) === false) {
                this.LogSeq("`628`", _313);
                this.LogSeqSimple("\"" + _310 + "\" is sastisfied by measure but does not have a known measure so its satisfaction is unknown.", _312);
                _314.SetProgressStatus(false, false, _310);
            } else {
                this.LogSeq("`1594`", _313);
                this.LogSeq("`130`", _313);
                if (_310.IsActive() === false || _310.GetMeasureSatisfactionIfActive() === true) {
                    this.LogSeq("`105`", _313);
                    var _315 = _314.GetNormalizedMeasure(_310, false);
                    var _316 = _314.GetMinimumSatisfiedNormalizedMeasure();
                    if (_315 >= _316) {
                        this.LogSeqSimple("\"" + _310 + "\" is sastisfied by measure and its measure of " + _315 + " exceeds the threshold of " + _316 + " so setting the status to satisfied.", _312);
                        this.LogSeq("`610`", _313);
                        _314.SetProgressStatus(true, false, _310);
                        this.LogSeq("`606`", _313);
                        _314.SetSatisfiedStatus(true, false, _310);
                    } else {
                        this.LogSeqSimple("\"" + _310 + "\" is sastisfied by measure and its measure of " + _315 + " is below the threshold of " + _316 + " so setting the status to not satisfied.", _312);
                        this.LogSeq("`1518`", _313);
                        this.LogSeq("`611`", _313);
                        _314.SetProgressStatus(true, false, _310);
                        this.LogSeq("`601`", _313);
                        _314.SetSatisfiedStatus(false, false, _310);
                    }
                } else {
                    this.LogSeq("`1560`", _313);
                    this.LogSeq("`270`", _313);
                    _314.SetProgressStatus(false, false, _310);
                }
            }
        }
        this.LogSeq("`917`", _313);
        this.LogSeqReturn("", _313);
        return;
    } else {
        this.LogSeq("`1683`", _313);
        this.LogSeq("`391`", _313);
        this.LogSeqReturn("", _313);
        return;
    }
}

function Sequencer_ObjectiveRollupUsingRulesProcess(_317, _318, _319) {
    Debug.AssertError("Calling log not passed.", (_318 === undefined || _318 === null));
    var _31a = this.LogSeqAudit("`1060`" + _317 + ")", _318);
    var _31b;
    this.LogSeq("`23`", _31a);
    if (Sequencer_GetApplicableSetofRollupRules(_317, RULE_SET_NOT_SATISFIED).length === 0 && Sequencer_GetApplicableSetofRollupRules(_317, RULE_SET_SATISFIED).length === 0) {
        this.LogSeqSimple("Applying the default set of satisfaction rollup rules to \"" + _317 + "\".", _319);
        this.LogSeq("`110`", _31a);
        _317.ApplyRollupRule(new SequencingRollupRule(RULE_CONDITION_COMBINATION_ANY, CHILD_ACTIVITY_SET_ALL, ROLLUP_RULE_MINIMUM_COUNT_DEFAULT, ROLLUP_RULE_MINIMUM_PERCENT_DEFAULT, ROLLUP_RULE_ACTION_SATISFIED, new Array(new SequencingRollupRuleCondition(RULE_CONDITION_OPERATOR_NOOP, ROLLUP_RULE_CONDITION_SATISFIED))));
        this.LogSeq("`69`", _31a);
        _317.ApplyRollupRule(new SequencingRollupRule(RULE_CONDITION_COMBINATION_ANY, CHILD_ACTIVITY_SET_ALL, ROLLUP_RULE_MINIMUM_COUNT_DEFAULT, ROLLUP_RULE_MINIMUM_PERCENT_DEFAULT, ROLLUP_RULE_ACTION_NOT_SATISFIED, new Array(new SequencingRollupRuleCondition(RULE_CONDITION_OPERATOR_NOOP, ROLLUP_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN))));
    } else {
        if (_317.UsesDefaultSatisfactionRollupRules() === true) {
            this.LogSeqSimple("Applying the default set of satisfaction rollup rules to \"" + _317 + "\".", _319);
        }
    }
    this.LogSeq("`1047`", _31a);
    var _31c = null;
    this.LogSeq("`619`", _31a);
    var _31c = _317.GetPrimaryObjective();
    this.LogSeq("`1066`", _31a);
    if (_31c !== null) {
        this.LogSeq("`295`", _31a);
        _31b = this.RollupRuleCheckSubprocess(_317, RULE_SET_NOT_SATISFIED, _31a, _319);
        this.LogSeq("`803`", _31a);
        if (_31b === true) {
            this.LogSeqSimple("Setting " + _317 + " to not satisfied.", _319);
            this.LogSeq("`654`", _31a);
            _31c.SetProgressStatus(true, false, _317);
            this.LogSeq("`633`", _31a);
            _31c.SetSatisfiedStatus(false, false, _317);
        }
        this.LogSeq("`328`", _31a);
        _31b = this.RollupRuleCheckSubprocess(_317, RULE_SET_SATISFIED, _31a, _319);
        this.LogSeq("`804`", _31a);
        if (_31b === true) {
            this.LogSeqSimple("Setting \"" + _317 + "\" to satisfied.", _319);
            this.LogSeq("`655`", _31a);
            _31c.SetProgressStatus(true, false, _317);
            this.LogSeq("`644`", _31a);
            _31c.SetSatisfiedStatus(true, false, _317);
        }
        this.LogSeq("`949`", _31a);
        this.LogSeqReturn("", _31a);
        return;
    } else {
        this.LogSeq("`1685`", _31a);
        this.LogSeq("`432`", _31a);
        this.LogSeqReturn("", _31a);
        return;
    }
}

function Sequencer_OverallRollupProcess(_31d, _31e, _31f) {
    Debug.AssertError("Calling log not passed.", (_31e === undefined || _31e === null));
    Debug.AssertError("Simple calling log not passed.", (_31f === undefined || _31f === null));
    var _320 = this.LogSeqAudit("`1382`" + _31d + ")", _31e);
    _31f = this.LogSeqSimpleAudit("Rolling up data for \"" + _31d + "\".", _31f);
    this.LogSeq("`256`", _320);
    var _321 = this.GetActivityPath(_31d, true);
    this.LogSeq("`1127`", _320);
    if (_321.length === 0) {
        this.LogSeq("`896`", _320);
        this.LogSeqReturn("", _320);
        return;
    }
    this.LogSeq("`1054`", _320);
    var _322;
    var _323;
    var _324;
    var _325;
    var _326;
    var _327;
    var _328;
    var _329;
    var _32a;
    var _32b;
    var _32c;
    var _32d;
    var _32e;
    var _32f = new Array();
    var _330 = false;
    for (var i = 0; i < _321.length; i++) {
        if (!_321[i].IsALeaf()) {
            _321[i].RollupDurations();
        }
        if (_330) {
            continue;
        }
        _322 = _321[i].GetPrimaryObjective();
        _323 = _322.GetMeasureStatus(_321[i], false);
        _324 = _322.GetNormalizedMeasure(_321[i], false);
        _325 = _322.GetProgressStatus(_321[i], false);
        _326 = _322.GetSatisfiedStatus(_321[i], false);
        _327 = _321[i].GetAttemptProgressStatus();
        _328 = _321[i].GetAttemptCompletionStatus();
        this.LogSeq("`551`", _320);
        if (!_321[i].IsALeaf()) {
            this.LogSeq("`564`", _320);
            this.MeasureRollupProcess(_321[i], _320, _31f);
            this.LogSeq("`454`", _320);
            this.CompletionMeasureRollupProcess(_321[i], _320, _31f);
        }
        this.LogSeq("`731`", _320);
        this.ObjectiveRollupProcess(_321[i], _320, _31f);
        this.LogSeq("`261`", _320);
        this.ActivityProgressRollupProcess(_321[i], _320, _31f);
        _329 = _322.GetMeasureStatus(_321[i], false);
        _32a = _322.GetNormalizedMeasure(_321[i], false);
        _32b = _322.GetProgressStatus(_321[i], false);
        _32c = _322.GetSatisfiedStatus(_321[i], false);
        _32d = _321[i].GetAttemptProgressStatus();
        _32e = _321[i].GetAttemptCompletionStatus();
        if (!this.LookAhead && _321[i].IsTheRoot()) {
            if (_32d != _327 || _32e != _328) {
                var _332 = (_32d ? (_32e ? SCORM_STATUS_COMPLETED : SCORM_STATUS_INCOMPLETE) : SCORM_STATUS_NOT_ATTEMPTED);
                this.WriteHistoryLog("", {
                    ev: "Rollup Completion",
                    v: _332,
                    ai: _321[i].ItemIdentifier
                });
            }
            if (_32b != _325 || _32c != _326) {
                var _333 = (_32b ? (_32c ? SCORM_STATUS_PASSED : SCORM_STATUS_FAILED) : SCORM_STATUS_UNKNOWN);
                this.WriteHistoryLog("", {
                    ev: "Rollup Satisfaction",
                    v: _333,
                    ai: _321[i].ItemIdentifier
                });
            }
        }
        if (_32c != _326) {
            _321[i].WasAutoSatisfied = _31d.WasAutoSatisfied;
        }
        if (_32e != _328) {
            _321[i].WasAutoCompleted = _31d.WasAutoCompleted;
        }
        if (i > 0 && _329 == _323 && _32a == _324 && _32b == _325 && _32c == _326 && _32d == _327 && _32e == _328) {
            this.LogSeq("`905`", _320);
            _330 = true;
        } else {
            this.LogSeq("`869`", _320);
            _32f[_32f.length] = _321[i];
        }
    }
    this.LogSeq("`1282`", _320);
    this.LogSeqReturn("", _320);
    return _32f;
}

function Sequencer_OverallSequencingProcess(_334) {
    try {
        var _335 = null;
        var _336 = null;
        var _337 = null;
        var _338 = null;
        var _339 = null;
        this.ResetException();
        if (this.NavigationRequest !== null) {
            var _33a = this.LogSeqSimpleAudit("Starting the sequencing process for navigation request " + this.NavigationRequest.toDescriptiveString() + ".", _33a);
        } else {
            var _33a = this.LogSeqSimpleAudit("Starting the sequencing process with no navigation request.", _33a);
        }
        var _33b = this.LogSeqAudit("`1360`");
        this.LogSeq("`1414`" + this.NavigationRequest, _33b);
        if (this.NavigationRequest === null) {
            var _33c = this.GetExitAction(this.GetCurrentActivity(), _33b);
            this.LogSeq("`1044`" + _33c, _33b);
            var _33d = "";
            if (_33c == EXIT_ACTION_EXIT_CONFIRMATION || _33c == EXIT_ACTION_DISPLAY_MESSAGE) {
                var _33e = Control.Activities.GetRootActivity();
                var _33f = (_33e.IsCompleted() || _33e.IsSatisfied());
                if (_33f === true) {
                    _33d = IntegrationImplementation.GetString("The course is now complete. Please make a selection to continue.");
                } else {
                    _33d = IntegrationImplementation.GetString("Please make a selection.");
                }
            }
            switch (_33c) {
                case (EXIT_ACTION_EXIT_NO_CONFIRMATION):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL, null, "");
                    break;
                case (EXIT_ACTION_EXIT_CONFIRMATION):
                    if (confirm("Would you like to exit the course now?")) {
                        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT_ALL, null, "");
                    } else {
                        this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE, null, _33d);
                    }
                    break;
                case (EXIT_ACTION_GO_TO_NEXT_SCO):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_CONTINUE, null, "");
                    break;
                case (EXIT_ACTION_DISPLAY_MESSAGE):
                    this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_DISPLAY_MESSAGE, null, _33d);
                    break;
                case (EXIT_ACTION_DO_NOTHING):
                    this.NavigationRequest = null;
                    break;
                case (EXIT_ACTION_REFRESH_PAGE):
                    Control.RefreshPage();
                    break;
            }
        }
        if (this.NavigationRequest == null) {
            this.LogSeqSimpleReturn("Perform no action, no navigation request identified", _33a);
            this.LogSeqReturn("`1409`", _33b);
            return;
        }
        if (this.NavigationRequest.Type == NAVIGATION_REQUEST_DISPLAY_MESSAGE) {
            this.LogSeq("`690`", _33b);
            this.NavigationRequest = new NavigationRequest(NAVIGATION_REQUEST_EXIT, null, "");
        }
        if (this.NavigationRequest.Type == NAVIGATION_REQUEST_EXIT_PLAYER) {
            this.LogSeq("`814`", _33b);
            Control.ExitScormPlayer("Sequencer");
            return;
        }
        this.LogSeq("`757`", _33b);
        var _340 = this.NavigationRequestProcess(this.NavigationRequest.Type, this.NavigationRequest.TargetActivity, _33b, _33a);
        this.LogSeq("`626`", _33b);
        if (_340.NavigationRequest == NAVIGATION_REQUEST_NOT_VALID) {
            this.LogSeqSimple("The navigation request is invalid and should not have been triggered. The specific error was: " + _340.ExceptionText, _33a);
            this.LogSeq("`726`", _33b);
            this.Exception = _340.Exception;
            this.ExceptionText = _340.ExceptionText;
            this.LogSeq("`847`", _33b);
            this.LogSeqSimpleReturn("Perform no action, navigation request is invalid.", _33a);
            this.LogSeqReturn("`1759`", _33b);
            return false;
        }
        _335 = _340.TerminationRequest;
        _336 = _340.SequencingRequest;
        _337 = _340.TargetActivity;
        this.LogSeq("`368`", _33b);
        if (_335 !== null) {
            this.LogSeq("`707`", _33b);
            var _341 = this.TerminationRequestProcess(_335, _33b, _33a);
            this.LogSeq("`599`", _33b);
            if (_341.TerminationRequest == TERMINATION_REQUEST_NOT_VALID) {
                this.LogSeq("`699`", _33b);
                this.Exception = _341.Exception;
                this.ExceptionText = _341.ExceptionText;
                this.LogSeq("`823`", _33b);
                this.LogSeqSimpleReturn("Perform no action, can't terminate current activity.", _33a);
                this.LogSeqReturn("`1759`", _33b);
                return false;
            }
            this.LogSeq("`700`", _33b);
            if (_341.SequencingRequest !== null) {
                if (_336 != _341.SequencingRequest) {
                    this.LogSeqSimple("After exiting the current activity and evaluating all exit/post condition sequencing rules, the original sequencing request (from the user or from the SCO) of '" + _336 + "' is being replaced with a sequencing request of '" + _341.SequencingRequest + "'.", _33a);
                }
                this.LogSeq("`39`", _33b);
                _336 = _341.SequencingRequest;
            }
        }
        this.LogSeq("`1062`", _33b);
        if (_336 !== null) {
            this.LogSeq("`727`", _33b);
            var _342 = this.SequencingRequestProcess(_336, _337, _33b, _33a);
            this.LogSeq("`609`", _33b);
            if (_342.SequencingRequest == SEQUENCING_REQUEST_NOT_VALID) {
                this.LogSeqSimple("No activity identified for delivery, invalid request. Display an error message or user prompt.", _33a);
                this.LogSeq("`708`", _33b);
                this.Exception = _342.Exception;
                this.ExceptionText = _342.ExceptionText;
                this.LogSeq("`824`", _33b);
                this.LogSeqSimpleReturn("Perform no action, couldn't identify an activity for delivery.", _33a);
                this.LogSeqReturn("`1759`", _33b);
                return false;
            }
            this.LogSeq("`534`", _33b);
            if (_342.EndSequencingSession === true) {
                this.LogSeqSimple("The sequencing request resulting in the end of the course. Exit the SCORM player.", _33a);
                this.LogSeq("`76`", _33b);
                Control.ExitScormPlayer("Sequencer");
                this.LogSeqSimpleReturn("Exit SCORM Player.", _33a);
                this.LogSeqReturn("", _33b);
                return;
            }
            this.LogSeq("`583`", _33b);
            if (_342.DeliveryRequest === null) {
                this.LogSeqSimple("The sequencing session did not identify an activity for delivery, but not because of an error condition. Display a message to the user.", _33a);
                this.LogSeq("`825`", _33b);
                this.Exception = "OP.1.4";
                this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
                this.LogSeqSimpleReturn("Prompt user for selection.", _33a);
                this.LogSeqReturn("", _33b);
                return;
            }
            this.LogSeqSimple("The sequencing session identified \"" + _342.DeliveryRequest + "\" for delivery.", _33a);
            this.LogSeq("`571`", _33b);
            _338 = _342.DeliveryRequest;
        }
        this.LogSeq("`1104`", _33b);
        var _343 = false;
        if (_338 !== null) {
            this.LogSeq("`777`", _33b);
            var _344 = this.DeliveryRequestProcess(_338, _33b, _33a);
            this.LogSeq("`630`", _33b);
            if (_344.Valid === false) {
                this.LogSeq("`728`", _33b);
                this.Exception = "OP.1.5";
                this.ExceptionText = IntegrationImplementation.GetString("Please make a selection.");
                this.LogSeq("`826`", _33b);
                this.LogSeqSimpleReturn("Prompt user for selection.", _33a);
                this.LogSeqReturn("`1759`", _33b);
                return false;
            }
            this.LogSeq("`651`", _33b);
            _343 = true;
            this.ContentDeliveryEnvironmentProcess(_338, _33b, _33a);
        }
        this.LogSeq("`946`", _33b);
        if (_343 === true) {
            this.LogSeqSimpleReturn("Deliver activity: " + _338, _33a);
            this.LogSeqReturn("`1647`" + _338, _33b);
        } else {
            this.LogSeqReturn("", _33b);
        }
        return;
    } catch (error) {
        var _345 = "Error in OverallSequencingProcess for SCORM 2004 4th Edition: ";
        if (typeof RegistrationToDeliver != "undefined" && typeof RegistrationToDeliver.Id != "undefined") {
            _345 = _345 + "RegistrationId: " + RegistrationToDeliver.Id + ", ";
        }
        Control.Comm.LogOnServer(_345, error);
        throw error;
    }
}

function Sequencer_PreviousSequencingRequestProcess(_346, _347) {
    Debug.AssertError("Calling log not passed.", (_346 === undefined || _346 === null));
    Debug.AssertError("Simple calling log not passed.", (_347 === undefined || _347 === null));
    var _348 = this.LogSeqAudit("`1137`", _346);
    var _349;
    this.LogSeq("`501`", _348);
    if (!this.IsCurrentActivityDefined(_348)) {
        this.LogSeq("`409`", _348);
        _349 = new Sequencer_PreviousSequencingRequestProcessResult(null, "SB.2.8-1", IntegrationImplementation.GetString("You cannot use 'Previous' at this time."), false);
        this.LogSeqReturn(_349, _348);
        return _349;
    }
    var _34a = this.GetCurrentActivity();
    this.LogSeq("`710`", _348);
    if (!_34a.IsTheRoot()) {
        var _34b = this.Activities.GetParentActivity(_34a);
        this.LogSeq("`300`", _348);
        if (_34b.GetSequencingControlFlow() === false) {
            this.LogSeq("`567`", _348);
            this.LogSeqSimple("Flow navigation is not allowed within \"" + _34b + "\". Prompting the used to make a different selection.", _347);
            _349 = new Sequencer_PreviousSequencingRequestProcessResult(null, "SB.2.8-2", IntegrationImplementation.GetString("Please select 'Next' or 'Previous' to move through {0}.", _34b.GetTitle()), false);
            this.LogSeqReturn(_349, _348);
            return _349;
        }
    }
    this.LogSeq("`131`", _348);
    var _34c = this.FlowSubprocess(_34a, FLOW_DIRECTION_BACKWARD, false, _348, _347);
    this.LogSeq("`995`", _348);
    if (_34c.Deliverable === false) {
        this.LogSeq("`229`", _348);
        _349 = new Sequencer_PreviousSequencingRequestProcessResult(null, _34c.Exception, _34c.ExceptionText, _34c.EndSequencingSession);
        this.LogSeqReturn(_349, _348);
        return _349;
    } else {
        this.LogSeq("`1720`", _348);
        this.LogSeq("`324`", _348);
        _349 = new Sequencer_PreviousSequencingRequestProcessResult(_34c.IdentifiedActivity, null, "", false);
        this.LogSeqReturn(_349, _348);
        return _349;
    }
}

function Sequencer_PreviousSequencingRequestProcessResult(_34d, _34e, _34f, _350) {
    Debug.AssertError("Invalid endSequencingSession (" + _350 + ") passed to PreviousSequencingRequestProcessResult.", (_350 != true && _350 != false));
    this.DeliveryRequest = _34d;
    this.Exception = _34e;
    this.ExceptionText = _34f;
    this.EndSequencingSession = _350;
}
Sequencer_PreviousSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RandomizeChildrenProcess(_351, _352, _353, _354) {
    Debug.AssertError("Calling log not passed.", (_353 === undefined || _353 === null));
    Debug.AssertError("Simple calling log not passed.", (_354 === undefined || _354 === null));
    var _355 = this.LogSeqAudit("`1343`" + _351 + ")", _353);
    var _356;
    this.LogSeq("`537`", _355);
    if (_351.IsALeaf()) {
        this.LogSeq("`1203`", _355);
        this.LogSeqReturn("", _355);
        return;
    }
    this.LogSeq("`155`", _355);
    if (_351.IsActive() === true || _351.IsSuspended() === true) {
        this.LogSeq("`1204`", _355);
        this.LogSeqReturn("", _355);
        return;
    }
    var _357 = _351.GetRandomizationTiming();
    switch (_357) {
        case TIMING_NEVER:
            this.LogSeq("`854`", _355);
            this.LogSeq("`1205`", _355);
            break;
        case TIMING_ONCE:
            this.LogSeq("`861`", _355);
            this.LogSeq("`783`", _355);
            if (_351.GetRandomizedChildren() === false) {
                this.LogSeq("`441`", _355);
                if (_351.GetActivityProgressStatus() === false) {
                    this.LogSeq("`862`", _355);
                    if (_351.GetRandomizeChildren() === true) {
                        this.LogSeqSimple("Randomizing the order of the children of \"" + _351 + "\".", _354);
                        this.LogSeq("`568`", _355);
                        _356 = Sequencer_RandomizeArray(_351.GetAvailableChildren());
                        _351.SetAvailableChildren(_356);
                        _351.SetRandomizedChildren(true);
                    }
                }
            }
            this.LogSeq("`1206`", _355);
            break;
        case TIMING_ON_EACH_NEW_ATTEMPT:
            this.LogSeq("`696`", _355);
            this.LogSeq("`876`", _355);
            if (_351.GetRandomizeChildren() === true) {
                this.LogSeqSimple("Randomizing the order of the children of \"" + _351 + "\".", _354);
                this.LogSeq("`586`", _355);
                _356 = Sequencer_RandomizeArray(_351.GetAvailableChildren());
                _351.SetAvailableChildren(_356);
                _351.SetRandomizedChildren(true);
                if (_352 === true) {
                    Control.RedrawChildren(_351);
                }
            }
            this.LogSeq("`1207`", _355);
            break;
        default:
            this.LogSeq("`833`", _355);
            break;
    }
    this.LogSeqReturn("", _355);
    return;
}

function Sequencer_RandomizeArray(ary) {
    var _359 = ary.length;
    var orig;
    var swap;
    for (var i = 0; i < _359; i++) {
        var _35d = Math.floor(Math.random() * _359);
        orig = ary[i];
        swap = ary[_35d];
        ary[i] = swap;
        ary[_35d] = orig;
    }
    return ary;
}

function Sequencer_ResumeAllSequencingRequestProcess(_35e, _35f) {
    Debug.AssertError("Calling log not passed.", (_35e === undefined || _35e === null));
    Debug.AssertError("Simple calling log not passed.", (_35f === undefined || _35f === null));
    var _360 = this.LogSeqAudit("`1102`", _35e);
    var _361;
    this.LogSeq("`499`", _360);
    if (this.IsCurrentActivityDefined(_360)) {
        this.LogSeq("`400`", _360);
        _361 = new Sequencer_ResumeAllSequencingRequestProcessResult(null, "SB.2.6-1", IntegrationImplementation.GetString("A 'Resume All' sequencing request cannot be processed while there is a current activity defined."));
        this.LogSeqReturn(_361, _360);
        return _361;
    }
    this.LogSeq("`397`", _360);
    if (!this.IsSuspendedActivityDefined(_360)) {
        this.LogSeq("`401`", _360);
        _361 = new Sequencer_ResumeAllSequencingRequestProcessResult(null, "SB.2.6-2", IntegrationImplementation.GetString("There is no suspended activity to resume."));
        this.LogSeqReturn(_361, _360);
        return _361;
    }
    this.LogSeq("`58`", _360);
    var _362 = this.GetSuspendedActivity(_360);
    this.LogSeqSimple("The previously suspended activity that should be resumed is \"" + _362 + "\".", _35f);
    if (_362 !== null && _362.IsDeliverable() !== true && Control.Package.Properties.AlwaysFlowToFirstSco === true) {
        this.LogSeq("`604`", _360);
        var _363 = this.GetOrderedListOfActivities(_360);
        for (var i = 0; i < _363.length; i++) {
            if (_363[i] && _363[i].IsDeliverable() === true) {
                _361 = new Sequencer_ResumeAllSequencingRequestProcessResult(_363[i], null, "");
                this.LogSeqReturn(_361, _360);
                return _361;
            }
        }
    }
    _361 = new Sequencer_ResumeAllSequencingRequestProcessResult(_362, null, "");
    this.LogSeqReturn(_361, _360);
    return _361;
}

function Sequencer_ResumeAllSequencingRequestProcessResult(_365, _366, _367) {
    this.DeliveryRequest = _365;
    this.Exception = _366;
    this.ExceptionText = _367;
}
Sequencer_ResumeAllSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RetrySequencingRequestProcess(_368, _369) {
    Debug.AssertError("Calling log not passed.", (_368 === undefined || _368 === null));
    Debug.AssertError("Simple calling log not passed.", (_369 === undefined || _369 === null));
    var _36a = this.LogSeqAudit("`1193`", _368);
    var _36b;
    var _36c;
    this.LogSeq("`488`", _36a);
    if (!this.IsCurrentActivityDefined(_36a)) {
        this.LogSeq("`433`", _36a);
        _36b = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-1", IntegrationImplementation.GetString("You cannot use 'Resume All' while the current item is open."));
        this.LogSeqReturn(_36b, _36a);
        return _36b;
    }
    var _36d = this.GetCurrentActivity();
    this.LogSeq("`101`", _36a);
    if (_36d.IsActive() || _36d.IsSuspended()) {
        this.LogSeq("`434`", _36a);
        _36b = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-2", IntegrationImplementation.GetString("A 'Retry' sequencing request cannot be processed while there is an active or suspended activity."));
        this.LogSeqReturn(_36b, _36a);
        return _36b;
    }
    this.LogSeq("`975`", _36a);
    if (!_36d.IsALeaf()) {
        _369 = this.LogSeqSimpleAudit("Processing a Retry of \"" + _36d + "\".", _369);
        this.LogSeq("`511`" + _36d + ").", _36a);
        this.LogSeqSimple("Resetting sequencing activity tree data (but not CMI runtime data) for \"" + _36d + "\" and all its descendents.", _369);
        _36d.InitializeForNewAttempt(true, true);
        this.LogSeq("`830`" + Control.Package.ObjectivesGlobalToSystem + "`930`" + _36d.IsTheRoot() + ").", _36a);
        if (Control.Package.ObjectivesGlobalToSystem === false && _36d.IsTheRoot() === true) {
            this.LogSeq("`1201`", _36a);
            this.LogSeqSimple("A retry on the root activity when objectives global to system is false will also reset all global objectives.", _369);
            this.ResetGlobalObjectives();
        }
        this.LogSeq("`372`", _36a);
        flowSubProcessResult = this.FlowSubprocess(_36d, FLOW_DIRECTION_FORWARD, true, _36a, _369);
        this.LogSeq("`951`", _36a);
        if (flowSubProcessResult.Deliverable === false) {
            this.LogSeq("`407`", _36a);
            _36b = new Sequencer_RetrySequencingRequestProcessResult(null, "SB.2.10-3", IntegrationImplementation.GetString("You cannot 'Retry' this item because: {1}", _36d.GetTitle(), flowSubProcessResult.ExceptionText));
            this.LogSeqReturn(_36b, _36a);
            return _36b;
        } else {
            this.LogSeq("`1655`", _36a);
            this.LogSeq("`322`", _36a);
            _36b = new Sequencer_RetrySequencingRequestProcessResult(flowSubProcessResult.IdentifiedActivity, null, "");
            this.LogSeqReturn(_36b, _36a);
            return _36b;
        }
    } else {
        this.LogSeq("`1704`", _36a);
        this.LogSeq("`489`", _36a);
        _36b = new Sequencer_RetrySequencingRequestProcessResult(_36d, null, "");
        this.LogSeqReturn(_36b, _36a);
        return _36b;
    }
}

function Sequencer_RetrySequencingRequestProcessResult(_36e, _36f, _370) {
    this.DeliveryRequest = _36e;
    this.Exception = _36f;
    this.ExceptionText = _370;
}
Sequencer_RetrySequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function Sequencer_RollupRuleCheckSubprocess(_371, _372, _373, _374) {
    Debug.AssertError("Calling log not passed.", (_373 === undefined || _373 === null));
    Debug.AssertError("Simple calling log not passed.", (_374 === undefined || _374 === null));
    var _375 = this.LogSeqAudit("`1274`" + _371 + ", " + _372 + ")", _373);
    var _376;
    var _377;
    var _378;
    var _379;
    var _37a = 0;
    var _37b = 0;
    var _37c = 0;
    this.LogSeq("`331`", _375);
    var _37d = Sequencer_GetApplicableSetofRollupRules(_371, _372);
    if (_37d.length > 0) {
        this.LogSeq("`214`", _375);
        _374 = this.LogSeqSimpleAudit("Evaluating rollup rules for " + _372 + " on \"" + _371 + "\".", _374);
        _376 = _371.GetAvailableChildren();
        this.LogSeq("`1145`", _375);
        for (var i = 0; i < _37d.length; i++) {
            this.LogSeq("`1366`" + _37d[i].toString(), _375);
            var _37f = this.LogSeqSimpleAudit("Evaluating Rule #" + (i + 1) + ": \"" + _37d[i].toString() + "\".", _374);
            this.LogSeq("`748`", _375);
            contributingChldren = new Array();
            _37a = 0;
            _37b = 0;
            _37c = 0;
            this.LogSeq("`1126`", _375);
            for (var j = 0; j < _376.length; j++) {
                this.LogSeq("`974`", _375);
                if (_376[j].IsTracked() === true) {
                    this.LogSeq("`236`", _375);
                    _377 = this.CheckChildForRollupSubprocess(_376[j], _37d[i].Action, _375, _37f);
                    this.LogSeq("`749`", _375);
                    if (_377 === true) {
                        this.LogSeq("`156`", _375);
                        _378 = this.EvaluateRollupConditionsSubprocess(_376[j], _37d[i], _375, _37f);
                        this.LogSeq("`309`", _375);
                        if (_378 == RESULT_UNKNOWN) {
                            this.LogSeq("`721`", _375);
                            _37c++;
                            if (_37d[i].ChildActivitySet == CHILD_ACTIVITY_SET_ALL || _37d[i].ChildActivitySet == CHILD_ACTIVITY_SET_NONE) {
                                j = _376.length;
                            }
                        } else {
                            this.LogSeq("`1519`", _375);
                            this.LogSeq("`682`", _375);
                            if (_378 === true) {
                                this.LogSeq("`772`", _375);
                                _37a++;
                                if (_37d[i].ChildActivitySet == CHILD_ACTIVITY_SET_ANY || _37d[i].ChildActivitySet == CHILD_ACTIVITY_SET_NONE) {
                                    j = _376.length;
                                }
                            } else {
                                this.LogSeq("`1520`", _375);
                                this.LogSeq("`762`", _375);
                                _37b++;
                                if (_37d[i].ChildActivitySet == CHILD_ACTIVITY_SET_ALL) {
                                    j = _376.length;
                                }
                            }
                        }
                    }
                } else {
                    this.LogSeqSimple("\"" + _376[j] + "\" is not tracked so it is not included in the rollup.", _37f);
                }
            }
            this.LogSeq("`189`", _375);
            _379 = false;
            this.LogSeq("`904`", _375);
            if (_376.length == 0) {
                this.LogSeq("`550`", _375);
            } else {
                switch (_37d[i].ChildActivitySet) {
                    case CHILD_ACTIVITY_SET_ALL:
                        this.LogSeq("`936`", _375);
                        this.LogSeq("`541`", _375);
                        if (_37b === 0 && _37c === 0) {
                            this.LogSeq("`1147`", _375);
                            _379 = true;
                        }
                        break;
                    case CHILD_ACTIVITY_SET_ANY:
                        this.LogSeq("`938`", _375);
                        this.LogSeq("`694`", _375);
                        if (_37a > 0) {
                            this.LogSeq("`1148`", _375);
                            _379 = true;
                        }
                        break;
                    case CHILD_ACTIVITY_SET_NONE:
                        this.LogSeq("`924`", _375);
                        this.LogSeq("`547`", _375);
                        if (_37a === 0 && _37c === 0) {
                            this.LogSeq("`1149`", _375);
                            _379 = true;
                        }
                        break;
                    case CHILD_ACTIVITY_SET_AT_LEAST_COUNT:
                        this.LogSeq("`817`", _375);
                        this.LogSeq("`272`", _375);
                        if (_37a >= _37d[i].MinimumCount) {
                            this.LogSeq("`1150`", _375);
                            _379 = true;
                        }
                        break;
                    case CHILD_ACTIVITY_SET_AT_LEAST_PERCENT:
                        this.LogSeq("`794`", _375);
                        this.LogSeq("`119`", _375);
                        var _381 = (_37a / (_37a + _37b + _37c));
                        if (_381 >= _37d[i].MinimumPercent) {
                            this.LogSeq("`1152`", _375);
                            _379 = true;
                        }
                        break;
                    default:
                        break;
                }
            }
            this.LogSeq("`1125`", _375);
            if (_379 === true) {
                this.LogSeq("`260`", _375);
                this.LogSeqReturn("`1763`", _375);
                this.LogSeqSimpleReturn("Rule #" + (i + 1) + " fires. Status will change to " + _372 + ".", _374);
                this.LogSeqSimpleReturn("Rule fires and status will change.", _37f);
                return true;
            } else {
                this.LogSeqSimpleReturn("Rule does not fire.", _37f);
            }
        }
    }
    this.LogSeq("`420`", _375);
    this.LogSeqSimpleReturn("No rule fired, status will not change.", _374);
    this.LogSeqReturn("`1759`", _375);
    return false;
}

function Sequencer_GetApplicableSetofRollupRules(_382, _383) {
    var _384 = new Array();
    var _385 = _382.GetRollupRules();
    for (var i = 0; i < _385.length; i++) {
        switch (_383) {
            case RULE_SET_SATISFIED:
                if (_385[i].Action == ROLLUP_RULE_ACTION_SATISFIED) {
                    _384[_384.length] = _385[i];
                }
                break;
            case RULE_SET_NOT_SATISFIED:
                if (_385[i].Action == ROLLUP_RULE_ACTION_NOT_SATISFIED) {
                    _384[_384.length] = _385[i];
                }
                break;
            case RULE_SET_COMPLETED:
                if (_385[i].Action == ROLLUP_RULE_ACTION_COMPLETED) {
                    _384[_384.length] = _385[i];
                }
                break;
            case RULE_SET_INCOMPLETE:
                if (_385[i].Action == ROLLUP_RULE_ACTION_INCOMPLETE) {
                    _384[_384.length] = _385[i];
                }
                break;
        }
    }
    return _384;
}

function Sequencer_SelectChildrenProcess(_387, _388, _389) {
    Debug.AssertError("Calling log not passed.", (_388 === undefined || _388 === null));
    Debug.AssertError("Simple calling log not passed.", (_389 === undefined || _389 === null));
    var _38a = this.LogSeqAudit("`1396`" + _387 + ")", _388);
    this.LogSeq("`561`", _38a);
    if (_387.IsALeaf()) {
        this.LogSeq("`1257`", _38a);
        this.LogSeqReturn("", _38a);
        return;
    }
    this.LogSeq("`175`", _38a);
    if (_387.IsActive() === true || _387.IsSuspended() === true) {
        this.LogSeq("`1258`", _38a);
        this.LogSeqReturn("", _38a);
        return;
    }
    var _38b = _387.GetSelectionTiming();
    switch (_38b) {
        case TIMING_NEVER:
            this.LogSeq("`888`", _38a);
            this.LogSeq("`1259`", _38a);
            break;
        case TIMING_ONCE:
            this.LogSeq("`897`", _38a);
            this.LogSeq("`818`", _38a);
            if (_387.GetSelectedChildren() === false) {
                this.LogSeq("`440`", _38a);
                if (_387.GetActivityProgressStatus() === false) {
                    this.LogSeq("`773`", _38a);
                    if (_387.GetSelectionCountStatus() === true) {
                        this.LogSeq("`889`", _38a);
                        var _38c = new Array();
                        var _38d = _387.GetChildren();
                        var _38e = _387.GetSelectionCount();
                        _389 = this.LogSeqSimpleAudit("Randomly selecting " + _387.GetSelectionCount() + " children of \"" + _387 + "\" to be included.", _389);
                        if (_38e < _38d.length) {
                            var _38f = Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_38e, 0, _38d.length - 1);
                            this.LogSeq("`870`", _38a);
                            for (var i = 0; i < _38f.length; i++) {
                                this.LogSeq("`536`", _38a);
                                this.LogSeq("`339`", _38a);
                                this.LogSeqSimple("Selected \"" + _38d[_38f[i]] + "\".", _389);
                                _38c[i] = _38d[_38f[i]];
                            }
                        } else {
                            _38c = _38d;
                        }
                        this.LogSeq("`774`", _38a);
                        _387.SetAvailableChildren(_38c);
                        _387.SetSelectedChildren(true);
                    }
                }
            }
            this.LogSeq("`1260`", _38a);
            break;
        case TIMING_ON_EACH_NEW_ATTEMPT:
            this.LogSeq("`739`", _38a);
            this.LogSeq("`898`", _38a);
            this.LogSeqSimple("Selection timing of on each new attempt is currently not supported in SCORM.", _389);
            break;
        default:
            this.LogSeq("`842`", _38a);
            break;
    }
    this.LogSeqReturn("", _38a);
}

function Sequencer_GetUniqueRandomNumbersBetweenTwoValues(_391, _392, _393) {
    if (_391 === null || _391 === undefined || _391 < _392) {
        _391 = _392;
    }
    if (_391 > _393) {
        _391 = _393;
    }
    var _394 = new Array(_391);
    var _395;
    var _396;
    for (var i = 0; i < _391; i++) {
        _396 = true;
        while (_396) {
            _395 = Sequencer_GetRandomNumberWithinRange(_392, _393);
            _396 = Sequencer_IsNumberAlreadyInArray(_395, _394);
        }
        _394[i] = _395;
    }
    _394.sort();
    return _394;
}

function Sequencer_GetRandomNumberWithinRange(_398, _399) {
    var diff = _399 - _398;
    return Math.floor(Math.random() * (diff + _398 + 1));
}

function Sequencer_IsNumberAlreadyInArray(_39b, _39c) {
    for (var i = 0; i < _39c.length; i++) {
        if (_39c[i] == _39b) {
            return true;
        }
    }
    return false;
}

function Sequencer_SequencingExitActionRulesSubprocess(_39e, _39f) {
    Debug.AssertError("Calling log not passed.", (_39e === undefined || _39e === null));
    Debug.AssertError("Simple calling log not passed.", (_39f === undefined || _39f === null));
    var _3a0 = this.LogSeqAudit("`1061`", _39e);
    this.LogSeq("`249`", _3a0);
    var _3a1 = this.GetCurrentActivity();
    var _3a2 = this.Activities.GetParentActivity(_3a1);
    var _3a3;
    if (_3a2 !== null) {
        _3a3 = this.GetActivityPath(_3a2, true);
    } else {
        _3a3 = this.GetActivityPath(_3a1, true);
    }
    this.LogSeq("`1225`", _3a0);
    var _3a4 = null;
    var _3a5 = null;
    this.LogSeq("`307`", _3a0);
    for (var i = (_3a3.length - 1); i >= 0; i--) {
        this.LogSeq("`553`", _3a0);
        _3a5 = this.SequencingRulesCheckProcess(_3a3[i], RULE_SET_EXIT, _3a0, _39f);
        this.LogSeq("`740`", _3a0);
        if (_3a5 !== null) {
            this.LogSeq("`415`", _3a0);
            _3a4 = _3a3[i];
            this.LogSeq("`1544`", _3a0);
            break;
        }
    }
    this.LogSeq("`1208`", _3a0);
    if (_3a4 !== null) {
        this.LogSeqSimple("Exiting " + _3a4 + " because of its EXIT sequencing rule.", _39f);
        this.LogSeq("`352`", _3a0);
        this.TerminateDescendentAttemptsProcess(_3a4, _3a0, _39f);
        this.LogSeq("`466`", _3a0);
        this.EndAttemptProcess(_3a4, false, _3a0, false, _39f);
        this.LogSeq("`348`", _3a0);
        this.SetCurrentActivity(_3a4, _3a0, _39f);
    }
    this.LogSeq("`966`", _3a0);
    this.LogSeqReturn("", _3a0);
    return;
}

function Sequencer_SequencingPostConditionRulesSubprocess(_3a7, _3a8) {
    Debug.AssertError("Calling log not passed.", (_3a7 === undefined || _3a7 === null));
    Debug.AssertError("Simple calling log not passed.", (_3a8 === undefined || _3a8 === null));
    var _3a9 = this.LogSeqAudit("`1000`", _3a7);
    var _3aa;
    this.LogSeq("`340`", _3a9);
    var _3ab = this.GetCurrentActivity();
    if (_3ab.IsSuspended()) {
        this.LogSeq("`899`", _3a9);
        _3aa = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, null);
        this.LogSeqReturn(_3aa, _3a9);
        return _3aa;
    }
    this.LogSeq("`190`", _3a9);
    var _3ac = this.SequencingRulesCheckProcess(_3ab, RULE_SET_POST_CONDITION, _3a9, _3a8);
    this.LogSeq("`766`", _3a9);
    if (_3ac !== null) {
        this.LogSeq("`587`", _3a9);
        if (_3ac == SEQUENCING_RULE_ACTION_RETRY || _3ac == SEQUENCING_RULE_ACTION_CONTINUE || _3ac == SEQUENCING_RULE_ACTION_PREVIOUS) {
            this.LogSeq("`47`", _3a9);
            _3aa = new Sequencer_SequencingPostConditionRulesSubprocessResult(this.TranslateSequencingRuleActionIntoSequencingRequest(_3ac), null);
            this.LogSeqReturn(_3aa, _3a9);
            return _3aa;
        }
        this.LogSeq("`621`", _3a9);
        if (_3ac == SEQUENCING_RULE_ACTION_EXIT_PARENT || _3ac == SEQUENCING_RULE_ACTION_EXIT_ALL) {
            this.LogSeq("`85`", _3a9);
            _3aa = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, this.TranslateSequencingRuleActionIntoTerminationRequest(_3ac));
            this.LogSeqReturn(_3aa, _3a9);
            return _3aa;
        }
        this.LogSeq("`752`", _3a9);
        if (_3ac == SEQUENCING_RULE_ACTION_RETRY_ALL) {
            this.LogSeq("`30`", _3a9);
            _3aa = new Sequencer_SequencingPostConditionRulesSubprocessResult(SEQUENCING_REQUEST_RETRY, TERMINATION_REQUEST_EXIT_ALL);
            this.LogSeqReturn(_3aa, _3a9);
            return _3aa;
        }
    }
    this.LogSeq("`484`", _3a9);
    _3aa = new Sequencer_SequencingPostConditionRulesSubprocessResult(null, null);
    this.LogSeqReturn(_3aa, _3a9);
    return _3aa;
}

function Sequencer_SequencingPostConditionRulesSubprocessResult(_3ad, _3ae) {
    this.TerminationRequest = _3ae;
    this.SequencingRequest = _3ad;
}
Sequencer_SequencingPostConditionRulesSubprocessResult.prototype.toString = function() {
    return "TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest;
};

function Sequencer_SequencingRequestProcess(_3af, _3b0, _3b1, _3b2) {
    Debug.AssertError("Calling log not passed.", (_3b1 === undefined || _3b1 === null));
    Debug.AssertError("Simple calling log not passed.", (_3b2 === undefined || _3b2 === null));
    var _3b3 = this.LogSeqAudit("`1293`" + _3af + ", " + _3b0 + ")", _3b1);
    var _3b4;
    _3b2 = this.LogSeqSimpleAudit("Identifying the activity to be delivered in response to a sequencing request of '" + _3af + "'.", _3b2);
    switch (_3af) {
        case SEQUENCING_REQUEST_START:
            this.LogSeq("`1128`", _3b3);
            this.LogSeq("`952`", _3b3);
            var _3b5 = this.StartSequencingRequestProcess(_3b3, _3b2);
            this.LogSeq("`695`", _3b3);
            if (_3b5.Exception !== null) {
                this.LogSeq("`81`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3b5.Exception, _3b5.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1656`", _3b3);
                this.LogSeq("`42`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3b5.DeliveryRequest, _3b5.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_RESUME_ALL:
            this.LogSeq("`1034`", _3b3);
            this.LogSeq("`885`", _3b3);
            var _3b6 = this.ResumeAllSequencingRequestProcess(_3b3, _3b2);
            this.LogSeq("`646`", _3b3);
            if (_3b6.Exception !== null) {
                this.LogSeq("`71`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3b6.Exception, _3b6.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1657`", _3b3);
                this.LogSeq("`108`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3b6.DeliveryRequest, null, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_EXIT:
            this.LogSeq("`1153`", _3b3);
            this.LogSeq("`962`", _3b3);
            var _3b7 = this.ExitSequencingRequestProcess(_3b3, _3b2);
            this.LogSeq("`701`", _3b3);
            if (_3b7.Exception !== null) {
                this.LogSeq("`83`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3b7.Exception, _3b7.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1658`", _3b3);
                this.LogSeq("`125`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, null, _3b7.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_RETRY:
            this.LogSeq("`1129`", _3b3);
            this.LogSeq("`953`", _3b3);
            var _3b8 = this.RetrySequencingRequestProcess(_3b3, _3b2);
            if (_3b8.Exception !== null) {
                this.LogSeq("`82`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3b8.Exception, _3b8.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1659`", _3b3);
                this.LogSeq("`116`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3b8.DeliveryRequest, null, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_CONTINUE:
            this.LogSeq("`1070`", _3b3);
            this.LogSeq("`906`", _3b3);
            var _3b9 = this.ContinueSequencingRequestProcess(_3b3, _3b2);
            this.LogSeq("`661`", _3b3);
            if (_3b9.Exception !== null) {
                this.LogSeq("`27`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, _3b9.EndSequencingSession, _3b9.Exception, _3b9.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1660`", _3b3);
                this.LogSeq("`37`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3b9.DeliveryRequest, _3b9.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_PREVIOUS:
            this.LogSeq("`1071`", _3b3);
            this.LogSeq("`907`", _3b3);
            var _3ba = this.PreviousSequencingRequestProcess(_3b3, _3b2);
            this.LogSeq("`662`", _3b3);
            if (_3ba.Exception !== null) {
                this.LogSeq("`73`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, _3ba.EndSequencingSession, _3ba.Exception, _3ba.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1661`", _3b3);
                this.LogSeq("`113`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3ba.DeliveryRequest, _3ba.EndSequencingSession, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_CHOICE:
            this.LogSeq("`1110`", _3b3);
            this.LogSeq("`939`", _3b3);
            var _3bb = this.ChoiceSequencingRequestProcess(_3b0, _3b3, _3b2);
            this.LogSeq("`683`", _3b3);
            if (_3bb.Exception !== null) {
                this.LogSeq("`77`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3bb.Exception, _3bb.ExceptionText, _3bb.Hidden);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1662`", _3b3);
                this.LogSeq("`120`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3bb.DeliveryRequest, null, null, "", _3bb.Hidden);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
        case SEQUENCING_REQUEST_JUMP:
            this.LogSeq("`1154`", _3b3);
            this.LogSeq("`963`", _3b3);
            var _3bc = this.JumpSequencingRequestProcess(_3b0, _3b3, _3b2);
            this.LogSeq("`702`", _3b3);
            if (_3bc.Exception !== null) {
                this.LogSeq("`84`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, _3bc.Exception, _3bc.ExceptionText, false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            } else {
                this.LogSeq("`1663`", _3b3);
                this.LogSeq("`123`", _3b3);
                _3b4 = new Sequencer_SequencingRequestProcessResult(_3af, _3bc.DeliveryRequest, null, null, "", false);
                this.LogSeqReturn(_3b4, _3b3);
                return _3b4;
            }
            break;
    }
    this.LogSeq("`151`", _3b3);
    _3b4 = new Sequencer_SequencingRequestProcessResult(SEQUENCING_REQUEST_NOT_VALID, null, null, "SB.2.12-1", "The sequencing request (" + _3af + ") is not recognized.", false);
    this.LogSeqReturn(_3b4, _3b3);
    return _3b4;
}

function Sequencer_SequencingRequestProcessResult(_3bd, _3be, _3bf, _3c0, _3c1, _3c2) {
    Debug.AssertError("undefined hidden value", (_3c2 === undefined));
    Debug.AssertError("Invalid endSequencingSession (" + _3bf + ") passed to SequencingRequestProcessResult.", (_3bf != null && _3bf != true && _3bf != false));
    this.SequencingRequest = _3bd;
    this.DeliveryRequest = _3be;
    this.EndSequencingSession = _3bf;
    this.Exception = _3c0;
    this.ExceptionText = _3c1;
    this.Hidden = _3c2;
}
Sequencer_SequencingRequestProcessResult.prototype.toString = function() {
    return "SequencingRequest=" + this.SequencingRequest + ", DeliveryRequest=" + this.DeliveryRequest + ", EndSequencingSession=" + this.EndSequencingSession + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", Hidden=" + this.Hidden;
};

function Sequencer_SequencingRulesCheckProcess(_3c3, _3c4, _3c5, _3c6) {
    Debug.AssertError("Calling log not passed.", (_3c5 === undefined || _3c5 === null));
    Debug.AssertError("Simple calling log not passed.", (_3c6 === undefined || _3c6 === null));
    var _3c7 = this.LogSeqAudit("`1276`" + _3c3 + ", " + _3c4 + ")", _3c5);
    var _3c8;
    var _3c9 = Sequencer_GetApplicableSetofSequencingRules(_3c3, _3c4);
    this.LogSeq("`304`", _3c7);
    if (_3c9.length > 0) {
        var _3ca = this.LogSeqSimpleAudit("\"" + _3c3 + "\" has " + _3c4 + " sequencing rules to evaulate. Checking to see if any apply.", _3c6);
        this.LogSeq("`191`", _3c7);
        this.LogSeq("`1209`", _3c7);
        for (var i = 0; i < _3c9.length; i++) {
            this.LogSeq("`416`", _3c7);
            var _3cc = this.LogSeqSimpleAudit("Evaluating Rule #" + (i + 1) + ": \"" + _3c9[i].toString() + "\".", _3ca);
            _3c8 = this.SequencingRulesCheckSubprocess(_3c3, _3c9[i], _3c7, _3cc);
            this.LogSeq("`796`", _3c7);
            if (_3c8 === true) {
                this.LogSeq("`211`", _3c7);
                this.LogSeqReturn(_3c9[i].Action, _3c7);
                this.LogSeqSimpleReturn("Rule fired, performing action: " + _3c9[i].Action + ".", _3ca);
                return _3c9[i].Action;
            }
        }
    }
    this.LogSeq("`460`", _3c7);
    this.LogSeqReturn("`1762`", _3c7);
    return null;
}

function Sequencer_GetApplicableSetofSequencingRules(_3cd, _3ce) {
    var _3cf = new Array();
    if (_3ce == RULE_SET_POST_CONDITION) {
        _3cf = _3cd.GetPostConditionRules();
    } else {
        if (_3ce == RULE_SET_EXIT) {
            _3cf = _3cd.GetExitRules();
        } else {
            var _3d0 = _3cd.GetPreConditionRules();
            for (var i = 0; i < _3d0.length; i++) {
                switch (_3ce) {
                    case RULE_SET_HIDE_FROM_CHOICE:
                        if (_3d0[i].Action == SEQUENCING_RULE_ACTION_HIDDEN_FROM_CHOICE) {
                            _3cf[_3cf.length] = _3d0[i];
                        }
                        break;
                    case RULE_SET_STOP_FORWARD_TRAVERSAL:
                        if (_3d0[i].Action == SEQUENCING_RULE_ACTION_STOP_FORWARD_TRAVERSAL) {
                            _3cf[_3cf.length] = _3d0[i];
                        }
                        break;
                    case RULE_SET_DISABLED:
                        if (_3d0[i].Action == SEQUENCING_RULE_ACTION_DISABLED) {
                            _3cf[_3cf.length] = _3d0[i];
                        }
                        break;
                    case RULE_SET_SKIPPED:
                        if (_3d0[i].Action == SEQUENCING_RULE_ACTION_SKIP) {
                            _3cf[_3cf.length] = _3d0[i];
                        }
                        break;
                    default:
                        Debug.AssertError("ERROR - invalid sequencing rule set - " + _3ce);
                        return null;
                }
            }
        }
    }
    return _3cf;
}

function Sequencer_SequencingRulesCheckSubprocess(_3d2, rule, _3d4, _3d5) {
    Debug.AssertError("Calling log not passed.", (_3d4 === undefined || _3d4 === null));
    Debug.AssertError("Simple calling log not passed.", (_3d5 === undefined || _3d5 === null));
    var _3d6 = this.LogSeqAudit("`1166`" + _3d2 + ", " + rule + ")", _3d4);
    this.LogSeq("`326`", _3d6);
    var _3d7 = new Array();
    var _3d8;
    var _3d9;
    var i;
    this.LogSeq("`742`", _3d6);
    for (i = 0; i < rule.RuleConditions.length; i++) {
        this.LogSeq("`102`", _3d6);
        _3d8 = this.EvaluateSequencingRuleCondition(_3d2, rule.RuleConditions[i], _3d6, _3d5);
        this.LogSeq("`704`", _3d6);
        if (rule.RuleConditions[i].Operator == RULE_CONDITION_OPERATOR_NOT) {
            this.LogSeq("`667`", _3d6);
            if (_3d8 != "unknown") {
                _3d8 = (!_3d8);
            }
        }
        this.LogSeq("`291`", _3d6);
        _3d7[_3d7.length] = _3d8;
    }
    this.LogSeq("`375`", _3d6);
    if (_3d7.length === 0) {
        this.LogSeq("`614`", _3d6);
        this.LogSeqReturn(RESULT_UNKNOWN, _3d6);
        return RESULT_UNKNOWN;
    }
    this.LogSeq("`62`", _3d6);
    if (rule.ConditionCombination == RULE_CONDITION_COMBINATION_ANY) {
        _3d9 = false;
        for (i = 0; i < _3d7.length; i++) {
            _3d9 = Sequencer_LogicalOR(_3d9, _3d7[i]);
        }
        if (rule.RuleConditions.length > 1) {
            this.LogSeqSimple("Are ANY of the conditions true=" + _3d9, _3d5);
        }
    } else {
        _3d9 = true;
        for (i = 0; i < _3d7.length; i++) {
            _3d9 = Sequencer_LogicalAND(_3d9, _3d7[i]);
        }
        if (rule.RuleConditions.length > 1) {
            this.LogSeqSimple("Are ALL of the conditions true=" + _3d9, _3d5);
        }
    }
    this.LogSeq("`622`", _3d6);
    this.LogSeqReturn(_3d9, _3d6);
    if (_3d9 === true) {
        this.LogSeqSimpleReturn("True, rule will fire", _3d5);
    } else {
        if (_3d9 === false) {
            this.LogSeqSimpleReturn("False, rule will not fire", _3d5);
        } else {
            this.LogSeqSimpleReturn("Unknown, rule will not fire", _3d5);
        }
    }
    return _3d9;
}

function Sequencer_EvaluateSequencingRuleCondition(_3db, _3dc, _3dd, _3de) {
    Debug.AssertError("Calling log not passed.", (_3dd === undefined || _3dd === null));
    Debug.AssertError("Simple calling log not passed.", (_3de === undefined || _3de === null));
    var _3df = this.LogSeqAudit("`1319`" + _3db + ", " + _3dc + ")", _3dd);
    var _3e0 = null;
    switch (_3dc.Condition) {
        case SEQUENCING_RULE_CONDITION_SATISFIED:
            _3e0 = _3db.IsSatisfied(_3dc.ReferencedObjective, true);
            this.LogSeqSimple(_3db + "\" satisfied = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_STATUS_KNOWN:
            _3e0 = _3db.IsObjectiveStatusKnown(_3dc.ReferencedObjective, true);
            this.LogSeqSimple("\"" + _3db + "\" objective status known = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_KNOWN:
            _3e0 = _3db.IsObjectiveMeasureKnown(_3dc.ReferencedObjective, true);
            this.LogSeqSimple("\"" + _3db + "\" objective measure known = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_GREATER_THAN:
            _3e0 = _3db.IsObjectiveMeasureGreaterThan(_3dc.ReferencedObjective, _3dc.MeasureThreshold, true);
            this.LogSeqSimple("\"" + _3db + "\" objective measure greater than " + _3dc.MeasureThreshold + " = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_OBJECTIVE_MEASURE_LESS_THAN:
            _3e0 = _3db.IsObjectiveMeasureLessThan(_3dc.ReferencedObjective, _3dc.MeasureThreshold, true);
            this.LogSeqSimple("\"" + _3db + "\" objective measure less than " + _3dc.MeasureThreshold + " = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_COMPLETED:
            _3e0 = _3db.IsCompleted(_3dc.ReferencedObjective, true);
            this.LogSeqSimple("\"" + _3db + "\" completed = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_ACTIVITY_PROGRESS_KNOWN:
            _3e0 = _3db.IsActivityProgressKnown(_3dc.ReferencedObjective, true);
            this.LogSeqSimple("\"" + _3db + "\" activity progress known = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_ATTEMPTED:
            _3e0 = _3db.IsAttempted();
            this.LogSeqSimple("\"" + _3db + "\" attempted = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_ATTEMPT_LIMIT_EXCEEDED:
            _3e0 = _3db.IsAttemptLimitExceeded();
            this.LogSeqSimple("\"" + _3db + "\" attempt limit exceeded = " + _3e0, _3de);
            break;
        case SEQUENCING_RULE_CONDITION_ALWAYS:
            _3e0 = true;
            this.LogSeqSimple("\"" + _3db + "\" 'always' will always return true.", _3de);
            break;
        default:
            Debug.AssertError("ERROR - Encountered unsupported rule condition - " + _3dc);
            _3e0 = RESULT_UNKNOWN;
            break;
    }
    _3df.setReturn(_3e0 + "", _3df);
    return _3e0;
}

function Sequencer_LogicalOR(_3e1, _3e2) {
    if (_3e1 == RESULT_UNKNOWN) {
        if (_3e2 === true) {
            return true;
        } else {
            return RESULT_UNKNOWN;
        }
    } else {
        if (_3e2 == RESULT_UNKNOWN) {
            if (_3e1 === true) {
                return true;
            } else {
                return RESULT_UNKNOWN;
            }
        } else {
            return (_3e1 || _3e2);
        }
    }
}

function Sequencer_LogicalAND(_3e3, _3e4) {
    if (_3e3 == RESULT_UNKNOWN) {
        if (_3e4 === false) {
            return false;
        } else {
            return RESULT_UNKNOWN;
        }
    } else {
        if (_3e4 == RESULT_UNKNOWN) {
            if (_3e3 === false) {
                return false;
            } else {
                return RESULT_UNKNOWN;
            }
        } else {
            return (_3e3 && _3e4);
        }
    }
}

function Sequencer_StartSequencingRequestProcess(_3e5, _3e6) {
    Debug.AssertError("Calling log not passed.", (_3e5 === undefined || _3e5 === null));
    Debug.AssertError("Simple calling log not passed.", (_3e6 === undefined || _3e6 === null));
    var _3e7 = this.LogSeqAudit("`1222`", _3e5);
    var _3e8;
    this.LogSeq("`498`", _3e7);
    if (this.IsCurrentActivityDefined(_3e7)) {
        this.LogSeq("`455`", _3e7);
        _3e8 = new Sequencer_StartSequencingRequestProcessResult(null, "SB.2.5-1", IntegrationImplementation.GetString("You cannot 'Start' an item that is already open."), false);
        this.LogSeqReturn(_3e8, _3e7);
        return _3e8;
    }
    var _3e9 = this.GetRootActivity(_3e7);
    this.LogSeq("`318`", _3e7);
    if (_3e9.IsALeaf()) {
        this.LogSeq("`240`", _3e7);
        _3e8 = new Sequencer_StartSequencingRequestProcessResult(_3e9, null, "", false);
        this.LogSeqReturn(_3e8, _3e7);
        return _3e8;
    } else {
        if (Control.Package.Properties.AlwaysFlowToFirstSco === true || Control.Package.Properties.ShowCourseStructure == false) {
            this.LogSeqSimple("Ignoring all sequencing rules and selecting the first SCO because the package property setting AlwaysFlowToFristSco is true.", _3e6);
            this.LogSeq("`315`", _3e7);
            this.LogSeq("`1055`", _3e7);
            var _3ea = this.GetOrderedListOfActivities(false, _3e7);
            this.LogSeq("`926`", _3e7);
            for (var _3eb in _3ea) {
                if (_3ea[_3eb].IsDeliverable() === true) {
                    _3e8 = new Sequencer_StartSequencingRequestProcessResult(_3ea[_3eb], null, "", false);
                    this.LogSeqReturn(_3e8, _3e7);
                    return _3e8;
                }
            }
            _3e8 = new Sequencer_StartSequencingRequestProcessResult(null, "SB.2.5-2.5", "There are no deliverable activities in this course.", false);
            this.LogSeqReturn(_3e8, _3e7);
            return _3e8;
        } else {
            this.LogSeq("`1705`", _3e7);
            this.LogSeq("`164`", _3e7);
            var _3ec = this.FlowSubprocess(_3e9, FLOW_DIRECTION_FORWARD, true, _3e7, _3e6);
            this.LogSeq("`978`", _3e7);
            if (_3ec.Deliverable === false) {
                this.LogSeq("`65`", _3e7);
                _3e8 = new Sequencer_StartSequencingRequestProcessResult(null, _3ec.Exception, _3ec.ExceptionText, _3ec.EndSequencingSession);
                this.LogSeqReturn(_3e8, _3e7);
                return _3e8;
            } else {
                this.LogSeq("`1664`", _3e7);
                this.LogSeq("`325`", _3e7);
                _3e8 = new Sequencer_StartSequencingRequestProcessResult(_3ec.IdentifiedActivity, null, "", false);
                this.LogSeqReturn(_3e8, _3e7);
                return _3e8;
            }
        }
    }
}

function Sequencer_StartSequencingRequestProcessResult(_3ed, _3ee, _3ef, _3f0) {
    Debug.AssertError("Invalid endSequencingSession (" + _3f0 + ") passed to StartSequencingRequestProcessResult.", (_3f0 != true && _3f0 != false));
    this.DeliveryRequest = _3ed;
    this.Exception = _3ee;
    this.ExceptionText = _3ef;
    this.EndSequencingSession = _3f0;
}
Sequencer_StartSequencingRequestProcessResult.prototype.toString = function() {
    return "DeliveryRequest=" + this.DeliveryRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText + ", EndSequencingSession=" + this.EndSequencingSession;
};

function Sequencer_TerminateDescendentAttemptsProcess(_3f1, _3f2, _3f3) {
    Debug.AssertError("Calling log not passed.", (_3f2 === undefined || _3f2 === null));
    Debug.AssertError("Simple calling log not passed.", (_3f3 === undefined || _3f3 === null));
    var _3f4 = this.LogSeqAudit("`1121`" + _3f1 + ")", _3f2);
    _3f3 = this.LogSeqSimpleAudit("Ending all attempts underneath \"" + _3f1 + "\".", _3f3);
    this.LogSeq("`689`" + this.GetCurrentActivity() + "`1386`" + _3f1 + ")", _3f4);
    var _3f5 = this.FindCommonAncestor(_3f1, this.GetCurrentActivity(), _3f4);
    this.LogSeq("`152`" + _3f5 + "`967`", _3f4);
    var _3f6 = this.GetPathToAncestorExclusive(this.GetCurrentActivity(), _3f5, false);
    var _3f7 = new Array();
    this.LogSeq("`526`", _3f4);
    if (_3f6.length > 0) {
        this.LogSeq("`1057`", _3f4);
        for (var i = 0; i < _3f6.length; i++) {
            this.LogSeq("`474`" + _3f6[i].LearningObject.ItemIdentifier, _3f4);
            _3f7 = _3f7.concat(this.EndAttemptProcess(_3f6[i], true, _3f4, false, _3f3));
        }
    }
    this.LogSeq("`743`", _3f4);
    var _3f9 = this.GetMinimalSubsetOfActivitiesToRollup(_3f7, null);
    if (_3f9.length > 0) {
        this.LogSeqSimple("Invoking rollup on all activities that were just ended.", _3f3);
    }
    for (var _3fa in _3f9) {
        this.OverallRollupProcess(_3f9[_3fa], _3f4, _3f3);
    }
    this.LogSeq("`1018`", _3f4);
    this.LogSeqReturn("", _3f4);
    return;
}

function Sequencer_TerminationRequestProcess(_3fb, _3fc, _3fd) {
    Debug.AssertError("Calling log not passed.", (_3fc === undefined || _3fc === null));
    Debug.AssertError("Simple calling log not passed.", (_3fd === undefined || _3fd === null));
    var _3fe = this.LogSeqAudit("`1294`" + _3fb + ")", _3fc);
    var _3ff;
    var _400 = this.GetCurrentActivity();
    var _401 = this.Activities.GetParentActivity(_400);
    var _402 = this.GetRootActivity(_3fe);
    var _403;
    var _404 = null;
    var _405 = false;
    this.LogSeq("`367`", _3fe);
    if (!this.IsCurrentActivityDefined(_3fe)) {
        this.LogSeq("`381`", _3fe);
        _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-1", IntegrationImplementation.GetString("You cannot use 'Terminate' because no item is currently open."));
        this.LogSeqReturn(_3ff, _3fe);
        return _3ff;
    }
    this.LogSeq("`88`", _3fe);
    if ((_3fb == TERMINATION_REQUEST_EXIT || _3fb == TERMINATION_REQUEST_ABANDON) && (_400.IsActive() === false)) {
        this.LogSeq("`382`", _3fe);
        _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-2", IntegrationImplementation.GetString("The current activity has already been terminated."));
        this.LogSeqReturn(_3ff, _3fe);
        return _3ff;
    }
    switch (_3fb) {
        case TERMINATION_REQUEST_EXIT:
            this.LogSeq("`1157`", _3fe);
            this.LogSeq("`383`", _3fe);
            this.EndAttemptProcess(_400, false, _3fe, false, _3fd);
            this.LogSeq("`241`", _3fe);
            this.SequencingExitActionRulesSubprocess(_3fe, _3fd);
            this.LogSeq("`1641`", _3fe);
            var _406;
            do {
                this.LogSeq("`1112`", _3fe);
                _406 = false;
                this.LogSeq("`588`" + this.GetCurrentActivity() + ")", _3fe);
                _404 = this.SequencingPostConditionRulesSubprocess(_3fe, _3fd);
                this.LogSeq("`473`", _3fe);
                if (_404.TerminationRequest == TERMINATION_REQUEST_EXIT_ALL) {
                    this.LogSeq("`908`", _3fe);
                    _3fb = TERMINATION_REQUEST_EXIT_ALL;
                    this.LogSeq("`675`", _3fe);
                    _405 = true;
                    break;
                }
                this.LogSeq("`53`", _3fe);
                if (_404.TerminationRequest == TERMINATION_REQUEST_EXIT_PARENT) {
                    this.LogSeq("`281`", _3fe);
                    if (this.GetCurrentActivity() !== null && this.GetCurrentActivity().IsTheRoot() === false) {
                        this.LogSeq("`676`", _3fe);
                        this.SetCurrentActivity(this.Activities.GetParentActivity(this.GetCurrentActivity()), _3fe, _3fd);
                        this.LogSeq("`775`", _3fe);
                        this.EndAttemptProcess(this.GetCurrentActivity(), false, _3fe, false, _3fd);
                        this.LogSeq("`494`", _3fe);
                        _406 = true;
                    } else {
                        this.LogSeq("`1598`", _3fe);
                        this.LogSeq("`355`", _3fe);
                        _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-4", IntegrationImplementation.GetString("An 'Exit Parent' sequencing request cannot be processed on the root of the activity tree."));
                        this.LogSeqReturn(_3ff, _3fe);
                        return _3ff;
                    }
                } else {
                    this.LogSeq("`1642`", _3fe);
                    this.LogSeq("`8`", _3fe);
                    if (this.GetCurrentActivity() !== null && this.GetCurrentActivity().IsTheRoot() === true && _404.SequencingRequest != SEQUENCING_REQUEST_RETRY) {
                        this.LogSeq("`404`", _3fe);
                        _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, SEQUENCING_REQUEST_EXIT, null, "");
                        this.LogSeqReturn(_3ff, _3fe);
                        return _3ff;
                    }
                }
                this.LogSeq("`912`" + _406 + ")", _3fe);
            } while (_406 !== false);
            if (!_405) {
                this.LogSeq("`54`", _3fe);
                _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, _404.SequencingRequest, null, "");
                this.LogSeqReturn(_3ff, _3fe);
                return _3ff;
                break;
            }
        case TERMINATION_REQUEST_EXIT_ALL:
            this.LogSeq("`1077`", _3fe);
            this.LogSeq("`238`", _3fe);
            if (_400.IsActive()) {
                this.LogSeq("`819`", _3fe);
                this.EndAttemptProcess(_400, false, _3fe, false, _3fd);
            }
            this.LogSeq("`589`", _3fe);
            this.TerminateDescendentAttemptsProcess(_402, _3fe, _3fd);
            this.LogSeq("`741`", _3fe);
            this.EndAttemptProcess(_402, false, _3fe, false, _3fd);
            this.LogSeq("`353`", _3fe);
            this.SetCurrentActivity(_402, _3fe, _3fd);
            this.LogSeq("`3`", _3fe);
            if (_404 !== null && _404.SequencingRequest !== null) {
                this.LogSeq("`451`", _3fe);
                _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, _404.SequencingRequest, null, "");
                this.LogSeqReturn(_3ff, _3fe);
                return _3ff;
            } else {
                this.LogSeq("`1036`", _3fe);
                _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, SEQUENCING_REQUEST_EXIT, null, "");
                this.LogSeqReturn(_3ff, _3fe);
                return _3ff;
            }
            break;
        case TERMINATION_REQUEST_SUSPEND_ALL:
            this.LogSeq("`1014`", _3fe);
            this.LogSeq("`45`", _3fe);
            this.LogSeqSimple("Exiting the course because of a Suspend All request.", _3fd);
            if ((Control.Package.Properties.InvokeRollupAtSuspendAll === true || this.ReturnToLmsInvoked) && _400.IsActive()) {
                this.LogSeq("`510`", _3fe);
                this.EndAttemptProcess(_400, false, _3fe, true, _3fd);
            }
            if (_400.IsActive() || _400.IsSuspended()) {
                this.LogSeq("`1096`", _3fe);
                this.OverallRollupProcess(_400, _3fe, _3fd);
                this.LogSeq("`856`", _3fe);
                this.SetSuspendedActivity(_400, _3fd);
            } else {
                this.LogSeq("`1693`", _3fe);
                this.LogSeq("`258`", _3fe);
                if (!_400.IsTheRoot()) {
                    this.LogSeq("`677`", _3fe);
                    this.SetSuspendedActivity(_401, _3fd);
                } else {
                    this.LogSeq("`1643`", _3fe);
                    this.LogSeq("`263`", _3fe);
                    Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-3", "The suspend all termination request failed because there is no activity to suspend");
                }
            }
            this.LogSeq("`273`", _3fe);
            var _407 = this.GetSuspendedActivity(_3fe);
            _403 = this.GetActivityPath(_407, true);
            this.LogSeq("`1097`", _3fe);
            if (_403.length === 0) {
                this.LogSeq("`274`", _3fe);
                _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-5", IntegrationImplementation.GetString("Nothing to suspend"));
                this.LogSeqReturn(_3ff, _3fe);
                return _3ff;
            }
            this.LogSeqSimple("Marking all the parents of \"" + _407 + "\" as suspended and not active, then setting the root to be the current activity.", _3fd);
            this.LogSeq("`1015`", _3fe);
            for (var i = 0; i < _403.length; i++) {
                this.LogSeq("`640`" + _403[i].GetItemIdentifier() + ")", _3fe);
                _403[i].SetActive(false);
                this.LogSeq("`857`", _3fe);
                _403[i].SetSuspended(true);
            }
            this.LogSeq("`354`", _3fe);
            this.SetCurrentActivity(_402, _3fe, _3fd);
            this.LogSeq("`160`", _3fe);
            _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, SEQUENCING_REQUEST_EXIT, null, "");
            this.LogSeqReturn(_3ff, _3fe);
            return _3ff;
            break;
        case TERMINATION_REQUEST_ABANDON:
            this.LogSeqSimple("Setting \"" + _400 + "\" to be not active.", _3fd);
            this.LogSeq("`1098`", _3fe);
            this.LogSeq("`810`", _3fe);
            _400.SetActive(false);
            this.LogSeq("`459`", _3fe);
            _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, null, null, "");
            this.LogSeqReturn(_3ff, _3fe);
            return _3ff;
            break;
        case TERMINATION_REQUEST_ABANDON_ALL:
            this.LogSeqSimple("Exiting the course with an abandon all request.", _3fd);
            this.LogSeqSimple("Setting \"" + _400 + "\" and all its parents to be not active. Also setting the current activity to the root.", _3fd);
            this.LogSeq("`1016`", _3fe);
            this.LogSeq("`282`", _3fe);
            _403 = this.GetActivityPath(_400, true);
            this.LogSeq("`1099`", _3fe);
            if (_403.length === 0) {
                this.LogSeq("`283`", _3fe);
                _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-6", IntegrationImplementation.GetString("Nothing to close"));
                this.LogSeqReturn(_3ff, _3fe);
                return _3ff;
            }
            this.LogSeq("`1017`", _3fe);
            for (var i = 0; i < _403.length; i++) {
                this.LogSeq("`871`", _3fe);
                _403[i].SetActive(false);
            }
            this.LogSeq("`360`", _3fe);
            this.SetCurrentActivity(_402, _3fe, _3fd);
            this.LogSeq("`165`", _3fe);
            _3ff = new Sequencer_TerminationRequestProcessResult(_3fb, SEQUENCING_REQUEST_EXIT, null, "");
            this.LogSeqReturn(_3ff, _3fe);
            return _3ff;
            break;
        default:
            this.LogSeq("`255`", _3fe);
            _3ff = new Sequencer_TerminationRequestProcessResult(TERMINATION_REQUEST_NOT_VALID, null, "TB.2.3-7", IntegrationImplementation.GetString("The 'Termination' request {0} is not recognized.", _3fb));
            this.LogSeqReturn(_3ff, _3fe);
            return _3ff;
            break;
    }
}

function Sequencer_TerminationRequestProcessResult(_409, _40a, _40b, _40c) {
    this.TerminationRequest = _409;
    this.SequencingRequest = _40a;
    this.Exception = _40b;
    this.ExceptionText = _40c;
}
Sequencer_TerminationRequestProcessResult.prototype.toString = function() {
    return "TerminationRequest=" + this.TerminationRequest + ", SequencingRequest=" + this.SequencingRequest + ", Exception=" + this.Exception + ", ExceptionText=" + this.ExceptionText;
};

function SSPApi(_40d, _40e) {
    this.MaxSSPStorage = parseInt(_40d, 10);
    this.ApiInstance = _40e;
}
SSPApi.prototype.InitializeBuckets = SSPApi_InitializeBuckets;
SSPApi.prototype.CheckForGetValueError = SSPApi_CheckForGetValueError;
SSPApi.prototype.CheckForSetValueError = SSPApi_CheckForSetValueError;
SSPApi.prototype.RetrieveGetValueData = SSPApi_RetrieveGetValueData;
SSPApi.prototype.StoreValue = SSPApi_StoreValue;
SSPApi.prototype.GetBucketById = SSPApi_GetBucketById;
SSPApi.prototype.GetBucketByIndex = SSPApi_GetBucketByIndex;
SSPApi.prototype.GetAccessibleBucketCount = SSPApi_GetAccessibleBucketCount;
SSPApi.prototype.GetDelimiterValues = SSPApi_GetDelimiterValues;
SSPApi.prototype.RemoveDelimitersFromElementName = SSPApi_RemoveDelimitersFromElementName;
SSPApi.prototype.RemoveDelimitersFromValue = SSPApi_RemoveDelimitersFromValue;
SSPApi.prototype.GetDelimiterValues = SSPApi_GetDelimiterValues;
SSPApi.prototype.GetCurrentSCOItemIdentifier = SSPApi_GetCurrentSCOItemIdentifier;
SSPApi.prototype.AllocateBucket = SSPApi_AllocateBucket;
SSPApi.prototype.GetStorageAllowedByLms = SSPApi_GetStorageAllowedByLms;
SSPApi.prototype.ResetBucketsForActivity = SSPApi_ResetBucketsForActivity;
SSPApi.prototype.SetErrorState = SSPApi_SetErrorState;
SSPApi.prototype.WriteDetailedLog = SSPApi_WriteDetailedLog;

function SSPApi_InitializeBuckets() {
    var _40f;
    var _410;
    var _411;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _40f = Control.SSPBuckets[i];
        if (_40f.AllocationSuccess == SSP_ALLOCATION_SUCCESS_NOT_ATTEMPTED) {
            _410 = this.GetStorageAllowedByLms(_40f.SizeMin, _40f.SizeRequested);
            if (_410 == null) {
                _411 = SSP_ALLOCATION_SUCCESS_FAILURE;
            } else {
                if (_410 == _40f.SizeMin) {
                    _411 = SSP_ALLOCATION_SUCCESS_MINIMUM;
                } else {
                    if (_410 == _40f.SizeRequested) {
                        _411 = SSP_ALLOCATION_SUCCESS_REQUESTED;
                    } else {
                        Debug.AssertError("Invalid allocation");
                    }
                }
            }
            _40f.AllocationSuccess = _411;
        }
    }
}

function SSPApi_CheckForGetValueError(_413, _414, _415, _416) {
    var _417 = this.RemoveDelimitersFromElementName(_414);
    var _418 = this.GetDelimiterValues(_413);
    var _419;
    var _41a;
    var size;
    if (_415 !== "") {
        var _41c = this.GetAccessibleBucketCount();
        if (_415 >= _41c) {
            this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The SSP Bucket collection does not have an element at index " + _415 + ", the current element count is " + _41c + ".");
            return false;
        }
    }
    switch (_417) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.allocate data model element is write-only.");
            return false;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _419 = this.GetBucketByIndex(_415);
            _41a = _418["offset"];
            size = _418["size"];
            if (_419.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_41a != null) {
                _41a = new String(_41a);
                if (_41a.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _41a = parseInt(_41a, 10);
                if (_41a % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_41a >= _419.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _419.SizeAllocated() + " bytes of storage. Bytes started at offset " + _41a + "were requested.");
                    return false;
                }
            }
            if (size != null) {
                size = new String(size);
                if (size.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be a valid even integer greater than 0.");
                    return false;
                }
                size = parseInt(size, 10);
                if (size % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be an even integer.");
                    return false;
                }
                if ((_41a + size) >= _419.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Requested data exceeds available data. This bucket currently has allocated " + _419.SizeAllocated() + " bytes of storage. " + size + " bytes starting at offset " + _41a + " were requested. Size + Offset = " + (size + _41a));
                    return false;
                }
            }
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.n.appendData data model element is write-only.");
            return false;
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            if (_418["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _419 = this.GetBucketById(_418["bucketID"], true);
            if (_419 == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_418["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            _41a = _418["offset"];
            size = _418["size"];
            if (_419.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_41a != null) {
                _41a = new String(_41a);
                if (_41a.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _41a = parseInt(_41a, 10);
                if (_41a % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_41a >= _419.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _419.SizeAllocated() + " bytes of storage. Bytes starting at offset " + _41a + " were requested.");
                    return false;
                }
            }
            if (size != null) {
                size = new String(size);
                if (size.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be a valid even integer greater than 0.");
                    return false;
                }
                size = parseInt(size, 10);
                if (size % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "The value for size must be an even integer.");
                    return false;
                }
                if ((_41a + size) >= _419.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Requested data exceeds available data. This bucket currently has allocated " + _419.SizeAllocated() + " bytes of storage. " + size + " bytes started at offset " + _41a + " were requested. Size + Offset = " + (size + _41a));
                    return false;
                }
            }
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            var _41d = _418["bucketID"];
            if (_41d == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _419 = this.GetBucketById(_41d, true);
            if (_419 == null) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_418["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            if (_419.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_GET_FAILURE_ERROR, "Bucket improperly declared.");
            }
            break;
        case "ssp.appendData":
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_WRITE_ONLY_ERROR, "The ssp.appendData data model element is write-only.");
            return false;
            break;
        default:
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _413 + "' does not exist.");
            return false;
            break;
    }
    this.WriteDetailedLog("`1558`");
    return true;
}

function SSPApi_CheckForSetValueError(_41e, _41f, _420, _421, _422) {
    var _423 = this.RemoveDelimitersFromElementName(_420);
    var _424 = this.GetDelimiterValues(_41f);
    _41f = this.RemoveDelimitersFromValue(_41f);
    var _425;
    var _426;
    var _427;
    if (_421 !== "") {
        var _428 = this.GetAccessibleBucketCount();
        if (_421 >= _428) {
            this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The SSP Bucket collection does not have an element at index " + _421 + ", the current element count is " + _428 + ".");
            return false;
        }
    }
    switch (_423) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp._count data model element is read-only");
            return false;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            var _429 = _424["bucketID"];
            var _42a = _424["minimum"];
            var _42b = _424["requested"];
            var _42c = _424["reducible"];
            var _42d = _424["persistence"];
            var type = _424["type"];
            if (_429 == null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucketID delimiter must be included in calls to ssp.allocate.");
                return false;
            }
            _429 = new String(_429);
            if (_429.length > 4000) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucketID can only have a maximum of 4000 characters.");
                return false;
            }
            if (_42b == null) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The requested delimiter must be included in calls to ssp.allocate.");
                return false;
            }
            _42b = new String(_42b);
            if (_42b.search(/\D/) >= 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be a valid integer greater than or equal to 0.");
                return false;
            }
            _42b = parseInt(_42b, 10);
            if (_42b < 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be greater than or equal to 0.");
                return false;
            }
            if (_42b % 2 != 0) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested must be an even number.");
                return false;
            }
            var _42f = (Math.pow(2, 32) - 1);
            if (_42b > _42f) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for requested is bigger than the max size this LMS allows of " + _42f + ".");
                return false;
            }
            if (_42a != null) {
                _42a = new String(_42a);
                if (_42a.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be a valid integer greater than or equal to 0.");
                    return false;
                }
                _42a = parseInt(_42a, 10);
                if (_42a < 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be greater than or equal to 0.");
                    return false;
                }
                if (_42a % 2 != 0) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum must be an even number.");
                    return false;
                }
                if (_42a > _42f) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The value for minimum is bigger than the max size this LMS allows of " + _42f + ".");
                    return false;
                }
                if (_42a > _42b) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The minimum requested amount of storage (" + _42a + ") cannot be greater than the requested amount (" + _42b + ").");
                    return false;
                }
            }
            if (_42c != null) {
                _42c = new String(_42c);
                if (_42c != "true" && _42c != "false") {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The reducible delimiter ('" + _42c + "') must be 'true' or 'false'.");
                    return false;
                }
            }
            if (_42d != null) {
                _42d = new String(_42d);
                if (_42d != SSP_PERSISTENCE_LEARNER && _42d != SSP_PERSISTENCE_COURSE && _42d != SSP_PERSISTENCE_SESSION) {
                    this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The persistence delimiter ('" + _42d + "') must be " + SSP_PERSISTENCE_SESSION + ", '" + SSP_PERSISTENCE_COURSE + "' or '" + SSP_PERSISTENCE_LEARNER + "'.");
                    return false;
                }
            }
            type = new String(type);
            if (type.length > 3000) {
                this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_TYPE_MISMATCH_ERROR, "The bucket type can only have a maximum of 3000 characters.");
                return false;
            }
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.allocation_success data model element is read-only");
            return false;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.bucket_id data model element is read-only");
            return false;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.n.bucket_state data model element is read-only");
            return false;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _427 = this.GetBucketByIndex(_421);
            _426 = _424["offset"];
            if (_427.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_426 != null) {
                _426 = new String(_426);
                if (_426.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _426 = parseInt(_426, 10);
                if (_426 % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_426 >= _427.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _427.SizeAllocated() + " bytes of storage. Setting bytes started at offset " + _426 + " was requested.");
                    return false;
                }
                if (_426 >= _427.CurrentlyUsedStorage()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket not packed. There are currently " + _427.CurrentlyUsedStorage() + " bytes of data stored in this bucket. The offset must be " + "less than this value.");
                    return false;
                }
            } else {
                _426 = 0;
            }
            _425 = _426 + (_41f.length * 2);
            if (_425 > _427.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_41f.length * 2) + " bytes (each character is 2 bytes). Added to an offset of " + _426 + " bytes, gives a total size of " + _425 + ", which is greater than the allocated size of this bucket (" + _427.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            _427 = this.GetBucketByIndex(_421);
            if (_427.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            _425 = _427.CurrentlyUsedStorage() + (_41f.length * 2);
            if (_425 > _427.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_41f.length * 2) + " bytes (each character is 2 bytes). Added to the current value of size " + _427.CurrentlyUsedStorage() + " bytes, gives a total size of " + _425 + ", which is greater than the allocated size of this bucket (" + _427.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            if (_424["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _427 = this.GetBucketById(_424["bucketID"], true);
            if (_427 == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_424["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            _426 = _424["offset"];
            if (_427.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            if (_426 != null) {
                _426 = new String(_426);
                if (_426.search(/\D/) >= 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be a valid even integer greater than 0.");
                    return false;
                }
                _426 = parseInt(_426, 10);
                if (_426 % 2 != 0) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "The value for offset must be an even integer.");
                    return false;
                }
                if (_426 >= _427.SizeAllocated()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Offset exceeds bucket size. This bucket currently has allocated " + _427.SizeAllocated() + " bytes of storage. Setting bytes started at offset " + _426 + " was requested.");
                    return false;
                }
                if (_426 >= _427.CurrentlyUsedStorage()) {
                    this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket not packed. There are currently " + _427.CurrentlyUsedStorage() + " bytes of data stored in this bucket. The offset must be " + "less than this value.");
                    return false;
                }
            } else {
                _426 = 0;
            }
            _425 = _426 + (_41f.length * 2);
            if (_425 > _427.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_41f.length * 2) + " bytes (each character is 2 bytes). Added to an offset of " + _426 + " bytes, gives a total size of " + _425 + ", which is greater than the allocated size of this bucket (" + _427.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            this.SetErrorState(SCORM2004_DATA_MODEL_ELEMENT_IS_READ_ONLY_ERROR, "The ssp.bucket_state data model element is read-only");
            return false;
        case "ssp.appendData":
            this.WriteDetailedLog("`1493`");
            if (_424["bucketID"] == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. bucketID delimiter is required when using the bucket manager interface.");
                return false;
            }
            _427 = this.GetBucketById(_424["bucketID"], true);
            if (_427 == null) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket does not exist. The bucketID '" + new String(_424["bucketID"]) + "' is not declared or is not visible to this SCO.");
                return false;
            }
            if (_427.AllocationSuccess == SSP_ALLOCATION_SUCCESS_FAILURE) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket improperly declared.");
                return false;
            }
            _425 = _427.CurrentlyUsedStorage() + (_41f.length * 2);
            if (_425 > _427.SizeAllocated()) {
                this.SetErrorState(SCORM2004_GENERAL_SET_FAILURE_ERROR, "Bucket size exceeded. The value sent has a length of " + (_41f.length * 2) + " bytes (each character is 2 bytes). Added to the current value of size " + _427.CurrentlyUsedStorage() + " bytes, gives a total size of " + _425 + ", which is greater than the allocated size of this bucket (" + _427.SizeAllocated() + " bytes).");
                return false;
            }
            break;
        default:
            this.SetErrorState(SCORM2004_UNDEFINED_DATA_MODEL_ELEMENT_ERROR, "The data model element '" + _41e + "' does not exist.");
            return false;
            break;
    }
    this.WriteDetailedLog("`1558`");
    return true;
}

function SSPApi_RetrieveGetValueData(_430, _431, _432, _433) {
    var _434 = this.RemoveDelimitersFromElementName(_431);
    var _435 = this.GetDelimiterValues(_430);
    var _436 = "";
    switch (_434) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            _436 = this.GetAccessibleBucketCount();
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            Debug.AssertError("ERROR - Element is Write Only, ssp.allocate");
            blnReturn = false;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            var _437 = this.GetBucketByIndex(_432);
            _436 = _437.AllocationSuccess;
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            _437 = this.GetBucketByIndex(_432);
            _436 = _437.Id;
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            _437 = this.GetBucketByIndex(_432);
            _436 = _437.GetBucketState();
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            _437 = this.GetBucketByIndex(_432);
            _436 = _437.GetData(_435["offset"], _435["size"]);
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            Debug.AssertError("ERROR - Element is Write Only, ssp.n.appendData");
            blnReturn = false;
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            _437 = this.GetBucketById(_435["bucketID"], true);
            _436 = _437.GetData(_435["offset"], _435["size"]);
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            _437 = this.GetBucketById(_435["bucketID"], true);
            _436 = _437.GetBucketState();
            break;
        case "ssp.appendData":
            Debug.AssertError("ERROR - Element is Write Only, ssp.appendData");
            blnReturn = false;
            break;
        default:
            Debug.AssertError("ERROR - Unrecognized data model element:" + _434);
            blnReturn = false;
            break;
    }
    return _436;
}

function SSPApi_StoreValue(_438, _439, _43a, _43b, _43c) {
    var _43d = this.RemoveDelimitersFromElementName(_43a);
    var _43e = this.GetDelimiterValues(_439);
    _439 = this.RemoveDelimitersFromValue(_439);
    var _43f = true;
    switch (_43d) {
        case "ssp._count":
            this.WriteDetailedLog("`1571`");
            Debug.AssertError("ERROR - Element is Read Only, ssp._count");
            _43f = false;
            break;
        case "ssp.allocate":
            this.WriteDetailedLog("`1533`");
            this.AllocateBucket(_43e["bucketID"], _43e["minimum"], _43e["requested"], _43e["reducible"], _43e["persistence"], _43e["type"]);
            _43f = true;
            break;
        case "ssp.n.allocation_success":
            this.WriteDetailedLog("`1305`");
            Debug.AssertError("ERROR - Element is Read Only, ssp._count");
            _43f = false;
            break;
        case "ssp.n.id":
            this.WriteDetailedLog("`1604`");
        case "ssp.n.bucket_id":
            this.WriteDetailedLog("`1479`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
            _43f = false;
            break;
        case "ssp.n.bucket_state":
            this.WriteDetailedLog("`1406`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_state");
            _43f = false;
            break;
        case "ssp.n.data":
            this.WriteDetailedLog("`1572`");
            bucket = this.GetBucketByIndex(_43b);
            bucket.WriteData(_43e["offset"], _439);
            break;
        case "ssp.n.appendData":
            this.WriteDetailedLog("`1451`");
            bucket = this.GetBucketByIndex(_43b);
            bucket.AppendData(_439);
            break;
        case "ssp.data":
            this.WriteDetailedLog("`1603`");
            bucket = this.GetBucketById(_43e["bucketID"], true);
            bucket.WriteData(_43e["offset"], _439);
            break;
        case "ssp.bucket_state":
            this.WriteDetailedLog("`1450`");
            Debug.AssertError("ERROR - Element is Read Only, ssp.n.bucket_id");
            _43f = false;
            break;
        case "ssp.appendData":
            this.WriteDetailedLog("`1493`");
            bucket = this.GetBucketById(_43e["bucketID"], true);
            bucket.AppendData(_439);
            break;
        default:
            Debug.AssertError("ERROR - Unrecognized data model element:" + _43d);
            _43f = false;
            break;
    }
    return _43f;
}

function SSPApi_GetBucketById(_440, _441) {
    var _442 = null;
    for (var _443 in Control.SSPBuckets) {
        if ((_441 == false) || Control.SSPBuckets[_443].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            if (Control.SSPBuckets[_443].Id == _440) {
                return Control.SSPBuckets[_443];
            }
        }
    }
    return _442;
}

function SSPApi_GetBucketByIndex(_444) {
    var _445 = null;
    i = 0;
    for (var _446 in Control.SSPBuckets) {
        if (Control.SSPBuckets[_446].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            if (i == _444) {
                return Control.SSPBuckets[_446];
            }
            i++;
        }
    }
    return _445;
}

function SSPApi_GetAccessibleBucketCount() {
    var _447 = 0;
    for (var _448 in Control.SSPBuckets) {
        if (Control.SSPBuckets[_448].IsVisible(this.GetCurrentSCOItemIdentifier())) {
            _447++;
        }
    }
    return _447;
}

function SSPApi_RemoveDelimitersFromElementName(_449) {
    var _44a;
    var _44b;
    _449 = new String(_449);
    _44b = _449;
    _44a = _449.indexOf("{");
    if (_44a > 0) {
        _44b = _449.substr(0, _44a - 1);
    }
    return _44b.toString();
}

function SSPApi_RemoveDelimitersFromValue(_44c) {
    var _44d = /^\{\w+=[^\s\}]+\}/;
    _44c = new String(_44c);
    while (_44c.match(_44d)) {
        _44c = _44c.replace(_44d, "");
    }
    return _44c;
}

function SSPApi_GetDelimiterValues(_44e) {
    var _44f = /\{\w+=[^\s\}]+\}/g;
    var _450 = _44e.match(_44f);
    var _451 = new Array();
    if (_450 != null) {
        for (var i = 0; i < _450.length; i++) {
            var _453 = _450[i].slice(1, -1);
            var _454 = _453.split("=");
            _451[_454[0]] = [_454[1]];
        }
    }
    return _451;
}

function SSPApi_GetCurrentSCOItemIdentifier() {
    return Control.Sequencer.GetCurrentActivity().ItemIdentifier;
}

function SSPApi_AllocateBucket(_455, _456, _457, _458, _459, type) {
    var _45b = this.GetBucketById(_455, false);
    var _45c;
    if (_456 == undefined || type == "minimum") {
        _456 = 0;
    }
    if (_458 == undefined || type == "reducible") {
        redicible = false;
    }
    if (_459 == undefined || type == "persistence") {
        _459 = "learner";
    }
    if (type == undefined || type == "undefined") {
        type = "";
    }
    if (_45b != null) {
        if (_45b.SizeMin != _456 || _45b.SizeRequested != _457 || _45b.Reducible != _458 || _45b.Persistence != _459 || _45b.BucketType != type) {
            _45c = Control.SSPBuckets.length;
            Control.SSPBuckets[_45c] = new SSPBucket(_45c, _455, type, _459, _456, _457, _458, this.GetCurrentSCOItemIdentifier(), SSP_ALLOCATION_SUCCESS_FAILURE, "");
            Control.SSPBuckets[_45c].SetDirtyData();
        }
    } else {
        var _45d = this.GetStorageAllowedByLms(_456, _457);
        var _45e;
        if (_45d == null) {
            _45e = SSP_ALLOCATION_SUCCESS_FAILURE;
        } else {
            if (_45d == _456) {
                _45e = SSP_ALLOCATION_SUCCESS_MINIMUM;
            } else {
                if (_45d == _457) {
                    _45e = SSP_ALLOCATION_SUCCESS_REQUESTED;
                } else {
                    Debug.AssertError("Invalid allocation");
                }
            }
        }
        _45c = Control.SSPBuckets.length;
        Control.SSPBuckets[_45c] = new SSPBucket(_45c, _455, type, _459, _456, _457, _458, (_459 == SSP_PERSISTENCE_SESSION ? this.GetCurrentSCOItemIdentifier() : ""), _45e, "");
        Control.SSPBuckets[_45c].SetDirtyData();
    }
}

function SSPApi_GetStorageAllowedByLms(_45f, _460) {
    _45f = parseInt(_45f, 10);
    _460 = parseInt(_460, 10);
    var _461 = 0;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _461 += Control.SSPBuckets[i].SizeAllocated();
    }
    if ((_461 + _460) <= this.MaxSSPStorage) {
        return _460;
    } else {
        if (_45f > 0 && ((_461 + _45f) <= this.MaxSSPStorage)) {
            return _45f;
        } else {
            return null;
        }
    }
}

function SSPApi_ResetBucketsForActivity(_463) {
    var _464;
    for (var i = 0; i < Control.SSPBuckets.length; i++) {
        _464 = Control.SSPBuckets[i];
        if (_464.LocalActivityId == _463 && _464.Persistence == SSP_PERSISTENCE_SESSION) {
            _464.ResetData();
        }
    }
}

function SSPApi_SetErrorState(_466, _467) {
    this.ApiInstance.SetErrorState(_466, _467);
}

function SSPApi_WriteDetailedLog(str) {
    this.ApiInstance.WriteDetailedLog(str);
}
