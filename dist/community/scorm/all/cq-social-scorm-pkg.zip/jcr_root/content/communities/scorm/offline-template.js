function GetCurrentRegistration() {
    var outputScript = 'new Registration("' + RegistrationToDeliver.Id + '",';
    //if(Control.Sequencer.CurrentActivity){
    //	outputScript += '"'+Control.Sequencer.CurrentActivity.DatabaseId + '"';
    //}else{
    outputScript += 'null';
    //}


    outputScript += ',true,"normal",';
    outputScript += 'new Package ("' +
        Control.Package.Id + '",' +
        Control.Package.ObjectivesGlobalToSystem + ',"' +
        Control.Package.LearningStandard.value + '",' +
        'new PackageProperties( ' +
        Control.Package.Properties.ShowFinishButton + ',' +
        Control.Package.Properties.ShowCloseItem + ',' +
        Control.Package.Properties.ShowHelp + ',' +
        Control.Package.Properties.ShowProgressBar + ',' +
        Control.Package.Properties.UseMeasureProgressBar + ',' +
        Control.Package.Properties.ShowCourseStructure + ',' +
        Control.Package.Properties.CourseStructureStartsOpen + ',' +
        Control.Package.Properties.ShowNavBar + ',' +
        Control.Package.Properties.ShowTitleBar + ',' +
        Control.Package.Properties.EnableFlowNav + ',' +
        Control.Package.Properties.EnableChoiceNav + ',' +
        Control.Package.Properties.DesiredWidth + ',' +
        Control.Package.Properties.DesiredHeight + ',' +
        Control.Package.Properties.DesiredFullScreen + ',' +
        Control.Package.Properties.RequiredWidth + ',' +
        Control.Package.Properties.RequiredHeight + ',' +
        Control.Package.Properties.RequiredFullScreen + ',' +
        Control.Package.Properties.CourseStructureWidth + ',"' +
        Control.Package.Properties.ScoLaunchType + '","' +
        Control.Package.Properties.PlayerLaunchType + '","' +
        Control.Package.Properties.IntermediateScoSatisfiedNormalExitAction + '","' +
        Control.Package.Properties.IntermediateScoSatisfiedSuspendExitAction + '","' +
        Control.Package.Properties.IntermediateScoSatisfiedTimeoutExitAction + '","' +
        Control.Package.Properties.IntermediateScoSatisfiedLogoutExitAction + '","' +
        Control.Package.Properties.IntermediateScoNotSatisfiedNormalExitAction + '","' +
        Control.Package.Properties.IntermediateScoNotSatisfiedSuspendExitAction + '","' +
        Control.Package.Properties.IntermediateScoNotSatisfiedTimeoutExitAction + '","' +
        Control.Package.Properties.IntermediateScoNotSatisfiedLogoutExitAction + '","' +
        Control.Package.Properties.FinalScoCourseSatisfiedNormalExitAction + '","' +
        Control.Package.Properties.FinalScoCourseSatisfiedSuspendExitAction + '","' +
        Control.Package.Properties.FinalScoCourseSatisfiedTimeoutExitAction + '","' +
        Control.Package.Properties.FinalScoCourseSatisfiedLogoutExitAction + '","' +
        Control.Package.Properties.FinalScoCourseNotSatisfiedNormalExitAction + '","' +
        Control.Package.Properties.FinalScoCourseNotSatisfiedSuspendExitAction + '","' +
        Control.Package.Properties.FinalScoCourseNotSatisfiedTimeoutExitAction + '","' +
        Control.Package.Properties.FinalScoCourseNotSatisfiedLogoutExitAction + '",' +
        Control.Package.Properties.PreventRightClick + ',' +
        Control.Package.Properties.PreventWindowResize + ',' +
        Control.Package.Properties.IsAvailableOffline + ',"' +
        Control.Package.Properties.StatusDisplay + '","' +
        Control.Package.Properties.ScoreRollupMode + '",' +
        Control.Package.Properties.NumberOfScoringObjects + ',"' +
        Control.Package.Properties.StatusRollupMode + '",' +
        Control.Package.Properties.ThresholdScore + ',' +
        Control.Package.Properties.ApplyRollupStatusToSuccess + ',' +
        Control.Package.Properties.FirstScoIsPretest + ',' +
        Control.Package.Properties.WrapScoWindowWithApi + ',' +
        Control.Package.Properties.FinishCausesImmediateCommit + ',' +
        Control.Package.Properties.DebugControlAudit + ',' +
        Control.Package.Properties.DebugControlDetailed + ',' +
        Control.Package.Properties.DebugRteAudit + ',' +
        Control.Package.Properties.DebugRteDetailed + ',' +
        Control.Package.Properties.DebugSequencingAudit + ',' +
        Control.Package.Properties.DebugSequencingDetailed + ',' +
        Control.Package.Properties.DebugSequencingSimple + ',' +
        Control.Package.Properties.DebugLookAheadAudit + ',' +
        Control.Package.Properties.DebugLookAheadDetailed + ',' +
        Control.Package.Properties.DebugIncludeTimestamps + ',' +
        Control.Package.Properties.CaptureHistory + ',' +
        Control.Package.Properties.CaptureHistoryDetailed + ',' +
        Control.Package.Properties.CommMaxFailedSubmissions + ',' +
        Control.Package.Properties.CommCommitFrequency + ',"' +
        Control.Package.Properties.InvalidMenuItemAction + '",' +
        Control.Package.Properties.AlwaysFlowToFirstSco + ',' +
        Control.Package.Properties.LogoutCausesPlayerExit + ',"' +
        Control.Package.Properties.ResetRunTimeDataTiming + '",' +
        Control.Package.Properties.ValidateInteractionResponses + ',"' +
        Control.Package.Properties.LookaheadSequencerMode + '",' +
        Control.Package.Properties.ScoreOverridesStatus + ',' +
        Control.Package.Properties.AllowCompleteStatusChange + ',' +
        Control.Package.Properties.ScaleRawScore + ',' +
        Control.Package.Properties.RollupEmptySetToUnknown + ',"' +
        Control.Package.Properties.ReturnToLmsAction + '",' +
        Control.Package.Properties.UseQuickLookaheadSequencer + ',' +
        Control.Package.Properties.ForceDisableRootChoice + ',' +
        Control.Package.Properties.RollupRuntimeAtScoUnload + ',' +
        Control.Package.Properties.ForceObjectiveCompletionSetByContent + ',' +
        Control.Package.Properties.InvokeRollupAtSuspendAll + ',"' +
        Control.Package.Properties.CompletionStatOfFailedSuccessStat + '",' +
        Control.Package.Properties.SatisfiedCausesCompletion + ',' +
        Control.Package.Properties.MakeStudentPrefsGlobalToCourse + ',' +
        Control.Package.Properties.LaunchCompletedRegsAsNoCredit + ',' +
        Control.Package.Properties.IsCompletionTracked + ',' +
        Control.Package.Properties.IsSatisfactionTracked + ',' +
        Control.Package.Properties.IsScoreTracked + ',' +
        Control.Package.Properties.IsIncompleteScoreMeaningful + ',' +
        Control.Package.Properties.IsIncompleteSatisfactionMeaningful + ',' +
        Control.Package.Properties.SuspendDataMaxLength + ',' +
        Control.Package.Properties.TimeLimit + '),' +
        Control.Package.SharedDataGlobalToSystem + ',' +
        'new Array(';
    for (var k = 0; k < Control.Package.LearningObjects.length; k++) {
        outputScript += GetPackageLearningObjectOutputString(Control.Package.LearningObjects[k]);
        if (k < Control.Package.LearningObjects.length - 1) {
            outputScript += ',';
        }
    }
    outputScript += '))';
    //start activities
    outputScript += ',new Array(';
    for (var i = 0; i < Control.Sequencer.Activities.ActivityList.length; i++) {
        outputScript += GetActivityOutputString(Control.Sequencer.Activities.ActivityList[i]);
        if (i < Control.Sequencer.Activities.ActivityList.length - 1) {
            outputScript += ',';
        }
    }
    outputScript += '),new Array(), new Array(), new Array());';


    return outputScript;

}

function GetPackageLearningObjectOutputString(lo) {
    var out = '';

    out += 'new LearningObject ( ' +
        checkForNull(lo.Title, true) + ',' +
        checkForNull(lo.Href, true) + ',' +
        checkForNull(lo.Parameters, true) + ',' +
        checkForNull(lo.DataFromLms, true) + ',' +
        checkForNull(lo.MasteryScore) + ',' +
        checkForNull(lo.MaxTimeAllowed, true) + ',' +
        checkForNull(lo.TimeLimitAction, true) + ',' +
        checkForNull(lo.Prerequisites, true) + ',' +
        checkForNull(lo.Visible) + ',' +
        checkForNull(lo.CompletedByMeasure) + ',' +
        checkForNull(lo.CompletionThreshold) + ',' +
        lo.CompletionProgressWeight + ',' +
        checkForNull(lo.PersistState) + ',' +
        checkForNull(lo.ItemIdentifier, true) + ',' +
        checkForNull(lo.ResourceIdentifier, true) + ',' +
        checkForNull(lo.ExternalIdentifier, true) + ',' +
        checkForNull(lo.DatabaseIdentifier, true) + ',' +
        checkForNull(lo.ScormType, true) + ',' +
        'new Array(),' +
        'new SequencingData ( ' +
        checkForNull(lo.SequencingData.Identifier, true) + ',' +
        checkForNull(lo.SequencingData.Identifierref, true) + ',' +
        checkForNull(lo.SequencingData.ControlChoice) + ',' +
        checkForNull(lo.SequencingData.ControlChoiceExit) + ',' +
        checkForNull(lo.SequencingData.ControlFlow) + ',' +
        checkForNull(lo.SequencingData.ControlForwardOnly) + ',' +
        checkForNull(lo.SequencingData.UseCurrentAttemptObjectiveInformation) + ',' +
        checkForNull(lo.SequencingData.UseCurrentAttemptProgressInformation) + ',' +
        checkForNull(lo.SequencingData.ConstrainChoice) + ',' +
        checkForNull(lo.SequencingData.PreventActivation) + ',new Array(),new Array(),new Array(),' +
        //lo.SequencingData.PreConditionSequencingRules+',"'+
        //lo.SequencingData.PostConditionSequencingRules)+','+
        //lo.SequencingData.ExitSequencingRules)+','+
        checkForNull(lo.SequencingData.LimitConditionAttemptControl) + ',' +
        lo.SequencingData.LimitConditionAttemptLimit + ',' +
        checkForNull(lo.SequencingData.LimitConditionAttemptAbsoluteDurationControl) + ',' +
        checkForNull(lo.SequencingData.LimitConditionAttemptAbsoluteDurationLimit) + ',new Array(),' +
        //lo.SequencingData.RollupRules)+','+
        checkForNull(lo.SequencingData.RollupObjectiveSatisfied) + ',' +
        lo.SequencingData.RollupObjectiveMeasureWeight + ',' +
        checkForNull(lo.SequencingData.RollupProgressCompletion) + ',' +
        checkForNull(lo.SequencingData.MeasureSatisfactionIfActive) + ',' +
        checkForNull(lo.SequencingData.RequiredForSatisfied) + ',' +
        checkForNull(lo.SequencingData.RequiredForNotSatisfied) + ',' +
        checkForNull(lo.SequencingData.RequiredForCompleted) + ',' +
        checkForNull(lo.SequencingData.RequiredForIncomplete) + ',null, new Array(),' +
        //lo.SequencingData.PrimaryObjective)+','+
        //lo.SequencingData.Objectives+',"'+
        checkForNull(lo.SequencingData.SelectionTiming) + ',' +
        checkForNull(lo.SequencingData.SelectionCountStatus) + ',' +
        lo.SequencingData.SelectionCount + ',' +
        checkForNull(lo.SequencingData.RandomizationTiming) + ',' +
        checkForNull(lo.SequencingData.RandomizeChildren) + ',' +
        checkForNull(lo.SequencingData.Tracked) + ',' +
        checkForNull(lo.SequencingData.CompletionSetByContent) + ',' +
        checkForNull(lo.SequencingData.ObjectiveSetByContent) + ',' +
        checkForNull(lo.SequencingData.HidePrevious) + ',' +
        checkForNull(lo.SequencingData.HideContinue) + ',' +
        checkForNull(lo.SequencingData.HideExit) + ',' +
        checkForNull(lo.SequencingData.HideAbandon) + ',' +
        checkForNull(lo.SequencingData.HideSuspendAll) + ',' +
        checkForNull(lo.SequencingData.HideAbandonAll) + ',' +
        checkForNull(lo.SequencingData.HideExitAll) + '),' +
        'new Array(),';
    if (lo.Children.length > 0) {
        for (var c = 0; c < lo.Children.length; c++) {
            out += 'new Array(' + GetPackageLearningObjectOutputString(lo.Children[c]) + ')';
            if (c < lo.Children.length - 1) {
                out += ",";
            }
        }

    } else {
        out += 'new Array()';
    }
    out += ')';

    return out;
}

function GetActivityOutputString(activity) {
    var out = '';
    out += 'new Activity (' +
        checkForNull(activity.DatabaseId, true) + ',' +
        checkForNull(activity.ItemIdentifier, true) + ',' +
        checkForNull(activity.ScormObjectDatabaseId, true) + ',' +
        checkForNull(activity.ActivityProgressStatus) + ',' +
        activity.ActivityAttemptCount + ',' +
        checkForNull(activity.AttemptProgressStatus) + ',' +
        checkForNull(activity.AttemptCompletionAmountStatus) + ',' +
        activity.AttemptCompletionAmount + ',' +
        checkForNull(activity.AttemptCompletionStatus) + ',' +
        checkForNull(activity.Active) + ',' +
        checkForNull(activity.Suspended) + ',' +
        checkForNull(activity.Included) + ',' +
        activity.Ordinal + ',' +
        checkForNull(activity.SelectedChildren) + ',' +
        checkForNull(activity.RandomizedChildren) + ',';

    out += 'new Array(';
    for (var o = 0; o < activity.ActivityObjectives.length; o++) {
        out += GetActivityObjectiveOutputString(activity.ActivityObjectives[o]);
    }
    out += '),';
    out += GetActivityRunTimeOutputString(activity.RunTime) + ',' +
        checkForNull(activity.PrevAttemptProgressStatus) + ',' +
        checkForNull(activity.PrevAttemptCompletionStatus) + ',' +
        checkForNull(activity.AttemptedDuringThisAttempt) + ',' +
        checkForNull(activity.FirstCompletionTimestampUtc, true) + ',' +
        checkForNull(activity.ActivityStartTimestampUtc, true) + ',' +
        checkForNull(activity.AttemptStartTimestampUtc, true) + ',' +
        checkForNull(activity.ActivityAbsoluteDuration) + ',' +
        checkForNull(activity.AttemptAbsoluteDuration) + ',' +
        checkForNull(activity.ActivityExperiencedDurationTracked) + ',' +
        checkForNull(activity.AttemptExperiencedDurationTracked) + ',' +
        checkForNull(activity.ActivityExperiencedDurationReported) + ',' +
        checkForNull(activity.AttemptExperiencedDurationReported) + ',' +
        checkForNull(activity.AiccSessionId, true) + ')';
    return out;
}

function GetActivityObjectiveOutputString(ActivityObjective) {
    var out = '';
    out += 'new ActivityObjective (' +
        checkForNull(ActivityObjective.Identifier, true) + ',' +
        checkForNull(ActivityObjective.ProgressStatus) + ',' +
        checkForNull(ActivityObjective.SatisfiedStatus) + ',' +
        checkForNull(ActivityObjective.MeasureStatus) + ',' +
        ActivityObjective.NormalizedMeasure + ',' +
        checkForNull(ActivityObjective.Primary) + ',' +
        checkForNull(ActivityObjective.PrevProgressStatus) + ',' +
        checkForNull(ActivityObjective.PrevSatisfiedStatus) + ',' +
        checkForNull(ActivityObjective.PrevMeasureStatus) + ',' +
        ActivityObjective.PrevNormalizedMeasure + ',' +
        checkForNull(ActivityObjective.FirstSuccessTimestampUtc) + ',' +
        ActivityObjective.FirstNormalizedMeasure + ',' +
        checkForNull(ActivityObjective.ScoreRaw) + ',' +
        checkForNull(ActivityObjective.ScoreMin) + ',' +
        checkForNull(ActivityObjective.ScoreMax) + ',' +
        checkForNull(ActivityObjective.CompletionStatus) + ',' +
        checkForNull(ActivityObjective.CompletionStatusValue) + ',' +
        checkForNull(ActivityObjective.ProgressMeasureStatus) + ',' +
        checkForNull(ActivityObjective.ProgressMeasure) + ')';
    return out;
}

function GetActivityRunTimeOutputString(ActivityRuntime) {
    var out = '';
    if (ActivityRuntime) {
        out += 'new ActivityRunTime (' +
            checkForNull(ActivityRuntime.CompletionStatus) + ',' +
            checkForNull(ActivityRuntime.Credit) + ',' +
            checkForNull(ActivityRuntime.Entry) + ',' +
            checkForNull(ActivityRuntime.Exit) + ',' +
            checkForNull(ActivityRuntime.Location) + ',' +
            checkForNull(ActivityRuntime.Mode) + ',' +
            checkForNull(ActivityRuntime.ProgressMeasure) + ',' +
            checkForNull(ActivityRuntime.ScoreRaw) + ',' +
            checkForNull(ActivityRuntime.ScoreMax) + ',' +
            checkForNull(ActivityRuntime.ScoreMin) + ',' +
            checkForNull(ActivityRuntime.ScoreScaled) + ',' +
            checkForNull(ActivityRuntime.SuccessStatus) + ',' +
            checkForNull(ActivityRuntime.SuspendData) + ',' +
            checkForNull(ActivityRuntime.TotalTime) + ',' +
            checkForNull(ActivityRuntime.TotalTimeTracked) + ',' +
            checkForNull(ActivityRuntime.AudioLevel) + ',' +
            checkForNull(ActivityRuntime.LanguagePreference) + ',' +
            checkForNull(ActivityRuntime.DeliverySpeed) + ',' +
            checkForNull(ActivityRuntime.AudioCaptioning) + ',' +
            checkForNull(ActivityRuntime.Comments) + ',' +
            checkForNull(ActivityRuntime.CommentsFromLMS) + ',' +
            checkForNull(ActivityRuntime.Interactions) + ',' +
            checkForNull(ActivityRuntime.Objectives) + ')';
    } else {
        out = 'null';
    }
    return out;
}

function checkForNull(value, isString) {
    if (value === null) {
        if (isString) {
            return '""';
        } else {
            return null;
        }
    } else if (value === true) {
        return true;
    } else if (value === false) {
        return false;
    } else if (value === '') {
        return '""';
    } else if (isString && value.indexOf('"') > -1) {
        // if there's a double quote in the string, then use single quotes for the storage
        return "'" + value + "'";
    } else {
        return '"' + value + '"';
    }
}

// jmh - setting these to true because these are set to false by default since this originated as a preview launch
var HistoryLog = new HistoryLogger(
    true,
    true,
    'mobile-launch'
);

var RedirectOnExitUrl = 'results.html';

var RegistrationToDeliver = $$REGISTRATION$$
