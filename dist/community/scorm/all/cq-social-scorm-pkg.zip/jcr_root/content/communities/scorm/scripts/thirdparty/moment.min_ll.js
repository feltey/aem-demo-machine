﻿ //! moment.js
//! version : 2.3.1
//! authors : Tim Wood, Iskren Chernev, Moment.js contributors
//! license : MIT
//! momentjs.com
(function(a) {
    function b(a, b) {
        return function(c) {
            return i(a.call(this, c), b)
        }
    }

    function c(a, b) {
        return function(c) {
            return this.lang().ordinal(a.call(this, c), b)
        }
    }

    function d() {}

    function e(a) {
        u(a), g(this, a)
    }

    function f(a) {
        var b = o(a),
            c = b.year || 0,
            d = b.month || 0,
            e = b.week || 0,
            f = b.day || 0,
            g = b.hour || 0,
            h = b.minute || 0,
            i = b.second || 0,
            j = b.millisecond || 0;
        this._input = a, this._milliseconds = +j + 1e3 * i + 6e4 * h + 36e5 * g, this._days = +f + 7 * e, this._months = +d + 12 * c, this._data = {}, this._bubble()
    }

    function g(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
        return b.hasOwnProperty("toString") && (a.toString = b.toString), b.hasOwnProperty("valueOf") && (a.valueOf = b.valueOf), a
    }

    function h(a) {
        return 0 > a ? Math.ceil(a) : Math.floor(a)
    }

    function i(a, b) {
        for (var c = a + ""; c.length < b;) c = "0" + c;
        return c
    }

    function j(a, b, c, d) {
        var e, f, g = b._milliseconds,
            h = b._days,
            i = b._months;
        g && a._d.setTime(+a._d + g * c), (h || i) && (e = a.minute(), f = a.hour()), h && a.date(a.date() + h * c), i && a.month(a.month() + i * c), g && !d && bb.updateOffset(a), (h || i) && (a.minute(e), a.hour(f))
    }

    function k(a) {
        return "[object Array]" === Object.prototype.toString.call(a)
    }

    function l(a) {
        return "[object Date]" === Object.prototype.toString.call(a)
    }

    function m(a, b, c) {
        var d, e = Math.min(a.length, b.length),
            f = Math.abs(a.length - b.length),
            g = 0;
        for (d = 0; e > d; d++)(c && a[d] !== b[d] || !c && q(a[d]) !== q(b[d])) && g++;
        return g + f
    }

    function n(a) {
        if (a) {
            var b = a.toLowerCase().replace(/(.)s$/, "$1");
            a = Jb[a] || Kb[b] || b
        }
        return a
    }

    function o(a) {
        var b, c, d = {};
        for (c in a) a.hasOwnProperty(c) && (b = n(c), b && (d[b] = a[c]));
        return d
    }

    function p(b) {
        var c, d;
        if (0 === b.indexOf("week")) c = 7, d = "day";
        else {
            if (0 !== b.indexOf("month")) return;
            c = 12, d = "month"
        }
        bb[b] = function(e, f) {
            var g, h, i = bb.fn._lang[b],
                j = [];
            if ("number" == typeof e && (f = e, e = a), h = function(a) {
                    var b = bb().utc().set(d, a);
                    return i.call(bb.fn._lang, b, e || "")
                }, null != f) return h(f);
            for (g = 0; c > g; g++) j.push(h(g));
            return j
        }
    }

    function q(a) {
        var b = +a,
            c = 0;
        return 0 !== b && isFinite(b) && (c = b >= 0 ? Math.floor(b) : Math.ceil(b)), c
    }

    function r(a, b) {
        return new Date(Date.UTC(a, b + 1, 0)).getUTCDate()
    }

    function s(a) {
        return t(a) ? 366 : 365
    }

    function t(a) {
        return 0 === a % 4 && 0 !== a % 100 || 0 === a % 400
    }

    function u(a) {
        var b;
        a._a && -2 === a._pf.overflow && (b = a._a[gb] < 0 || a._a[gb] > 11 ? gb : a._a[hb] < 1 || a._a[hb] > r(a._a[fb], a._a[gb]) ? hb : a._a[ib] < 0 || a._a[ib] > 23 ? ib : a._a[jb] < 0 || a._a[jb] > 59 ? jb : a._a[kb] < 0 || a._a[kb] > 59 ? kb : a._a[lb] < 0 || a._a[lb] > 999 ? lb : -1, a._pf._overflowDayOfYear && (fb > b || b > hb) && (b = hb), a._pf.overflow = b)
    }

    function v(a) {
        a._pf = {
            empty: !1,
            unusedTokens: [],
            unusedInput: [],
            overflow: -2,
            charsLeftOver: 0,
            nullInput: !1,
            invalidMonth: null,
            invalidFormat: !1,
            userInvalidated: !1
        }
    }

    function w(a) {
        return null == a._isValid && (a._isValid = !isNaN(a._d.getTime()) && a._pf.overflow < 0 && !a._pf.empty && !a._pf.invalidMonth && !a._pf.nullInput && !a._pf.invalidFormat && !a._pf.userInvalidated, a._strict && (a._isValid = a._isValid && 0 === a._pf.charsLeftOver && 0 === a._pf.unusedTokens.length)), a._isValid
    }

    function x(a) {
        return a ? a.toLowerCase().replace("_", "-") : a
    }

    function y(a, b) {
        return b.abbr = a, mb[a] || (mb[a] = new d), mb[a].set(b), mb[a]
    }

    function z(a) {
        delete mb[a]
    }

    function A(a) {
        var b, c, d, e, f = 0,
            g = function(a) {
                if (!mb[a] && nb) try {
                    require("./lang/" + a)
                } catch (b) {}
                return mb[a]
            };
        if (!a) return bb.fn._lang;
        if (!k(a)) {
            if (c = g(a)) return c;
            a = [a]
        }
        for (; f < a.length;) {
            for (e = x(a[f]).split("-"), b = e.length, d = x(a[f + 1]), d = d ? d.split("-") : null; b > 0;) {
                if (c = g(e.slice(0, b).join("-"))) return c;
                if (d && d.length >= b && m(e, d, !0) >= b - 1) break;
                b--
            }
            f++
        }
        return bb.fn._lang
    }

    function B(a) {
        return a.match(/\[[\s\S]/) ? a.replace(/^\[|\]$/g, "") : a.replace(/\\/g, "")
    }

    function C(a) {
        var b, c, d = a.match(rb);
        for (b = 0, c = d.length; c > b; b++) d[b] = Ob[d[b]] ? Ob[d[b]] : B(d[b]);
        return function(e) {
            var f = "";
            for (b = 0; c > b; b++) f += d[b] instanceof Function ? d[b].call(e, a) : d[b];
            return f
        }
    }

    function D(a, b) {
        return a.isValid() ? (b = E(b, a.lang()), Lb[b] || (Lb[b] = C(b)), Lb[b](a)) : a.lang().invalidDate()
    }

    function E(a, b) {
        function c(a) {
            return b.longDateFormat(a) || a
        }
        var d = 5;
        for (sb.lastIndex = 0; d >= 0 && sb.test(a);) a = a.replace(sb, c), sb.lastIndex = 0, d -= 1;
        return a
    }

    function F(a, b) {
        var c;
        switch (a) {
            case "DDDD":
                return vb;
            case "YYYY":
            case "GGGG":
            case "gggg":
                return wb;
            case "YYYYY":
            case "GGGGG":
            case "ggggg":
                return xb;
            case "S":
            case "SS":
            case "SSS":
            case "DDD":
                return ub;
            case "MMM":
            case "MMMM":
            case "dd":
            case "ddd":
            case "dddd":
                return yb;
            case "a":
            case "A":
                return A(b._l)._meridiemParse;
            case "X":
                return Bb;
            case "Z":
            case "ZZ":
                return zb;
            case "T":
                return Ab;
            case "MM":
            case "DD":
            case "YY":
            case "GG":
            case "gg":
            case "HH":
            case "hh":
            case "mm":
            case "ss":
            case "M":
            case "D":
            case "d":
            case "H":
            case "h":
            case "m":
            case "s":
            case "w":
            case "ww":
            case "W":
            case "WW":
            case "e":
            case "E":
                return tb;
            default:
                return c = new RegExp(N(M(a.replace("\\", "")), "i"))
        }
    }

    function G(a) {
        var b = (zb.exec(a) || [])[0],
            c = (b + "").match(Gb) || ["-", 0, 0],
            d = +(60 * c[1]) + q(c[2]);
        return "+" === c[0] ? -d : d
    }

    function H(a, b, c) {
        var d, e = c._a;
        switch (a) {
            case "M":
            case "MM":
                null != b && (e[gb] = q(b) - 1);
                break;
            case "MMM":
            case "MMMM":
                d = A(c._l).monthsParse(b), null != d ? e[gb] = d : c._pf.invalidMonth = b;
                break;
            case "D":
            case "DD":
                null != b && (e[hb] = q(b));
                break;
            case "DDD":
            case "DDDD":
                null != b && (c._dayOfYear = q(b));
                break;
            case "YY":
                e[fb] = q(b) + (q(b) > 68 ? 1900 : 2e3);
                break;
            case "YYYY":
            case "YYYYY":
                e[fb] = q(b);
                break;
            case "a":
            case "A":
                c._isPm = A(c._l).isPM(b);
                break;
            case "H":
            case "HH":
            case "h":
            case "hh":
                e[ib] = q(b);
                break;
            case "m":
            case "mm":
                e[jb] = q(b);
                break;
            case "s":
            case "ss":
                e[kb] = q(b);
                break;
            case "S":
            case "SS":
            case "SSS":
                e[lb] = q(1e3 * ("0." + b));
                break;
            case "X":
                c._d = new Date(1e3 * parseFloat(b));
                break;
            case "Z":
            case "ZZ":
                c._useUTC = !0, c._tzm = G(b);
                break;
            case "w":
            case "ww":
            case "W":
            case "WW":
            case "d":
            case "dd":
            case "ddd":
            case "dddd":
            case "e":
            case "E":
                a = a.substr(0, 1);
            case "gg":
            case "gggg":
            case "GG":
            case "GGGG":
            case "GGGGG":
                a = a.substr(0, 2), b && (c._w = c._w || {}, c._w[a] = b)
        }
    }

    function I(a) {
        var b, c, d, e, f, g, h, i, j, k, l = [];
        if (!a._d) {
            for (d = K(a), a._w && null == a._a[hb] && null == a._a[gb] && (f = function(b) {
                    return b ? b.length < 3 ? parseInt(b, 10) > 68 ? "19" + b : "20" + b : b : null == a._a[fb] ? bb().weekYear() : a._a[fb]
                }, g = a._w, null != g.GG || null != g.W || null != g.E ? h = X(f(g.GG), g.W || 1, g.E, 4, 1) : (i = A(a._l), j = null != g.d ? T(g.d, i) : null != g.e ? parseInt(g.e, 10) + i._week.dow : 0, k = parseInt(g.w, 10) || 1, null != g.d && j < i._week.dow && k++, h = X(f(g.gg), k, j, i._week.doy, i._week.dow)), a._a[fb] = h.year, a._dayOfYear = h.dayOfYear), a._dayOfYear && (e = null == a._a[fb] ? d[fb] : a._a[fb], a._dayOfYear > s(e) && (a._pf._overflowDayOfYear = !0), c = S(e, 0, a._dayOfYear), a._a[gb] = c.getUTCMonth(), a._a[hb] = c.getUTCDate()), b = 0; 3 > b && null == a._a[b]; ++b) a._a[b] = l[b] = d[b];
            for (; 7 > b; b++) a._a[b] = l[b] = null == a._a[b] ? 2 === b ? 1 : 0 : a._a[b];
            l[ib] += q((a._tzm || 0) / 60), l[jb] += q((a._tzm || 0) % 60), a._d = (a._useUTC ? S : R).apply(null, l)
        }
    }

    function J(a) {
        var b;
        a._d || (b = o(a._i), a._a = [b.year, b.month, b.day, b.hour, b.minute, b.second, b.millisecond], I(a))
    }

    function K(a) {
        var b = new Date;
        return a._useUTC ? [b.getUTCFullYear(), b.getUTCMonth(), b.getUTCDate()] : [b.getFullYear(), b.getMonth(), b.getDate()]
    }

    function L(a) {
        a._a = [], a._pf.empty = !0;
        var b, c, d, e, f, g = A(a._l),
            h = "" + a._i,
            i = h.length,
            j = 0;
        for (d = E(a._f, g).match(rb) || [], b = 0; b < d.length; b++) e = d[b], c = (F(e, a).exec(h) || [])[0], c && (f = h.substr(0, h.indexOf(c)), f.length > 0 && a._pf.unusedInput.push(f), h = h.slice(h.indexOf(c) + c.length), j += c.length), Ob[e] ? (c ? a._pf.empty = !1 : a._pf.unusedTokens.push(e), H(e, c, a)) : a._strict && !c && a._pf.unusedTokens.push(e);
        a._pf.charsLeftOver = i - j, h.length > 0 && a._pf.unusedInput.push(h), a._isPm && a._a[ib] < 12 && (a._a[ib] += 12), a._isPm === !1 && 12 === a._a[ib] && (a._a[ib] = 0), I(a), u(a)
    }

    function M(a) {
        return a.replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(a, b, c, d, e) {
            return b || c || d || e
        })
    }

    function N(a) {
        return a.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")
    }

    function O(a) {
        var b, c, d, e, f;
        if (0 === a._f.length) return a._pf.invalidFormat = !0, a._d = new Date(0 / 0), void 0;
        for (e = 0; e < a._f.length; e++) f = 0, b = g({}, a), v(b), b._f = a._f[e], L(b), w(b) && (f += b._pf.charsLeftOver, f += 10 * b._pf.unusedTokens.length, b._pf.score = f, (null == d || d > f) && (d = f, c = b));
        g(a, c || b)
    }

    function P(a) {
        var b, c = a._i,
            d = Cb.exec(c);
        if (d) {
            for (b = 4; b > 0; b--)
                if (d[b]) {
                    a._f = Eb[b - 1] + (d[6] || " ");
                    break
                }
            for (b = 0; 4 > b; b++)
                if (Fb[b][1].exec(c)) {
                    a._f += Fb[b][0];
                    break
                }
            zb.exec(c) && (a._f += " Z"), L(a)
        } else a._d = new Date(c)
    }

    function Q(b) {
        var c = b._i,
            d = ob.exec(c);
        c === a ? b._d = new Date : d ? b._d = new Date(+d[1]) : "string" == typeof c ? P(b) : k(c) ? (b._a = c.slice(0), I(b)) : l(c) ? b._d = new Date(+c) : "object" == typeof c ? J(b) : b._d = new Date(c)
    }

    function R(a, b, c, d, e, f, g) {
        var h = new Date(a, b, c, d, e, f, g);
        return 1970 > a && h.setFullYear(a), h
    }

    function S(a) {
        var b = new Date(Date.UTC.apply(null, arguments));
        return 1970 > a && b.setUTCFullYear(a), b
    }

    function T(a, b) {
        if ("string" == typeof a)
            if (isNaN(a)) {
                if (a = b.weekdaysParse(a), "number" != typeof a) return null
            } else a = parseInt(a, 10);
        return a
    }

    function U(a, b, c, d, e) {
        return e.relativeTime(b || 1, !!c, a, d)
    }

    function V(a, b, c) {
        var d = eb(Math.abs(a) / 1e3),
            e = eb(d / 60),
            f = eb(e / 60),
            g = eb(f / 24),
            h = eb(g / 365),
            i = 45 > d && ["s", d] || 1 === e && ["m"] || 45 > e && ["mm", e] || 1 === f && ["h"] || 22 > f && ["hh", f] || 1 === g && ["d"] || 25 >= g && ["dd", g] || 45 >= g && ["M"] || 345 > g && ["MM", eb(g / 30)] || 1 === h && ["y"] || ["yy", h];
        return i[2] = b, i[3] = a > 0, i[4] = c, U.apply({}, i)
    }

    function W(a, b, c) {
        var d, e = c - b,
            f = c - a.day();
        return f > e && (f -= 7), e - 7 > f && (f += 7), d = bb(a).add("d", f), {
            week: Math.ceil(d.dayOfYear() / 7),
            year: d.year()
        }
    }

    function X(a, b, c, d, e) {
        var f, g, h = new Date(Date.UTC(a, 0)).getUTCDay();
        return c = null != c ? c : e, f = e - h + (h > d ? 7 : 0), g = 7 * (b - 1) + (c - e) + f + 1, {
            year: g > 0 ? a : a - 1,
            dayOfYear: g > 0 ? g : s(a - 1) + g
        }
    }

    function Y(a) {
        var b = a._i,
            c = a._f;
        return "undefined" == typeof a._pf && v(a), null === b ? bb.invalid({
            nullInput: !0
        }) : ("string" == typeof b && (a._i = b = A().preparse(b)), bb.isMoment(b) ? (a = g({}, b), a._d = new Date(+b._d)) : c ? k(c) ? O(a) : L(a) : Q(a), new e(a))
    }

    function Z(a, b) {
        bb.fn[a] = bb.fn[a + "s"] = function(a) {
            var c = this._isUTC ? "UTC" : "";
            return null != a ? (this._d["set" + c + b](a), bb.updateOffset(this), this) : this._d["get" + c + b]()
        }
    }

    function $(a) {
        bb.duration.fn[a] = function() {
            return this._data[a]
        }
    }

    function _(a, b) {
        bb.duration.fn["as" + a] = function() {
            return +this / b
        }
    }

    function ab() {
        "undefined" == typeof ender && (this.moment = bb)
    }
    for (var bb, cb, db = "2.3.1", eb = Math.round, fb = 0, gb = 1, hb = 2, ib = 3, jb = 4, kb = 5, lb = 6, mb = {}, nb = "undefined" != typeof module && module.exports, ob = /^\/?Date\((\-?\d+)/i, pb = /(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/, qb = /^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/, rb = /(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|SS?S?|X|zz?|ZZ?|.)/g, sb = /(\[[^\[]*\])|(\\)?(LT|LL?L?L?|l{1,4})/g, tb = /\d\d?/, ub = /\d{1,3}/, vb = /\d{3}/, wb = /\d{1,4}/, xb = /[+\-]?\d{1,6}/, yb = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i, zb = /Z|[\+\-]\d\d:?\d\d/i, Ab = /T/i, Bb = /[\+\-]?\d+(\.\d{1,3})?/, Cb = /^\s*\d{4}-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d\d?\d?)?)?)?)?([\+\-]\d\d:?\d\d)?)?$/, Db = "YYYY-MM-DDTHH:mm:ssZ", Eb = ["YYYY-MM-DD", "GGGG-[W]WW", "GGGG-[W]WW-E", "YYYY-DDD"], Fb = [
            ["HH:mm:ss.S", /(T| )\d\d:\d\d:\d\d\.\d{1,3}/],
            ["HH:mm:ss", /(T| )\d\d:\d\d:\d\d/],
            ["HH:mm", /(T| )\d\d:\d\d/],
            ["HH", /(T| )\d\d/]
        ], Gb = /([\+\-]|\d\d)/gi, Hb = "Date|Hours|Minutes|Seconds|Milliseconds".split("|"), Ib = {
            Milliseconds: 1,
            Seconds: 1e3,
            Minutes: 6e4,
            Hours: 36e5,
            Days: 864e5,
            Months: 2592e6,
            Years: 31536e6
        }, Jb = {
            ms: "millisecond",
            s: "second",
            m: "minute",
            h: "hour",
            d: "day",
            D: "date",
            w: "week",
            W: "isoWeek",
            M: "month",
            y: "year",
            DDD: "dayOfYear",
            e: "weekday",
            E: "isoWeekday",
            gg: "weekYear",
            GG: "isoWeekYear"
        }, Kb = {
            dayofyear: "dayOfYear",
            isoweekday: "isoWeekday",
            isoweek: "isoWeek",
            weekyear: "weekYear",
            isoweekyear: "isoWeekYear"
        }, Lb = {}, Mb = "DDD w W M D d".split(" "), Nb = "M D H h m s w W".split(" "), Ob = {
            M: function() {
                return this.month() + 1
            },
            MMM: function(a) {
                return this.lang().monthsShort(this, a)
            },
            MMMM: function(a) {
                return this.lang().months(this, a)
            },
            D: function() {
                return this.date()
            },
            DDD: function() {
                return this.dayOfYear()
            },
            d: function() {
                return this.day()
            },
            dd: function(a) {
                return this.lang().weekdaysMin(this, a)
            },
            ddd: function(a) {
                return this.lang().weekdaysShort(this, a)
            },
            dddd: function(a) {
                return this.lang().weekdays(this, a)
            },
            w: function() {
                return this.week()
            },
            W: function() {
                return this.isoWeek()
            },
            YY: function() {
                return i(this.year() % 100, 2)
            },
            YYYY: function() {
                return i(this.year(), 4)
            },
            YYYYY: function() {
                return i(this.year(), 5)
            },
            gg: function() {
                return i(this.weekYear() % 100, 2)
            },
            gggg: function() {
                return this.weekYear()
            },
            ggggg: function() {
                return i(this.weekYear(), 5)
            },
            GG: function() {
                return i(this.isoWeekYear() % 100, 2)
            },
            GGGG: function() {
                return this.isoWeekYear()
            },
            GGGGG: function() {
                return i(this.isoWeekYear(), 5)
            },
            e: function() {
                return this.weekday()
            },
            E: function() {
                return this.isoWeekday()
            },
            a: function() {
                return this.lang().meridiem(this.hours(), this.minutes(), !0)
            },
            A: function() {
                return this.lang().meridiem(this.hours(), this.minutes(), !1)
            },
            H: function() {
                return this.hours()
            },
            h: function() {
                return this.hours() % 12 || 12
            },
            m: function() {
                return this.minutes()
            },
            s: function() {
                return this.seconds()
            },
            S: function() {
                return q(this.milliseconds() / 100)
            },
            SS: function() {
                return i(q(this.milliseconds() / 10), 2)
            },
            SSS: function() {
                return i(this.milliseconds(), 3)
            },
            Z: function() {
                var a = -this.zone(),
                    b = "+";
                return 0 > a && (a = -a, b = "-"), b + i(q(a / 60), 2) + ":" + i(q(a) % 60, 2)
            },
            ZZ: function() {
                var a = -this.zone(),
                    b = "+";
                return 0 > a && (a = -a, b = "-"), b + i(q(10 * a / 6), 4)
            },
            z: function() {
                return this.zoneAbbr()
            },
            zz: function() {
                return this.zoneName()
            },
            X: function() {
                return this.unix()
            }
        }, Pb = ["months", "monthsShort", "weekdays", "weekdaysShort", "weekdaysMin"]; Mb.length;) cb = Mb.pop(), Ob[cb + "o"] = c(Ob[cb], cb);
    for (; Nb.length;) cb = Nb.pop(), Ob[cb + cb] = b(Ob[cb], 2);
    for (Ob.DDDD = b(Ob.DDD, 3), g(d.prototype, {
            set: function(a) {
                var b, c;
                for (c in a) b = a[c], "function" == typeof b ? this[c] = b : this["_" + c] = b
            },
            _months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
            months: function(a) {
                return this._months[a.month()]
            },
            _monthsShort: "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
            monthsShort: function(a) {
                return this._monthsShort[a.month()]
            },
            monthsParse: function(a) {
                var b, c, d;
                for (this._monthsParse || (this._monthsParse = []), b = 0; 12 > b; b++)
                    if (this._monthsParse[b] || (c = bb.utc([2e3, b]), d = "^" + this.months(c, "") + "|^" + this.monthsShort(c, ""), this._monthsParse[b] = new RegExp(d.replace(".", ""), "i")), this._monthsParse[b].test(a)) return b
            },
            _weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
            weekdays: function(a) {
                return this._weekdays[a.day()]
            },
            _weekdaysShort: "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
            weekdaysShort: function(a) {
                return this._weekdaysShort[a.day()]
            },
            _weekdaysMin: "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
            weekdaysMin: function(a) {
                return this._weekdaysMin[a.day()]
            },
            weekdaysParse: function(a) {
                var b, c, d;
                for (this._weekdaysParse || (this._weekdaysParse = []), b = 0; 7 > b; b++)
                    if (this._weekdaysParse[b] || (c = bb([2e3, 1]).day(b), d = "^" + this.weekdays(c, "") + "|^" + this.weekdaysShort(c, "") + "|^" + this.weekdaysMin(c, ""), this._weekdaysParse[b] = new RegExp(d.replace(".", ""), "i")), this._weekdaysParse[b].test(a)) return b
            },
            _longDateFormat: {
                LT: "h:mm A",
                L: "MM/DD/YYYY",
                LL: "MMMM D YYYY",
                LLL: "MMMM D YYYY LT",
                LLLL: "dddd, MMMM D YYYY LT"
            },
            longDateFormat: function(a) {
                var b = this._longDateFormat[a];
                return !b && this._longDateFormat[a.toUpperCase()] && (b = this._longDateFormat[a.toUpperCase()].replace(/MMMM|MM|DD|dddd/g, function(a) {
                    return a.slice(1)
                }), this._longDateFormat[a] = b), b
            },
            isPM: function(a) {
                return "p" === (a + "").toLowerCase().charAt(0)
            },
            _meridiemParse: /[ap]\.?m?\.?/i,
            meridiem: function(a, b, c) {
                return a > 11 ? c ? "pm" : "PM" : c ? "am" : "AM"
            },
            _calendar: {
                sameDay: "[Today at] LT",
                nextDay: "[Tomorrow at] LT",
                nextWeek: "dddd [at] LT",
                lastDay: "[Yesterday at] LT",
                lastWeek: "[Last] dddd [at] LT",
                sameElse: "L"
            },
            calendar: function(a, b) {
                var c = this._calendar[a];
                return "function" == typeof c ? c.apply(b) : c
            },
            _relativeTime: {
                future: "in %s",
                past: "%s ago",
                s: "a few seconds",
                m: "a minute",
                mm: "%d minutes",
                h: "an hour",
                hh: "%d hours",
                d: "a day",
                dd: "%d days",
                M: "a month",
                MM: "%d months",
                y: "a year",
                yy: "%d years"
            },
            relativeTime: function(a, b, c, d) {
                var e = this._relativeTime[c];
                return "function" == typeof e ? e(a, b, c, d) : e.replace(/%d/i, a)
            },
            pastFuture: function(a, b) {
                var c = this._relativeTime[a > 0 ? "future" : "past"];
                return "function" == typeof c ? c(b) : c.replace(/%s/i, b)
            },
            ordinal: function(a) {
                return this._ordinal.replace("%d", a)
            },
            _ordinal: "%d",
            preparse: function(a) {
                return a
            },
            postformat: function(a) {
                return a
            },
            week: function(a) {
                return W(a, this._week.dow, this._week.doy).week
            },
            _week: {
                dow: 0,
                doy: 6
            },
            _invalidDate: "Invalid date",
            invalidDate: function() {
                return this._invalidDate
            }
        }), bb = function(b, c, d, e) {
            return "boolean" == typeof d && (e = d, d = a), Y({
                _i: b,
                _f: c,
                _l: d,
                _strict: e,
                _isUTC: !1
            })
        }, bb.utc = function(b, c, d, e) {
            var f;
            return "boolean" == typeof d && (e = d, d = a), f = Y({
                _useUTC: !0,
                _isUTC: !0,
                _l: d,
                _i: b,
                _f: c,
                _strict: e
            }).utc()
        }, bb.unix = function(a) {
            return bb(1e3 * a)
        }, bb.duration = function(a, b) {
            var c, d, e, g = bb.isDuration(a),
                h = "number" == typeof a,
                i = g ? a._input : h ? {} : a,
                j = null;
            return h ? b ? i[b] = a : i.milliseconds = a : (j = pb.exec(a)) ? (c = "-" === j[1] ? -1 : 1, i = {
                y: 0,
                d: q(j[hb]) * c,
                h: q(j[ib]) * c,
                m: q(j[jb]) * c,
                s: q(j[kb]) * c,
                ms: q(j[lb]) * c
            }) : (j = qb.exec(a)) && (c = "-" === j[1] ? -1 : 1, e = function(a) {
                var b = a && parseFloat(a.replace(",", "."));
                return (isNaN(b) ? 0 : b) * c
            }, i = {
                y: e(j[2]),
                M: e(j[3]),
                d: e(j[4]),
                h: e(j[5]),
                m: e(j[6]),
                s: e(j[7]),
                w: e(j[8])
            }), d = new f(i), g && a.hasOwnProperty("_lang") && (d._lang = a._lang), d
        }, bb.version = db, bb.defaultFormat = Db, bb.updateOffset = function() {}, bb.lang = function(a, b) {
            var c;
            return a ? (b ? y(x(a), b) : null === b ? (z(a), a = "en") : mb[a] || A(a), c = bb.duration.fn._lang = bb.fn._lang = A(a), c._abbr) : bb.fn._lang._abbr
        }, bb.langData = function(a) {
            return a && a._lang && a._lang._abbr && (a = a._lang._abbr), A(a)
        }, bb.isMoment = function(a) {
            return a instanceof e
        }, bb.isDuration = function(a) {
            return a instanceof f
        }, cb = Pb.length - 1; cb >= 0; --cb) p(Pb[cb]);
    for (bb.normalizeUnits = function(a) {
            return n(a)
        }, bb.invalid = function(a) {
            var b = bb.utc(0 / 0);
            return null != a ? g(b._pf, a) : b._pf.userInvalidated = !0, b
        }, bb.parseZone = function(a) {
            return bb(a).parseZone()
        }, g(bb.fn = e.prototype, {
            clone: function() {
                return bb(this)
            },
            valueOf: function() {
                return +this._d + 6e4 * (this._offset || 0)
            },
            unix: function() {
                return Math.floor(+this / 1e3)
            },
            toString: function() {
                return this.clone().lang("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
            },
            toDate: function() {
                return this._offset ? new Date(+this) : this._d
            },
            toISOString: function() {
                return D(bb(this).utc(), "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]")
            },
            toArray: function() {
                var a = this;
                return [a.year(), a.month(), a.date(), a.hours(), a.minutes(), a.seconds(), a.milliseconds()]
            },
            isValid: function() {
                return w(this)
            },
            isDSTShifted: function() {
                return this._a ? this.isValid() && m(this._a, (this._isUTC ? bb.utc(this._a) : bb(this._a)).toArray()) > 0 : !1
            },
            parsingFlags: function() {
                return g({}, this._pf)
            },
            invalidAt: function() {
                return this._pf.overflow
            },
            utc: function() {
                return this.zone(0)
            },
            local: function() {
                return this.zone(0), this._isUTC = !1, this
            },
            format: function(a) {
                var b = D(this, a || bb.defaultFormat);
                return this.lang().postformat(b)
            },
            add: function(a, b) {
                var c;
                return c = "string" == typeof a ? bb.duration(+b, a) : bb.duration(a, b), j(this, c, 1), this
            },
            subtract: function(a, b) {
                var c;
                return c = "string" == typeof a ? bb.duration(+b, a) : bb.duration(a, b), j(this, c, -1), this
            },
            diff: function(a, b, c) {
                var d, e, f = this._isUTC ? bb(a).zone(this._offset || 0) : bb(a).local(),
                    g = 6e4 * (this.zone() - f.zone());
                return b = n(b), "year" === b || "month" === b ? (d = 432e5 * (this.daysInMonth() + f.daysInMonth()), e = 12 * (this.year() - f.year()) + (this.month() - f.month()), e += (this - bb(this).startOf("month") - (f - bb(f).startOf("month"))) / d, e -= 6e4 * (this.zone() - bb(this).startOf("month").zone() - (f.zone() - bb(f).startOf("month").zone())) / d, "year" === b && (e /= 12)) : (d = this - f, e = "second" === b ? d / 1e3 : "minute" === b ? d / 6e4 : "hour" === b ? d / 36e5 : "day" === b ? (d - g) / 864e5 : "week" === b ? (d - g) / 6048e5 : d), c ? e : h(e)
            },
            from: function(a, b) {
                return bb.duration(this.diff(a)).lang(this.lang()._abbr).humanize(!b)
            },
            fromNow: function(a) {
                return this.from(bb(), a)
            },
            calendar: function() {
                var a = this.diff(bb().zone(this.zone()).startOf("day"), "days", !0),
                    b = -6 > a ? "sameElse" : -1 > a ? "lastWeek" : 0 > a ? "lastDay" : 1 > a ? "sameDay" : 2 > a ? "nextDay" : 7 > a ? "nextWeek" : "sameElse";
                return this.format(this.lang().calendar(b, this))
            },
            isLeapYear: function() {
                return t(this.year())
            },
            isDST: function() {
                return this.zone() < this.clone().month(0).zone() || this.zone() < this.clone().month(5).zone()
            },
            day: function(a) {
                var b = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
                return null != a ? (a = T(a, this.lang()), this.add({
                    d: a - b
                })) : b
            },
            month: function(a) {
                var b, c = this._isUTC ? "UTC" : "";
                return null != a ? "string" == typeof a && (a = this.lang().monthsParse(a), "number" != typeof a) ? this : (b = this.date(), this.date(1), this._d["set" + c + "Month"](a), this.date(Math.min(b, this.daysInMonth())), bb.updateOffset(this), this) : this._d["get" + c + "Month"]()
            },
            startOf: function(a) {
                switch (a = n(a)) {
                    case "year":
                        this.month(0);
                    case "month":
                        this.date(1);
                    case "week":
                    case "isoWeek":
                    case "day":
                        this.hours(0);
                    case "hour":
                        this.minutes(0);
                    case "minute":
                        this.seconds(0);
                    case "second":
                        this.milliseconds(0)
                }
                return "week" === a ? this.weekday(0) : "isoWeek" === a && this.isoWeekday(1), this
            },
            endOf: function(a) {
                return a = n(a), this.startOf(a).add("isoWeek" === a ? "week" : a, 1).subtract("ms", 1)
            },
            isAfter: function(a, b) {
                return b = "undefined" != typeof b ? b : "millisecond", +this.clone().startOf(b) > +bb(a).startOf(b)
            },
            isBefore: function(a, b) {
                return b = "undefined" != typeof b ? b : "millisecond", +this.clone().startOf(b) < +bb(a).startOf(b)
            },
            isSame: function(a, b) {
                return b = "undefined" != typeof b ? b : "millisecond", +this.clone().startOf(b) === +bb(a).startOf(b)
            },
            min: function(a) {
                return a = bb.apply(null, arguments), this > a ? this : a
            },
            max: function(a) {
                return a = bb.apply(null, arguments), a > this ? this : a
            },
            zone: function(a) {
                var b = this._offset || 0;
                return null == a ? this._isUTC ? b : this._d.getTimezoneOffset() : ("string" == typeof a && (a = G(a)), Math.abs(a) < 16 && (a = 60 * a), this._offset = a, this._isUTC = !0, b !== a && j(this, bb.duration(b - a, "m"), 1, !0), this)
            },
            zoneAbbr: function() {
                return this._isUTC ? "UTC" : ""
            },
            zoneName: function() {
                return this._isUTC ? "Coordinated Universal Time" : ""
            },
            parseZone: function() {
                return "string" == typeof this._i && this.zone(this._i), this
            },
            hasAlignedHourOffset: function(a) {
                return a = a ? bb(a).zone() : 0, 0 === (this.zone() - a) % 60
            },
            daysInMonth: function() {
                return r(this.year(), this.month())
            },
            dayOfYear: function(a) {
                var b = eb((bb(this).startOf("day") - bb(this).startOf("year")) / 864e5) + 1;
                return null == a ? b : this.add("d", a - b)
            },
            weekYear: function(a) {
                var b = W(this, this.lang()._week.dow, this.lang()._week.doy).year;
                return null == a ? b : this.add("y", a - b)
            },
            isoWeekYear: function(a) {
                var b = W(this, 1, 4).year;
                return null == a ? b : this.add("y", a - b)
            },
            week: function(a) {
                var b = this.lang().week(this);
                return null == a ? b : this.add("d", 7 * (a - b))
            },
            isoWeek: function(a) {
                var b = W(this, 1, 4).week;
                return null == a ? b : this.add("d", 7 * (a - b))
            },
            weekday: function(a) {
                var b = (this.day() + 7 - this.lang()._week.dow) % 7;
                return null == a ? b : this.add("d", a - b)
            },
            isoWeekday: function(a) {
                return null == a ? this.day() || 7 : this.day(this.day() % 7 ? a : a - 7)
            },
            get: function(a) {
                return a = n(a), this[a]()
            },
            set: function(a, b) {
                return a = n(a), "function" == typeof this[a] && this[a](b), this
            },
            lang: function(b) {
                return b === a ? this._lang : (this._lang = A(b), this)
            }
        }), cb = 0; cb < Hb.length; cb++) Z(Hb[cb].toLowerCase().replace(/s$/, ""), Hb[cb]);
    Z("year", "FullYear"), bb.fn.days = bb.fn.day, bb.fn.months = bb.fn.month, bb.fn.weeks = bb.fn.week, bb.fn.isoWeeks = bb.fn.isoWeek, bb.fn.toJSON = bb.fn.toISOString, g(bb.duration.fn = f.prototype, {
        _bubble: function() {
            var a, b, c, d, e = this._milliseconds,
                f = this._days,
                g = this._months,
                i = this._data;
            i.milliseconds = e % 1e3, a = h(e / 1e3), i.seconds = a % 60, b = h(a / 60), i.minutes = b % 60, c = h(b / 60), i.hours = c % 24, f += h(c / 24), i.days = f % 30, g += h(f / 30), i.months = g % 12, d = h(g / 12), i.years = d
        },
        weeks: function() {
            return h(this.days() / 7)
        },
        valueOf: function() {
            return this._milliseconds + 864e5 * this._days + 2592e6 * (this._months % 12) + 31536e6 * q(this._months / 12)
        },
        humanize: function(a) {
            var b = +this,
                c = V(b, !a, this.lang());
            return a && (c = this.lang().pastFuture(b, c)), this.lang().postformat(c)
        },
        add: function(a, b) {
            var c = bb.duration(a, b);
            return this._milliseconds += c._milliseconds, this._days += c._days, this._months += c._months, this._bubble(), this
        },
        subtract: function(a, b) {
            var c = bb.duration(a, b);
            return this._milliseconds -= c._milliseconds, this._days -= c._days, this._months -= c._months, this._bubble(), this
        },
        get: function(a) {
            return a = n(a), this[a.toLowerCase() + "s"]()
        },
        as: function(a) {
            return a = n(a), this["as" + a.charAt(0).toUpperCase() + a.slice(1) + "s"]()
        },
        lang: bb.fn.lang,
        toIsoString: function() {
            var a = Math.abs(this.years()),
                b = Math.abs(this.months()),
                c = Math.abs(this.days()),
                d = Math.abs(this.hours()),
                e = Math.abs(this.minutes()),
                f = Math.abs(this.seconds() + this.milliseconds() / 1e3);
            return this.asSeconds() ? (this.asSeconds() < 0 ? "-" : "") + "P" + (a ? a + "Y" : "") + (b ? b + "M" : "") + (c ? c + "D" : "") + (d || e || f ? "T" : "") + (d ? d + "H" : "") + (e ? e + "M" : "") + (f ? f + "S" : "") : "P0D"
        }
    });
    for (cb in Ib) Ib.hasOwnProperty(cb) && (_(cb, Ib[cb]), $(cb.toLowerCase()));
    _("Weeks", 6048e5), bb.duration.fn.asMonths = function() {
        return (+this - 31536e6 * this.years()) / 2592e6 + 12 * this.years()
    }, bb.lang("en", {
        ordinal: function(a) {
            var b = a % 10,
                c = 1 === q(a % 100 / 10) ? "th" : 1 === b ? "st" : 2 === b ? "nd" : 3 === b ? "rd" : "th";
            return a + c
        }
    }), nb ? (module.exports = bb, ab()) : "function" == typeof define && define.amd ? define("moment", function(a, b, c) {
        return c.config().noGlobal !== !0 && ab(), bb
    }) : ab()
}).call(this);
